@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo xlounger SETUP — eingebettetes Python (KVA 313) + Abhaengigkeiten
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\install-embed-python.ps1"
if errorlevel 1 (
  echo FEHLER: Python-Laufzeit — siehe Meldung oben.
  exit /b 1
)

set "PY=%~dp0python\python.exe"
if not exist "%PY%" (
  echo FEHLER: python\python.exe fehlt nach Setup.
  exit /b 1
)

"%PY%" -m pip install --no-warn-script-location -r "%~dp0requirements.txt"
if errorlevel 1 (
  echo FEHLER: pip install
  exit /b 1
)

echo.
echo SETUP OK — Start: XX1LOUNGER-START-PAKET.bat
echo Smoke: ..\dist\SMOKE-AUSLIEFERUNG.bat "%~dp0."
exit /b 0
