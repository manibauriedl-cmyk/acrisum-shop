@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "PYW=%~dp0python\pythonw.exe"
if not exist "%PYW%" (
  echo FEHLER: Bitte zuerst SETUP.bat ausfuehren.
  exit /b 1
)
start "" "%PYW%" "%~dp0xx1lounger_prozess.py" start-if-down
exit /b 0
