"""Port-Check fuer localhost-Dienste + Dienst-Start per BAT (KVA 168, 169).

Eintraege mit URL auf localhost/127.0.0.1: vor dem Oeffnen pruefen, ob der
Dienst lebt. Wenn tot und fuer den Eintrag eine Start-BAT hinterlegt ist
(Benutzer-Anpassung `dienst_bat`), BAT starten und auf den Port warten.
"""
from __future__ import annotations

import logging
import socket
import subprocess
import time
from urllib.parse import urlsplit

from .browser_url import is_localhost_hostname, is_web_url

_LOOPBACK_IPS = frozenset({"127.0.0.1", "::1"})


def localhost_port(url: str) -> int | None:
    """Port einer localhost-URL — None wenn keine localhost-URL."""
    if not is_web_url(url):
        return None
    try:
        parts = urlsplit(url.strip())
    except ValueError:
        return None
    host = parts.hostname or ""
    if not (is_localhost_hostname(host) or host.strip() in _LOOPBACK_IPS):
        return None
    if parts.port is not None:
        return int(parts.port)
    return 443 if parts.scheme.casefold() == "https" else 80


def port_offen(port: int, host: str = "127.0.0.1", timeout: float = 0.8) -> bool:
    """KVA 168 — TCP-Verbindung testen (IPv4, kurzer Timeout)."""
    try:
        with socket.create_connection((host, int(port)), timeout=timeout):
            return True
    except OSError:
        return False


def dienst_starten_und_warten(bat_pfad: str, port: int, warte_sek: float = 20.0) -> bool:
    """KVA 169 — BAT starten, dann warten bis der Port lebt. True = Port offen."""
    import os

    bat_pfad = str(bat_pfad or "").strip()
    if not bat_pfad or not os.path.isfile(bat_pfad):
        return False
    logging.info("Port %s tot — starte Dienst: %s", port, bat_pfad)
    try:
        subprocess.Popen(
            ["cmd", "/c", bat_pfad],
            creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0,
        )
    except OSError as exc:
        logging.warning("Dienst-Start fehlgeschlagen: %s", exc)
        return False

    ende = time.monotonic() + max(1.0, warte_sek)
    while time.monotonic() < ende:
        if port_offen(port):
            logging.info("Dienst lebt nach Start: Port %s", port)
            return True
        time.sleep(0.5)
    logging.warning("Dienst nach %.0fs nicht erreichbar: Port %s", warte_sek, port)
    return False
