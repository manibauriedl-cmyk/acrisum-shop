"""Erklaertexte und Icon-Pfade fuer Eintraege (KVA 297, 78, 180)."""
from __future__ import annotations

import os
from pathlib import Path
from urllib.parse import urlparse

_ANZEIGE_ZEICHEN = frozenset(
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "0123456789 ._-–—()&@#+/:,'ÄÖÜäöüß°%"
)


def _fallback_name_aus_target(target: str) -> str:
    t = (target or "").strip()
    if not t:
        return ""
    low = t.lower()
    if low.startswith(("http://", "https://")):
        parsed = urlparse(t)
        host = (parsed.hostname or "").strip()
        port = parsed.port
        if host in ("127.0.0.1", "localhost") and port:
            return f"Dienst :{port}"
        if host:
            return host
        return t[:48]
    p = Path(t)
    if p.suffix.lower() in (".lnk", ".url") and p.stem:
        return p.stem
    if p.name:
        return p.stem or p.name
    return t[:48]


def _name_wirkt_kaputt(text: str) -> bool:
    if not text or "\ufffd" in text:
        return True
    fremd = 0
    for c in text:
        if c in _ANZEIGE_ZEICHEN:
            continue
        if ord(c) < 32 or not c.isprintable():
            return True
        fremd += 1
    return fremd > max(1, len(text) // 6)


def name_lesbar_fuer_anzeige(name: str, target: str = "") -> str:
    """Leisten-Text: kaputte/Mojibake-Namen ersetzen (nur Anzeige, Config unveraendert)."""
    ziel = (target or "").strip()
    roh = (name or "").strip()
    if not roh and not ziel:
        return "?"
    if not roh:
        return _fallback_name_aus_target(ziel) or "?"
    if roh == ziel and ziel.lower().startswith(("http://", "https://")):
        return _fallback_name_aus_target(ziel) or roh[:48]
    if _name_wirkt_kaputt(roh):
        ersatz = _fallback_name_aus_target(ziel)
        if ersatz:
            return ersatz
        bereinigt = "".join(c for c in roh if c in _ANZEIGE_ZEICHEN)
        return (bereinigt.strip()[:48] if bereinigt.strip() else "?")
    return roh[:48]


def entry_namen_in_liste_reparieren(entries: list) -> int:
    """Kaputte name-Felder in config.json ersetzen. Rueckgabe: Anzahl geaendert."""
    geaendert = 0
    for e in entries:
        if not isinstance(e, dict):
            continue
        alt = str(e.get("name") or "")
        ziel = str(e.get("target") or "")
        if alt and not _name_wirkt_kaputt(alt):
            continue
        neu = name_lesbar_fuer_anzeige(alt, ziel)
        if not neu or neu == "?" or neu == alt:
            continue
        e["name"] = neu
        geaendert += 1
    return geaendert


def entry_typ_label(target: str) -> str:
    t = str(target or "").strip()
    if not t:
        return "Unbekannt"
    low = t.lower()
    if low.startswith(("http://", "https://")):
        return "Webseite"
    if low.startswith(("ms-settings:", "shell:", "mailto:")):
        return "System"
    if t.endswith(".lnk"):
        return "Verknuepfung (.lnk)"
    if t.endswith(".url"):
        return "Internetverknuepfung"
    if t.endswith(".exe"):
        return "Programm (.exe)"
    if t.endswith(".msc"):
        return "Microsoft Management"
    if os.path.isdir(t):
        return "Ordner"
    if os.path.isfile(t):
        return f"Datei ({Path(t).suffix or '?'})"
    return "Unbekannt"


_KAT_TITEL: dict[str, str] = {
    "system": "System",
    "programme": "Programme",
    "netz": "Netz",
    "ordner": "Ordner",
    "startmenue": "Startmenü",
}


def entry_gruppe(entry: dict) -> str:
    g = entry.get("group") or entry.get("gruppe")
    if g:
        return str(g)
    kat = str(entry.get("kat") or "").strip()
    if kat:
        return _KAT_TITEL.get(kat, kat)
    return "—"


def entry_quelle_anzeige(entry: dict) -> str:
    q = str(entry.get("quelle") or entry.get("source") or "").strip()
    return q if q else "—"


def entry_icon_pfad(target: str, entry: dict | None = None) -> str:
    """Dateipfad fuer Shell-IconLocation — leer wenn nicht ermittelbar."""
    if entry and isinstance(entry, dict) and entry.get("launch"):
        try:
            from .verbindung_profil import icon_fuer_entry

            ip, _idx = icon_fuer_entry(entry)
            if ip:
                return ip
        except Exception:
            pass
    t = str(target or "").strip()
    if not t:
        return ""
    p = Path(t)
    if p.suffix.lower() == ".lnk" and p.is_file():
        try:
            from .launcher import resolve_lnk

            path, _args = resolve_lnk(str(p))
            if path and os.path.exists(path):
                return path
        except Exception:
            pass
        return str(p)
    if p.is_file() and p.suffix.lower() in (".exe", ".ico", ".dll"):
        return str(p)
    if p.is_dir():
        return str(p)
    if p.is_file():
        return str(p)
    return ""


def entry_tooltip_text(
    entry: dict,
    *,
    name: str,
    display_target: str,
    typ: str,
    always_restart: bool = False,
) -> str:
    """Mehrzeiliger Hover-Text — Name, Typ, Ziel, Hinweise."""
    lines = [name.strip() or "?"]
    if typ:
        lines.append(f"Typ: {typ}")
    ziel = display_target.strip()
    roh = str(entry.get("target") or "").strip()
    if ziel and ziel != roh:
        lines.append(f"Ziel: {ziel}")
    elif ziel:
        lines.append(f"Ziel: {ziel}")
    quelle = str(entry.get("source") or "").strip()
    if quelle:
        lines.append(f"Quelle: {quelle}")
    if always_restart:
        lines.append("Immer neu starten")
    lines.append("Linksklick = starten · Rechtsklick = Menü")
    return "\n".join(lines)
