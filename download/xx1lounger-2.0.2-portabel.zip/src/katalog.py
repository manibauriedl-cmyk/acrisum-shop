"""Katalog-Gruppen fuer Anheften-Panel (KVA 128–129, 141, Phase 11)."""
from __future__ import annotations

import logging
import os
import re
import threading
from pathlib import Path

from . import drop
from . import katalog_eingebaut
from .config import stable_id

_pool_cache: list[dict] | None = None
_vorgewaermen_laeuft = False
_vorgewaermen_fehlgeschlagen = False

KATEGORIEN: list[tuple[str, str]] = [
    ("system", "System"),
    ("programme", "Windows-Werkzeuge"),
    ("netz", "Netz"),
    ("ordner", "Ordner"),
    ("startmenue", "Programme (Startmenü)"),
    ("desktop", "Desktop"),
]

_UNINSTALL_RE = re.compile(
    r"uninstall|deinstall|remove|setup|installer|update",
    re.I,
)
_AUTOSTART_MARK = re.compile(r"startup|autostart|anmelde", re.I)

# DisplayIcon zeigt bei manchen Programmen auf den Uninstaller —
# der Katalog-Eintrag wuerde sonst beim Klick deinstallieren.
_UNINSTALL_EXE_RE = re.compile(
    r"^(unins|uninst|uninstall|unwise|setup|install|remove|update)",
    re.I,
)


def _startmenue_pfade() -> list[Path]:
    roots: list[Path] = []
    for env in ("ProgramData", "APPDATA"):
        base = os.environ.get(env)
        if not base:
            continue
        roots.append(Path(base) / "Microsoft" / "Windows" / "Start Menu" / "Programs")
    return [p for p in roots if p.is_dir()]


def _lnk_filter(name: str, path: Path) -> bool:
    """KVA 265–267."""
    n = name.lower()
    if _UNINSTALL_RE.search(n):
        return False
    if _AUTOSTART_MARK.search(str(path).lower()):
        return False
    if path.suffix.lower() not in (".lnk", ".url"):
        return False
    if path.suffix.lower() == ".lnk" and path.stat().st_size < 512:
        return False
    return True


def startmenue_eintraege(limit: int = 400) -> list[dict]:
    """KVA 264 — .lnk aus ProgramData + APPDATA Start Menu."""
    gefunden: list[dict] = []
    gesehen: set[str] = set()
    for root in _startmenue_pfade():
        try:
            for p in root.rglob("*"):
                if len(gefunden) >= limit:
                    break
                if p.suffix.lower() not in (".lnk", ".url"):
                    continue
                if not _lnk_filter(p.stem, p):
                    continue
                ziel = str(p.resolve())
                sid = stable_id(ziel)
                if sid in gesehen:
                    continue
                gesehen.add(sid)
                gefunden.append(
                    {
                        "id": f"sm_{sid}",
                        "name": p.stem,
                        "target": ziel,
                        "kat": "startmenue",
                        "quelle": "startmenue",
                    }
                )
        except OSError:
            continue
    gefunden.sort(key=lambda e: (e.get("name") or "").lower())
    return gefunden


def _desktop_pfade() -> list[Path]:
    roots: list[Path] = []
    for env, sub in (("USERPROFILE", "Desktop"), ("PUBLIC", "Desktop")):
        base = os.environ.get(env)
        if base:
            roots.append(Path(base) / sub)
    return [p for p in roots if p.is_dir()]


def desktop_eintraege(limit: int = 300) -> list[dict]:
    """Desktop-Verknuepfungen (.lnk + .url) — gehoert zu „Programme" dazu."""
    gefunden: list[dict] = []
    gesehen: set[str] = set()
    for root in _desktop_pfade():
        try:
            for p in root.iterdir():
                if len(gefunden) >= limit:
                    break
                if p.suffix.lower() not in (".lnk", ".url"):
                    continue
                if not _lnk_filter(p.stem, p):
                    continue
                ziel = str(p.resolve())
                sid = stable_id(ziel)
                if sid in gesehen:
                    continue
                gesehen.add(sid)
                gefunden.append(
                    {
                        "id": f"dk_{sid}",
                        "name": p.stem,
                        "target": ziel,
                        "kat": "desktop",
                        "quelle": "desktop",
                    }
                )
        except OSError:
            continue
    gefunden.sort(key=lambda e: (e.get("name") or "").lower())
    return gefunden


def _uninstall_exe_map() -> dict[str, str]:
    """DisplayName (klein) -> exe-Pfad aus DisplayIcon der Uninstall-Registry."""
    try:
        import winreg
    except Exception:
        return {}
    out: dict[str, str] = {}
    for root, sub in (
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
    ):
        try:
            with winreg.OpenKey(root, sub) as key:
                for i in range(winreg.QueryInfoKey(key)[0]):
                    try:
                        with winreg.OpenKey(key, winreg.EnumKey(key, i)) as app:
                            name = str(winreg.QueryValueEx(app, "DisplayName")[0]).strip()
                            icon = str(winreg.QueryValueEx(app, "DisplayIcon")[0]).strip()
                    except OSError:
                        continue
                    exe = icon.split(",")[0].strip().strip('"')
                    if (
                        name
                        and exe.lower().endswith(".exe")
                        and not _UNINSTALL_EXE_RE.match(os.path.basename(exe))
                        and os.path.isfile(exe)
                    ):
                        out.setdefault(name.lower(), exe)
        except OSError:
            continue
    return out


def _apps_zu_eintraegen(
    items: list[tuple[str, str]],
    bekannte_namen: set[str],
    exe_map: dict[str, str],
    limit: int = 400,
) -> list[dict]:
    """(Name, AppUserModelId)-Paare -> Katalog-Eintraege.

    Desktop-Apps auf die echte exe aufloesen (Icon + Lauf-Match gratis),
    Store-Apps als shell:AppsFolder-Ziel startbar halten.
    """
    gefunden: list[dict] = []
    gesehen: set[str] = set()
    for name, appid in items:
        if len(gefunden) >= limit:
            break
        key = name.lower()
        if not name or not appid or key in gesehen or key in bekannte_namen:
            continue
        if _UNINSTALL_RE.search(key):
            continue
        exe = exe_map.get(key)
        target = exe or f"shell:AppsFolder\\{appid}"
        gesehen.add(key)
        gefunden.append(
            {
                "id": f"ap_{stable_id(target)}",
                "name": name,
                "target": target,
                "kat": "startmenue",
                "quelle": "apps",
            }
        )
    return gefunden


def _apps_via_startapps() -> list[tuple[str, str]] | None:
    """Get-StartApps im Subprozess — kein COM/gen_py im eigenen Prozess.

    Erstes Dispatch(\"Shell.Application\") erzeugt den gen_py-Cache der
    Shell32-Typelib und blockiert den GIL fuer viele Sekunden — das Panel
    fror ~30 s ein (Nutzer 09.10.2026). Get-StartApps liefert dieselben
    (Name, AppUserModelId)-Paare wie der AppsFolder.
    """
    import subprocess

    try:
        r = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-NonInteractive",
                "-Command",
                "[Console]::OutputEncoding=[Text.Encoding]::UTF8;"
                "Get-StartApps | ForEach-Object { $_.Name + \"`t\" + $_.AppID }",
            ],
            capture_output=True,
            timeout=60,
            creationflags=0x08000000,  # CREATE_NO_WINDOW
        )
    except Exception:
        return None
    if r.returncode != 0:
        return None
    out: list[tuple[str, str]] = []
    for line in r.stdout.decode("utf-8", errors="replace").splitlines():
        if "\t" in line:
            name, appid = line.rsplit("\t", 1)
            out.append((name.strip(), appid.strip()))
    return out or None


def _apps_via_com() -> list[tuple[str, str]]:
    """Fallback: AppsFolder direkt per COM (gen_py-Aufbau akzeptiert)."""
    try:
        import pythoncom
        import win32com.client
    except Exception:
        return []
    items: list[tuple[str, str]] = []
    try:
        pythoncom.CoInitialize()
        folder = win32com.client.Dispatch("Shell.Application").NameSpace("shell:AppsFolder")
        for it in folder.Items():
            items.append((str(it.Name or "").strip(), str(it.Path or "").strip()))
    except Exception:
        return []
    finally:
        try:
            pythoncom.CoUninitialize()
        except Exception:
            pass
    return items


def apps_ordner_eintraege(bekannte_namen: set[str], limit: int = 400) -> list[dict]:
    """Registrierte Apps — auch ohne .lnk im Startmenue.

    RustDesk z. B. legt keine .lnk an, steht aber als registrierte App in
    Windows' App-Liste (Nutzer 09.10.2026: Suche „rust“ fand installiertes
    Programm nicht). Namen, die schon als Startmenue-/Desktop-Eintrag
    existieren, werden uebersprungen (Dedup).
    """
    items = _apps_via_startapps()
    if items is None:
        items = _apps_via_com()
    return _apps_zu_eintraegen(items, bekannte_namen, _uninstall_exe_map(), limit)


def ziel_norm_key(target: str) -> str:
    """Gleiches Programm (.lnk vs .exe) — ein Schluessel (KVA 142)."""
    roh = (target or "").strip()
    if not roh:
        return ""
    return drop.normalize_target(roh).lower()


_QUELLE_PRIO = {"eingebaut": 0, "startmenue": 1, "desktop": 2, "apps": 3}


def dedupliziere_pool(items: list[dict]) -> list[dict]:
    """KVA 142 — pro aufgeloestem Ziel nur ein Katalog-Eintrag."""
    best: dict[str, dict] = {}
    for e in items:
        k = ziel_norm_key(e.get("target") or "")
        if not k:
            continue
        alt = best.get(k)
        if alt is None:
            best[k] = e
            continue
        q_new = _QUELLE_PRIO.get(str(e.get("quelle") or ""), 5)
        q_alt = _QUELLE_PRIO.get(str(alt.get("quelle") or ""), 5)
        if q_new < q_alt:
            best[k] = e
    return list(best.values())


def pool_eintraege(mit_startmenue: bool = True, *, use_cache: bool = True) -> list[dict]:
    global _pool_cache
    if use_cache and mit_startmenue and _pool_cache is not None:
        return list(_pool_cache)
    items = list(katalog_eingebaut.alle_eingebauten())
    if mit_startmenue:
        items.extend(startmenue_eintraege())
        items.extend(desktop_eintraege())
        bekannte = {
            str(e.get("name") or "").strip().lower()
            for e in items
            if str(e.get("name") or "").strip()
        }
        items.extend(apps_ordner_eintraege(bekannte))
    items = dedupliziere_pool(items)
    if mit_startmenue:
        _pool_cache = list(items)
    return items


def pool_bereit() -> bool:
    return _pool_cache is not None


def pool_wird_geladen() -> bool:
    return _vorgewaermen_laeuft and _pool_cache is None


def pool_fehlgeschlagen() -> bool:
    return _vorgewaermen_fehlgeschlagen and _pool_cache is None


def vorgewaermen_starten() -> None:
    """KVA 141 — Startmenue-Scan im Hintergrund (Panel oeffnet schneller)."""
    global _vorgewaermen_laeuft, _pool_cache
    if _pool_cache is not None or _vorgewaermen_laeuft:
        return
    _vorgewaermen_laeuft = True

    def _arbeit() -> None:
        global _vorgewaermen_laeuft, _pool_cache, _vorgewaermen_fehlgeschlagen
        try:
            pool_eintraege(mit_startmenue=True, use_cache=False)
            logging.info(
                "Anheften-Katalog vorgewarmt (%s Eintraege)",
                len(_pool_cache or []),
            )
        except Exception as exc:
            _vorgewaermen_fehlgeschlagen = True
            logging.debug("Katalog-Vorwaermen fehlgeschlagen: %s", exc)
        finally:
            _vorgewaermen_laeuft = False

    threading.Thread(target=_arbeit, name="xlounger-katalog-pool", daemon=True).start()


def entfernte_katalog_eintraege(data: dict | None) -> list[dict]:
    """Früher entfernte Leisten-Einträge — neueste zuerst.

    Bleiben im Katalog sichtbar, damit Wieder-Anheften auch dann geht,
    wenn die ursprüngliche Quelle (z. B. Desktop-.lnk) gelöscht wurde.
    """
    removed = (data or {}).get("removed_entries")
    if not isinstance(removed, list):
        return []
    out: list[dict] = []
    for e in reversed(removed):
        if not isinstance(e, dict):
            continue
        target = str(e.get("target") or "").strip()
        if not target:
            continue
        out.append(
            {
                "id": f"rm_{stable_id(target)}",
                "name": str(e.get("name") or target),
                "target": target,
                "kat": "entfernt",
                "quelle": "entfernt",
            }
        )
    return out


def gruppen(
    mit_startmenue: bool = True, *, data: dict | None = None
) -> list[tuple[str, str, list[dict]]]:
    """(kat_id, Titel, Eintraege) — KVA 129."""
    pool = pool_eintraege(mit_startmenue=mit_startmenue)
    out: list[tuple[str, str, list[dict]]] = []
    for kid, titel in KATEGORIEN:
        if kid == "startmenue" and not mit_startmenue:
            continue
        teil = [e for e in pool if e.get("kat") == kid]
        teil.sort(key=lambda x: (x.get("name") or "").lower())
        out.append((kid, titel, teil))
    entfernte = entfernte_katalog_eintraege(data)
    if entfernte:
        out.insert(0, ("entfernt", "Zuletzt entfernt", entfernte))
    return out


def suche_filter(eintraege: list[dict], query: str) -> list[dict]:
    """KVA 131."""
    q = (query or "").strip().lower()
    if not q:
        return eintraege
    out: list[dict] = []
    for e in eintraege:
        hay = f"{e.get('name','')} {e.get('target','')}".lower()
        if q in hay:
            out.append(e)
    return out
