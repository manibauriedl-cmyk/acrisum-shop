"""Windows Drag & Drop (WM_DROPFILES) für xlounger.

Ermoeglicht das Ablegen von Dateien und Ordnern aus dem Explorer
auf die Leiste. Weitere Formate (URLs, Text) koennen spaeter per OLE dazu.
"""
from __future__ import annotations

import ctypes
import logging as _logging
import queue
import struct
import threading
from ctypes import wintypes
from pathlib import Path

try:
    import pythoncom
    import win32api
    import win32con
    import win32gui
    from win32com.server.util import wrap

    _OLE_DROP_AVAILABLE = True
except Exception:
    _OLE_DROP_AVAILABLE = False
    pythoncom = None  # type: ignore
    win32api = None  # type: ignore
    win32con = None  # type: ignore
    win32gui = None  # type: ignore
    wrap = None  # type: ignore


WM_DROPFILES = 0x0233
WM_HOTKEY = 0x0312
_WM_USER_DROP = 0x0400 + 1
GWL_WNDPROC = -4

_ole_targets: dict[int, "OLEDROP"] = {}

_user32 = ctypes.windll.user32
_shell32 = ctypes.windll.shell32

# Explizite ctypes-Prototypen verhindern Pointer-Truncation auf 64-Bit
_shell32.DragAcceptFiles.argtypes = [wintypes.HWND, wintypes.BOOL]
_shell32.DragAcceptFiles.restype = None
_shell32.DragQueryFileW.argtypes = [wintypes.HANDLE, wintypes.UINT, ctypes.c_wchar_p, wintypes.UINT]
_shell32.DragQueryFileW.restype = wintypes.UINT
_shell32.DragFinish.argtypes = [wintypes.HANDLE]
_shell32.DragFinish.restype = None
_shell32.DragQueryPoint.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.POINT)]
_shell32.DragQueryPoint.restype = wintypes.BOOL

# Explizite ctypes-Prototypen verhindern Pointer-Truncation auf 64-Bit
WNDPROC = ctypes.WINFUNCTYPE(
    ctypes.c_longlong,
    wintypes.HWND,
    wintypes.UINT,
    wintypes.WPARAM,
    wintypes.LPARAM,
)
_user32.GetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int]
_user32.GetWindowLongPtrW.restype = ctypes.c_void_p
_user32.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
_user32.GetWindowLongW.restype = ctypes.c_void_p
_user32.SetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_void_p]
_user32.SetWindowLongPtrW.restype = ctypes.c_void_p
_user32.SetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_void_p]
_user32.SetWindowLongW.restype = ctypes.c_void_p
_user32.CallWindowProcW.argtypes = [ctypes.c_void_p, wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
_user32.CallWindowProcW.restype = ctypes.c_longlong


class DROPFILES:
    """Einfache WM_DROPFILES-Annahme fuer ein HWND."""

    def __init__(self, hwnd: int, on_paths, on_hotkey=None, on_show=None, on_shell_notify=None, on_tray=None):
        self.hwnd = int(hwnd)
        self.on_paths = on_paths
        self.on_hotkey = on_hotkey
        self.on_show = on_show
        self.on_shell_notify = on_shell_notify
        self.on_tray = on_tray
        self._old_proc = None
        self._new_proc_ref = None
        self._install()

    def _install(self):
        _shell32.DragAcceptFiles(self.hwnd, True)
        from .single_instance import WM_XLOUNGER_SHOW
        from .tray_win32 import WM_TRAYICON

        def wndproc(hwnd, msg, wparam, lparam):
            if msg == WM_DROPFILES:
                self._handle_drop(wparam)
                return 0
            if msg == WM_HOTKEY and self.on_hotkey:
                self.on_hotkey(int(wparam))
                return 0
            if msg == WM_XLOUNGER_SHOW and self.on_show:
                self.on_show()
                return 0
            if msg == WM_TRAYICON and self.on_tray:
                # Tray-Maus-Event (lparam) — laeuft im Tk-Thread, kein Zusatz-Thread.
                self.on_tray(int(lparam))
                return 0
            if msg == _WM_USER_DROP:
                ole = _ole_targets.get(hwnd)
                if ole and self.on_paths:
                    with ole._pending_lock:
                        pending = list(ole._pending_paths)
                        ole._pending_paths.clear()
                    for paths in pending:
                        try:
                            self.on_paths(paths)
                        except Exception as exc:
                            _logging.error("WM_USER_DROP on_paths Fehler: %s", exc)
                return 0
            if self.on_shell_notify:
                try:
                    if self.on_shell_notify(int(msg), int(wparam), int(lparam)):
                        return 0
                except Exception as exc:
                    _logging.debug("on_shell_notify: %s", exc)
            # Weiterleiten, damit Tk weiter funktioniert
            if self._old_proc:
                return _user32.CallWindowProcW(self._old_proc, hwnd, msg, wparam, lparam)
            return 0

        self._new_proc = WNDPROC(wndproc)
        new_ptr = ctypes.cast(self._new_proc, ctypes.c_void_p)

        # Alten WndProc merken und neuen setzen (Rueckgabe = alter WndProc)
        if hasattr(_user32, "SetWindowLongPtrW"):
            self._old_proc = _user32.SetWindowLongPtrW(self.hwnd, GWL_WNDPROC, new_ptr)
            self._setter = _user32.SetWindowLongPtrW
        else:
            self._old_proc = _user32.SetWindowLongW(self.hwnd, GWL_WNDPROC, new_ptr)
            self._setter = _user32.SetWindowLongW

    def _handle_drop(self, hdrop):
        file_count = _shell32.DragQueryFileW(hdrop, 0xFFFFFFFF, None, 0)
        paths = []
        for i in range(file_count):
            buf = ctypes.create_unicode_buffer(32768)
            _shell32.DragQueryFileW(hdrop, i, buf, 32768)
            path = buf.value
            if path:
                paths.append(path)
        # Ablegestelle: DragQueryPoint liefert Client-Koordinaten -> Bildschirm.
        # Rueckgabewert nur "innerhalb Client-Area" — pt ist immer gefuellt,
        # also unabhaengig davon uebernehmen (sonst Ablegestelle None -> Ende).
        point = None
        try:
            pt = wintypes.POINT()
            _shell32.DragQueryPoint(hdrop, ctypes.byref(pt))
            _user32.ClientToScreen(self.hwnd, ctypes.byref(pt))
            point = (int(pt.x), int(pt.y))
        except Exception:
            point = None
        _shell32.DragFinish(hdrop)
        if paths and self.on_paths:
            _logging.info("WM_DROPFILES empfangen: %s", paths)
            self.on_paths(paths, point)

    def close(self):
        if self.hwnd:
            try:
                if getattr(self, "_setter", None) and self._old_proc:
                    self._setter(self.hwnd, GWL_WNDPROC, self._old_proc)
            except Exception:
                pass
            _shell32.DragAcceptFiles(self.hwnd, False)
            self.hwnd = None


def resolve_lnk(path: str) -> str:
    """Windows-Verknuepfung (.lnk) zum echten Ziel aufloesen."""
    try:
        import win32com.client
        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortcut(path)
        target = shortcut.TargetPath
        if target and Path(target).exists():
            return target
    except Exception:
        pass
    return path


def normalize_target(path: str) -> str:
    """Vergleichsschlüssel-Quelle (Katalog/Dedup) — logisches Ziel, nicht Leisten-target."""
    from .verbindung_profil import ziel_schluessel_fuer_quelle

    return ziel_schluessel_fuer_quelle(path)


def ziel_fuer_leiste(path: str) -> str:
    """Persistierter Leisten-target — .lnk bleibt .lnk."""
    from .verbindung_profil import profil_aus_quelle, ziel_fuer_config

    quelle = (path or "").strip()
    launch = profil_aus_quelle(quelle)
    return ziel_fuer_config(quelle, launch)


def _clip_format(name: str) -> int:
    try:
        import win32clipboard

        return int(win32clipboard.RegisterClipboardFormat(name))
    except Exception:
        return 0


def _stg_handle(stg) -> int | None:
    """PySTGMEDIUM / HDROP-Handle aus IDataObject::GetData."""
    if stg is None:
        return None
    if isinstance(stg, int):
        return int(stg)
    for attr in ("data_handle", "hGlobal", "handle", "value"):
        try:
            roh = getattr(stg, attr, None)
            if roh:
                return int(roh)
        except (TypeError, ValueError):
            continue
    if isinstance(stg, (list, tuple)) and stg:
        return _stg_handle(stg[0])
    return None


def _pfade_aus_hdrop_handle(handle: int) -> list[str]:
    if not handle:
        return []
    try:
        h = wintypes.HANDLE(int(handle))
        n = int(_shell32.DragQueryFileW(h, 0xFFFFFFFF, None, 0))
        out: list[str] = []
        for i in range(n):
            buf = ctypes.create_unicode_buffer(32768)
            _shell32.DragQueryFileW(h, i, buf, 32768)
            if buf.value.strip():
                out.append(buf.value.strip())
        if out:
            return out
    except Exception:
        pass
    try:
        from win32com.shell import shell

        n = shell.DragQueryFileW(handle, 0xFFFFFFFF)
        if isinstance(n, str) and n.strip():
            return [n.strip()]
        count = max(0, int(n))
        return [
            str(shell.DragQueryFileW(handle, i)).strip()
            for i in range(count)
            if shell.DragQueryFileW(handle, i)
        ]
    except Exception:
        return []


def _pfade_aus_hdrop(stg) -> list[str]:
    if stg is None:
        return []
    if isinstance(stg, (list, tuple)):
        return [str(x) for x in stg if x]
    if isinstance(stg, str) and stg.strip():
        return [stg.strip()]
    handle = _stg_handle(stg)
    if handle:
        return _pfade_aus_hdrop_handle(handle)
    try:
        from win32com.shell import shell

        n = int(shell.DragQueryFile(stg, -1))
        return [str(shell.DragQueryFile(stg, i)) for i in range(n)]
    except Exception:
        return []


def _get_data_safe(dataobj, fmt: tuple):
    try:
        return dataobj.GetData(fmt)
    except Exception:
        return None


def _global_bytes(handle: int) -> bytes:
    if not handle:
        return b""
    k32 = ctypes.windll.kernel32
    k32.GlobalSize.restype = ctypes.c_size_t
    k32.GlobalSize.argtypes = [ctypes.c_void_p]
    k32.GlobalLock.restype = ctypes.c_void_p
    k32.GlobalLock.argtypes = [ctypes.c_void_p]
    h = ctypes.c_void_p(int(handle))
    size = int(k32.GlobalSize(h))
    if size <= 0:
        return b""
    ptr = k32.GlobalLock(h)
    if not ptr:
        return b""
    try:
        return bytes((ctypes.c_char * size).from_address(ptr))
    finally:
        k32.GlobalUnlock(h)


def _pidl_bytes_schneiden(raw: bytes, off: int) -> bytes | None:
    if off < 0 or off >= len(raw):
        return None
    i = off
    while i + 2 <= len(raw):
        cb = int.from_bytes(raw[i : i + 2], "little")
        if cb == 0:
            return raw[off : i + 2]
        if cb < 2 or i + cb > len(raw):
            break
        i += cb
    return None


def _pidl_bytes_zu_liste(blob: bytes) -> list[bytes]:
    items: list[bytes] = []
    i = 0
    while i + 2 <= len(blob):
        cb = int.from_bytes(blob[i : i + 2], "little")
        if cb == 0:
            break
        if cb < 2 or i + cb > len(blob):
            break
        items.append(blob[i : i + cb])
        i += cb
    return items


def _ziel_aus_pidl_liste(pidl: list[bytes]) -> str:
    from win32com.shell import shell

    if not pidl:
        return ""
    try:
        pfad = shell.SHGetPathFromIDList(pidl)
        if pfad and str(pfad).strip():
            return str(pfad).strip()
    except Exception:
        pass
    try:
        name = shell.SHGetNameFromIDList(pidl, 0x8000)
        if name and str(name).strip():
            return str(name).strip()
    except Exception:
        pass
    return ""


def _pfade_aus_shell_idlist(stg) -> list[str]:
    """Shell IDList — Desktop-Symbole liefern oft nur dieses Format (nicht CF_HDROP)."""
    handle = _stg_handle(stg)
    if not handle:
        return []
    try:
        raw = _global_bytes(handle)
        if not raw or len(raw) < 8:
            return []
        cidl = struct.unpack_from("<I", raw, 0)[0]
        if cidl <= 0 or cidl > 512:
            return []
        need = 4 + 4 * (cidl + 1)
        if len(raw) < need:
            return []
        offsets = struct.unpack_from("<" + "I" * (cidl + 1), raw, 4)
        parent_b = _pidl_bytes_schneiden(raw, int(offsets[0]))
        parent_items = _pidl_bytes_zu_liste(parent_b) if parent_b else []
        out: list[str] = []
        for i in range(1, cidl + 1):
            child_b = _pidl_bytes_schneiden(raw, int(offsets[i]))
            if not child_b:
                continue
            child_items = _pidl_bytes_zu_liste(child_b)
            if not child_items:
                continue
            full = list(parent_items) + list(child_items) if parent_items else list(child_items)
            ziel = _ziel_aus_pidl_liste(full)
            if not ziel and child_items:
                ziel = _ziel_aus_pidl_liste(list(child_items))
            if ziel:
                out.append(ziel)
        return out
    except Exception:
        return []


def _dateien_aus(dataobj) -> list[str]:
    """Pfade aus IDataObject — nur innerhalb Drop() aufrufen."""
    if dataobj is None:
        return []
    gefunden: list[str] = []

    fmt_hdrop = (
        win32con.CF_HDROP,
        None,
        pythoncom.DVASPECT_CONTENT,
        -1,
        pythoncom.TYMED_HGLOBAL,
    )
    stg = _get_data_safe(dataobj, fmt_hdrop)
    if stg is not None:
        gefunden.extend(_pfade_aus_hdrop(stg))

    cf_idlist = _clip_format("Shell IDList Array")
    if cf_idlist:
        fmt_id = (cf_idlist, None, pythoncom.DVASPECT_CONTENT, -1, pythoncom.TYMED_HGLOBAL)
        stg_id = _get_data_safe(dataobj, fmt_id)
        if stg_id is not None:
            gefunden.extend(_pfade_aus_shell_idlist(stg_id))

    for name in ("FileNameW", "FileName"):
        cf = _clip_format(name)
        if not cf:
            continue
        fmt = (cf, None, pythoncom.DVASPECT_CONTENT, -1, pythoncom.TYMED_HGLOBAL)
        roh = _get_data_safe(dataobj, fmt)
        if roh is None:
            continue
        if isinstance(roh, str) and roh.strip():
            gefunden.append(roh.strip("\x00"))
        elif isinstance(roh, bytes):
            gefunden.append(roh.decode("utf-16-le", errors="ignore").strip("\x00"))
        else:
            # FileNameW/FileName-HGLOBAL ist ein String-Handle, KEIN HDROP —
            # als HDROP lesen lieferte Binaermuell-Eintraege (25.09.2026).
            handle = _stg_handle(roh)
            if handle:
                raw = _global_bytes(handle)
                if raw:
                    enc = "utf-16-le" if name.endswith("W") else "mbcs"
                    txt = raw.decode(enc, errors="ignore").strip("\x00").strip()
                    if txt:
                        gefunden.append(txt)

    out: list[str] = []
    gesehen: set[str] = set()
    for p in gefunden:
        t = str(p).strip().strip('"')
        if not t:
            continue
        key = t.casefold()
        if key in gesehen:
            continue
        gesehen.add(key)
        out.append(t)
    return out


def pfade_aus_clipboard() -> list[str]:
    """CF_HDROP aus Zwischenablage — Fallback wenn OLE-Pfade leer."""
    try:
        import win32clipboard

        win32clipboard.OpenClipboard(0)
        try:
            if not win32clipboard.IsClipboardFormatAvailable(win32con.CF_HDROP):
                return []
            return _pfade_aus_hdrop(win32clipboard.GetClipboardData(win32con.CF_HDROP))
        finally:
            win32clipboard.CloseClipboard()
    except Exception:
        return []


def _performed_drop_effect_setzen(dataobj, effect: int) -> None:
    """Explorer: COPY statt MOVE — Desktop-Symbol bleibt."""
    if dataobj is None or not effect:
        return
    try:
        import struct

        cf = _clip_format("Performed DropEffect")
        if not cf:
            return
        medium = pythoncom.STGMEDIUM()
        medium.set(pythoncom.TYMED_HGLOBAL, struct.pack("I", int(effect)))
        fmt = (cf, None, pythoncom.DVASPECT_CONTENT, -1, pythoncom.TYMED_HGLOBAL)
        dataobj.SetData(fmt, medium, True)
    except Exception:
        pass


if _OLE_DROP_AVAILABLE:
    _CF_HDROP = 15
    _DROPEFFECT_NONE = 0
    _DROPEFFECT_COPY = 1
    _DROPEFFECT_LINK = 4

    class _OleDropTarget:
        _public_methods_ = ["DragEnter", "DragOver", "DragLeave", "Drop"]
        _com_interfaces_ = [pythoncom.IID_IDropTarget]

        def __init__(self, drop_queue):
            self._queue = drop_queue

        def DragEnter(self, data_object, key_state, point, effect):
            return _DROPEFFECT_COPY

        def DragOver(self, key_state, point, effect):
            return _DROPEFFECT_COPY

        def DragLeave(self):
            _logging.info("OLE DragLeave")
            return 0

        def Drop(self, data_object, key_state, point, effect):
            _logging.info("OLE Drop (point=%s)", point)
            paths: list[str] = []
            try:
                paths = _dateien_aus(data_object)
            except Exception as exc:
                _logging.error("OLE Drop _dateien_aus Fehler: %s", exc)
            if not paths:
                paths = pfade_aus_clipboard()
            if paths:
                _logging.info("OLE Drop Pfade: %s", paths)
                try:
                    # Ablegestelle (Bildschirm-Koordinaten) mitgeben, damit der
                    # Eintrag an der Stelle eingefuegt werden kann (KVA 120).
                    self._queue.put((paths, (int(point[0]), int(point[1]))))
                except Exception as exc:
                    _logging.error("OLE Drop queue Fehler: %s", exc)
                _performed_drop_effect_setzen(data_object, _DROPEFFECT_COPY)
                return _DROPEFFECT_COPY
            _logging.warning("OLE Drop ohne Pfade (point=%s)", point)
            return _DROPEFFECT_NONE

    _overlay_class_atom = None
    _overlay_registered_count = 0

    def _overlay_wndproc(hwnd, msg, wparam, lparam):
        if msg == win32con.WM_NCHITTEST:
            return win32con.HTTRANSPARENT
        return win32gui.DefWindowProc(hwnd, msg, wparam, lparam)

    class OLEDROP:
        """OLE IDropTarget auf Leisten-HWND (optional separates Overlay)."""

        def __init__(self, owner_hwnd: int, on_paths=None, on_hotkey=None, use_overlay: bool = False):
            self.owner_hwnd = int(owner_hwnd)
            self._queue = queue.Queue()
            self._overlay_owned = bool(use_overlay)
            self._drop_hwnds: list[int] = []
            overlay_hwnd = 0
            if use_overlay:
                overlay_hwnd = self._create_overlay(self.owner_hwnd)
            if overlay_hwnd:
                self._drop_hwnds.append(overlay_hwnd)
            self._drop_hwnds.append(self.owner_hwnd)
            self.hwnd = overlay_hwnd or self.owner_hwnd
            self._wrapped = []
            try:
                pythoncom.OleInitialize()
            except Exception as exc:
                _logging.info("OleInitialize Info/Warnung: %s", exc)
            target = _OleDropTarget(self._queue)
            for h in self._drop_hwnds:
                _ole_targets[h] = self
                try:
                    pythoncom.RevokeDragDrop(h)
                except Exception:
                    pass
                wrapped = wrap(target, pythoncom.IID_IDropTarget)
                self._wrapped.append((h, wrapped))
                pythoncom.RegisterDragDrop(h, wrapped)
                _logging.info("OLE Drop-Target registriert fuer HWND %s", h)

        def _create_overlay(self, owner_hwnd):
            global _overlay_class_atom, _overlay_registered_count
            if _overlay_class_atom is None:
                try:
                    wc = win32gui.WNDCLASS()
                    wc.lpfnWndProc = _overlay_wndproc
                    wc.hInstance = win32gui.GetModuleHandle(None)
                    wc.lpszClassName = "xlounger_drop_overlay"
                    _overlay_class_atom = win32gui.RegisterClass(wc)
                except Exception as exc:
                    _logging.error("Overlay WNDCLASS Fehler: %s", exc)
                    return 0
            try:
                left, top, right, bottom = win32gui.GetWindowRect(owner_hwnd)
            except Exception:
                return 0
            width = right - left
            height = bottom - top
            try:
                hwnd = win32gui.CreateWindowEx(
                    win32con.WS_EX_LAYERED
                    | win32con.WS_EX_TOOLWINDOW
                    | win32con.WS_EX_NOACTIVATE,
                    _overlay_class_atom,
                    "xlounger drop overlay",
                    win32con.WS_POPUP | win32con.WS_VISIBLE,
                    left,
                    top,
                    width,
                    height,
                    owner_hwnd,
                    0,
                    win32gui.GetModuleHandle(None),
                    None,
                )
                # Alpha 1 = praktisch unsichtbar; HTTRANSPARENT (WndProc):
                # Maus/Klick geht zu den Tk-Zellen darunter — kein WS_EX_TRANSPARENT,
                # sonst nimmt OLE Desktop-Drags oft nicht an.
                win32gui.SetLayeredWindowAttributes(hwnd, 0, 1, win32con.LWA_ALPHA)
                win32gui.SetWindowPos(
                    hwnd,
                    win32con.HWND_TOPMOST,
                    0,
                    0,
                    0,
                    0,
                    win32con.SWP_NOMOVE
                    | win32con.SWP_NOSIZE
                    | win32con.SWP_NOACTIVATE
                    | win32con.SWP_SHOWWINDOW,
                )
                _overlay_registered_count += 1
                return hwnd
            except Exception as exc:
                _logging.error("Overlay CreateWindowEx Fehler: %s", exc)
                return 0

        def get_paths(self):
            items = []
            while True:
                try:
                    items.append(self._queue.get_nowait())
                except queue.Empty:
                    break
            return items

        def sync(self):
            if not self._overlay_owned:
                return
            if not self.hwnd or not win32gui.IsWindow(self.hwnd):
                return
            if not win32gui.IsWindow(self.owner_hwnd):
                return
            try:
                if not win32gui.IsWindowVisible(self.owner_hwnd):
                    # Leiste versteckt/zurueckgezogen -> Overlay mit verstecken,
                    # sonst liegt eine unsichtbare Fangflaeche ueber dem Desktop
                    # und frisst dort Drops (25.09.2026: "blockiert Desktop-Drops").
                    win32gui.SetWindowPos(
                        self.hwnd,
                        win32con.HWND_BOTTOM,
                        0, 0, 0, 0,
                        win32con.SWP_NOMOVE | win32con.SWP_NOSIZE
                        | win32con.SWP_NOACTIVATE | win32con.SWP_HIDEWINDOW,
                    )
                    return
                left, top, right, bottom = win32gui.GetWindowRect(self.owner_hwnd)
                win32gui.SetWindowPos(
                    self.hwnd,
                    win32con.HWND_TOPMOST,
                    left,
                    top,
                    right - left,
                    bottom - top,
                    win32con.SWP_NOACTIVATE | win32con.SWP_SHOWWINDOW,
                )
            except Exception as exc:
                _logging.warning("Overlay sync Fehler: %s", exc)

        def close(self):
            if self._wrapped:
                for h, _w in self._wrapped:
                    try:
                        pythoncom.RevokeDragDrop(h)
                    except Exception:
                        pass
                    _ole_targets.pop(h, None)
                self._wrapped = []
            if self.hwnd:
                if self.hwnd in _ole_targets:
                    try:
                        del _ole_targets[self.hwnd]
                    except Exception:
                        pass
                if self._overlay_owned:
                    try:
                        win32gui.DestroyWindow(self.hwnd)
                    except Exception:
                        pass
                self.hwnd = 0
            if not self._overlay_owned:
                return
            global _overlay_class_atom, _overlay_registered_count
            _overlay_registered_count -= 1
            if _overlay_registered_count <= 0 and _overlay_class_atom is not None:
                try:
                    win32gui.UnregisterClass(
                        _overlay_class_atom, win32gui.GetModuleHandle(None)
                    )
                except Exception:
                    pass
                _overlay_class_atom = None
                _overlay_registered_count = 0
