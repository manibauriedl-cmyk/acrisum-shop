"""Windows-Taskleisten-Integration (KVA 220–224).

- AUMID „xlounger" (KVA 224): Taskleiste gruppiert Fenster + Pin zusammen.
- Anheften (KVA 220): offizieller WinRT-Weg braucht Paket-Identitaet (MSIX)
  — fuer eine lose Python-App nicht vorhanden. Ehrlich pruefen, nicht raten.
- Fallback (KVA 221): Verknuepfung mit AUMID-Property in
  „User Pinned\\TaskBar" — wird nach Explorer-Neustart sichtbar.
- Win 8.1 (KVA 222): Anheften nicht moeglich (OS-Grenze) — Aufrufer zeigt
  die manuelle Anleitung (KVA 223).
"""
from __future__ import annotations

import ctypes
import gc
import logging
import os
import sys
from pathlib import Path

from .app_id import APP_NAME

ROOT = Path(__file__).resolve().parent.parent
AUMID = APP_NAME


def aumid_setzen(aumid: str = AUMID) -> bool:
    """KVA 224 — eigene AppUserModelID fuer diesen Prozess."""
    try:
        hr = ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(aumid)
        if hr == 0:
            logging.info("AUMID gesetzt: %s", aumid)
            return True
        logging.warning("SetCurrentProcessExplicitAppUserModelID hr=0x%x", hr & 0xFFFFFFFF)
    except Exception as exc:
        logging.warning("AUMID konnte nicht gesetzt werden: %s", exc)
    return False


def anheften_moeglich() -> bool:
    """KVA 222 — Anheften an die Taskleiste braucht Windows 10+."""
    try:
        return sys.getwindowsversion().major >= 10
    except Exception:
        return False


def hat_paket_identitaet() -> bool:
    """True wenn die App MSIX-Identitaet hat (Voraussetzung fuer WinRT-Pin)."""
    try:
        laenge = ctypes.c_ulong(0)
        rc = ctypes.windll.kernel32.GetCurrentPackageFullName(
            ctypes.byref(laenge), None
        )
        # ERROR_INSUFFICIENT_BUFFER (122) = Identitaet vorhanden
        return rc == 122
    except Exception:
        return False


def taskleisten_link_pfad() -> Path:
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return (
        Path(base)
        / "Microsoft"
        / "Internet Explorer"
        / "Quick Launch"
        / "User Pinned"
        / "TaskBar"
        / f"{APP_NAME}.lnk"
    )


def lnk_aumid_setzen(pfad: Path) -> bool:
    """AUMID-Property auf eine .lnk schreiben (IPropertyStore).

    Damit gruppiert die Taskleiste Pin und laufendes Fenster zusammen.
    """
    try:
        from win32com import storagecon
        from win32com.propsys import propsys, pscon

        store = propsys.SHGetPropertyStoreFromParsingName(
            str(pfad), None, storagecon.STGM_READWRITE, propsys.IID_IPropertyStore
        )
        store.SetValue(pscon.PKEY_AppUserModel_ID, propsys.PROPVARIANTType(AUMID))
        store.Commit()
        return True
    except Exception as exc:
        logging.warning("AUMID-Property an %s fehlgeschlagen: %s", pfad, exc)
        return False


def _pin_link_erstellen(pfad: Path) -> bool:
    """Verknuepfung xlounger.lnk (pythonw + xx1lounger.py) mit AUMID anlegen."""
    try:
        import win32com.client

        import xx1lounger_prozess

        pfad.parent.mkdir(parents=True, exist_ok=True)
        sc = win32com.client.Dispatch("WScript.Shell").CreateShortcut(str(pfad))
        sc.TargetPath = xx1lounger_prozess.pythonw()
        sc.Arguments = f'"{ROOT / "xx1lounger.py"}"'
        sc.WorkingDirectory = str(ROOT)
        sc.Description = f"{APP_NAME} — Leiste"
        ico = ROOT / "assets" / "xlounger.ico"
        if ico.is_file():
            sc.IconLocation = f"{ico},0"
        sc.Save()
        # COM-Objekt freigeben — sonst sperrt es die Datei fuer IPropertyStore
        sc = None
        gc.collect()
        lnk_aumid_setzen(pfad)
        return True
    except Exception as exc:
        logging.error("Taskleisten-Verknuepfung fehlgeschlagen: %s", exc)
        return False


def an_taskleiste_anheften() -> str:
    """KVA 220/221/222 — an Taskleiste anheften.

    Rueckgabe: "winrt" | "fallback" | "bereits" | "os-grenze" | "fehler".
    """
    if not anheften_moeglich():
        logging.info("Taskleisten-Pin: OS zu alt (Win 8.1-Grenze, KVA 222)")
        return "os-grenze"

    pfad = taskleisten_link_pfad()
    if pfad.is_file():
        return "bereits"

    if hat_paket_identitaet():
        # Offizieller Weg (KVA 220) — nur mit MSIX-Identitaet moeglich.
        try:
            import asyncio

            from windows.ui.startscreen import TaskbarManager  # type: ignore

            asyncio.run(TaskbarManager.request_pin_current_app_async())
            logging.info("Taskleisten-Pin per WinRT angefragt")
            return "winrt"
        except Exception as exc:
            logging.warning("WinRT-Pin fehlgeschlagen, Fallback: %s", exc)

    # KVA 221 — Fallback: .lnk im „User Pinned\\TaskBar"-Ordner.
    # Wird erst nach Explorer-Neustart sichtbar (Shell liest den Ordner
    # nur beim Start) — bewusst KEIN automatischer Explorer-Neustart.
    if _pin_link_erstellen(pfad):
        logging.info(
            "Taskleisten-Pin als Verknuepfung abgelegt (sichtbar nach "
            "Explorer-Neustart): %s",
            pfad,
        )
        return "fallback"
    return "fehler"
