"""Zentrale Geometrie-Berechnung für xlounger.

Hier werden Monitor, Dock-Position, Snap-Zonen, Inhaltslänge,
Überlauf und AppBar-Streifen-Größen berechnet. Keine UI-Logik.
"""
from __future__ import annotations

from .appbar import ABE_LEFT, ABE_TOP, ABE_RIGHT, ABE_BOTTOM


# Dock-Kanten
DOCK_TOP = "top"
DOCK_BOTTOM = "bottom"
DOCK_LEFT = "left"
DOCK_RIGHT = "right"
DOCK_TOP_LEFT = "top_left"
DOCK_TOP_RIGHT = "top_right"
DOCK_BOTTOM_LEFT = "bottom_left"
DOCK_BOTTOM_RIGHT = "bottom_right"
DOCK_FREE = "none"

DOCK_HORIZONTAL = frozenset({
    DOCK_TOP, DOCK_BOTTOM,
    DOCK_TOP_LEFT, DOCK_TOP_RIGHT,
    DOCK_BOTTOM_LEFT, DOCK_BOTTOM_RIGHT,
})
DOCK_VERTICAL = frozenset({DOCK_LEFT, DOCK_RIGHT})
DOCK_EDGE = frozenset({DOCK_TOP, DOCK_BOTTOM, DOCK_LEFT, DOCK_RIGHT})
DOCK_CORNER = frozenset({
    DOCK_TOP_LEFT, DOCK_TOP_RIGHT,
    DOCK_BOTTOM_LEFT, DOCK_BOTTOM_RIGHT,
})
DOCK_ALL = DOCK_HORIZONTAL | DOCK_VERTICAL | {DOCK_FREE}

EDGES = {
    DOCK_LEFT: ABE_LEFT,
    DOCK_TOP: ABE_TOP,
    DOCK_RIGHT: ABE_RIGHT,
    DOCK_BOTTOM: ABE_BOTTOM,
    DOCK_TOP_LEFT: ABE_TOP,
    DOCK_TOP_RIGHT: ABE_TOP,
    DOCK_BOTTOM_LEFT: ABE_BOTTOM,
    DOCK_BOTTOM_RIGHT: ABE_BOTTOM,
}

# Snap-/Zonen-Parameter
SNAP_PX = 40
SNAP_SIDE_PX = 60
ZONE_FRACTION = 0.10
ZONE_FRACTION_LEFT = 0.10
# Quer (oben/unten): 10 % — Kompromiss zwischen „zu viel Kleb" (alte
# 20 %, Launcher 1.2.10) und „unbrauchbar eng" (5 %, 05.10.2026 —
# Loslassen bei y=105 ging still frei, Nutzer 07.10.2026).
ZONE_FRACTION_Y = 0.10
# Andock-Zone am physischen Bildschirmrand: 10 pt bei 96 dpi ≈ 13 px
# (Nutzer 04.10.2026: „die leiste darf erst zurueckspringen wenn sie links
# 10pt von linkenrand" — die alte 20-%-Zone war viel zu breit).
EDGE_DOCK_PX = 13
GESTURE_PX = 16
DRAG_START_PX = 6  # Griff-Zug früher als Dock-Geste (GESTURE_PX)
MIN_DOCK_THICKNESS = 40
# Horizontale Leiste: Mindesthoehe deutlich kleiner, damit sie der Icon-Zeile
# folgt statt stur 40 px (Totraum unter den Icons, Nutzer 28.09.2026:
# „nur diese Hoehe"). 18 px bleibt klickbar. Gilt NUR fuer die Hoehe im
# else-Zweig von clamp_bar_geometry — die senkrechte Breite/Dicke bleibt 40.
MIN_DOCK_THICKNESS_H = 18
MIN_CONTENT_LENGTH = 80
TASKLEISTE_LUFT_PX = 8
# Frei schwebende Leiste: darf ueber die Arbeitsflaeche ragen (z. B. Teil
# unter der Taskleiste), aber mindestens so viele px muessen im
# Arbeitsbereich sichtbar bleiben — sonst waere der Griff unerreichbar
# und die Leiste „im Nirwana" (Nutzer 06.10.2026).
FREI_MIN_SICHT = 96


def is_horizontal(dock: str) -> bool:
    return dock in DOCK_HORIZONTAL


def edge_for_dock(dock: str) -> int | None:
    return EDGES.get(dock)


def _monitor_tuple(monitor):
    if monitor is None:
        return (0, 0, 1920, 1080)
    rect = getattr(monitor, "rect", None)
    if rect is not None:
        return (rect.left, rect.top, rect.right, rect.bottom)
    work = getattr(monitor, "work", None)
    if work is not None:
        return (work.left, work.top, work.right, work.bottom)
    return (0, 0, 1920, 1080)


def _work_tuple(monitor):
    if monitor is None:
        return (0, 0, 1920, 1040)
    return (monitor.work.left, monitor.work.top, monitor.work.right, monitor.work.bottom)


def detect_dock(
    drop_x: int,
    drop_y: int,
    monitor,
    *,
    start_x: int | None = None,
    start_y: int | None = None,
    current_dock: str = DOCK_FREE,
    bar_width: int = 700,
    bar_height: int = 120,
    bar_x: int | None = None,
    bar_y: int | None = None,
    form_w: int | None = None,
    form_h: int | None = None,
    rand_verankert: bool = True,
) -> str:
    """Entscheidet, wohin die Leiste andockt, basierend auf der Loslass-Position.

    Nur Mausposition + Arbeitsfläche: eigene Kante klebt, Rand-Gürtel dockt.
    Leistenkante nur bei ``DOCK_FREE``.
    """
    sl, st, sr, sb = _monitor_tuple(monitor)
    wl, wt, wr, wb = _work_tuple(monitor)
    px = int(drop_x)
    py = int(drop_y)
    von = current_dock if current_dock in DOCK_ALL else DOCK_FREE

    # Nur-Klick-Erkennung: Ausserhalb einer Zone bleibt ein Wackler ein
    # Klick — keine Entscheidung. Steht der Zeiger dagegen IN einer
    # Andock-Zone, zaehlt der Ort fuer eine FREIE Leiste trotzdem:
    # an der Kante kann der Griff nicht „tiefer" geschoben werden, ein
    # kurzer Wackler muss anheften duerfen (Nutzer 07.10.2026).
    dx = dy = 0
    if start_x is not None and start_y is not None:
        dx = px - int(start_x)
        dy = py - int(start_y)
    am_phys_rand = (py - st <= 4) or (sb - py <= 4) or (px - sl <= 4) or (sr - px <= 4)
    klick = abs(dx) < GESTURE_PX and abs(dy) < GESTURE_PX and not am_phys_rand
    if klick and von != DOCK_FREE:
        return von

    # Ausserhalb (Taskleiste / 1 px ueber den Rand, zittrige Hand):
    # auf den Monitor klemmen und die naechste Kante nehmen — nicht zurueck
    # auf die Startkante (sonst: ganz unten loslassen -> Sprung nach oben).
    if not (sl <= px < sr and st <= py < sb):
        px = min(max(px, sl), sr - 1)
        py = min(max(py, st), sb - 1)

    wi, hi = int(bar_width), int(bar_height)
    if von == DOCK_LEFT:
        wl = min(wl, max(sl, wl - wi))
    elif von == DOCK_RIGHT:
        wr = max(wr, min(sr, wr + wi))
    elif von in (DOCK_TOP, DOCK_TOP_LEFT, DOCK_TOP_RIGHT):
        wt = min(wt, max(st, wt - hi))
    elif von in (DOCK_BOTTOM, DOCK_BOTTOM_LEFT, DOCK_BOTTOM_RIGHT):
        wb = max(wb, min(sb, wb + hi))

    dl = max(0, px - wl)
    dr = max(0, wr - px)
    dt = max(0, py - wt)
    db = max(0, wb - py)

    ecke_ok = wi < max(220, int((sr - sl) * 0.35))
    # Senkrecht-Form: rein die gezogene/ablagebereite Form zaehlt (h >= 2w),
    # nicht der Dock-Status — ein links angedockter 88x80-Stummel ist fuer
    # den Nutzer ein normales Kästchen und darf weiter ueberall andocken.
    # Die Startform kommt mit: ein an der Kante geschrumpfter Rest bleibt
    # senkrecht (Nutzer 06.10.2026).
    fw = int(form_w) if form_w is not None else wi
    fh = int(form_h) if form_h is not None else hi
    senkrecht = hi >= max(80, wi * 2) or fh >= max(80, fw * 2)
    if ecke_ok and not senkrecht:
        if dt <= SNAP_PX and dl <= SNAP_PX:
            return DOCK_TOP_LEFT
        if dt <= SNAP_PX and dr <= SNAP_PX:
            return DOCK_TOP_RIGHT
        if db <= SNAP_PX and dl <= SNAP_PX:
            return DOCK_BOTTOM_LEFT
        if db <= SNAP_PX and dr <= SNAP_PX:
            return DOCK_BOTTOM_RIGHT

    zone_x = max(SNAP_SIDE_PX, int((sr - sl) * ZONE_FRACTION))
    zone_left = max(SNAP_SIDE_PX, int((sr - sl) * ZONE_FRACTION_LEFT))
    zone_y = max(SNAP_PX, int((sb - st) * ZONE_FRACTION_Y))
    # Alle Seiten 10 % (Kompromiss, Nutzer 07.10.2026): Andocken erst im
    # Randstreifen; ausserhalb nur Status quo, keine vorzeitige
    # Entscheidung. 5 % war zu eng — echte Absicht ging still frei.
    zonen = {
        DOCK_TOP: zone_y,
        DOCK_BOTTOM: zone_y,
        DOCK_LEFT: zone_left,
        DOCK_RIGHT: zone_x,
    }
    zu_rand = {DOCK_TOP: dt, DOCK_BOTTOM: db, DOCK_LEFT: dl, DOCK_RIGHT: dr}
    in_zone = {k: v for k, v in zu_rand.items() if v <= zonen[k]}
    if klick and not in_zone:
        return von
    if not in_zone:
        pdl = max(0, px - sl)
        pdr = max(0, sr - px)
        pdt = max(0, py - st)
        pdb = max(0, sb - py)
        if bar_x is not None:
            bx = int(bar_x)
            # Arbeitsflaeche mitzaehlen: haelt eine fremde Leiste den
            # physischen Rand, endet die gezogene Leiste am Work-Rand —
            # sonst ist die Kante fuer breite Leisten nie erreichbar.
            # Tiefer Ueberstand zaehlt NICHT als „am Rand" — eine bewusst
            # hinter die Arbeitsflaeche gelegte Leiste muesste sonst beim
            # Loslassen sofort wieder andocken (Nutzer 06.10.2026).
            for d_abst in (bx - sl, bx - wl):
                if d_abst >= -EDGE_DOCK_PX:
                    pdl = min(pdl, max(0, d_abst))
            for d_abst in (sr - (bx + wi), wr - (bx + wi)):
                if d_abst >= -EDGE_DOCK_PX:
                    pdr = min(pdr, max(0, d_abst))
        if bar_y is not None:
            by = int(bar_y)
            for d_abst in (by - st, by - wt):
                if d_abst >= -EDGE_DOCK_PX:
                    pdt = min(pdt, max(0, d_abst))
            for d_abst in (sb - (by + hi), wb - (by + hi)):
                if d_abst >= -EDGE_DOCK_PX:
                    pdb = min(pdb, max(0, d_abst))
        zu_phys = {
            DOCK_TOP: pdt,
            DOCK_BOTTOM: pdb,
            DOCK_LEFT: pdl,
            DOCK_RIGHT: pdr,
        }
        # Leistenrand zaehlt wie der Zeiger: dieselbe 5-%-Zone — „5 %
        # Entfernung von der Leiste", nicht nur Cursor-Naehe (Nutzer 05.10.2026:
        # breite Leiste am Griff packen -> Rand in Reichweite, Zeiger aber
        # mitten in der Leiste -> dockte nicht). Angedockte Leisten: nur
        # Fremdkanten — die eigene verlaesst sie per Zeiger (sonst klebt
        # z. B. eine Top-Leiste dauerhaft oben fest).
        cand = {k: v for k, v in zu_phys.items() if v <= zonen[k]}
        # Ankerkante der Freiform ausnehmen (senkrechte Form: unten, quer:
        # rechts): die „immer bis Arbeitsbereich"-Regel (Nutzer 07.10.2026)
        # legt die Leistenkante dort zwangslaeufig auf 0 — keine Andock-
        # Absicht. Der Zeiger in der Zone dockt weiterhin (Zeilen oben).
        # Gilt nur, wenn die Regel wirklich streckt (rand_verankert —
        # Alle-Modus). Bei Slot-Fixzahl bleibt die Leiste kompakt: ihre
        # Kante am Arbeitsbereich-Rand ist echte Absicht (Nutzer
        # 07.10.2026: „unten andocken geht nicht bei slots").
        if rand_verankert:
            cand.pop(DOCK_BOTTOM if hi > wi else DOCK_RIGHT, None)
        if von == DOCK_FREE:
            in_zone = cand
        else:
            in_zone = {k: v for k, v in cand.items() if k != von}
    if not in_zone:
        return DOCK_FREE
    if von in in_zone:
        return von
    return min(in_zone, key=in_zone.get)


def dock_rect(
    dock: str,
    monitor,
    thickness: int,
    content_length: int | None = None,
    *,
    anchor_x: int | None = None,
    anchor_y: int | None = None,
):
    """Berechnet Position und Größe der Leiste für eine Dock-Position.

    Rückgabe: (x, y, w, h, orientation)
    """
    sl, st, sr, sb = _monitor_tuple(monitor)
    wl, wt, wr, wb = _work_tuple(monitor)
    # Dicke orientierungsabhaengig clampen: senkrecht (Breite) min 40 (klickbar),
    # waagerecht (Hoehe) min 18 — folgt der Icon-Zeile, kein leerer Streifen
    # unter den Icons (Totraum, Nutzer 28.09.2026: „nur diese Hoehe").
    _min_thick = MIN_DOCK_THICKNESS if dock in (DOCK_LEFT, DOCK_RIGHT) else MIN_DOCK_THICKNESS_H
    thick = max(_min_thick, int(thickness))

    if dock in (DOCK_LEFT, DOCK_RIGHT):
        orient = "vertical"
        x = sl if dock == DOCK_LEFT else sr - thick
        w = thick
        full_h = sb - st
        if content_length is not None:
            h = max(MIN_CONTENT_LENGTH, min(int(content_length), full_h))
        else:
            h = full_h
        y = st
        if anchor_y is not None:
            y = max(st, min(int(anchor_y), sb - max(60, h)))
    elif dock in (DOCK_TOP, DOCK_BOTTOM):
        orient = "horizontal"
        x = int(wl)
        if anchor_x is not None:
            x = max(int(wl), min(int(anchor_x), int(wr) - 80))
        y = st if dock == DOCK_TOP else sb - thick
        max_w = max(MIN_CONTENT_LENGTH, int(wr) - x)
        if content_length is not None:
            w = max(MIN_CONTENT_LENGTH, min(int(content_length), max_w))
        else:
            w = max_w
        h = thick
    elif dock in DOCK_CORNER:
        orient = "horizontal"
        span = max(MIN_CONTENT_LENGTH, int(wr) - int(wl))
        length = content_length if content_length is not None else span
        length = max(MIN_CONTENT_LENGTH, min(int(length), span))
        h = thick
        if "top" in dock:
            y = st
        else:
            y = sb - thick
        if "left" in dock:
            x = int(wl)
        elif "right" in dock:
            x = int(wr) - length
        else:
            x = int(wl)
        w = length
    else:
        # Frei
        orient = "horizontal"
        x = wl + (wr - wl - 700) // 2
        y = wt + (wb - wt - 120) // 2
        w = 700
        h = 120

    return int(x), int(y), int(w), int(h), orient


def strip_echo_y_top(monitor, strip_st: int, default_y: int) -> int:
    """Launcher 2.16 — Streifen-Echo: strip.top ≈ work.top → blauer Spalt oben."""
    sl0, st0, _sr0, _sb0 = _monitor_tuple(monitor)
    _wl, wt, _wr, _wb = _work_tuple(monitor)
    st = int(strip_st)
    y = int(default_y)
    # Fremde AppBar oben — Streifen nicht an work.top kleben lassen
    if st < int(wt) - 2:
        return y
    if abs(st - int(wt)) <= 2 and st > int(st0) + 2:
        return int(st0)
    if abs(st - int(wt)) <= 2 and int(wt) <= int(st0) + 2 and st > int(st0) + 2:
        return int(st0)
    return y


def strip_echo_y_bottom(
    monitor, strip_st: int, strip_sh: int, bar_h: int, default_y: int
) -> int:
    """Launcher 2.16 — analog unten: Echo an work.bottom statt physischem Rand."""
    _sl0, _st0, _sr0, sb0 = _monitor_tuple(monitor)
    _wl, _wt, _wr, wb = _work_tuple(monitor)
    strip_bottom = int(strip_st) + int(strip_sh)
    y = int(default_y)
    if abs(strip_bottom - int(wb)) <= 2:
        return int(wb) - int(bar_h)
    return y


def position_in_strip(
    dock: str,
    w: int,
    h: int,
    x: int,
    y: int,
    strip: tuple[int, int, int, int],
    monitor=None,
) -> tuple[int, int, int, int]:
    """Leiste im reservierten AppBar-Streifen positionieren."""
    sl, st, sw, sh = strip
    sr = sl + sw
    sb = st + sh
    w = min(max(1, int(w)), max(1, sw))
    if dock not in (DOCK_LEFT, DOCK_RIGHT):
        h = min(max(1, int(h)), max(1, sh))

    def _y_top() -> int:
        y0 = int(st)
        if monitor is not None:
            y0 = strip_echo_y_top(monitor, st, y0)
        return y0

    def _y_bottom() -> int:
        y0 = int(sb) - int(h)
        if monitor is not None:
            y0 = strip_echo_y_bottom(monitor, st, sh, h, y0)
        return y0

    if dock == DOCK_TOP_LEFT:
        return w, h, sl, _y_top()
    if dock == DOCK_TOP_RIGHT:
        return w, h, sr - w, _y_top()
    if dock == DOCK_BOTTOM_LEFT:
        return w, h, sl, _y_bottom()
    if dock == DOCK_BOTTOM_RIGHT:
        return w, h, sr - w, _y_bottom()
    if dock == DOCK_TOP:
        # Anker X halten, Breite kuerzen — nicht x auf Streifenanfang (sl)
        # zwingen, nur weil w noch die volle Kante ist (KVA 35 / Regel 38).
        px = max(sl, min(int(x), sr - MIN_CONTENT_LENGTH))
        cur_w = min(max(MIN_CONTENT_LENGTH, int(w)), max(1, sr - px))
        return cur_w, h, px, _y_top()
    if dock == DOCK_BOTTOM:
        px = max(sl, min(int(x), sr - MIN_CONTENT_LENGTH))
        cur_w = min(max(MIN_CONTENT_LENGTH, int(w)), max(1, sr - px))
        return cur_w, h, px, _y_bottom()
    if dock == DOCK_LEFT:
        # Anker Y halten, Hoehe kuerzen — nicht y auf Streifenanfang (st)
        # zwingen, nur weil h noch die volle Kante ist (KVA 35 / Regel 38).
        py = max(st, min(int(y), sb - MIN_CONTENT_LENGTH))
        h = min(max(MIN_CONTENT_LENGTH, int(h)), max(1, sb - py))
        return w, h, sl, py
    if dock == DOCK_RIGHT:
        py = max(st, min(int(y), sb - MIN_CONTENT_LENGTH))
        h = min(max(MIN_CONTENT_LENGTH, int(h)), max(1, sb - py))
        return w, h, sr - w, py
    return w, h, int(x), int(y)


def snap_to_dock_strip(
    x: int,
    y: int,
    w: int,
    h: int,
    dock: str,
    strip: tuple[int, int, int, int],
) -> tuple[int, int, int, int]:
    """Fenster an den von der Shell zugeteilten Streifen klemmen — nicht am physischen Rand.

    Fremde AppBars (PowerToys, andere Leisten) liegen oft am Monitorrand; QUERYPOS/SETPOS
    rückt unseren Streifen nach innen. Physisches sr-/sl-Snap würde sie überdecken.
    """
    sl, st, sw, sh = strip
    sr = sl + int(sw)
    sb = st + int(sh)
    w = min(max(1, int(w)), max(1, int(sw)))
    h = min(max(1, int(h)), max(1, int(sh)))
    if dock == DOCK_TOP_LEFT:
        return sl, st, w, h
    if dock == DOCK_TOP_RIGHT:
        return sr - w, st, w, h
    if dock == DOCK_BOTTOM_LEFT:
        return sl, sb - h, w, h
    if dock == DOCK_BOTTOM_RIGHT:
        return sr - w, sb - h, w, h
    if dock == DOCK_TOP:
        px = max(sl, min(int(x), sr - MIN_CONTENT_LENGTH))
        w = min(max(1, int(w)), max(1, sr - px))
        return px, st, w, h
    if dock == DOCK_BOTTOM:
        px = max(sl, min(int(x), sr - MIN_CONTENT_LENGTH))
        w = min(max(1, int(w)), max(1, sr - px))
        return px, sb - h, w, h
    if dock == DOCK_LEFT:
        py = max(st, min(int(y), sb - MIN_CONTENT_LENGTH))
        h = min(max(1, int(h)), max(1, sb - py))
        return sl, py, w, h
    if dock == DOCK_RIGHT:
        py = max(st, min(int(y), sb - MIN_CONTENT_LENGTH))
        h = min(max(1, int(h)), max(1, sb - py))
        return sr - w, py, w, h
    return int(x), int(y), w, h


def appbar_strip_rect(dock: str, monitor, thickness: int):
    """Rechteck für SHAppBarMessage: reserviert den ganzen Streifen."""
    sl, st, sr, sb = _monitor_tuple(monitor)
    # Waagerecht (Hoehe) folgt der Icon-Zeile (min 18), senkrecht (Breite) min 40
    # — sonst haengt unter den Icons ein leerer Streifen (Nutzer 28.09.2026).
    _min_thick = MIN_DOCK_THICKNESS if dock in (DOCK_LEFT, DOCK_RIGHT) else MIN_DOCK_THICKNESS_H
    thick = max(_min_thick, int(thickness))

    if dock in (DOCK_LEFT,):
        return sl, st, thick, sb - st
    if dock in (DOCK_RIGHT,):
        return sr - thick, st, thick, sb - st
    if dock in (DOCK_TOP, DOCK_TOP_LEFT, DOCK_TOP_RIGHT):
        return sl, st, sr - sl, thick
    if dock in (DOCK_BOTTOM, DOCK_BOTTOM_LEFT, DOCK_BOTTOM_RIGHT):
        return sl, sb - thick, sr - sl, thick

    return None


def content_length_for_entries(
    entry_count: int,
    icon_size: int,
    labels: bool,
    header_width: int = 60,
    slot_limit: int | None = None,
    measured_widths: list[int] | None = None,
) -> int:
    """Inhaltslänge berechnen.

    Wenn measured_widths übergeben wird (eine Breite pro sichtbarem
    Entry-Button, gemessen nach pack/update_idletasks), wird die
    Summe der echten Breiten genommen. Sonst Fallback-Schätzung.
    """
    if entry_count <= 0:
        return max(MIN_CONTENT_LENGTH, header_width + 40)

    if slot_limit is not None:
        entry_count = min(entry_count, max(0, slot_limit))

    if measured_widths:
        total_items = sum(measured_widths[:entry_count])
    else:
        item_width = icon_size + 12
        if labels:
            item_width = max(item_width, icon_size + 40)
        total_items = entry_count * item_width

    total = header_width + total_items + 20
    return max(MIN_CONTENT_LENGTH, total)


def fremd_leisten_ueberlapp_kanten(
    x: int,
    y: int,
    w: int,
    h: int,
    dock: str,
    monitor,
    *,
    luft: int = 2,
) -> list[str]:
    """Kanten, an denen das Fenster in *fremde* rcWork-Insets ragt.

    Die eigene Dock-Kante darf im eigenen Streifen liegen (oben andocken:
    y=0 trotz work.top). Links/rechts einer oberen Leiste zaehlen als fremd
    (andere AppBar). Messung, kein Raten — Nutzer 05.10.2026.
    """
    wl, wt, wr, wb = _work_tuple(monitor)
    d = dock if dock in DOCK_ALL else DOCK_FREE
    eigene_l = d in (DOCK_LEFT, DOCK_TOP_LEFT, DOCK_BOTTOM_LEFT)
    eigene_r = d in (DOCK_RIGHT, DOCK_TOP_RIGHT, DOCK_BOTTOM_RIGHT)
    eigene_o = d in (DOCK_TOP, DOCK_TOP_LEFT, DOCK_TOP_RIGHT)
    eigene_u = d in (DOCK_BOTTOM, DOCK_BOTTOM_LEFT, DOCK_BOTTOM_RIGHT)
    if d == DOCK_FREE:
        eigene_l = eigene_r = eigene_o = eigene_u = False
    kanten: list[str] = []
    xi, yi, wi, hi = int(x), int(y), int(w), int(h)
    if not eigene_l and xi < int(wl) - luft:
        kanten.append("links")
    if not eigene_r and xi + wi > int(wr) + luft:
        kanten.append("rechts")
    if not eigene_o and yi < int(wt) - luft:
        kanten.append("oben")
    if not eigene_u and yi + hi > int(wb) + luft:
        kanten.append("unten")
    return kanten


def available_horizontal_span(
    monitor,
    bar_x: int,
    bar_width: int,
    dock: str,
) -> int:
    """KVA 31/29: verfuegbare Breite ab Leistenposition bis rechter Rand.
    
    Entkoppelt von fremden Leisten (z. B. andere AppBar rechts/links):
    Horizontale Docks und Monitorkanten nutzen die physische Bildschirmbreite (sr - sl).
    """
    wl, wt, wr, wb = _work_tuple(monitor)
    sl, st, sr, sb = _monitor_tuple(monitor)
    if dock in (DOCK_TOP, DOCK_BOTTOM):
        x = max(sl, int(bar_x)) if bar_x is not None else sl
        x = max(int(wl), min(x, int(wr) - MIN_CONTENT_LENGTH))
        return max(MIN_CONTENT_LENGTH, int(wr) - x)
    if dock in DOCK_VERTICAL:
        thick = max(MIN_DOCK_THICKNESS, int(bar_width) if bar_width > 0 else MIN_DOCK_THICKNESS)
        return max(MIN_CONTENT_LENGTH, thick)
    if dock in DOCK_CORNER:
        if "right" in dock:
            length = max(MIN_CONTENT_LENGTH, min(int(bar_width) if bar_width > 0 else sr - sl, sr - sl))
            return length
        return max(MIN_CONTENT_LENGTH, sr - sl)
    x = max(sl, int(bar_x))
    return max(MIN_CONTENT_LENGTH, sr - x)


def float_bar_width_at(monitor, bar_x: int, content_width: int) -> int:
    """KVA 35: freie Leiste — Breite aus Sollposition bis rechter Arbeitsflaechen-Rand."""
    max_w = available_horizontal_span(monitor, bar_x, content_width, DOCK_FREE)
    return min(max(int(content_width), MIN_CONTENT_LENGTH), max_w)


def available_vertical_span(
    monitor,
    bar_y: int,
    bar_height: int,
    dock: str,
) -> int:
    """KVA 37: verfuegbare Hoehe ab Leistenposition bis unterer Arbeitsflaechen-Rand.
    
    Entkoppelt von fremden Leisten:
    Vertikale Docks nutzen die physische Hoehe (sb - st).
    """
    wl, wt, wr, wb = _work_tuple(monitor)
    sl, st, sr, sb = _monitor_tuple(monitor)
    if dock in DOCK_VERTICAL:
        y = max(st, int(bar_y))
        return max(MIN_CONTENT_LENGTH, int(sb) - y - TASKLEISTE_LUFT_PX)
    if dock in (DOCK_TOP, DOCK_BOTTOM):
        thick = max(MIN_DOCK_THICKNESS, int(bar_height) if bar_height > 0 else MIN_DOCK_THICKNESS)
        return max(MIN_CONTENT_LENGTH, thick)
    y = max(st, int(bar_y))
    return max(MIN_CONTENT_LENGTH, sb - y)


def clamp_bar_geometry(
    x: int,
    y: int,
    w: int,
    h: int,
    monitor,
    dock: str = DOCK_FREE,
    *,
    ecken_andocken: bool = True,
    anker_halten: bool = False,
):
    """KVA 33/34: Fenster in Arbeitsflaeche halten (links/rechts/oben/unten).

    Edge-Docks duerfen auf der eigenen Dock-Achse bis an die physische Kante
    (sonst schwebt die Leiste in der Workarea, 24.09.2026). Auf der
    Längsachse gilt die gemessene Arbeitsfläche — fremde Leisten
    (fremde Leisten links/rechts) nicht überdecken (Nutzer 05.10.2026).
    """
    wl, wt, wr, wb = _work_tuple(monitor)
    sl, st, sr, sb = _monitor_tuple(monitor)
    if dock in (DOCK_TOP, DOCK_BOTTOM):
        if dock == DOCK_TOP:
            wt = st
        else:
            wb = sb
    elif dock in (DOCK_LEFT, DOCK_RIGHT):
        wt = st
        wb = sb
        if dock == DOCK_LEFT:
            wl = sl
        else:
            wr = sr
    elif dock in DOCK_CORNER:
        if "top" in dock:
            wt = st
        elif "bottom" in dock:
            wb = sb
    elif dock == DOCK_FREE:
        pass

    if anker_halten and dock in (DOCK_TOP, DOCK_BOTTOM):
        # Zug/Slide: Anker X nicht auf wl ziehen (sonst Griff-Sprung links/rechts).
        h = max(MIN_DOCK_THICKNESS_H, min(int(h), wb - wt))
        x = max(sl, min(int(x), int(wr) - MIN_CONTENT_LENGTH))
        w = max(MIN_CONTENT_LENGTH, min(int(w), max(1, int(wr) - x)))
        y = max(wt, min(int(y), wb - h))
        return x, y, w, h

    if dock in (DOCK_LEFT, DOCK_RIGHT):
        # Senkrechte Leiste: w = Dicke, h = Laenge. Die Breite darf NICHT auf
        # MIN_CONTENT_LENGTH (80) gezwungen werden — sonst bleibt die Leiste
        # 80 px breit, obwohl der Inhalt viel schmaler ist (Totraum,
        # Nutzer 28.09.2026: „diesen Platz braucht kein Mensch").
        w = max(MIN_DOCK_THICKNESS, min(int(w), wr - wl))
        h = max(MIN_CONTENT_LENGTH, min(int(h), wb - wt))
    else:
        w = max(MIN_CONTENT_LENGTH, min(int(w), wr - wl))
        # Horizontale Hoehe folgt dem Inhalt (Icon-Zeile), nicht der globalen
        # Mindest-Dicke 40 — sonst haengt unter den Icons ein leerer Streifen.
        h = max(MIN_DOCK_THICKNESS_H, min(int(h), wb - wt))
    if dock == DOCK_FREE:
        # Freie Ablage: die Leiste wird nie kleiner als gezogen/abgelegt —
        # die Position klemmt so, dass die ganze Leiste in der Arbeits-
        # flaeche bleibt: Griff (Anfang) UND das Inhaltsende (»N) muessen
        # sichtbar sein — kein Teil darf unter der Taskleiste verschwinden.
        x = max(int(wl), min(int(x), int(wr) - int(w)))
        y = max(int(wt), min(int(y), int(wb) - int(h)))
    else:
        x = max(wl, min(int(x), wr - w))
        y = max(wt, min(int(y), wb - h))
    if ecken_andocken:
        if dock in (DOCK_TOP_RIGHT, DOCK_BOTTOM_RIGHT):
            x = max(int(wl), int(wr) - int(w))
        elif dock in (DOCK_TOP_LEFT, DOCK_BOTTOM_LEFT):
            x = int(wl)
    return x, y, w, h


def clamp_length(
    length: int,
    monitor,
    dock: str,
    bar_x: int | None = None,
    bar_y: int | None = None,
) -> int:
    """Länge an Monitor/Arbeitsflaeche begrenzen (KVA 34)."""
    sl, st, sr, sb = _monitor_tuple(monitor)
    wl, wt, wr, wb = _work_tuple(monitor)
    if is_horizontal(dock):
        if bar_x is not None:
            x0 = max(int(wl), min(int(bar_x), int(wr) - MIN_CONTENT_LENGTH))
            max_w = max(MIN_CONTENT_LENGTH, int(wr) - x0)
        else:
            max_w = max(MIN_CONTENT_LENGTH, int(wr) - int(wl))
        return max(MIN_CONTENT_LENGTH, min(length, max_w))
    if bar_y is not None:
        max_h = max(MIN_CONTENT_LENGTH, sb - max(st, int(bar_y)))
    else:
        max_h = sb - st
    return max(MIN_CONTENT_LENGTH, min(length, max_h))


def visible_entry_count(entry_count: int, slot_limit: int | None = None) -> int:
    """slot_limit None = alle (Breite entscheidet); 0 = nur Griff/+ (KVA 64); n>0 = max n."""
    if slot_limit is None:
        return entry_count
    if slot_limit <= 0:
        return 0
    return min(entry_count, slot_limit)


def estimate_entry_width(icon_size: int, labels: bool) -> int:
    """Grobe Breite eines Symbol-Slots inkl. Beschriftung."""
    slot = icon_size + max(12, icon_size // 3)
    return slot + (6 if labels else 2)


def estimate_entry_height(icon_size: int, labels: bool) -> int:
    """Grobe Hoehe eines Symbol-Slots inkl. Beschriftung (senkrecht)."""
    h = icon_size + max(6, icon_size // 6)
    if labels:
        h += max(14, min(28, icon_size // 3)) + 4
    return h + 6


def visible_entries_for_width(
    entry_count: int,
    available_width: int,
    icon_size: int,
    labels: bool,
    header_width: int,
    slot_limit: int | None = None,
    item_widths: list[int] | None = None,
    overflow_button_width: int = 40,
) -> int:
    """Wie viele Eintraege in available_width passen; Rest geht ins >>-Menue."""
    if entry_count <= 0:
        return 0

    usable = max(0, int(available_width) - int(header_width) - 8)
    if item_widths:
        widths = list(item_widths[:entry_count])
    else:
        w = estimate_entry_width(icon_size, labels)
        widths = [w] * entry_count

    total = sum(widths)
    if total <= usable:
        visible = entry_count
    else:
        usable -= overflow_button_width
        visible = 0
        used = 0
        for w in widths:
            if used + w > usable:
                break
            used += w
            visible += 1
        if visible < 1 and entry_count > 0:
            visible = 1
    # Slot-Fixzahl = Nutzer-Obergrenze UEBER dem Platz-Fit (K1) —
    # kein Fruehreturn ohne Breitenrechnung (Nutzer 07.10.2026:
    # Laengen-/Breitenberechnung ist die feste Grundlage).
    if slot_limit is not None:
        visible = min(visible, visible_entry_count(entry_count, slot_limit))
    return visible


def estimate_overflow_button_width(n_rest: int) -> int:
    """»N-Knopf (ohne Tk-Font) — Tests + Naeherung."""
    n = max(1, int(n_rest))
    return max(48, 28 + len(str(n)) * 9)


def fit_horizontal_visible_count(
    entry_count: int,
    available_width: int,
    header_width: int,
    item_widths: list[int],
    overflow_width_fn=None,
    immer_ueberlauf: bool = False,
) -> int:
    """Max. sichtbare Eintraege bei fester Leistenbreite."""
    if entry_count <= 0:
        return 0
    if overflow_width_fn is None:
        overflow_width_fn = estimate_overflow_button_width
    widths = list(item_widths[:entry_count])
    if len(widths) < entry_count:
        pad_w = widths[-1] if widths else estimate_entry_width(24, True)
        widths.extend([pad_w] * (entry_count - len(widths)))
    n = entry_count
    keep = n
    keep_alt = -1
    for _ in range(n + 3):
        n_rest = max(0, n - keep)
        reserve = int(header_width) + 8
        if n_rest or immer_ueberlauf:
            # » steht auch bei Rest=0 da (»0) — Platz immer einrechnen.
            reserve += int(overflow_width_fn(max(1, n_rest)))
        budget = max(1, int(available_width) - reserve)
        acc = 0
        neu_keep = 0
        for w in widths:
            if acc + w > budget:
                break
            acc += w
            neu_keep += 1
        # keep darf 0 sein: reicht der Platz nicht einmal fuer einen Eintrag
        # NEBEN dem »-Knopf, wandern alle in den Ueberlauf — der Knopf darf
        # nie gequetscht/abgeschnitten werden (Nutzer 28.09.2026: »N muss auf
        # oben/unten/rechts/links gleich lesbar sein).
        neu_keep = max(0, min(neu_keep, n))
        if neu_keep == keep or neu_keep == keep_alt:
            keep = neu_keep
            break
        keep_alt = keep
        keep = neu_keep
    return keep


def fit_vertical_visible_count(
    entry_count: int,
    available_height: int,
    header_height: int,
    item_heights: list[int],
    overflow_height_fn=None,
    immer_ueberlauf: bool = False,
) -> int:
    """Senkrecht: max. sichtbare Eintraege bei fester Leistenhoehe."""
    if entry_count <= 0:
        return 0
    if overflow_height_fn is None:
        overflow_height_fn = lambda _n: 36
    heights = list(item_heights[:entry_count])
    if len(heights) < entry_count:
        pad_h = heights[-1] if heights else estimate_entry_height(24, True)
        heights.extend([pad_h] * (entry_count - len(heights)))
    n = entry_count
    keep = n
    keep_alt = -1
    for _ in range(n + 3):
        n_rest = max(0, n - keep)
        reserve = int(header_height) + 8
        if n_rest or immer_ueberlauf:
            reserve += int(overflow_height_fn(max(1, n_rest)))
        budget = max(1, int(available_height) - reserve)
        acc = 0
        neu_keep = 0
        for ht in heights:
            if acc + ht > budget:
                break
            acc += ht
            neu_keep += 1
        # keep darf 0 sein — siehe fit_horizontal_visible_count (»N lesbar).
        neu_keep = max(0, min(neu_keep, n))
        if neu_keep == keep or neu_keep == keep_alt:
            keep = neu_keep
            break
        keep_alt = keep
        keep = neu_keep
    return keep


def fenster_breite_nach_inhalt(
    req_w: int,
    pad: int = 6,
    breite_min: int | None = None,
) -> int:
    """Fit-Breite: Inhalt + optional Platzbudget (Zoom: Leiste lang lassen)."""
    w = max(MIN_CONTENT_LENGTH, int(req_w) + pad)
    if breite_min is not None:
        w = max(w, int(breite_min))
    return w


def leerstreifen_soll_schrumpfen(
    fenster_breite: int,
    inhalt_breite: int,
    pad: int = 12,
) -> bool:
    """Nur schrumpfen wenn echter gruener Rest — nicht bei Zoom."""
    if inhalt_breite <= 0:
        return False
    return int(fenster_breite) > int(inhalt_breite) + pad


def dialog_neben_leiste(
    bar_x: int,
    bar_y: int,
    bar_w: int,
    bar_h: int,
    dlg_w: int,
    dlg_h: int,
    screen_w: int,
    screen_h: int,
    *,
    vertical: bool,
    anchor_x: int | None = None,
    anchor_y: int | None = None,
    rand: int = 8,
) -> tuple[int, int]:
    """Dialog sinnvoll neben die Leiste setzen — egal wo sie dockt (28.09.2026).

    Senkrechte Leiste am rechten Rand  -> Dialog links daneben.
    Senkrechte Leiste am linken Rand   -> Dialog rechts daneben.
    Waagerechte Leiste unten           -> Dialog darueber, sonst darunter.
    Hoehe folgt dem Klickpunkt (anchor), Breite wird auf den Schirm geclamped.
    """
    if vertical:
        y = int(anchor_y) + 4 if anchor_y is not None else bar_y + 40
        # Bildschirmhaelfte statt physischem Rand: rechts der Leiste kann noch
        # etwas anderes liegen (zweite Leiste, Taskleiste) — 28.09.2026.
        if bar_x + bar_w // 2 >= screen_w // 2:
            x = bar_x - dlg_w - rand
        else:
            x = bar_x + bar_w + rand
    else:
        x = int(anchor_x) if anchor_x is not None else bar_x + (bar_w - dlg_w) // 2
        if bar_y + bar_h >= screen_h - rand:
            y = bar_y - dlg_h - rand
        else:
            y = bar_y + bar_h + 4
    x = max(4, min(x, screen_w - dlg_w - 4))
    y = max(4, min(y, screen_h - dlg_h - 4))
    return x, y


def dialog_neben_feld(
    feld_x: int,
    feld_y: int,
    feld_w: int,
    feld_h: int,
    dlg_w: int,
    dlg_h: int,
    screen_w: int,
    screen_h: int,
    *,
    anchor_y: int | None = None,
    rand: int = 8,
) -> tuple[int, int]:
    """Dialog neben das >>-Ueberlauffeld — freie Seite je nach Feld-Lage.

    Feld in rechter Bildhaelfte -> Dialog links vom Feld; sonst rechts.
    Passt seitlich nichts -> unter das Feld (darueber, wenn unten voll).
    Hoehe folgt dem Klickpunkt, sonst Feld-Oberkante (Nutzer 11.10.2026:
    „Abstand Eigenschaften zum Ueberlauffenster sinnvoll je nach Lage").
    """
    if feld_x + feld_w // 2 >= screen_w // 2:
        x = feld_x - dlg_w - rand
        if x < rand:
            x = feld_x + feld_w + rand
    else:
        x = feld_x + feld_w + rand
        if x + dlg_w > screen_w - rand:
            x = feld_x - dlg_w - rand
    y = int(anchor_y) if anchor_y is not None else feld_y
    if x < rand or x + dlg_w > screen_w - rand:
        x = max(4, min(feld_x, screen_w - dlg_w - 4))
        y = feld_y + feld_h + rand
        if y + dlg_h > screen_h - rand:
            y = feld_y - dlg_h - rand
    return max(4, min(x, screen_w - dlg_w - 4)), max(4, min(y, screen_h - dlg_h - 4))


def dialog_zentriert_arbeitsbereich(
    work: tuple[int, int, int, int],
    dlg_w: int,
    dlg_h: int,
    *,
    rand: int = 4,
) -> tuple[int, int]:
    """Dialog mittig im freien Arbeitsbereich des Monitors.

    monitor.work enthaelt die gedockte Leiste (AppBar) schon NICHT mehr —
    ein zentrierter Dialog kann die Leiste also niemals ueberdecken und
    klebt auch nicht am Klick- oder Bildschirmrand (Nutzer 11.10.2026:
    „Eigenschaften immer am Rand, Leiste nicht mehr lesbar").
    work = (left, top, right, bottom).
    """
    wl, wt, wr, wb = work
    x = wl + max(0, (wr - wl - dlg_w) // 2)
    y = wt + max(0, (wb - wt - dlg_h) // 2)
    # Dialog groesser als der freie Platz -> an die Arbeitsbereichs-Kante.
    x = min(max(x, wl), max(wl, wr - dlg_w))
    y = min(max(y, wt), max(wt, wb - dlg_h))
    return max(rand, x), max(rand, y)


def visible_entries_for_height(
    entry_count: int,
    available_height: int,
    icon_size: int,
    labels: bool,
    header_height: int,
    slot_limit: int | None = None,
    item_heights: list[int] | None = None,
    overflow_button_height: int = 36,
) -> int:
    """Wie viele Eintraege in available_height passen; Rest ins >>-Menue."""
    if entry_count <= 0:
        return 0
    if slot_limit is not None:
        return visible_entry_count(entry_count, slot_limit)

    usable = max(0, int(available_height) - int(header_height) - 8)
    if item_heights:
        heights = list(item_heights[:entry_count])
    else:
        est = estimate_entry_height(icon_size, labels)
        heights = [est] * entry_count

    total = sum(heights)
    if total <= usable:
        return entry_count

    usable -= overflow_button_height
    visible = 0
    used = 0
    for ht in heights:
        if used + ht > usable:
            break
        used += ht
        visible += 1
    if visible < 1 and entry_count > 0:
        visible = 1
    return visible
