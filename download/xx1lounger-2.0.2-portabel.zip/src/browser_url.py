"""KVA 146 — URLs im Standard-Browser (Localhost immer 127.0.0.1).

Windows löst „localhost“ häufig zuerst über IPv6 (::1) auf. Viele lokale
HTTP-Dienste hören nur auf IPv4 (127.0.0.1). Vor dem Öffnen wird der Host
deshalb auf IPv4 umgeschrieben; Port, Pfad, Query und Fragment bleiben.
"""

from __future__ import annotations

import logging
import os
from urllib.parse import urlsplit, urlunsplit

LOOPBACK_IPV4 = "127.0.0.1"

_LOCALHOST_NAMES = frozenset({"localhost", "::1"})


def is_web_url(target: str) -> bool:
    """http:// oder https:// (Groß/Kleinschreibung egal)."""
    return (target or "").strip().casefold().startswith(("http://", "https://"))


def is_localhost_hostname(hostname: str | None) -> bool:
    """Echter Loopback-Hostname — keine LAN-IPs, keine Subdomains."""
    if not hostname:
        return False
    return hostname.strip().casefold() in _LOCALHOST_NAMES


def browser_url(url: str) -> str:
    """URL für den Standard-Browser — Localhost-Host → 127.0.0.1 (KVA 146)."""
    raw = (url or "").strip()
    if not raw or not is_web_url(raw):
        return raw

    parts = urlsplit(raw)
    if parts.scheme.casefold() not in ("http", "https"):
        return raw
    if not is_localhost_hostname(parts.hostname):
        return raw

    port_part = f":{parts.port}" if parts.port is not None else ""
    auth = ""
    if parts.username:
        auth = parts.username
        if parts.password:
            auth += f":{parts.password}"
        auth += "@"

    netloc = f"{auth}{LOOPBACK_IPV4}{port_part}"
    return urlunsplit((parts.scheme, netloc, parts.path, parts.query, parts.fragment))


def open_in_browser(url: str) -> bool:
    """URL normalisieren und mit dem Standard-Browser öffnen."""
    raw = (url or "").strip()
    if not raw:
        return False
    if not is_web_url(raw):
        return False

    final = browser_url(raw)
    if final != raw:
        logging.info("Localhost → IPv4: %s → %s", raw, final)

    try:
        os.startfile(final)  # noqa: S606 — Windows-Standardweg für http(s)
        return True
    except OSError:
        logging.exception("Browser-Start fehlgeschlagen: %s", final)
        return False
