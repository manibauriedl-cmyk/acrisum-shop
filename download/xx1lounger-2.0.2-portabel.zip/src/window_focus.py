"""Fenster fokussieren per HWND (KVA 252)."""
from __future__ import annotations


def hwnd_gueltig(hwnd) -> bool:
    if not hwnd:
        return False
    try:
        import win32gui

        h = int(hwnd)
        return bool(win32gui.IsWindow(h))
    except Exception:
        return False


def fenster_in_vordergrund(hwnd) -> bool:
    """Sichtbares Fenster anheben — False wenn HWND tot oder Fehler."""
    if not hwnd_gueltig(hwnd):
        return False
    try:
        import win32con
        import win32gui

        h = int(hwnd)
        if win32gui.IsIconic(h):
            win32gui.ShowWindow(h, win32con.SW_RESTORE)
        try:
            win32gui.SetForegroundWindow(h)
            return True
        except Exception:
            win32gui.BringWindowToTop(h)
            return True
    except Exception:
        return False
