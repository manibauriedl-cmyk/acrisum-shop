"""Icon-Erstellung fuer xlounger.

Versucht, echte Icons aus Programmen, Dateien oder URLs zu holen.
Wenn nichts passt, faellt auf den alten Buchstaben-Platzhalter zurueck.

Icon-Extraktion:
- EXE: ExtractIconEx (pywin32)
- Alle anderen Dateien/Ordner: SHGetFileInfoW (ctypes/shell32)
- .lnk: Icon vom Verknuepfungsziel
- URLs: Favicon-Download
- HICON → PIL: Doppel-Render auf schwarz+weiss fuer korrekten Alpha-Kanal
"""
from __future__ import annotations

import ctypes
import ctypes.wintypes
import io
import logging
import os
import shutil
import threading
from pathlib import Path
from urllib.parse import urlparse

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageTk

_ICON_CACHE: dict[tuple, ImageTk.PhotoImage] = {}

# --- ctypes-Definitionen fuer SHGetFileInfoW ---

class _SHFILEINFOW(ctypes.Structure):
    _fields_ = [
        ("hIcon", ctypes.wintypes.HANDLE),
        ("iIcon", ctypes.c_int),
        ("dwAttributes", ctypes.wintypes.DWORD),
        ("szDisplayName", ctypes.wintypes.WCHAR * 260),
        ("szTypeName", ctypes.wintypes.WCHAR * 80),
    ]

_SHGFI_ICON = 0x000000100
_SHGFI_LARGEICON = 0x000000000
_SHGFI_SMALLICON = 0x000000001
_SHGFI_SYSICONINDEX = 0x000004000

# SHGetImageList: JUMBO = 256x256 (hoechste Icon-Aufloesung der Shell)
_SHIL_JUMBO = 0x4
_ILD_TRANSPARENT = 0x00000001

_shell32 = ctypes.windll.shell32
_user32 = ctypes.windll.user32
_ole32 = ctypes.windll.ole32

# --- pywin32 optional ---

try:
    import win32gui
    import win32ui
    import win32con
    _HAS_WIN32 = True
except Exception:
    _HAS_WIN32 = False


# --- High-Res-Icons (SHGetImageList JUMBO) ---
# Eigene GUID-Struktur statt comtypes-Abhaengigkeit (Auslieferung hat ggf. kein comtypes).
class _GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", ctypes.c_ulong),
        ("Data2", ctypes.c_ushort),
        ("Data3", ctypes.c_ushort),
        ("Data4", ctypes.c_ubyte * 8),
    ]


# IID_IImageList {46EB5926-582E-4017-9FDF-E8998DAA0950}
_IID_IIMAGELIST = _GUID(
    0x46EB5926, 0x582E, 0x4017,
    (0x9F, 0xDF, 0xE8, 0x99, 0x8D, 0xAA, 0x09, 0x50),
)

_com_ready_threads: set[int] = set()
_com_lock = threading.Lock()


def _com_init() -> None:
    """COM im aktuellen Thread einmal initialisieren (SHGetImageList braucht COM)."""
    tid = threading.get_ident()
    if tid in _com_ready_threads:
        return
    with _com_lock:
        if tid in _com_ready_threads:
            return
        try:
            _ole32.CoInitialize(None)
        except Exception:
            pass
        _com_ready_threads.add(tid)


def _get_hires_hicon(path: str) -> int | None:
    """Hochaufloesendes Icon (256x256) via SHGetImageList(JUMBO) als HICON.

    Rueckgabe: HICON (int), das der Aufrufer mit DestroyIcon freigeben muss.
    None bei Fehler -> Aufrufer faellt auf LARGEICON (32x32) zurueck.
    """
    try:
        _com_init()
        info = _SHFILEINFOW()
        res = _shell32.SHGetFileInfoW(
            path, 0, ctypes.byref(info), ctypes.sizeof(info), _SHGFI_SYSICONINDEX
        )
        if not res:
            return None
        piml = ctypes.c_void_p()
        hr = _shell32.SHGetImageList(
            _SHIL_JUMBO, ctypes.byref(_IID_IIMAGELIST), ctypes.byref(piml)
        )
        if hr != 0 or not piml:
            return None
        try:
            vtable = ctypes.cast(piml, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p)))[0]
            # IImageList::GetIcon ist Vtable-Index 10 (3x IUnknown + 7 IImageList).
            get_icon = ctypes.WINFUNCTYPE(
                ctypes.HRESULT, ctypes.c_void_p, ctypes.c_int,
                ctypes.wintypes.UINT, ctypes.POINTER(ctypes.wintypes.HICON),
            )(vtable[10])
            release = ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(vtable[2])
            hicon = ctypes.wintypes.HICON()
            hr = get_icon(piml, info.iIcon, _ILD_TRANSPARENT, ctypes.byref(hicon))
            release(piml)
            if hr != 0 or not hicon:
                return None
            return hicon.value
        except Exception:
            return None
    except Exception:
        return None


def _resolve_target(target: str) -> str:
    """Pfad-Aufloesung: nackte EXE-Namen (notepad.exe) zu vollem Pfad."""
    if os.path.exists(target):
        return target
    resolved = shutil.which(target)
    if resolved:
        return resolved
    # Pfad existiert nicht mehr (z. B. System32\\mspaint.exe nach dem
    # Win11-Paket-Umzug): Basisname ueber PATH/App-Paths neu aufloesen —
    # derselbe Weg, den ShellExecute beim Start geht (08.10.2026).
    base = shutil.which(os.path.basename(target))
    if base:
        return base
    return target


def _icon_datei_fuer_ziel(target_str: str) -> str | None:
    """Eingebaute Katalog-Ziele (ms-settings, .msc, shell:) — echtes Shell-Icon."""
    t = (target_str or "").strip()
    if not t:
        return None
    low = t.lower()
    windir = os.environ.get("WINDIR", r"C:\Windows")
    sys32 = os.path.join(windir, "System32")
    if low.startswith("ms-settings:"):
        for cand in (
            os.path.join(windir, "ImmersiveControlPanel", "SystemSettings.exe"),
            os.path.join(sys32, "control.exe"),
        ):
            if os.path.isfile(cand):
                return cand
    if low.startswith("control ") or low == "control printers":
        p = os.path.join(sys32, "control.exe")
        if os.path.isfile(p):
            return p
    if low.endswith(".msc"):
        p = os.path.join(sys32, os.path.basename(t))
        if os.path.isfile(p):
            return p
    if low.startswith("shell:"):
        p = os.path.join(sys32, "explorer.exe")
        if os.path.isfile(p):
            return p
    return None


def _resolve_lnk_target(path: str) -> str | None:
    """Ziel einer .lnk-Datei auflösen."""
    try:
        import win32com.client
        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortCut(path)
        return shortcut.Targetpath
    except Exception:
        return None


def _appexec_ziel(alias_path: str) -> str | None:
    """Echte exe hinter einem WindowsApps-Ausfuehrungsalias lesen.

    Stubs unter …\\Microsoft\\WindowsApps sind Reparse-Points
    (IO_REPARSE_TAG_APPEXECLINK) ohne eigenes Icon — Shell und ExtractIconEx
    liefern nur das generische Blatt. Der Reparse-Puffer enthaelt den
    echten exe-Pfad im Installationspaket (08.10.2026 — DuckDuckGo).
    """
    try:
        kernel32 = ctypes.windll.kernel32
        h = kernel32.CreateFileW(
            str(alias_path), 0x80000000, 7, None, 3,
            0x00200000 | 0x02000000,  # FILE_FLAG_OPEN_REPARSE_POINT | BACKUP_SEMANTICS
            None,
        )
        if not h or int(h) < 0:
            return None
        try:
            buf = ctypes.create_string_buffer(16384)
            ret = ctypes.wintypes.DWORD(0)
            ok = kernel32.DeviceIoControl(
                h, 0x000900A8, None, 0, buf, len(buf),
                ctypes.byref(ret), None,  # FSCTL_GET_REPARSE_POINT
            )
        finally:
            kernel32.CloseHandle(h)
        if not ok or ret.value < 8:
            return None
        import struct
        data = buf.raw[: ret.value]
        if struct.unpack("<I", data[:4])[0] != 0x8000001B:
            return None
        txt = data[4:].decode("utf-16-le", errors="ignore")
        for part in txt.split("\x00"):
            s = part.strip().strip("\x00")
            if s.lower().endswith(".exe") and ":\\" in s:
                return s
    except Exception:
        return None
    return None


def _get_lnk_icon(lnk_path: str, size: int) -> Image.Image | None:
    """IconLocation einer .lnk auswerten ('pfad,index' oder nur 'pfad').

    Das ist das Symbol, das der Explorer fuer die Verknuepfung zeigt.
    Wichtig bei WindowsApps-Aliasen (…\\WindowsApps\\*.exe): die Shell gibt
    fuer die .lnk nur das generische weisse Blatt, obwohl die Verknuepfung
    ein echtes .ico traegt (08.10.2026 — DuckDuckGo sah „kaputt" aus).
    """
    try:
        import win32com.client
        shell = win32com.client.Dispatch("WScript.Shell")
        loc = str(shell.CreateShortCut(lnk_path).IconLocation or "").strip()
    except Exception:
        return None
    if not loc:
        return None
    path, _sep, idx = loc.rpartition(",")
    if not os.path.isfile(path):
        path, idx = loc, "0"
    path = os.path.expandvars(path.strip())
    if not os.path.isfile(path):
        return None
    if path.lower().endswith(".ico"):
        try:
            img = Image.open(path)
            if img.mode != "RGBA":
                img = img.convert("RGBA")
            return img
        except Exception:
            return None
    if not _HAS_WIN32:
        return None
    try:
        index = int(idx)
    except ValueError:
        index = 0
    return _bibliothek_index_image(path, index, size)


def _bibliothek_index_image(pfad: str, index: int, size: int) -> Image.Image | None:
    """PIL-Bild aus DLL/exe per Ressourcen-Index (ExtractIconEx)."""
    if not _HAS_WIN32:
        return None
    try:
        large, small = win32gui.ExtractIconEx(str(pfad), int(index))
        hicons = (large or []) + (small or [])
        if not hicons:
            return None
        hicon = hicons[0]
        try:
            return _hicon_to_image(hicon, size)
        finally:
            for h in hicons:
                try:
                    win32gui.DestroyIcon(h)
                except Exception:
                    pass
    except Exception:
        return None


def get_icon_index(pfad: str, index: int, label=None, size=32, sichtbar_auf=None):
    """PhotoImage aus DLL/exe per Ressourcen-Index — IconIndex aus dem
    .lnk-Profil, sonst kommt nur das generische DLL-Blatt (Nutzer
    10.10.2026: „Alles minimieren" zeigte weisses Blatt statt
    imageres.dll,20)."""
    # Nur PE-Bibliotheken tragen Icon-Ressourcen — Bilddateien (.jpg/.png/
    # .ico als icon_path) laufen ueber den normalen Pfad (Thumbnail oeffnen),
    # sonst wird daraus der Buchstaben-Platzhalter.
    if os.path.splitext(str(pfad))[1].lower() not in (
        ".exe", ".dll", ".icl", ".cpl", ".scr", ".ocx",
    ):
        return get_icon(label, pfad, size, False, sichtbar_auf)
    key = (str(label), f"{pfad}!{index}", size, False, str(sichtbar_auf))
    if key in _ICON_CACHE:
        return _ICON_CACHE[key]
    img = _bibliothek_index_image(str(pfad), int(index), size)
    if img is not None and img.size != (size, size):
        img = img.resize((size, size), Image.Resampling.LANCZOS)
    if img is None:
        img = _placeholder_icon(label, size)
    if sichtbar_auf is not None:
        img = kontrast_sichern(img, sichtbar_auf)
    photo = ImageTk.PhotoImage(img)
    _ICON_CACHE[key] = photo
    return photo


def _draw_icon_on_bg(hicon: int, size: int, bg_rgb: int) -> Image.Image | None:
    """HICON auf einen einfarbigen Hintergrund zeichnen und als PIL-Bild zurueckgeben."""
    if not _HAS_WIN32:
        return None
    hdc_screen = None
    hdc = None
    hbmp = None
    mem_dc = None
    old_bmp = None
    try:
        hdc_screen = win32gui.GetDC(0)
        hdc = win32ui.CreateDCFromHandle(hdc_screen)
        hbmp = win32ui.CreateBitmap()
        hbmp.CreateCompatibleBitmap(hdc, size, size)
        mem_dc = hdc.CreateCompatibleDC()
        old_bmp = mem_dc.SelectObject(hbmp)
        mem_dc.FillSolidRect((0, 0, size, size), bg_rgb)
        win32gui.DrawIconEx(
            mem_dc.GetSafeHdc(), 0, 0, hicon, size, size,
            0, 0, win32con.DI_NORMAL,
        )
        bmpinfo = hbmp.GetInfo()
        bmpstr = hbmp.GetBitmapBits(True)
        img = Image.frombuffer(
            "RGBA",
            (bmpinfo["bmWidth"], bmpinfo["bmHeight"]),
            bmpstr, "raw", "BGRA", 0, 1,
        )
        return img.transpose(Image.FLIP_TOP_BOTTOM)
    except Exception:
        return None
    finally:
        # GDI-Objekte explizit freigeben, nicht dem Garbage-Collector ueberlassen.
        # Sonst Handle-Leak: 4 Handles pro Icon (Bitmap + MemDC, je schwarz/weiss).
        # Windows-Limit 10000 GDI-Handles/Prozess — nach ~2500 Icon-Ladungen
        # erschoepft, DrawIconEx/CreateBitmap schlagen fehl -> leere/transparente
        # Icons (Leiste zeigt nur noch Hintergrund-Kaestchen). Nach Neustart wieder
        # frei -> Icons gehen. Genau das "manchmal kaputt"-Muster (28.09.2026).
        if mem_dc is not None:
            try:
                if old_bmp is not None:
                    mem_dc.SelectObject(old_bmp)  # hbmp aus dem DC loesen
            except Exception:
                pass
            try:
                mem_dc.DeleteDC()
            except Exception:
                pass
        if hbmp is not None:
            try:
                win32gui.DeleteObject(hbmp.GetHandle())
            except Exception:
                pass
        if hdc is not None:
            try:
                hdc.Detach()  # Screen-DC nicht deleten — gehoert dem Desktop
            except Exception:
                pass
        if hdc_screen is not None:
            try:
                win32gui.ReleaseDC(0, hdc_screen)
            except Exception:
                pass


def _hicon_to_image(hicon: int, size: int) -> Image.Image | None:
    """HICON in PIL-Bild mit korrektem Alpha-Kanal wandeln.

    Methode: Icon auf schwarzen und weissen Hintergrund zeichnen,
    daraus Alpha ableiten und Farben entpremultiplizieren.
    """
    img_black = _draw_icon_on_bg(hicon, size, 0x000000)
    img_white = _draw_icon_on_bg(hicon, size, 0xFFFFFF)

    if img_black is None or img_white is None:
        # Fallback: nur schwarzer Hintergrund, Alpha = 255 wo Pixel != schwarz
        if img_black is not None:
            arr = np.array(img_black)
            has_color = (arr[:, :, 0] > 0) | (arr[:, :, 1] > 0) | (arr[:, :, 2] > 0)
            arr[:, :, 3] = np.where(has_color, 255, 0)
            return Image.fromarray(arr, "RGBA")
        return None

    b = np.array(img_black)[:, :, :3].astype(np.float32)
    w = np.array(img_white)[:, :, :3].astype(np.float32)

    # Alpha = 255 - mittlere Differenz (weiss - schwarz)
    alpha = 255.0 - (w - b).mean(axis=2)
    alpha = np.clip(alpha, 0, 255)

    # Farbe entpremultiplizieren
    result = np.zeros((*b.shape[:2], 4), dtype=np.uint8)
    mask = alpha > 0
    for c in range(3):
        ch = np.zeros_like(alpha, dtype=np.uint8)
        ch[mask] = np.clip(
            b[:, :, c][mask] * 255.0 / alpha[mask], 0, 255
        ).astype(np.uint8)
        result[:, :, c] = ch
    result[:, :, 3] = alpha.astype(np.uint8)
    return Image.fromarray(result, "RGBA")


def _icon_zu_leer(img: Image.Image, anteil: float = 0.08) -> bool:
    """True, wenn das Icon fast komplett transparent ist.

    Der Hires-Pfad (SHGetImageList JUMBO) liefert bei manchen .lnk/exe nur
    den Verknuepfungs-Pfeil als ~4-px-Fragment in der Ecke — sah im Katalog
    aus wie ein winziges kaputtes „x" (RustDesk u. a., 09.10.2026). So ein
    Bild ist kein brauchbares Icon -> Fallback-Pfad versuchen.
    """
    try:
        arr = np.array(img)
        if arr.size == 0:
            return True
        sichtbar = int((arr[:, :, 3] > 16).sum())
        return sichtbar < max(4, int(arr.shape[0] * arr.shape[1] * anteil))
    except Exception:
        return False


def _icon_verdaechtig_dunkel(img: Image.Image) -> bool:
    """True, wenn das Icon trotz sichtbarer Pixel fast schwarz ist.

    Der Hires-Pfad (SHGetImageList + DrawIconEx ueber den Screen-DC) kann in
    seltenen Faellen (z. B. waehrend die Leiste neu andockt und der Desktop
    gerade neu zusammengesetzt wird) ein dunkles Silhouetten-Ergebnis liefern.
    Ein echtes Icon ist so gut wie nie komplett dunkel — dann lieber Fallback.
    """
    try:
        arr = np.array(img)
        if arr.size == 0:
            return True
        sichtbar = arr[:, :, 3] > 16
        if not sichtbar.any():
            return True
        return float(arr[:, :, :3][sichtbar].mean()) < 28.0
    except Exception:
        return False


def _get_shell_icon(path: str, size: int) -> Image.Image | None:
    """Icon per SHGetFileInfoW (funktioniert fuer alle Dateitypen und Ordner).

    Zuerst hochaufloesend (256er-Quelle via SHGetImageList JUMBO) versuchen —
    scharf auch bei Zoom. Bei Fehler oder dunklem Render-Glitch Fallback auf
    LARGEICON (32x32).
    """
    hicon = _get_hires_hicon(path)
    if hicon:
        try:
            img = _hicon_to_image(hicon, size)
            if (
                img is not None
                and not _icon_verdaechtig_dunkel(img)
                and not _icon_zu_leer(img)
            ):
                return img
        finally:
            # HICON ist 64-Bit — ctypes nimmt sonst c_int und wirft
            # OverflowError bei grossen Handle-Werten (Fehlerbericht
            # 09.10.2026). Als HICON casten.
            _user32.DestroyIcon(ctypes.wintypes.HICON(hicon))
    # Fallback: klassisches LARGEICON (32x32).
    info = _SHFILEINFOW()
    result = _shell32.SHGetFileInfoW(
        path, 0, ctypes.byref(info), ctypes.sizeof(info),
        _SHGFI_ICON | _SHGFI_LARGEICON,
    )
    if not result or not info.hIcon:
        return None
    try:
        img = _hicon_to_image(info.hIcon, size)
        # Auch der Fallback kann Fragmente liefern — dann None, damit der
        # Aufrufer die naechste Quelle (lnk-Ziel, Platzhalter) nimmt.
        if img is not None and _icon_zu_leer(img):
            return None
        return img
    finally:
        _user32.DestroyIcon(ctypes.wintypes.HICON(info.hIcon))


def _get_exe_icon(path: str, size: int) -> Image.Image | None:
    """Icon per ExtractIconEx (EXE-spezifisch, liefert bessere Qualitaet)."""
    if not _HAS_WIN32:
        return None
    try:
        large, small = win32gui.ExtractIconEx(path, 0)
        icons = large or small
        if not icons:
            return None
        hicon = icons[0]
        # Restliche HICONs aufraeumen
        for h in (large or []) + (small or []):
            if h != hicon:
                try:
                    win32gui.DestroyIcon(h)
                except Exception:
                    pass
        try:
            return _hicon_to_image(hicon, size)
        finally:
            try:
                win32gui.DestroyIcon(hicon)
            except Exception:
                pass
    except Exception:
        return None


def _get_url_icon(url: str, size: int) -> Image.Image | None:
    host = urlparse(url).hostname
    if not host:
        return None
    try:
        import requests
    except Exception:
        return None

    candidates = [
        f"https://{host}/favicon.ico",
        f"https://{host}/favicon.png",
    ]
    for fav_url in candidates:
        try:
            # Kurzes Timeout: laeuft in der UI-Schleife (Icon-Nachladen) —
            # 3 s x 3 Kandidaten blockierten die Leiste bis zu 9 s pro URL.
            r = requests.get(fav_url, timeout=1)
            if r.status_code != 200:
                continue
            img = Image.open(io.BytesIO(r.content))
            if img.mode != "RGBA":
                img = img.convert("RGBA")
            img = img.resize((size, size), Image.Resampling.LANCZOS)
            return img
        except Exception:
            continue
    return None


def _placeholder_icon(label: str | None, size: int) -> Image.Image:
    img = Image.new("RGBA", (size, size), (128, 128, 128, 255))
    draw = ImageDraw.Draw(img)
    border = max(1, size // 16)
    draw.rectangle([0, 0, size - 1, size - 1], outline=(255, 0, 0, 255), width=border)

    letter = "?"
    if label:
        letter = str(label)[0].upper()

    try:
        font = ImageFont.truetype("segoeui.ttf", size // 2)
    except Exception:
        font = ImageFont.load_default()

    bbox = draw.textbbox((0, 0), letter, font=font)
    w = bbox[2] - bbox[0]
    h = bbox[3] - bbox[1]
    draw.text(
        ((size - w) // 2 - bbox[0], (size - h) // 2 - bbox[1]),
        letter,
        font=font,
        fill=(255, 255, 255, 255),
    )
    return img


def _add_running_dot(img: Image.Image, size: int) -> Image.Image:
    """Roten Punkt auf das Icon zeichnen (Programm laeuft)."""
    draw = ImageDraw.Draw(img)
    radius = max(3, size // 6)
    cx = size - radius - 2
    cy = size - radius - 2
    draw.ellipse(
        [cx - radius, cy - radius, cx + radius, cy + radius],
        fill=(200, 0, 0, 255),
        outline=(255, 255, 255, 255),
        width=max(1, size // 24),
    )
    return img


def fragezeichen_platzhalter(size: int = 32) -> ImageTk.PhotoImage:
    """Gemeinsames ?-Bild aus dem »-Feld — nicht als echtes Symbol ziehen."""
    return get_icon("?", "", size, False)


def ist_fragezeichen_platzhalter(photo, size: int = 32) -> bool:
    if photo is None:
        return True
    try:
        return photo is fragezeichen_platzhalter(size)
    except Exception:
        return False


def get_icon_fresh(label=None, target=None, size=32, running=False, sichtbar_auf=None):
    """Wie get_icon, aber Cache-Eintrag fuer dieses Ziel neu laden (Drag-Ghost)."""
    key = (str(label), str(target), size, running, str(sichtbar_auf))
    _ICON_CACHE.pop(key, None)
    return get_icon(label, target, size, running, sichtbar_auf)


def _hex_rgb(farbe) -> tuple[int, int, int]:
    """'#d4d0c8' oder 'red' -> (r, g, b). Bei Unbekanntem: dunkelgrau."""
    if isinstance(farbe, (tuple, list)) and len(farbe) >= 3:
        return int(farbe[0]), int(farbe[1]), int(farbe[2])
    s = str(farbe or "").strip()
    if s.startswith("#") and len(s) >= 7:
        try:
            return int(s[1:3], 16), int(s[3:5], 16), int(s[5:7], 16)
        except ValueError:
            pass
    return (60, 60, 60)


def kontrast_sichern(img: Image.Image, bg_rgb) -> Image.Image:
    """Zu kontrastarmes Icon auf dem Leisten-Hintergrund sichtbar machen.

    Weissliche Shell-Symbole (z. B. Netzwerkbruecke) verschwinden auf heller
    Leiste komplett — der Eintrag sieht aus wie „ohne Icon" (28.09.2026).
    Abhilfe: dunkle Kontur hinter das Symbol legen. Icons mit genug
    Kontrast bleiben unveraendert.
    """
    bg = _hex_rgb(bg_rgb)
    a = np.array(img.convert("RGBA"))
    alpha = a[:, :, 3]
    sichtbar = alpha > 10
    if not sichtbar.any():
        return img
    mittel = a[:, :, :3][sichtbar].mean(axis=0)
    dist = float(np.abs(mittel - np.array(bg, dtype=float)).sum())
    # Schwelle 140 (Summe ueber RGB, ~47 pro Kanal): darunter wirkt das
    # Symbol auf der Leiste „unsichtbar" (Netzwerkbruecke 28.09.2026: 88).
    if dist >= 140:
        return img
    outline = img.split()[3].filter(ImageFilter.MaxFilter(3))
    schatten = Image.new("RGBA", img.size, (60, 60, 60, 255))
    schatten.putalpha(outline)
    return Image.alpha_composite(schatten, img)


def get_icon(label=None, target=None, size=32, running=False, sichtbar_auf=None):
    key = (str(label), str(target), size, running, str(sichtbar_auf))
    if key in _ICON_CACHE:
        return _ICON_CACHE[key]

    img = None
    if target:
        target_str = str(target)
        resolved = _resolve_target(target_str)

        if target_str.lower().startswith(("http://", "https://")):
            img = _get_url_icon(target_str, size)
        elif target_str.lower().endswith((".png", ".ico", ".jpg", ".jpeg", ".bmp")) and os.path.isfile(resolved):
            try:
                img = Image.open(resolved)
                if img.mode != "RGBA":
                    img = img.convert("RGBA")
            except Exception:
                img = None
        elif target_str.lower().endswith(".lnk") and os.path.exists(resolved):
            # IconLocation zuerst — das Symbol, das der Explorer zeigt.
            img = _get_lnk_icon(resolved, size)
            lnk_target = None
            if img is None:
                lnk_target = _resolve_lnk_target(resolved)
                # WindowsApps-Alias (z. B. DuckDuckGo): Stub ohne eigenes
                # Icon — Reparse-Point zeigt auf die echte exe im Paket.
                if lnk_target and "\\windowsapps\\" in lnk_target.lower():
                    real = _appexec_ziel(lnk_target)
                    if real:
                        img = _get_exe_icon(real, size)
                        if img is None:
                            img = _get_shell_icon(real, size)
            # Ziel-Icon VOR dem lnk-eigenen Shell-Icon: kaputte IconLocation
            # (z. B. „D:\ordner,0") gibt sonst das leere weisse Blatt —
            # der Explorer zeigt dann das Icon des Verknuepfungsziels
            # (Nutzer 10.10.2026: „6018 Handy-Foto" ohne Icon im Katalog).
            if img is None and lnk_target and os.path.exists(lnk_target):
                if lnk_target.lower().endswith(".exe"):
                    img = _get_exe_icon(lnk_target, size)
                if img is None:
                    img = _get_shell_icon(lnk_target, size)
            if img is None:
                img = _get_shell_icon(resolved, size)
        elif os.path.exists(resolved):
            ext = Path(resolved).suffix.lower()
            if ext == ".exe":
                # WindowsApps-Alias direkt gepinnt: Stub ohne eigenes Icon —
                # echte exe im Paket ueber den Reparse-Point holen.
                if "\\windowsapps\\" in resolved.lower():
                    real = _appexec_ziel(resolved)
                    if real:
                        resolved = real
                img = _get_exe_icon(resolved, size)
                if img is None:
                    img = _get_shell_icon(resolved, size)
            else:
                # Ordner, .txt, .xpi, .json, ... — SHGetFileInfoW
                img = _get_shell_icon(resolved, size)
        if img is None:
            extra = _icon_datei_fuer_ziel(target_str)
            if extra and os.path.isfile(extra):
                ext = Path(extra).suffix.lower()
                if ext == ".exe":
                    img = _get_exe_icon(extra, size)
                if img is None:
                    img = _get_shell_icon(extra, size)

    # Skalieren auf Zielgroesse
    if img is not None and img.size != (size, size):
        img = img.resize((size, size), Image.Resampling.LANCZOS)

    if img is None:
        img = _placeholder_icon(label, size)
        fehlschlag = True
    else:
        fehlschlag = False

    if running:
        img = _add_running_dot(img, size)

    if sichtbar_auf is not None:
        img = kontrast_sichern(img, sichtbar_auf)

    photo = ImageTk.PhotoImage(img)
    # Ladefehler bei vorhandenem Ziel nicht dauerhaft cachen — sonst bleibt
    # der Platzhalter die ganze Laufzeit (z. B. write.exe beim Start,
    # Nutzer 03.10.2026). Fehlende Ziele cachen wir weiter (kein Shell-
    # Aufruf bei jedem Neuaufbau).
    ziel_vorhanden = bool(target) and os.path.exists(str(resolved or target))
    if not (fehlschlag and ziel_vorhanden):
        _ICON_CACHE[key] = photo
    return photo


def icon_anheften(*, size: int = 24) -> ImageTk.PhotoImage:
    """Blaue Stecknadel — Anheften-Zelle (Pin = „auf der Leiste festhalten").

    Selbsterklaerendes Symbol statt nacktem „+“ (Nutzer-Auftrag 28.09.2026).
    Blau als Aktionsfarbe — bewusst nicht gruen, damit sich die Leiste von
    anderen Pin-Werkzeugen am selben Bildschirm unterscheidet.
    """
    key = ("__anheften_pin__", size)
    if key in _ICON_CACHE:
        return _ICON_CACHE[key]
    s = max(16, size)
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    cx = s // 2
    # Kopf (blau, dunkler Rand, heller Glanzpunkt oben links).
    # Kopf + Nadel muessen das Bild wirklich ausfuellen — bei r = s*0.26
    # blieb von einem 37px-Bild nur ein 19px-Pin sichtbar („sieht nutzer
    # fast nix", 28.09.2026).
    r = max(5, int(s * 0.34))
    cy = int(s * 0.30)
    draw.ellipse(
        (cx - r, cy - r, cx + r, cy + r),
        fill=(37, 99, 235, 255),
        outline=(29, 78, 216, 255),
    )
    gl = max(2, r // 3)
    draw.ellipse(
        (cx - r + gl, cy - r + gl // 2, cx - r + 2 * gl + 1, cy - r + gl // 2 + gl + 1),
        fill=(147, 197, 253, 255),
    )
    # Nadel (silber, leicht schraeg nach unten rechts, heller Kern)
    top = cy + r - 1
    tx = cx + max(2, s // 7)
    ty = s - 1
    nw = max(3, s // 8)
    draw.line((cx, top, tx, ty), fill=(100, 116, 139, 255), width=nw)
    draw.line((cx, top, tx, ty), fill=(203, 213, 225, 255), width=max(1, nw // 2))
    photo = ImageTk.PhotoImage(img)
    _ICON_CACHE[key] = photo
    return photo


def icon_hinzufuegen(*, size: int = 24) -> ImageTk.PhotoImage:
    """Grünes Plus — Hinzufügen-Zelle (Position am Leistenende)."""
    key = ("__hinzufuegen__", size)
    if key in _ICON_CACHE:
        return _ICON_CACHE[key]
    s = max(16, size)
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    cx, cy = s // 2, s // 2
    r = max(6, s // 3)
    draw.ellipse((cx - r, cy - r, cx + r, cy + r), fill=(46, 125, 50, 255))
    w = max(2, s // 8)
    arm = max(4, s // 5)
    draw.rectangle((cx - w, cy - arm, cx + w, cy + arm), fill=(255, 255, 255, 255))
    draw.rectangle((cx - arm, cy - w, cx + arm, cy + w), fill=(255, 255, 255, 255))
    photo = ImageTk.PhotoImage(img)
    _ICON_CACHE[key] = photo
    return photo
