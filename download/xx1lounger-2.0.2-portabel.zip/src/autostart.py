"""Windows-Autostart für xlounger (KVA 242/243).

Eine kleine .vbs im Startup-Ordner startet fensterlos
`xx1lounger_prozess.py boot-check` — der wartet 10 s und startet nur nach,
wenn xlounger nicht ohnehin schon läuft (KVA 240).

StartupApproved: Windows traegt Startup-Ordner-Eintraege selbst in
HKCU\\...\\Explorer\\StartupApproved\\StartupFolder ein (Task-Manager ->
Autostart). Wir setzen den Wert auf „aktiviert", falls Windows ihn
angelegt, aber deaktiviert hat.
"""
from __future__ import annotations

import logging
import os
import winreg
from pathlib import Path

from .app_id import APP_NAME

ROOT = Path(__file__).resolve().parent.parent
VBS_NAME = f"{APP_NAME}.vbs"


def startup_ordner() -> Path:
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return Path(base) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"


def vbs_pfad() -> Path:
    return startup_ordner() / VBS_NAME


def _vbs_inhalt() -> str:
    import xx1lounger_prozess

    pythonw = xx1lounger_prozess.pythonw()
    skript = ROOT / "xx1lounger_prozess.py"
    return (
        f"' {APP_NAME} Autostart — fensterlos, Boot-Check (KVA 240/242)\n"
        "Set shell = CreateObject(\"WScript.Shell\")\n"
        f"shell.CurrentDirectory = \"{ROOT}\"\n"
        f"shell.Run \"\"\"{pythonw}\"\" \"\"{skript}\"\" boot-check\", 0, False\n"
    )


def _startup_approved_aktivieren() -> None:
    """StartupApproved-Eintrag auf „aktiviert" setzen, falls vorhanden."""
    try:
        schluessel = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder",
            0,
            winreg.KEY_SET_VALUE,
        )
        with schluessel:
            try:
                wert, _ = winreg.QueryValueEx(schluessel, VBS_NAME)
            except FileNotFoundError:
                return  # Windows hat ihn noch nicht angelegt — dann aktiviert es ihn selbst
            # Aktiviert = 12 Bytes mit 0x02 am Anfang; deaktiviert beginnt mit 0x03
            if wert and wert[0] == 3:
                winreg.SetValueEx(
                    schluessel, VBS_NAME, 0, winreg.REG_BINARY, b"\x02" + wert[1:]
                )
                logging.info("Autostart: StartupApproved auf aktiviert gesetzt")
    except OSError as exc:
        logging.warning("StartupApproved nicht gesetzt: %s", exc)


def eingerichtet() -> bool:
    return vbs_pfad().is_file()


def einrichten() -> bool:
    """KVA 242 — Autostart-VBS in den Startup-Ordner schreiben."""
    try:
        pfad = vbs_pfad()
        pfad.parent.mkdir(parents=True, exist_ok=True)
        pfad.write_text(_vbs_inhalt(), encoding="utf-8")
        _startup_approved_aktivieren()
        logging.info("Autostart eingerichtet: %s", pfad)
        return True
    except OSError as exc:
        logging.error("Autostart einrichten fehlgeschlagen: %s", exc)
        return False


def entfernen() -> bool:
    """Autostart-VBS wieder entfernen (KVA 243 — optional)."""
    try:
        pfad = vbs_pfad()
        if pfad.is_file():
            pfad.unlink()
            logging.info("Autostart entfernt: %s", pfad)
        return True
    except OSError as exc:
        logging.error("Autostart entfernen fehlgeschlagen: %s", exc)
        return False


def umschalten() -> bool:
    """Menue-Umschalter. Rueckgabe: neuer Zustand (True = eingerichtet)."""
    if eingerichtet():
        entfernen()
        return False
    return einrichten()
