from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VERSION_FILE = ROOT / "VERSION"


def get_version(default="0.0.0"):
    try:
        return VERSION_FILE.read_text(encoding="utf-8").strip()
    except Exception:
        return default


def get_version_tuple(default=(0, 0, 0)):
    v = get_version(default="0.0.0")
    parts = v.lstrip("v").split(".")
    try:
        return tuple(int(p) for p in parts[:3])
    except ValueError:
        return default
