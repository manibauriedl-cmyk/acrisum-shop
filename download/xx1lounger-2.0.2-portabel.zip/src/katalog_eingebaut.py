"""Eingebaute Katalog-Eintraege (Phase 11, KVA 256–263, 272)."""
from __future__ import annotations

import os
import platform
import sys


def _win_ge_10() -> bool:
    try:
        return int(platform.release()) >= 10
    except (TypeError, ValueError):
        return sys.getwindowsversion().major >= 10


def _e(id_: str, name: str, target: str, kat: str, quelle: str = "eingebaut") -> dict:
    return {"id": id_, "name": name, "target": target, "kat": kat, "quelle": quelle}


def system_eintraege() -> list[dict]:
    # ms-settings: existiert erst ab Win10 — auf 8.1 Systemsteuerung.
    einst = "ms-settings:" if _win_ge_10() else "control.exe"
    rows = [
        _e("sys_einst", "Einstellungen", einst, "system"),
        _e("sys_taskmgr", "Task-Manager", "taskmgr", "system"),
        _e("sys_devmgmt", "Geräte-Manager", "devmgmt.msc", "system"),
        _e("sys_drucker", "Drucker", "control printers", "system"),
        _e("sys_compmgmt", "Computerverwaltung", "compmgmt.msc", "system"),
    ]
    if _win_ge_10():
        rows.append(_e("sys_update", "Windows Update", "ms-settings:windowsupdate", "system"))
    return rows


def programme_eintraege() -> list[dict]:
    windir = os.environ.get("WINDIR", r"C:\Windows")
    return [
        _e("prog_explorer", "Explorer", "explorer.exe", "programme"),
        _e("prog_notepad", "Editor", "notepad.exe", "programme"),
        _e("prog_calc", "Rechner", "calc.exe", "programme"),
        _e("prog_paint", "Paint", os.path.join(windir, "System32", "mspaint.exe"), "programme"),
    ]


def netz_eintraege() -> list[dict]:
    return [
        _e("net_browser", "Browser (Google)", "https://www.google.com/", "netz"),
        _e("net_telegram", "Telegram Web", "https://web.telegram.org/", "netz"),
        _e("net_netz", "Netzwerk", "shell:ConnectionsFolder", "netz"),
        # ms-settings: existiert erst ab Win10 — auf 8.1 Netzwerkverbindungen.
        _e("net_wlan", "WLAN", "ms-settings:network-wifi" if _win_ge_10() else "ncpa.cpl", "netz"),
    ]


def ordner_eintraege() -> list[dict]:
    home = os.path.expanduser("~")
    return [
        _e("ord_desktop", "Desktop", os.path.join(home, "Desktop"), "ordner"),
        _e("ord_docs", "Dokumente", os.path.join(home, "Documents"), "ordner"),
        _e("ord_down", "Downloads", os.path.join(home, "Downloads"), "ordner"),
    ]


def shell_eintraege() -> list[dict]:
    return [
        _e("shell_recycle", "Papierkorb", "shell:RecycleBinFolder", "ordner"),
        _e("shell_pc", "Dieser PC", "shell:MyComputerFolder", "ordner"),
        _e("shell_net", "Netzwerk", "shell:NetworkPlacesFolder", "ordner"),
    ]


def alle_eingebauten() -> list[dict]:
    out: list[dict] = []
    for block in (
        system_eintraege(),
        programme_eintraege(),
        netz_eintraege(),
        ordner_eintraege(),
        shell_eintraege(),
    ):
        out.extend(block)
    return out
