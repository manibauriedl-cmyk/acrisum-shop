"""Einfache Tooltips fuer xlounger."""
from __future__ import annotations

import tkinter as tk

_MARGIN = 6

# Dock-Kurzzeichen (kein layout-Import — Tooltip bleibt UI-Hilfe)
_DOCK_LEFT = "left"
_DOCK_RIGHT = "right"
_DOCK_BOTTOM = "bottom"
_DOCK_BOTTOM_LEFT = "bottom_left"
_DOCK_BOTTOM_RIGHT = "bottom_right"

# Nur ein Tooltip gleichzeitig sichtbar (verhindert Geister-Toplevels)
_aktiver: Tooltip | None = None


def aktiven_ausblenden() -> None:
    global _aktiver
    t = _aktiver
    _aktiver = None
    if t is not None:
        try:
            t._hide()
        except Exception:
            t._tip_zerstoeren()


def berechne_tooltip_pos(
    wx: int,
    wy: int,
    ww: int,
    wh: int,
    tip_w: int,
    tip_h: int,
    screen_w: int,
    screen_h: int,
    *,
    dock: str = "none",
    margin: int = _MARGIN,
) -> tuple[int, int]:
    """Tooltip-Position — vollständig sichtbar, auch an linker/rechter Leiste."""
    ww = max(int(ww), 1)
    wh = max(int(wh), 1)
    tip_w = max(int(tip_w), 1)
    tip_h = max(int(tip_h), 1)
    sw = max(int(screen_w), tip_w + 2 * margin)
    sh = max(int(screen_h), tip_h + 2 * margin)

    if dock == _DOCK_LEFT:
        x = wx + ww + margin
        y = wy + max(0, (wh - tip_h) // 2)
    elif dock == _DOCK_RIGHT:
        x = wx - tip_w - margin
        y = wy + max(0, (wh - tip_h) // 2)
    elif dock in (_DOCK_BOTTOM, _DOCK_BOTTOM_LEFT, _DOCK_BOTTOM_RIGHT):
        x = wx + ww // 2 - tip_w // 2
        y = wy - tip_h - margin
    else:
        x = wx + ww // 2 - tip_w // 2
        y = wy + wh + margin

    if x < margin:
        x = wx + ww + margin
        y = wy + max(0, (wh - tip_h) // 2)
    elif x + tip_w > sw - margin:
        x = wx - tip_w - margin
        y = wy + max(0, (wh - tip_h) // 2)

    x = max(margin, min(x, sw - tip_w - margin))
    y = max(margin, min(y, sh - tip_h - margin))
    return x, y


class Tooltip:
    """Ein einfacher Tooltip, der beim Hover erscheint."""

    def __init__(
        self,
        widget: tk.Widget,
        text: str,
        bg: str = "#404040",
        fg: str = "white",
        dock: str = "none",
        *,
        auch: tuple[tk.Widget, ...] | list[tk.Widget] = (),
        hilfe_text: str = "",
        hilfe_ms: int = 5000,
        show_ms: int = 400,
    ):
        self.widget = widget
        self.text = text
        self.bg = bg
        self.fg = fg
        self.dock = dock or "none"
        # Zweite Stufe: bei langem Verweilen (hilfe_ms) loest der ausfuehrliche
        # Hilfetext den Kurz-Tipp ab (Nutzer-Auftrag 28.09.2026).
        self.hilfe_text = hilfe_text or ""
        self.hilfe_ms = max(500, int(hilfe_ms))
        # Kurz-Tipp erst nach show_ms — im Katalog verdeckt ein sofort
        # aufpoppender Beschreibungstext die Zeilen beim Durchfahren
        # (Nutzer 09.10.2026: „erst nach 3 s oeffnen").
        self.show_ms = max(0, int(show_ms))
        self._hilfe_job: str | None = None
        self._tip: tk.Toplevel | None = None
        self._show_job: str | None = None
        self._leave_job: str | None = None
        self._watch_job: str | None = None
        self._widgets: tuple[tk.Widget, ...] = (widget,) + tuple(auch)
        self._widget_set = frozenset(self._widgets)

        # add="+" ist PFLICHT: ohne add ersetzt bind() die Klick-/Hover-Behandlung
        # des Eintrags (Symbol-Klick waere dadurch komplett tot).
        for w in self._widgets:
            w.bind("<Enter>", self._on_enter, add="+")
            w.bind("<Leave>", self._on_leave, add="+")
            w.bind("<Button-1>", self._hide, add="+")
            # Rechtsklick oeffnet das Kontextmenue — Tooltip muss weg und
            # ausstehende Show-Jobs sterben, sonst schweben Menue und
            # Tooltip uebereinander (Nutzer-Screenshot 28.09.2026).
            w.bind("<Button-3>", self._hide, add="+")
            w.bind("<Destroy>", self._on_destroy, add="+")

    def _on_destroy(self, _event=None):
        self._abbrechen_jobs()
        self._hide()

    def _abbrechen_jobs(self):
        root = self.widget
        for job in (self._show_job, self._leave_job, self._watch_job, self._hilfe_job):
            if job:
                try:
                    root.after_cancel(job)
                except tk.TclError:
                    pass
        self._show_job = None
        self._leave_job = None
        self._watch_job = None
        self._hilfe_job = None

    def _tip_zerstoeren(self) -> None:
        if self._tip:
            try:
                self._tip.destroy()
            except tk.TclError:
                pass
            self._tip = None

    def _zeiger_ueber_tooltip(self) -> bool:
        if not self._tip:
            return False
        try:
            if not self._tip.winfo_exists():
                return False
            x, y = self.widget.winfo_pointerxy()
            tx = int(self._tip.winfo_rootx())
            ty = int(self._tip.winfo_rooty())
            tw = max(int(self._tip.winfo_width()), 1)
            th = max(int(self._tip.winfo_height()), 1)
            return tx <= x <= tx + tw and ty <= y <= ty + th
        except tk.TclError:
            return False

    def _watch_tick(self) -> None:
        self._watch_job = None
        if not self._tip:
            return
        try:
            if not self.widget.winfo_exists():
                self._hide()
                return
        except tk.TclError:
            self._hide()
            return
        if self._zeiger_in_gruppe() or self._zeiger_ueber_tooltip():
            try:
                self._watch_job = self.widget.after(350, self._watch_tick)
            except tk.TclError:
                pass
            return
        self._hide()

    def _zeiger_in_gruppe(self) -> bool:
        try:
            x, y = self.widget.winfo_pointerxy()
            w = self.widget.winfo_containing(x, y)
        except tk.TclError:
            return False
        while w is not None:
            if w in self._widget_set:
                return True
            try:
                w = w.master
            except (tk.TclError, AttributeError):
                break
        return False

    def _on_enter(self, _event=None):
        if self._leave_job:
            try:
                self.widget.after_cancel(self._leave_job)
            except tk.TclError:
                pass
            self._leave_job = None
        if self._show_job:
            return
        self._show_job = self.widget.after(self.show_ms, self._show)

    def _on_leave(self, _event=None):
        if self._show_job:
            try:
                self.widget.after_cancel(self._show_job)
            except tk.TclError:
                pass
            self._show_job = None
        if self._leave_job:
            return
        self._leave_job = self.widget.after(40, self._leave_pruefen)

    def _leave_pruefen(self):
        self._leave_job = None
        try:
            if not self.widget.winfo_exists() or not self.widget.winfo_viewable():
                self._hide()
                return
        except tk.TclError:
            self._hide()
            return
        if self._zeiger_in_gruppe() or self._zeiger_ueber_tooltip():
            return
        self._hide()

    def _show(self):
        self._show_job = None
        global _aktiver
        if _aktiver is not None and _aktiver is not self:
            _aktiver._hide()
        self._hide()
        if not self.text:
            return
        try:
            anchor = self.widget
            if not anchor.winfo_exists():
                return
            if not anchor.winfo_viewable():
                return
            wx = anchor.winfo_rootx()
            wy = anchor.winfo_rooty()
            ww = anchor.winfo_width()
            wh = anchor.winfo_height()
            sw = anchor.winfo_screenwidth()
            sh = anchor.winfo_screenheight()
        except tk.TclError:
            return

        root = self.widget.winfo_toplevel()
        self._tip = tk.Toplevel(root)
        self._tip.overrideredirect(True)
        self._tip.attributes("-topmost", True)
        self._tip.configure(bg=self.bg)
        lbl = tk.Label(
            self._tip,
            text=self.text,
            bg=self.bg,
            fg=self.fg,
            font=("Segoe UI", 9),
            padx=6,
            pady=3,
        )
        lbl.pack()
        self._tip.update_idletasks()
        tip_w = self._tip.winfo_reqwidth()
        tip_h = self._tip.winfo_reqheight()
        x, y = berechne_tooltip_pos(
            wx, wy, ww, wh, tip_w, tip_h, sw, sh, dock=self.dock,
        )
        self._tip.geometry(f"{tip_w}x{tip_h}+{x}+{y}")
        self._tip.bind("<Leave>", self._on_leave, add="+")
        lbl.bind("<Leave>", self._on_leave, add="+")
        _aktiver = self
        try:
            self._watch_job = self.widget.after(350, self._watch_tick)
        except tk.TclError:
            pass
        if self.hilfe_text and self.text != self.hilfe_text:
            try:
                self._hilfe_job = self.widget.after(self.hilfe_ms, self._hilfe_zeigen)
            except tk.TclError:
                pass

    def _hilfe_zeigen(self) -> None:
        """Zweite Stufe: Zeiger verweilt — ausfuehrlichen Hilfetext einblenden."""
        self._hilfe_job = None
        if not self.hilfe_text or self.text == self.hilfe_text or not self._tip:
            return
        if not (self._zeiger_in_gruppe() or self._zeiger_ueber_tooltip()):
            return
        self.text = self.hilfe_text
        self._tip_zerstoeren()
        self._show()

    def _hide(self, _event=None):
        global _aktiver
        self._abbrechen_jobs()
        self._tip_zerstoeren()
        if _aktiver is self:
            _aktiver = None

    def set_text(self, text: str):
        self.text = text

    def set_dock(self, dock: str):
        self.dock = dock or "none"
