"""Desktop-Symbolpositionen lesen/schreiben (KVA 194-203, 210).

SysListView32 des Desktops: Positionen merken (pro Leisten-Kante, mit
Arbeitsflaechen-Kontext), vor Kantenwechsel sichern, danach wiederherstellen,
Symbole unter der Leiste nach innen schieben.
"""
from __future__ import annotations

import ctypes
import json
import logging
from ctypes import wintypes

from . import monitors, paths

LVM_GETITEMCOUNT = 0x1004
LVM_GETITEMPOSITION = 0x1010
LVM_SETITEMPOSITION32 = 0x1031
LVM_GETITEMTEXTW = 0x1073
LVIF_TEXT = 0x0001

PROCESS_VM = 0x0438  # QUERY + VM_OPERATION + VM_READ + VM_WRITE
MEM_COMMIT_RESERVE = 0x3000
PAGE_READWRITE = 0x04
MEM_RELEASE = 0x8000

# Icon+Beschriftung — grob, nur zum Wegschieben vom Rand
_ICON_B = 76
_ICON_H = 96

# Arbeitsflaeche der letzten Messung (Notweg fuer wiederherstellen mit fallback)
_letzte_flaeche: tuple[int, int, int, int] | None = None


class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class LVITEMW(ctypes.Structure):
    _fields_ = [
        ("mask", wintypes.UINT),
        ("iItem", wintypes.INT),
        ("iSubItem", wintypes.INT),
        ("state", wintypes.UINT),
        ("stateMask", wintypes.UINT),
        ("pszText", ctypes.c_void_p),
        ("cchTextMax", wintypes.INT),
        ("iImage", wintypes.INT),
        ("lParam", wintypes.LPARAM),
        ("iIndent", wintypes.INT),
        ("iGroupId", wintypes.INT),
        ("cColumns", wintypes.UINT),
        ("puColumns", ctypes.c_void_p),
        ("piColFmt", ctypes.c_void_p),
        ("iGroup", wintypes.INT),
    ]


def kante_key(dock: str) -> str:
    """Eine Ablage je Kante — Ecken zaehlen zu ihrer Kante."""
    if dock in ("top", "top_left", "top_right"):
        return "top"
    if dock in ("bottom", "bottom_left", "bottom_right"):
        return "bottom"
    if dock == "left":
        return "left"
    if dock == "right":
        return "right"
    return "frei"


def icons_datei():
    return paths.get_appdata_dir() / "desktop_icons.json"


def _bildschirm_rect() -> tuple[int, int, int, int]:
    """Virtueller Desktop (alle Monitore)."""
    u32 = ctypes.windll.user32
    x = u32.GetSystemMetrics(76)  # SM_XVIRTUALSCREEN
    y = u32.GetSystemMetrics(77)  # SM_YVIRTUALSCREEN
    w = u32.GetSystemMetrics(78)  # SM_CXVIRTUALSCREEN
    h = u32.GetSystemMetrics(79)  # SM_CYVIRTUALSCREEN
    if w <= 0 or h <= 0:
        w = u32.GetSystemMetrics(0)
        h = u32.GetSystemMetrics(1)
        x, y = 0, 0
    return (x, y, x + w, y + h)


def _hauptmonitor_rect() -> tuple[int, int, int, int]:
    m = monitors.get_primary_monitor()
    if m is not None:
        return m.rect.as_tuple()
    return _bildschirm_rect()


def _zum_client(rect: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    """Bildschirm-Rect -> ListView-Client-Koordinaten.

    LVM_GETITEMPOSITION/LVM_SETITEMPOSITION32 arbeiten in Client-Koordinaten
    der Desktop-ListView, deren Ursprung die linke obere Ecke des VIRTUELLEN
    Desktops ist. Haengt links/oben vom Hauptmonitor ein Schirm, ist der
    Ursprung negativ (z. B. (-1366, 0)) — Bildschirm-Rects muessen dann um
    diesen Ursprung verschoben werden, sonst liegen Vergleiche/Klemmungen
    eine Schirmbreite daneben und Icons wandern massenhaft (3-Monitor-PC,
    11.10.2026: ~80 Icons auf den linken Schirm geschoben).
    """
    vx, vy, _r, _b = _bildschirm_rect()
    l, t, r, b = (int(v) for v in rect)
    return (l - vx, t - vy, r - vx, b - vy)


def _monitor_anzahl() -> int:
    try:
        return max(1, len(monitors.get_monitors()))
    except Exception:
        return 1


def _icon_auf_primaermonitor(x: int, y: int) -> bool:
    l, t, r, b = _zum_client(_hauptmonitor_rect())
    return l <= x + _ICON_B // 2 < r and t <= y + _ICON_H // 2 < b


def nur_primaer_icons(pos: dict) -> dict[str, tuple[int, int]]:
    """Mehrmonitor: nur Symbole auf dem Hauptbildschirm — andere nie anfassen."""
    if _monitor_anzahl() < 2:
        return {k: (int(v[0]), int(v[1])) for k, v in pos.items()}
    out: dict[str, tuple[int, int]] = {}
    for name, xy in pos.items():
        x, y = int(xy[0]), int(xy[1])
        if _icon_auf_primaermonitor(x, y):
            out[name] = (x, y)
    return out


def _flaeche_fuer_icons() -> tuple[int, int, int, int]:
    if _monitor_anzahl() >= 2:
        return _hauptmonitor_rect()
    return _bildschirm_rect()


def listview_hwnd() -> int:
    try:
        import win32gui
    except ImportError:
        return 0

    def _defview_unter(parent: int) -> int:
        return int(win32gui.FindWindowEx(parent, 0, "SHELLDLL_DefView", None) or 0)

    progman = int(win32gui.FindWindow("Progman", None) or 0)
    defview = _defview_unter(progman) if progman else 0
    if not defview:
        worker = 0
        while True:
            worker = int(win32gui.FindWindowEx(0, worker, "WorkerW", None) or 0)
            if not worker:
                break
            defview = _defview_unter(worker)
            if defview:
                break
    if not defview:
        return 0
    return int(win32gui.FindWindowEx(defview, 0, "SysListView32", None) or 0)


def _lesen_roh() -> dict[str, tuple[int, int, int]]:
    """Name -> (x, y, listview-index). Leer wenn ListView nicht lesbar."""
    hwnd = listview_hwnd()
    if not hwnd:
        return {}
    try:
        import win32gui
        import win32process
    except ImportError:
        return {}

    anzahl = int(win32gui.SendMessage(hwnd, LVM_GETITEMCOUNT, 0, 0) or 0)
    if anzahl <= 0 or anzahl > 2000:
        return {}
    _tid, pid = win32process.GetWindowThreadProcessId(hwnd)
    if not pid:
        return {}

    kernel32 = ctypes.windll.kernel32
    hproc = kernel32.OpenProcess(PROCESS_VM, False, int(pid))
    if not hproc:
        return {}

    text_bytes = 520
    remote = None
    ergebnis: dict[str, tuple[int, int, int]] = {}
    gesehen: dict[str, int] = {}
    try:
        remote = kernel32.VirtualAllocEx(hproc, None, 4096, MEM_COMMIT_RESERVE, PAGE_READWRITE)
        if not remote:
            return {}
        p_point = remote
        p_item = remote + 16
        p_text = remote + 16 + ctypes.sizeof(LVITEMW)

        for i in range(anzahl):
            pt = POINT()
            if not kernel32.WriteProcessMemory(hproc, p_point, ctypes.byref(pt), ctypes.sizeof(POINT), None):
                continue
            win32gui.SendMessage(hwnd, LVM_GETITEMPOSITION, i, p_point)
            if not kernel32.ReadProcessMemory(hproc, p_point, ctypes.byref(pt), ctypes.sizeof(POINT), None):
                continue

            item = LVITEMW()
            item.mask = LVIF_TEXT
            item.iItem = i
            item.iSubItem = 0
            item.pszText = p_text
            item.cchTextMax = text_bytes // 2
            if not kernel32.WriteProcessMemory(hproc, p_item, ctypes.byref(item), ctypes.sizeof(LVITEMW), None):
                continue
            win32gui.SendMessage(hwnd, LVM_GETITEMTEXTW, i, p_item)
            buf = ctypes.create_unicode_buffer(text_bytes // 2)
            kernel32.ReadProcessMemory(hproc, p_text, buf, text_bytes, None)
            name = (buf.value or "").strip()
            if not name:
                name = f"#{i}"
            n = gesehen.get(name, 0)
            gesehen[name] = n + 1
            key = name if n == 0 else f"{name}#{n + 1}"
            ergebnis[key] = (int(pt.x), int(pt.y), i)
    finally:
        if remote:
            kernel32.VirtualFreeEx(hproc, remote, 0, MEM_RELEASE)
        kernel32.CloseHandle(hproc)
    return ergebnis


def lesen() -> dict[str, tuple[int, int]]:
    """KVA 194 — Name -> (x, y) der Desktop-Icons."""
    return {name: (x, y) for name, (x, y, _i) in _lesen_roh().items()}


def pos_von_drop(x_root: int, y_root: int) -> tuple[int, int]:
    """ListView-Koordinaten aus Bildschirm-Loslasspunkt (Abheften von der Leiste)."""
    vx, vy, _r, _b = _bildschirm_rect()
    x = int(x_root) - vx - 38
    y = int(y_root) - vy - 48
    m = monitors.get_primary_monitor()
    if m is not None:
        wl, wt, wr, wb = _zum_client(
            (int(m.work_x), int(m.work_y),
             int(m.work_x) + int(m.work_width), int(m.work_y) + int(m.work_height))
        )
    else:
        wl, wt, wr, wb = _zum_client(_hauptmonitor_rect())
    x = min(max(x, wl), max(wl, wr - _ICON_B))
    y = min(max(y, wt), max(wt, wb - _ICON_H))
    return x, y


def ansicht_aktualisieren() -> None:
    """Explorer-Desktop neu einlesen — sonst bleibt .lnk nach Abheften unsichtbar."""
    try:
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0x0000, None, None)
    except Exception:
        pass


def item_aktualisieren(pfad: str) -> None:
    try:
        ctypes.windll.shell32.SHChangeNotify(
            0x00002000,
            0x0005,
            ctypes.c_wchar_p(str(pfad)),
            None,
        )
    except Exception:
        pass


def setzen(pos: dict) -> int:
    """KVA 195 — Positionen setzen. Rueckgabe: Anzahl gesetzter Icons."""
    if not pos:
        return 0
    hwnd = listview_hwnd()
    if not hwnd:
        return 0
    try:
        import win32gui
        import win32process
    except ImportError:
        return 0

    live = _lesen_roh()
    name_index = {name: idx for name, (_x, _y, idx) in live.items()}
    if not name_index:
        return 0

    _tid, pid = win32process.GetWindowThreadProcessId(hwnd)
    if not pid:
        return 0
    kernel32 = ctypes.windll.kernel32
    hproc = kernel32.OpenProcess(PROCESS_VM, False, int(pid))
    if not hproc:
        return 0
    remote = None
    gesetzt = 0
    try:
        remote = kernel32.VirtualAllocEx(hproc, None, 64, MEM_COMMIT_RESERVE, PAGE_READWRITE)
        if not remote:
            return 0
        for name, xy in pos.items():
            idx = name_index.get(name)
            if idx is None:
                continue
            pt = POINT(int(xy[0]), int(xy[1]))
            kernel32.WriteProcessMemory(hproc, remote, ctypes.byref(pt), ctypes.sizeof(POINT), None)
            win32gui.SendMessage(hwnd, LVM_SETITEMPOSITION32, idx, remote)
            gesetzt += 1
    finally:
        if remote:
            kernel32.VirtualFreeEx(hproc, remote, 0, MEM_RELEASE)
        kernel32.CloseHandle(hproc)
    return gesetzt


def _disk_laden() -> dict:
    pfad = icons_datei()
    if not pfad.is_file():
        return {}
    try:
        data = json.loads(pfad.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _disk_speichern(data: dict) -> None:
    pfad = icons_datei()
    pfad.parent.mkdir(parents=True, exist_ok=True)
    pfad.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _pos_dict_aus_eintrag(raw) -> dict[str, tuple[int, int]]:
    if isinstance(raw, dict) and isinstance(raw.get("pos"), dict) and raw["pos"]:
        return {
            n: (int(v[0]), int(v[1]))
            for n, v in raw["pos"].items()
            if isinstance(v, (list, tuple)) and len(v) >= 2
        }
    if isinstance(raw, dict) and raw and not raw.get("pos"):
        return {
            n: (int(v[0]), int(v[1]))
            for n, v in raw.items()
            if isinstance(v, (list, tuple)) and len(v) >= 2
        }
    return {}


def _anteil_rechts(pos: dict, flaeche: tuple[int, int, int, int], schwelle: float = 0.72) -> float:
    if not pos:
        return 0.0
    wl, _wt, wr, _wb = (int(v) for v in flaeche)
    grenze = wl + int(max(1, wr - wl) * schwelle)
    rechts = sum(1 for x, _y in pos.values() if int(x) >= grenze)
    return rechts / len(pos)


def _layout_rechts_unplausibel(snap: dict, flaeche: tuple, data: dict, kante: str) -> bool:
    """Schutz: ploetzlich viele Symbole weit rechts nicht als neues Normal speichern."""
    neu = _anteil_rechts(snap, flaeche)
    if neu < 0.28:
        return False
    alt_raw = data.get(kante)
    alt_pos = _pos_dict_aus_eintrag(alt_raw)
    if not alt_pos:
        return False
    alt_f = alt_raw.get("flaeche") if isinstance(alt_raw, dict) else None
    alt_flaeche = tuple(int(v) for v in alt_f) if isinstance(alt_f, (list, tuple)) and len(alt_f) == 4 else flaeche
    alt = _anteil_rechts(alt_pos, alt_flaeche)
    return alt < 0.12 and neu >= 0.28


def merken(dock: str) -> dict[str, tuple[int, int]]:
    """KVA 196+197+198 — aktuelle Lage unter dieser Kante ablegen, mit Arbeitsflaeche."""
    global _letzte_flaeche
    snap = nur_primaer_icons(lesen())
    if not snap:
        return {}
    flaeche = _flaeche_fuer_icons()
    _letzte_flaeche = flaeche
    data = _disk_laden()
    k = kante_key(dock)
    if _layout_rechts_unplausibel(snap, flaeche, data, k):
        logging.info("desktop-icons-merken blockiert kante=%s (verdaechtiges Rechts-Layout)", k)
        return snap
    data[k] = {
        "flaeche": [int(v) for v in flaeche],
        "pos": {n: [x, y] for n, (x, y) in snap.items()},
    }
    try:
        _disk_speichern(data)
    except OSError:
        pass
    return snap


def unter_leiste_schieben(pos: dict, streifen: tuple[int, int, int, int], dock: str) -> dict[str, tuple[int, int]]:
    """KVA 201 — nur Symbole unter DIESEM Streifen einen Tick nach innen."""
    sl, st, sw, sh = (int(v) for v in streifen)
    sl, st, sr, sb = _zum_client((sl, st, sl + sw, st + sh))
    k = kante_key(dock)
    out: dict[str, tuple[int, int]] = {}
    for name, xy in pos.items():
        x, y = int(xy[0]), int(xy[1])
        ix2, iy2 = x + _ICON_B, y + _ICON_H
        overlap = not (ix2 <= sl or x >= sr or iy2 <= st or y >= sb)
        if overlap:
            if k == "top":
                y = sb
            elif k == "bottom":
                y = st - _ICON_H
            elif k == "left":
                x = sr
            elif k == "right":
                x = sl - _ICON_B
        out[name] = (x, y)
    return out


def _mitwandern(layout: dict, flaeche_alt: tuple | None) -> dict[str, tuple[int, int]]:
    """Koordinaten behalten; nur am virtuellen Desktop-Rand anstossen."""
    flaeche_scr = _flaeche_fuer_icons()
    wsl, wst, wsr, wsb = flaeche_scr                    # dx/dy im Bildschirm-Raum (wie flaeche_alt)
    wl, wt, wr, wb = _zum_client(flaeche_scr)           # Klemmung im Client-Raum (wie pos)
    dx = dy = 0
    if flaeche_alt:
        alt = tuple(int(v) for v in flaeche_alt)
        if _monitor_anzahl() >= 2:
            prim = _hauptmonitor_rect()
            if alt == prim or (
                abs(alt[0] - prim[0]) <= 2
                and abs(alt[1] - prim[1]) <= 2
                and abs(alt[2] - prim[2]) <= 2
                and abs(alt[3] - prim[3]) <= 2
            ):
                dx = wsl - alt[0]
                dy = wst - alt[1]
        else:
            virt = _bildschirm_rect()
            span_alt = (alt[2] - alt[0]) + (alt[3] - alt[1])
            span_virt = (virt[2] - virt[0]) + (virt[3] - virt[1])
            if span_alt >= int(span_virt * 0.8):
                dx = wsl - alt[0]
                dy = wst - alt[1]
    layout = nur_primaer_icons(layout)
    verschoben = {name: (int(xy[0]) + dx, int(xy[1]) + dy) for name, xy in layout.items()}
    if not verschoben:
        return {}
    # Ausserhalb des virtuellen Desktops an den Rand setzen
    max_x = wr - _ICON_B
    max_y = wb - _ICON_H
    out: dict[str, tuple[int, int]] = {}
    for name, (x, y) in verschoben.items():
        x = min(max(x, wl), max_x)
        y = min(max(y, wt), max_y)
        out[name] = (x, y)
    return out


def wiederherstellen(dock: str, fallback: dict | None = None, streifen: tuple | None = None) -> int:
    """KVA 199 — gespeicherte Lage dieser Kante setzen; sonst fallback."""
    data = _disk_laden()
    raw = data.get(kante_key(dock))
    layout: dict | None = None
    flaeche_alt: tuple | None = None

    if isinstance(raw, dict) and isinstance(raw.get("pos"), dict) and raw["pos"]:
        layout = raw["pos"]
        f = raw.get("flaeche")
        if isinstance(f, (list, tuple)) and len(f) == 4:
            flaeche_alt = tuple(int(v) for v in f)
    elif isinstance(raw, dict) and raw:
        layout = raw
    if not layout and fallback:
        layout = fallback
        flaeche_alt = _letzte_flaeche
    if not layout:
        return 0
    layout = nur_primaer_icons(layout)
    if not layout:
        return 0
    gelegt = _mitwandern(layout, flaeche_alt)
    if streifen and kante_key(dock) != "frei":
        gelegt = unter_leiste_schieben(gelegt, streifen, dock)
    return setzen(gelegt)


def randstreifen_freiraeumen(breite: int = 110, *, links: int | None = None,
                             rechts: int | None = None) -> int:
    """Icons aus dem linken/rechten Randstreifen eine Spalte nach innen schieben.

    Reserve-Zone (Nutzer 04.10.2026): Die Raender bleiben icon-frei, damit
    angedockte Leisten dort Platz haben, OHNE dass Windows je wieder alle
    Icons umsortiert. Laeuft einmalig beim Start + per Menuepunkt; verschiebt
    nur, was tatsaechlich im Streifen liegt (meist 0).

    links/rechts: optionale Streifenbreite je Seite — dockt die Leiste dort,
    wird die echte Leistendicke uebergeben, damit Icons direkt an der
    Leistenkante liegen (keine leere Doppel-Spalte).
    """
    snap = nur_primaer_icons(lesen())
    if not snap:
        return 0
    l, _t, r, _b = _zum_client(_flaeche_fuer_icons())
    frei_l = l + (links if links is not None else breite)
    frei_r = r - (rechts if rechts is not None else breite)
    neu: dict[str, tuple[int, int]] = {}
    for name, (x, y) in snap.items():
        nx = int(x)
        if nx < frei_l:
            nx = frei_l
        elif nx + _ICON_B > frei_r:
            nx = frei_r - _ICON_B
        if nx != int(x):
            neu[name] = (nx, int(y))
    if not neu:
        return 0
    # Sicherung (11.10.2026): im Streifen liegen real wenige Icons —
    # mehr bedeutet falsche Flaeche/Monitore -> lieber GAR NICHTS
    # verschieben als den Kunden-Desktop umzupfluegen (80 Icons
    # auf einen Schirm gezogen).
    if len(neu) > 16:
        logging.warning(
            "Randstreifen-Abbruch: %d Icons wuerden verschoben — Flaeche/Monitor verdaechtig, nichts angefasst",
            len(neu),
        )
        return 0
    n = setzen(neu)
    logging.info("Randstreifen freigeraeumt: %s Icon(s) nach innen geschoben", n)
    return n


def icons_unter_leiste_nach_innen(streifen: tuple[int, int, int, int], dock: str) -> int:
    """KVA 201/202/203 — live lesen, Ueberlappungen nach innen schieben, setzen."""
    snap = nur_primaer_icons(lesen())
    if not snap:
        return 0
    verschoben = unter_leiste_schieben(snap, streifen, dock)
    geaendert = {n: xy for n, xy in verschoben.items() if xy != snap.get(n)}
    if not geaendert:
        return 0
    # Dieselbe Sicherung wie randstreifen: unter einem Leisten-Streifen
    # liegen real nur ein paar Icons — Massenverschiebung = Fehler.
    if len(geaendert) > 16:
        logging.warning(
            "icons-unter-leiste-Abbruch: %d Icons wuerden verschoben — Streifen verdaechtig, nichts angefasst",
            len(geaendert),
        )
        return 0
    return setzen(geaendert)
