"""HTML-Hilfe (KVA 290–292).

- 290: Hilfe als HTML mit Bildern, im Browser gezeigt.
- 291: lokaler HTTP-Server auf 127.0.0.1 — liefert UTF-8 korrekt aus
  (file:// raten Browser oft falsch, Umlaute kaputt).
- 292: fehlt die HTML-Datei, gibt es einen Text-Fallback-Dialog.
"""
from __future__ import annotations

import functools
import http.server
import logging
import threading
import webbrowser
from pathlib import Path

HELP_DIR = Path(__file__).resolve().parent.parent / "help"

_server = None
_port = 0


class _Handler(http.server.SimpleHTTPRequestHandler):
    """UTF-8-Charset fuer HTML — sonst zeigen Browser Umlaute kaputt an."""

    extensions_map = {
        **http.server.SimpleHTTPRequestHandler.extensions_map,
        ".html": "text/html; charset=utf-8",
        ".svg": "image/svg+xml",
    }

    def log_message(self, fmt, *args):  # still ins xlounger-Log statt stderr
        logging.debug("hilfe-http: " + fmt, *args)


def _server_starten() -> int:
    """Startet den Hilfe-Server einmal (Daemon-Thread). Rueckgabe: Port."""
    global _server, _port
    if _server is not None:
        return _port
    handler = functools.partial(_Handler, directory=str(HELP_DIR))
    _server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    _port = _server.server_address[1]
    threading.Thread(target=_server.serve_forever, daemon=True).start()
    logging.info("Hilfe-Server auf http://127.0.0.1:%d", _port)
    return _port


def hilfe_vorhanden() -> bool:
    return (HELP_DIR / "index.html").is_file()


def hilfe_url() -> str:
    return f"http://127.0.0.1:{_server_starten()}/index.html"


def hilfe_oeffnen(parent=None) -> bool:
    """Oeffnet die Hilfe im Browser. False = Fallback-Dialog gezeigt."""
    if not hilfe_vorhanden():
        _text_fallback(parent)
        return False
    webbrowser.open(hilfe_url())
    return True


def _text_fallback(parent=None) -> None:
    """KVA 292 — Text-Fallback, wenn die HTML-Hilfe fehlt."""
    from tkinter import messagebox

    messagebox.showinfo(
        "xlounger Hilfe",
        "xlounger — Kurzhilfe\n\n"
        "• Eintraege: Datei/Programm auf die Leiste ziehen\n"
        "  oder Rechtsklick auf den Griff -> „Verbindungen anheften…“\n"
        "• Andocken: Leiste an eine Bildschirmkante ziehen\n"
        "• Menue: Rechtsklick auf den Griff ganz links\n"
        "• Entfernen: Rechtsklick auf ein Symbol -> „Entfernen“\n\n"
        "(Die ausfuehrliche HTML-Hilfe fehlt im Ordner help/.)",
        parent=parent,
    )
