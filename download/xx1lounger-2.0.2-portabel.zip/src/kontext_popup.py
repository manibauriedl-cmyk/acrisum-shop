"""xlounger — Griff-Kontextmenü als eigenes Fenster (Slider/Checkboxen ohne tk.Menu)."""
from __future__ import annotations

import time
import tkinter as tk
from tkinter import font as tkfont
from typing import Callable

from . import monitors
from . import tooltip

MENU_BG = "#d4d0c8"
MENU_FG = "#000000"
HOVER_BG = "#0a246a"
HOVER_FG = "#ffffff"
_CHECK_AN = "* "
_CHECK_AUS = "  "
MENU_AUTO_CLOSE_MS = 45_000
POINTER_POLL_MS = 100
# 0.14 s waren viel zu kurz: Das Menue schloss sich, bevor die Maus vom
# Griff den Schieberegler erreichte — „Schieberegler kaputt" (Nutzer
# 28.09.2026). 1.2 s reichen fuer normale Mausbewegung; Klick ausserhalb
# und Auto-Close (45 s) schliessen weiterhin.
POINTER_LEAVE_S = 1.2

AktionsCallback = Callable[[str], None]


def _hover_faerben(widgets, bg: str, fg: str) -> None:
    """Hover-Farben setzen — Frame/Canvas kennen kein -fg (Tk-Fehler 28.09.2026)."""
    for w in widgets:
        if isinstance(w, (tk.Frame, tk.Canvas)):
            w.configure(bg=bg)
        else:
            w.configure(bg=bg, fg=fg)


class KontextPopup:
    _aktiv: KontextPopup | None = None

    def __init__(self, parent: tk.Misc) -> None:
        self.parent = parent
        self._fenster: tk.Toplevel | None = None
        self._offen_ab = 0.0
        self._ausserhalb_job: str | None = None
        self._auto_close_job: str | None = None
        self._focus_out_job: str | None = None
        self._global_bind_id: str | None = None
        self._flyout: KontextPopup | None = None
        self._pointer_watch_job: str | None = None
        self._pointer_leave_seit = 0.0
        self._leiste_rect: tuple[int, int, int, int, str] | None = None
        self._bei_schliessen: Callable[[], None] | None = None
        self._slider_zieht = False
        self._anker_x = 0
        self._anker_y = 0
        self._aktions_callback: AktionsCallback | None = None
        self._position_gefrostet = False
        self._fix_geo: tuple[int, int] | None = None
        self._geo_fest_ab_oeffnen = False

    def menue_position_einfrieren(self, ein: bool) -> None:
        """Symbolgröße live: Menü nicht mit Leistenbreite mitziehen."""
        self._position_gefrostet = bool(ein)
        if ein and self._fenster:
            try:
                self._fix_geo = (
                    int(self._fenster.winfo_rootx()),
                    int(self._fenster.winfo_rooty()),
                )
            except tk.TclError:
                self._fix_geo = None
        elif not ein:
            self._fix_geo = None

    def menue_position_nach_vorschau(
        self, leiste_rect: tuple[int, int, int, int, str] | None
    ) -> None:
        """Einmal nach Zoom-Schieberegler an Leiste ausrichten — kein Dauer-Jitter."""
        self._position_gefrostet = False
        self._fix_geo = None
        if not self._fenster:
            return
        if leiste_rect:
            self._leiste_rect = leiste_rect
        try:
            self._fenster.update_idletasks()
            breite = max(self._fenster.winfo_width(), self._fenster.winfo_reqwidth())
            hoehe = max(self._fenster.winfo_height(), self._fenster.winfo_reqheight())
            sx, sy = self._menue_xy(
                self._anker_x, self._anker_y, breite, hoehe, leiste_rect
            )
            self._fenster.geometry(f"+{sx}+{sy}")
            self._fix_geo = (int(sx), int(sy))
        except tk.TclError:
            pass

    @staticmethod
    def _menue_xy(
        x: int,
        y: int,
        breite: int,
        hoehe: int,
        leiste_rect: tuple[int, int, int, int, str] | None,
    ) -> tuple[int, int]:
        mon = monitors.get_primary_monitor()
        if mon:
            wl, wt, wr, wb = mon.work.as_tuple()
        else:
            wl, wt, wr, wb = 0, 0, 1920, 1080
        sx = x
        sy = y
        if leiste_rect:
            lx, ly, bw, bh, dock = leiste_rect
            margin = 6
            if dock in ("top", "top_left", "top_right"):
                sx = min(x, lx + max(0, bw - breite))
                sy = ly + bh + margin
            elif dock in ("bottom", "bottom_left", "bottom_right"):
                sx = min(x, lx + max(0, bw - breite))
                sy = ly - hoehe - margin
            elif dock == "left":
                sx = lx + bw + margin
            elif dock == "right":
                sx = lx - breite - margin
        sx = min(max(wl + 4, sx), max(wl + 4, wr - breite - 4))
        sy = min(max(wt + 4, sy), max(wt + 4, wb - hoehe - 4))
        if leiste_rect:
            lx, ly, bw, bh, dock = leiste_rect
            margin = 6
            if dock in ("top", "top_left", "top_right"):
                sy = max(sy, ly + bh + margin)
            elif dock in ("bottom", "bottom_left", "bottom_right"):
                sy = min(sy, max(wt + 4, ly - hoehe - margin))
            elif dock == "left":
                sx = max(sx, lx + bw + margin)
            elif dock == "right":
                sx = min(sx, max(wl + 4, lx - breite - margin))
        return sx, sy

    def _menue_mit_leiste_kante_sync(
        self, leiste_rect: tuple[int, int, int, int, str] | None
    ) -> None:
        """Nur die Kante zur Leiste nachziehen — kein Anker-Neurechnen (Jitter).

        Beim Zoomen waechst die Leiste (v. a. senkrecht: Breite). Ist das Menue
        eingefroren, darf es nicht unter der Leiste liegen bleiben — sonst
        ueberlagern sich HWNDs und der Bildschirm „zuckt“ mit Geisterzeilen
        (Nutzer 29.09.2026, ~30 s am Regler).
        """
        if not self._fenster or not leiste_rect:
            return
        lx, ly, bw, bh, dock = leiste_rect
        margin = 6
        try:
            self._fenster.update_idletasks()
            breite = max(self._fenster.winfo_width(), self._fenster.winfo_reqwidth())
            hoehe = max(self._fenster.winfo_height(), self._fenster.winfo_reqheight())
            ox, oy = int(self._fenster.winfo_rootx()), int(self._fenster.winfo_rooty())
            sx, sy = ox, oy
            if dock == "left":
                sx = lx + bw + margin
            elif dock == "right":
                sx = lx - breite - margin
            elif dock in ("top", "top_left", "top_right"):
                sy = ly + bh + margin
            elif dock in ("bottom", "bottom_left", "bottom_right"):
                sy = ly - hoehe - margin
            mon = monitors.get_primary_monitor()
            if mon:
                wl, wt, wr, wb = mon.work.as_tuple()
            else:
                wl, wt, wr, wb = 0, 0, 1920, 1080
            sx = min(max(wl + 4, sx), max(wl + 4, wr - breite - 4))
            sy = min(max(wt + 4, sy), max(wt + 4, wb - hoehe - 4))
            if (sx, sy) != (ox, oy):
                self._fenster.geometry(f"+{sx}+{sy}")
                self._fix_geo = (int(sx), int(sy))
                self._fenster.lift()
        except tk.TclError:
            pass

    def menue_waehrend_leistenumbau(
        self,
        leiste_rect: tuple[int, int, int, int, str] | None,
        apply_fn: Callable[[], None],
    ) -> None:
        """Menue kurz ausblenden, Leiste umbauen, Menue an Kante wieder — ohne Geister-Pixel."""
        if not self._fenster:
            apply_fn()
            return
        if leiste_rect:
            self._leiste_rect = leiste_rect
        try:
            self._fenster.withdraw()
        except tk.TclError:
            pass
        try:
            apply_fn()
        finally:
            if not self._fenster:
                return
            try:
                rect = leiste_rect or self._leiste_rect
                if self._position_gefrostet or self._geo_fest_ab_oeffnen:
                    self._menue_mit_leiste_kante_sync(rect)
                else:
                    self.leiste_position_anpassen(rect)
                self._fenster.deiconify()
                self._fenster.lift()
                self._fenster.update_idletasks()
            except tk.TclError:
                pass

    def leiste_position_anpassen(
        self, leiste_rect: tuple[int, int, int, int, str] | None
    ) -> None:
        if leiste_rect:
            self._leiste_rect = leiste_rect
        if not self._fenster:
            return
        if self._position_gefrostet:
            self._menue_mit_leiste_kante_sync(leiste_rect)
            return
        if self._geo_fest_ab_oeffnen:
            return
        try:
            self._fenster.update_idletasks()
            breite = max(self._fenster.winfo_width(), self._fenster.winfo_reqwidth())
            hoehe = max(self._fenster.winfo_height(), self._fenster.winfo_reqheight())
            sx, sy = self._menue_xy(
                self._anker_x, self._anker_y, breite, hoehe, leiste_rect
            )
            self._fenster.geometry(f"+{sx}+{sy}")
        except tk.TclError:
            pass

    def _auto_close_zuruecksetzen(self) -> None:
        if not self.parent:
            return
        if self._auto_close_job:
            try:
                self.parent.after_cancel(self._auto_close_job)
            except tk.TclError:
                pass
        self._auto_close_job = self.parent.after(MENU_AUTO_CLOSE_MS, self._auto_schliessen)

    @classmethod
    def schliesse_alle(cls) -> None:
        if cls._aktiv:
            cls._aktiv.schliessen()

    def schliessen(self) -> None:
        if self._flyout:
            self._flyout.schliessen()
            self._flyout = None
        acb = self._aktions_callback
        if acb and (self._slider_zieht or self._position_gefrostet):
            try:
                acb("zoom_vorschau_abbrechen")
            except Exception:
                pass
        self._slider_zieht = False
        self._position_gefrostet = False
        self._fix_geo = None
        self._geo_fest_ab_oeffnen = False
        cb = self._bei_schliessen
        for job in (
            self._ausserhalb_job,
            self._auto_close_job,
            self._focus_out_job,
            self._pointer_watch_job,
        ):
            if job and self.parent:
                try:
                    self.parent.after_cancel(job)
                except tk.TclError:
                    pass
        self._ausserhalb_job = None
        self._auto_close_job = None
        self._focus_out_job = None
        self._pointer_watch_job = None
        self._pointer_leave_seit = 0.0
        self._leiste_rect = None
        self._global_unbind()
        if self._fenster:
            try:
                self._fenster.destroy()
            except tk.TclError:
                pass
            self._fenster = None
        if KontextPopup._aktiv is self:
            KontextPopup._aktiv = None
        if cb:
            try:
                cb()
            except Exception:
                pass

    def _global_unbind(self) -> None:
        if self._global_bind_id and self.parent:
            try:
                self.parent.unbind("<ButtonRelease-1>", self._global_bind_id)
            except tk.TclError:
                pass
        self._global_bind_id = None

    def zeigen(
        self,
        x: int,
        y: int,
        eintraege: list[dict],
        callback: AktionsCallback,
        *,
        leiste_rect: tuple[int, int, int, int, str] | None = None,
    ) -> None:
        if KontextPopup._aktiv is not self:
            KontextPopup.schliesse_alle()
        self.schliessen()
        KontextPopup._aktiv = self
        self._aktions_callback = callback
        self._anker_x = int(x)
        self._anker_y = int(y)

        fenster = tk.Toplevel(self.parent)
        # Erst komplett aufbauen, dann zeigen (deiconify unten): ein sichtbar
        # wachsendes Menue liess auf langsam zeichnenden Systemen alte Pixel
        # des vorherigen Menues durchscheinen — Zeilen doppelt/durchgestrichen
        # (Nutzer 29.09.2026, nach Zoom mit »-Zeile im zweiten Menue).
        fenster.withdraw()
        fenster.overrideredirect(True)
        fenster.attributes("-topmost", True)
        fenster.configure(bg=MENU_BG)

        aussen = tk.Frame(
            fenster,
            bg=MENU_BG,
            highlightthickness=2,
            highlightbackground="#404040",
            highlightcolor="#ffffff",
        )
        aussen.pack(padx=1, pady=1)
        inner = tk.Frame(aussen, bg=MENU_BG, padx=2, pady=2)
        inner.pack()

        font_norm = tkfont.Font(root=fenster, family="Segoe UI", size=9, weight="normal")
        font_fett = tkfont.Font(root=fenster, family="Segoe UI", size=9, weight="bold")

        for entry in eintraege:
            typ = entry.get("typ", "item")
            if typ == "separator":
                sep = tk.Frame(inner, bg=MENU_BG, height=5)
                sep.pack(fill="x", pady=2)
                tk.Frame(sep, bg="#808080", height=1).pack(fill="x", padx=2)
                tk.Frame(sep, bg="#ffffff", height=1).pack(fill="x", padx=2)
                continue

            if typ == "slider":
                stufe = int(entry.get("value", 0))
                zmin = int(entry.get("min", 0))
                zmax = int(entry.get("max", 12))
                prefix = str(entry.get("aktion_prefix", "zoom_stufe"))
                titel = str(entry.get("text", "Symbolgröße"))
                anzahl = max(1, zmax - zmin + 1)
                zeile = tk.Frame(inner, bg=MENU_BG)
                zeile.pack(fill="x", padx=2, pady=(2, 4))
                lbl = tk.Label(
                    zeile,
                    text=f"{titel}  ({stufe + 1}/{anzahl})",
                    bg=MENU_BG,
                    fg=MENU_FG,
                    font=font_norm,
                    anchor="w",
                    padx=4,
                )
                lbl.pack(fill="x")
                scale_frm = tk.Frame(zeile, bg=MENU_BG)
                scale_frm.pack(fill="x", padx=6, pady=(0, 2))
                var = tk.IntVar(value=max(zmin, min(zmax, stufe)))
                zuletzt = [max(zmin, min(zmax, stufe))]

                def on_scale(val: str, lb=lbl, p=prefix, tit=titel, n=anzahl) -> None:
                    s = max(zmin, min(zmax, int(float(val))))
                    if s == zuletzt[0]:
                        return
                    zuletzt[0] = s
                    lb.configure(text=f"{tit}  ({s + 1}/{n})")
                    self._auto_close_zuruecksetzen()
                    callback(f"{p}_{s}")

                sc = tk.Scale(
                    scale_frm,
                    from_=zmin,
                    to=zmax,
                    orient=tk.HORIZONTAL,
                    resolution=1,
                    showvalue=0,
                    length=210,
                    variable=var,
                    command=on_scale,
                    bg=MENU_BG,
                    fg=MENU_FG,
                    troughcolor="#c0c0c0",
                    activebackground=MENU_FG,
                    highlightthickness=0,
                    # Greifbar statt verkuemmert: 10px-Linie mit Mini-Griff
                    # war praktisch nicht bedienbar (Nutzer 28.09.2026:
                    # „Schieberegler kaputt").
                    sliderlength=28,
                    width=22,
                )
                sc.pack(fill="x", expand=True, padx=2)

                def slider_down(_e) -> None:
                    callback("zoom_vorschau_start")
                    self.menue_position_einfrieren(True)
                    self._slider_zieht = True
                    self._auto_close_zuruecksetzen()

                def slider_zieht(_e) -> None:
                    self._slider_zieht = True

                def slider_up(_e) -> None:
                    try:
                        callback("zoom_stufe_flush")
                    finally:
                        self._slider_zieht = False
                        self._offen_ab = time.monotonic()

                sc.bind("<Button-1>", slider_down, add="+")
                sc.bind("<B1-Motion>", slider_zieht, add="+")
                sc.bind("<ButtonRelease-1>", slider_up, add="+")
                continue

            if typ == "submenu":
                text = str(entry.get("text", ""))
                kinder = list(entry.get("eintraege") or [])
                zeile = tk.Frame(inner, bg=MENU_BG, cursor="hand2")
                zeile.pack(fill="x")
                text_lbl = tk.Label(
                    zeile,
                    text=f"{_CHECK_AUS}{text}  »",
                    bg=MENU_BG,
                    fg=MENU_FG,
                    font=font_norm,
                    anchor="w",
                    padx=4,
                    pady=1,
                    cursor="hand2",
                )
                text_lbl.pack(side="left", fill="x", expand=True)
                widgets = (zeile, text_lbl)

                def hover_in(_ev, ws=widgets) -> None:
                    _hover_faerben(ws, HOVER_BG, HOVER_FG)

                def hover_out(_ev, ws=widgets) -> None:
                    _hover_faerben(ws, MENU_BG, MENU_FG)

                def klick_sub(_ev, k=kinder, z=zeile) -> None:
                    self._global_unbind()
                    try:
                        zx = fenster.winfo_rootx() + fenster.winfo_width()
                        zy = z.winfo_rooty()
                    except tk.TclError:
                        return "break"
                    fly = KontextPopup(self.parent)
                    self._flyout = fly
                    fly.zeigen(zx, zy, k, callback, leiste_rect=leiste_rect)
                    return "break"

                for w in widgets:
                    w.bind("<Enter>", hover_in)
                    w.bind("<Leave>", hover_out)
                    w.bind("<ButtonRelease-1>", klick_sub)
                continue

            text = str(entry.get("text", ""))
            fett = bool(entry.get("fett", False))
            fnt = font_fett if fett else font_norm
            if typ == "checkbox":
                zeilen_text = (_CHECK_AN if entry.get("checked") else _CHECK_AUS) + text
            else:
                zeilen_text = _CHECK_AUS + text

            zeile = tk.Frame(inner, bg=MENU_BG, cursor="hand2")
            zeile.pack(fill="x")
            text_lbl = tk.Label(
                zeile,
                text=zeilen_text,
                bg=MENU_BG,
                fg=MENU_FG,
                font=fnt,
                anchor="w",
                padx=4,
                pady=1,
                cursor="hand2",
            )
            text_lbl.pack(side="left", fill="x", expand=True)
            aktion = str(entry.get("aktion", ""))
            # Info-„ⓘ“ am rechten Zeilenrand: Erklaerung genau dort, wo der
            # Nutzer gerade ist — Hover aufs ⓘ zeigt den Text aus „info",
            # die Zeile selbst loest nichts aus (Nutzer 07.10.2026).
            info_text = str(entry.get("info") or "")
            info_lbl = None
            if info_text:
                info_lbl = tk.Label(
                    zeile,
                    text="ⓘ",
                    bg=MENU_BG,
                    fg="#404040",
                    font=font_norm,
                    padx=4,
                    cursor="question_arrow",
                )
                info_lbl.pack(side="right")
                info_lbl.bind("<ButtonRelease-1>", lambda _e: "break")
            widgets = (zeile, text_lbl) + ((info_lbl,) if info_lbl is not None else ())

            def hover_in(_ev, ws=widgets) -> None:
                _hover_faerben(ws, HOVER_BG, HOVER_FG)

            def hover_out(_ev, ws=widgets) -> None:
                _hover_faerben(ws, MENU_BG, MENU_FG)

            def klick(_ev, a=aktion) -> None:
                self._global_unbind()
                if self._ausserhalb_job and self.parent:
                    try:
                        self.parent.after_cancel(self._ausserhalb_job)
                    except tk.TclError:
                        pass
                    self._ausserhalb_job = None
                try:
                    callback(a)
                finally:
                    KontextPopup.schliesse_alle()
                return "break"

            for w in widgets:
                w.bind("<Enter>", hover_in)
                w.bind("<Leave>", hover_out)
            for w in (zeile, text_lbl):
                w.bind("<ButtonRelease-1>", klick)
            # Erst NACH den Zeilen-Bindings — die Schleife oben bindet ohne
            # add="+" und wuerde sonst Enter/Leave des Tooltips ersetzen
            # (ⓘ-Hover tot, Nutzer 07.10.2026).
            if info_lbl is not None:
                tooltip.Tooltip(info_lbl, info_text, dock="none")

        fenster.update_idletasks()
        breite = fenster.winfo_reqwidth()
        hoehe = fenster.winfo_reqheight()
        sx, sy = self._menue_xy(x, y, breite, hoehe, leiste_rect)
        fenster.geometry(f"+{sx}+{sy}")
        fenster.deiconify()
        fenster.lift()
        self._geo_fest_ab_oeffnen = True
        self._fix_geo = (int(sx), int(sy))

        fenster.bind("<Escape>", lambda _e: KontextPopup.schliesse_alle())
        self._leiste_rect = leiste_rect
        self._offen_ab = time.monotonic()
        self._pointer_leave_seit = 0.0
        self._ausserhalb_job = self.parent.after(120, self._ausserhalb_binden)
        self._auto_close_job = self.parent.after(MENU_AUTO_CLOSE_MS, self._auto_schliessen)
        self._fenster = fenster
        self._pointer_watch_start()

    @staticmethod
    def _in_rect(px: int, py: int, x: int, y: int, w: int, h: int, pad: int = 6) -> bool:
        return (x - pad) <= px <= (x + w + pad) and (y - pad) <= py <= (y + h + pad)

    def _menue_rects(self) -> list[tuple[int, int, int, int]]:
        rects: list[tuple[int, int, int, int]] = []
        if self._fenster:
            try:
                rects.append(
                    (
                        int(self._fenster.winfo_rootx()),
                        int(self._fenster.winfo_rooty()),
                        int(self._fenster.winfo_width()),
                        int(self._fenster.winfo_height()),
                    )
                )
            except tk.TclError:
                pass
        if self._flyout and self._flyout._fenster:
            try:
                rects.append(
                    (
                        int(self._flyout._fenster.winfo_rootx()),
                        int(self._flyout._fenster.winfo_rooty()),
                        int(self._flyout._fenster.winfo_width()),
                        int(self._flyout._fenster.winfo_height()),
                    )
                )
            except tk.TclError:
                pass
        return rects

    def _pointer_in_bedienzone(self, px: int, py: int) -> bool:
        for x, y, w, h in self._menue_rects():
            if self._in_rect(px, py, x, y, w, h, pad=10):
                return True
        if self._leiste_rect:
            lx, ly, bw, bh, _dock = self._leiste_rect
            if self._in_rect(px, py, lx, ly, bw, bh, pad=12):
                return True
            # Schmaler Korridor nur zwischen Leiste und Menue (nicht volle Hoehe —
            # sonst bleibt das Menue offen, wenn die Maus nur nach oben geht).
            menues = self._menue_rects()
            if menues:
                mx, my, mw, mh = menues[0]
                dock = self._leiste_rect[4]
                if dock in ("left", "right"):
                    y0 = max(ly, my) - 18
                    y1 = min(ly + bh, my + mh) + 18
                    x0 = min(lx + bw, mx) - 10
                    x1 = max(lx + bw, mx) + 10
                elif dock in ("top", "top_left", "top_right"):
                    x0 = max(lx, mx) - 18
                    x1 = min(lx + bw, mx + mw) + 18
                    y0 = min(ly + bh, my) - 10
                    y1 = max(ly + bh, my) + 10
                elif dock in ("bottom", "bottom_left", "bottom_right"):
                    x0 = max(lx, mx) - 18
                    x1 = min(lx + bw, mx + mw) + 18
                    y0 = min(ly, my + mh) - 10
                    y1 = max(ly, my + mh) + 10
                else:
                    x0 = x1 = y0 = y1 = 0
                if x0 <= x1 and y0 <= py <= y1 and x0 <= px <= x1:
                    return True
        return False

    def _pointer_watch_start(self) -> None:
        self._pointer_watch_tick()

    def _pointer_watch_tick(self) -> None:
        self._pointer_watch_job = None
        if KontextPopup._aktiv is not self or not self._fenster:
            return
        if self._slider_zieht or self._position_gefrostet:
            self._pointer_leave_seit = 0.0
            self._pointer_watch_job = self.parent.after(
                POINTER_POLL_MS, self._pointer_watch_tick
            )
            return
        if time.monotonic() - self._offen_ab < 0.2:
            self._pointer_watch_job = self.parent.after(
                POINTER_POLL_MS, self._pointer_watch_tick
            )
            return
        try:
            px, py = int(self.parent.winfo_pointerx()), int(self.parent.winfo_pointery())
        except tk.TclError:
            return
        if self._pointer_in_bedienzone(px, py):
            self._pointer_leave_seit = 0.0
        else:
            jetzt = time.monotonic()
            if self._pointer_leave_seit <= 0.0:
                self._pointer_leave_seit = jetzt
            elif jetzt - self._pointer_leave_seit >= POINTER_LEAVE_S:
                KontextPopup.schliesse_alle()
                return
        self._pointer_watch_job = self.parent.after(
            POINTER_POLL_MS, self._pointer_watch_tick
        )

    def _ausserhalb_binden(self) -> None:
        self._ausserhalb_job = None
        if not self._fenster:
            return
        try:
            self._global_bind_id = self.parent.bind(
                "<ButtonRelease-1>", self._ausserhalb_global, add="+"
            )
        except tk.TclError:
            pass

    def _ausserhalb_global(self, event: tk.Event) -> None:
        if KontextPopup._aktiv is not self or not self._fenster:
            return
        if self._slider_zieht:
            return
        if time.monotonic() - self._offen_ab < 0.18:
            return
        try:
            wx, wy = self._fenster.winfo_rootx(), self._fenster.winfo_rooty()
            ww, wh = self._fenster.winfo_width(), self._fenster.winfo_height()
            if wx <= event.x_root <= wx + ww and wy <= event.y_root <= wy + wh:
                return
            if self._flyout and self._flyout._fenster:
                fx, fy = self._flyout._fenster.winfo_rootx(), self._flyout._fenster.winfo_rooty()
                fw, fh = self._flyout._fenster.winfo_width(), self._flyout._fenster.winfo_height()
                if fx <= event.x_root <= fx + fw and fy <= event.y_root <= fy + fh:
                    return
        except tk.TclError:
            pass
        KontextPopup.schliesse_alle()

    def _auto_schliessen(self) -> None:
        self._auto_close_job = None
        KontextPopup.schliesse_alle()


def zoom_slider_eintrag(stufe: int) -> dict:
    from . import masse

    s = masse.zoom_clamp(stufe)
    return {
        "typ": "slider",
        "text": "Symbolgröße",
        "value": s,
        "min": masse.ZOOM_MIN,
        "max": masse.ZOOM_MAX,
        "aktion_prefix": "zoom_stufe",
    }
