"""Leisten-Masse (Zoom-Stufen, Hoehe, Schrift, Abstaende).

Nur Berechnungsformeln — eigenstaendiges Modul.
"""

from __future__ import annotations

import tkinter as tk

ZOOM_MIN = 0
ZOOM_MAX = 12
ZOOM_DEFAULT = 7
ICON_LEISTE = 24
ZOOM_ICON_PX = (15, 16, 18, 20, 22, 24, 26, 29, 32, 35, 39, 43, 47)
ZOOM_FAKTOREN = tuple(px / float(ICON_LEISTE) for px in ZOOM_ICON_PX)

BG_SYMBOL_HOVER_H = "#484848"
RUNNING_DOT = "#1a9e3f"  # gruen = „laeuft" — rot wirkt wie Alarm (Nutzer 09.10.2026)
KLICK_BG = "#606061"
LEISTE_BG_STANDARD = "grau"

# Hintergrund-Farbvorschlaege
_FARBEN: dict[str, str] = {
    "grau": "#606060",
    "dunkel": "#404040",
    "schwarz": "#1e1e1e",
    "office": "#008000",
    "win_leiste": "#9ec5eb",
    "blau": "#2b579a",
    "hell": "#a0a0a0",
}
_HELL = frozenset({"win_leiste", "hell"})


def transparency_value(bar: dict) -> float:
    return max(0.0, min(1.0, float(bar.get("transparency", 0) or 0)))


def chroma_transparent(bar: dict) -> bool:
    """Nur „ganz transparent“ (1.0) — Chroma-Key. Mittel/Stark = Alpha, Farbe bleibt."""
    return transparency_value(bar) >= 0.99


def bar_einst(bar: dict) -> dict:
    """bar-Dict → Einstellungs-Form fuer Farben."""
    key = str(bar.get("leiste_hintergrund", LEISTE_BG_STANDARD) or LEISTE_BG_STANDARD)
    if key not in _FARBEN:
        key = LEISTE_BG_STANDARD
    return {
        "leiste_hintergrund": key,
        "hintergrund_transparent": chroma_transparent(bar),
    }


def hintergrund_volltransparent(bar: dict) -> bool:
    return chroma_transparent(bar)


def effektiver_schluessel(bar: dict) -> str:
    einst = bar_einst(bar)
    if einst.get("hintergrund_transparent"):
        return LEISTE_BG_STANDARD
    key = str(einst.get("leiste_hintergrund", LEISTE_BG_STANDARD) or LEISTE_BG_STANDARD)
    return key if key in _FARBEN else LEISTE_BG_STANDARD


def schluessel_fuer_hex(hex_color: str) -> str | None:
    ziel = str(hex_color or "").strip().lower()
    if not ziel.startswith("#"):
        return None
    for key, farbe in _FARBEN.items():
        if farbe.lower() == ziel:
            return key
    return None


def leiste_bg(bar: dict) -> str:
    if chroma_transparent(bar):
        return _FARBEN[LEISTE_BG_STANDARD]
    custom = str(bar.get("background_color") or "").strip()
    if custom.startswith("#") and len(custom) == 7:
        return custom
    return _FARBEN[effektiver_schluessel(bar)]


def chroma_key(bar: dict) -> str:
    """Chroma-Key bei „ganz transparent“ — neutrales Grau #606060."""
    return _FARBEN[LEISTE_BG_STANDARD]


def leiste_klick_bg(bar: dict) -> str:
    if hintergrund_volltransparent(bar):
        return KLICK_BG
    return leiste_bg(bar)


def leiste_fg(bar: dict) -> str:
    if chroma_transparent(bar):
        return "#ffffff"
    return "#1a1a1a" if effektiver_schluessel(bar) in _HELL else "#ffffff"


def leiste_hover_bg(bar: dict) -> str:
    if chroma_transparent(bar):
        return BG_SYMBOL_HOVER_H
    key = effektiver_schluessel(bar)
    if key == "win_leiste":
        return "#7eb5dd"
    if key == "hell":
        return "#8a8a8a"
    return BG_SYMBOL_HOVER_H


def grip_bg(bar: dict) -> str:
    if chroma_transparent(bar):
        chroma = leiste_bg(bar).strip().lower()
        klick = KLICK_BG.strip()
        if klick.lower() == chroma:
            return "#404040"
        return klick
    return leiste_bg(bar)


def farbe_fuer_schluessel(key: str) -> str:
    return _FARBEN.get(key, _FARBEN[LEISTE_BG_STANDARD])


def zoom_clamp(zoom: int) -> int:
    return max(ZOOM_MIN, min(ZOOM_MAX, int(zoom)))


def icon_groesse_leiste(stufe: int, *, horizontal: bool = True) -> int:
    """Feste Pixel je Stufe, kein DPI-Faktor."""
    s = zoom_clamp(stufe)
    px = ZOOM_ICON_PX[s]
    if not horizontal:
        px += 8
    return px


def icon_px(stufe: int, *, vertical: bool = False, scale: float = 1.0) -> int:
    """Legacy-Alias — bevorzugt icon_groesse_leiste (ohne scale)."""
    return icon_groesse_leiste(stufe, horizontal=not vertical)


def zoom_anzahl() -> int:
    return len(ZOOM_ICON_PX)


def zoom_label(stufe: int) -> str:
    """Anzeige: Stufe 7 = „8/13“."""
    s = zoom_clamp(stufe)
    return f"{s + 1}/{zoom_anzahl()}"


def zoom_factor(stufe: int) -> float:
    return ZOOM_FAKTOREN[zoom_clamp(stufe)]


def bar_zoom_stufe(bar: dict) -> int:
    if "zoom_stufe" in bar:
        return zoom_clamp(bar["zoom_stufe"])
    if "zoom" in bar:
        return zoom_clamp(bar["zoom"])
    return ZOOM_DEFAULT


def label_font_px(icon_px: int) -> int:
    return max(9, min(20, int(round(icon_px * 0.5))))


def dock_thickness(icon_sz: int, show_labels: bool) -> int:
    """Fallback-Hoehe ohne Font-Metriken (bar._calc_dock_thickness bevorzugen)."""
    if not show_labels:
        return icon_sz + max(8, icon_sz // 5)
    label_h = max(14, min(28, icon_sz // 3))
    pad = max(2, int(round(2 * (icon_sz / float(ICON_LEISTE)))))
    return icon_sz + label_h + pad * 2 + max(6, icon_sz // 10) + 4


def slot_step(icon_sz: int) -> int:
    return icon_sz + max(12, icon_sz // 3)


def lesbar_kurz(name: str, kurz: str = "", *, mit_text: bool, horizontal: bool = True) -> str:
    lang = (name or "").strip()
    short = (kurz or "").strip()
    if mit_text:
        label = short if short else (lang or "?")
    else:
        label = short or lang or "?"
    if horizontal:
        if mit_text:
            limit = 10
            return label if len(label) <= limit else label[: limit - 1] + "\u2026"
        if len(label) <= 8:
            return label
        return label[:7] + "\u2026"
    if mit_text:
        limit = 8
        if label.startswith(":") or len(label) <= limit:
            return label
        return label[: limit - 1] + "\u2026"
    if len(label) <= 6:
        return label
    return label[:5] + "\u2026"


def grip_fg(bg_hex: str) -> str:
    bg = (bg_hex or "#606060").lstrip("#")
    if len(bg) != 6:
        return "#e8e8e8"
    try:
        r, g, b = int(bg[0:2], 16), int(bg[2:4], 16), int(bg[4:6], 16)
    except ValueError:
        return "#e8e8e8"
    lux = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
    return "#222222" if lux >= 0.45 else "#e8e8e8"


def grip_photo(fg: str, bg: str, *, vertical: bool = False) -> tk.PhotoImage:
    if vertical:
        w, h = 22, 18
        zentren = ((6, 4), (15, 4), (6, 9), (15, 9), (6, 14), (15, 14))
    else:
        w, h = 14, 26
        zentren = ((4, 5), (9, 5), (4, 12), (9, 12), (4, 19), (9, 19))
    img = tk.PhotoImage(width=w, height=h)
    img.put(bg, to=(0, 0, w, h))
    for cx, cy in zentren:
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dx * dx + dy * dy > 1:
                    continue
                x, y = cx + dx, cy + dy
                if 0 <= x < w and 0 <= y < h:
                    img.put(fg, to=(x, y))
    return img
