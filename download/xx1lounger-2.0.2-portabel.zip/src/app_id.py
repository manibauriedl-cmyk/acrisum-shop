"""Programm-Identität — eine Quelle für alles, was Windows pro App unterscheidet.

Diese Kopie (D:\\xx1lounger) läuft neben dem Original (D:\\_xLounger).
Alles, was beide sonst teilen würden, hängt an APP_NAME:
Mutex, Fenstertitel, %APPDATA%-Ordner, Startmenü-/Autostart-Verknüpfung,
AUMID, Tray-Tooltip, Zweitstart-Message. Ein anderer Name = eigener Baum.
"""

APP_NAME = "xx1lounger"
