import sys
import traceback
import logging
import tkinter.messagebox as msgbox

_im_dialog = False


def _fehlerbericht_url() -> str:
    import json

    from src.paths import get_config_path

    try:
        return str(
            json.loads(get_config_path().read_text(encoding="utf-8")).get(
                "fehlerbericht_url", ""
            )
            or ""
        )
    except Exception:
        return ""


def fehler_dialog(exc_type, exc_value, exc_tb) -> None:
    """Öffnet den Fehlerbericht-Dialog — Kunde wählt selbst:
    Datei speichern / per eigener Mail senden / direkt an Acrisum."""
    global _im_dialog
    if _im_dialog:
        return
    _im_dialog = True
    try:
        import tkinter as tk

        from src import fehlerbericht

        root = tk._default_root
        neu = root is None
        if neu:
            root = tk.Tk()
            root.withdraw()
        dlg = fehlerbericht.bericht_dialog(
            root,
            anlass="Unerwarteter Fehler:\n"
            + "".join(traceback.format_exception(exc_type, exc_value, exc_tb)),
            server_url=_fehlerbericht_url(),
        )
        if neu and dlg is not None:
            # Kein Mainloop aktiv (Absturz vorm/außerhalb der Leiste):
            # eigener Tk + wait_window macht den Dialog trotzdem bedienbar.
            root.wait_window(dlg)
            root.destroy()
    finally:
        _im_dialog = False


def install():
    def handler(exc_type, exc_value, exc_tb):
        text = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        logging.error("Unhandled exception:\n%s", text)
        try:
            fehler_dialog(exc_type, exc_value, exc_tb)
        except Exception:
            try:
                msgbox.showerror(
                    "xlounger Fehler",
                    f"Ein unerwarteter Fehler ist aufgetreten:\n\n{exc_value}\n\n"
                    "Details wurden in xlounger.log geschrieben.",
                )
            except Exception:
                pass

    sys.excepthook = handler
