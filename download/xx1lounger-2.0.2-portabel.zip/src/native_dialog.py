"""Windows-Dateidialog ohne Geister-Titelleiste.

Tk `filedialog` legt ein Owner-Toplevel an. Ist der parent `overrideredirect`
oder `-topmost` (Leiste / Anheften-Panel), erscheint dieses Owner-Fenster als
kleine leere Titelleiste UEBER dem Explorer-Dialog und schneidet das Suchfeld
ab (Screenshot 05.10.2026: „unger durchsuchen“ statt „xx1lounger durchsuchen“).

Loesung: unsichtbarer, normaler Owner ohne topmost; topmost am Aufrufer
kurz aus, Grab loesen, danach wiederherstellen.
"""
from __future__ import annotations

import tkinter as tk
from tkinter import filedialog
from collections.abc import Callable
from typing import Any


def _topmost_kette(widget: tk.Misc | None) -> list[tk.Misc]:
    gefunden: list[tk.Misc] = []
    w = widget
    gesehen: set[int] = set()
    while w is not None:
        wid = id(w)
        if wid in gesehen:
            break
        gesehen.add(wid)
        try:
            if bool(w.attributes("-topmost")):
                gefunden.append(w)
        except tk.TclError:
            pass
        try:
            w = w.master  # type: ignore[assignment]
        except tk.TclError:
            break
    return gefunden


def owner_anlegen(parent: tk.Misc | None) -> tuple[tk.Toplevel, Callable[[], None]]:
    """Normales, unsichtbares Owner-Fenster + Wiederhersteller."""
    owner = tk.Toplevel(parent) if parent is not None else tk.Toplevel()
    owner.withdraw()
    owner.overrideredirect(False)
    try:
        owner.attributes("-topmost", False)
    except tk.TclError:
        pass
    owner.title("")
    try:
        if parent is not None:
            parent.update_idletasks()
            x = int(parent.winfo_rootx())
            y = int(parent.winfo_rooty())
            owner.geometry(f"1x1+{x}+{y}")
    except tk.TclError:
        pass
    try:
        owner.update_idletasks()
    except tk.TclError:
        pass

    ausgeschaltet = []
    for w in _topmost_kette(parent):
        try:
            w.attributes("-topmost", False)
            ausgeschaltet.append(w)
        except tk.TclError:
            pass

    grab = None
    try:
        grab = parent.grab_current() if parent is not None else None
    except tk.TclError:
        grab = None
    if grab is not None:
        try:
            grab.grab_release()
        except tk.TclError:
            grab = None

    def wiederherstellen() -> None:
        for w in ausgeschaltet:
            try:
                if w.winfo_exists():
                    w.attributes("-topmost", True)
            except tk.TclError:
                pass
        if grab is not None:
            try:
                if grab.winfo_exists():
                    grab.grab_set()
            except tk.TclError:
                pass
        try:
            owner.destroy()
        except tk.TclError:
            pass

    return owner, wiederherstellen


def _ask(fn: Callable[..., Any], parent: tk.Misc | None, **kwargs: Any) -> str:
    owner, wiederherstellen = owner_anlegen(parent)
    try:
        wert = fn(parent=owner, **kwargs)
        return wert or ""
    finally:
        wiederherstellen()


def askdirectory(parent: tk.Misc | None = None, **kwargs: Any) -> str:
    return _ask(filedialog.askdirectory, parent, **kwargs)


def askopenfilename(parent: tk.Misc | None = None, **kwargs: Any) -> str:
    return _ask(filedialog.askopenfilename, parent, **kwargs)
