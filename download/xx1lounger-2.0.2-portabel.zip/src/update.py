"""Update-System (KVA 277–288, 293/294).

Quelle: latest.json von konfigurierbaren URLs (config.json →
„update_urls": [primaer, fallback]). Keine URLs fest im Code.

Format latest.json (bewährtes Shop-Format wird mitgelesen):
    {"version": "1.2.3", "setup_url": "https://…/xlounger-setup.exe",
     "sha256": "…", "win_min": "10.0", "hinweis": "…", "python": "3.12"}
    Generische Alternativen: „url" statt setup_url, „notes" statt hinweis.

Status liegt in %APPDATA%\\xx1lounger\\update-status.json:
    letzte_pruefung (ISO)        — KVA 279: max. 1×/24 h
    abgelehnte_version, am (ISO) — KVA 283: 24 h nicht erneut anbieten
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import subprocess
import sys
import tempfile
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path

TIMEOUT_SEK = 8
PRUEF_INTERVALL = timedelta(hours=24)
ABLEHNUNG_SPERRE = timedelta(hours=24)


def _status_pfad() -> Path:
    from src.paths import get_appdata_dir

    return get_appdata_dir() / "update-status.json"


def status_lesen() -> dict:
    try:
        return json.loads(_status_pfad().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _status_schreiben(status: dict) -> None:
    try:
        _status_pfad().parent.mkdir(parents=True, exist_ok=True)
        _status_pfad().write_text(
            json.dumps(status, ensure_ascii=False, indent=1), encoding="utf-8"
        )
    except OSError as exc:
        logging.warning("Update-Status nicht schreibbar: %s", exc)


# ---------- KVA 281 — latest.json laden (primär + Fallback) ----------

def lade_latest_json(urls: list[str], timeout: float = TIMEOUT_SEK) -> dict | None:
    """Erste URL, die ein gültiges latest.json liefert. None bei Totalausfall."""
    for url in urls:
        try:
            with urllib.request.urlopen(url, timeout=timeout) as antwort:
                daten = json.loads(antwort.read().decode("utf-8"))
            if daten.get("version"):
                logging.info("Update-Info geladen von %s", url)
                return daten
            logging.warning("Update-Info ohne version-Feld: %s", url)
        except Exception as exc:
            logging.warning("Update-Quelle %s fehlgeschlagen: %s", url, exc)
    return None


# ---------- Vergleiche ----------

def _version_tuple(v: str) -> tuple[int, ...]:
    try:
        return tuple(int(p) for p in str(v).lstrip("v").split(".")[:3])
    except ValueError:
        return (0,)


def update_verfuegbar(latest: dict, aktuell: str) -> bool:
    return _version_tuple(latest.get("version", "0")) > _version_tuple(aktuell)


def download_url(latest: dict) -> str:
    """Download-Adresse — Shop-Format (setup_url) bevorzugt, sonst „url"."""
    return str(latest.get("setup_url") or latest.get("url") or "")


def hinweis(latest: dict) -> str:
    """Anzeigetext — Shop-Format (hinweis) bevorzugt, sonst „notes"."""
    return str(latest.get("hinweis") or latest.get("notes") or "")


def windows_passt(latest: dict) -> bool:
    """KVA 284 — win_min aus latest.json gegen dieses Windows."""
    win_min = str(latest.get("win_min", "") or "")
    if not win_min:
        return True
    try:
        major, minor = (int(p) for p in win_min.split(".")[:2])
    except ValueError:
        return True
    v = sys.getwindowsversion()
    return (v.major, v.minor) >= (major, minor)


# ---------- KVA 279/283 — Zeitregeln ----------

def pruefung_faellig(jetzt: datetime | None = None) -> bool:
    """KVA 279 — höchstens einmal pro 24 h automatisch prüfen."""
    jetzt = jetzt or datetime.now()
    roh = status_lesen().get("letzte_pruefung")
    if not roh:
        return True
    try:
        return jetzt - datetime.fromisoformat(roh) >= PRUEF_INTERVALL
    except ValueError:
        return True


def pruefung_vermerken() -> None:
    status = status_lesen()
    status["letzte_pruefung"] = datetime.now().isoformat(timespec="seconds")
    _status_schreiben(status)


def version_ablehnen(version: str) -> None:
    """KVA 283 — abgelehnte Version 24 h nicht erneut anbieten."""
    status = status_lesen()
    status["abgelehnte_version"] = version
    status["abgelehnt_am"] = datetime.now().isoformat(timespec="seconds")
    _status_schreiben(status)


def ist_abgelehnt(version: str, jetzt: datetime | None = None) -> bool:
    jetzt = jetzt or datetime.now()
    status = status_lesen()
    if status.get("abgelehnte_version") != version:
        return False
    try:
        am = datetime.fromisoformat(status.get("abgelehnt_am", ""))
    except ValueError:
        return False
    return jetzt - am < ABLEHNUNG_SPERRE


# ---------- KVA 282/285 — Download, Hash, stille Installation ----------

def sha256_datei(pfad: Path) -> str:
    h = hashlib.sha256()
    with open(pfad, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def lade_setup_herunter(url: str, erwarteter_sha256: str = "") -> Path | None:
    """KVA 282 — Setup laden und SHA256 prüfen. None bei Fehler/Mismatch."""
    try:
        ziel = Path(tempfile.gettempdir()) / "xlounger-setup.exe"
        with urllib.request.urlopen(url, timeout=TIMEOUT_SEK * 4) as antwort:
            ziel.write_bytes(antwort.read())
    except Exception as exc:
        logging.error("Setup-Download fehlgeschlagen: %s", exc)
        return None
    if erwarteter_sha256:
        ist = sha256_datei(ziel)
        if ist.lower() != erwarteter_sha256.lower():
            logging.error(
                "SHA256-Mismatch: erwartet %s, geladen %s", erwarteter_sha256, ist
            )
            try:
                ziel.unlink()
            except OSError:
                pass
            return None
    return ziel


def installiere_still(setup: Path) -> int:
    """KVA 285 — Inno Setup still. Rueckgabe: Prozess-Returncode."""
    logging.info("Starte stille Installation: %s", setup)
    proc = subprocess.run(
        [str(setup), "/VERYSILENT", "/NORESTART", "/CLOSEAPPLICATIONS"],
        timeout=600,
    )
    return proc.returncode
