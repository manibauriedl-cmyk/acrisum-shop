"""Monitore ermitteln — Win 8.1+ (EnumDisplayMonitors / MONITORINFOEX).

Anzahl egal (1, 2, 5 …): xlounger nutzt immer den Windows-Hauptmonitor (primär).
"""
import ctypes
from ctypes import wintypes

user32 = ctypes.windll.user32

try:
    import tkinter as tk
    from tkinter import ttk
except Exception:
    tk = None

try:
    win32api = None
    import win32api
except Exception:
    pass

MONITORINFOF_PRIMARY = 1
EDD_GET_DEVICE_INTERFACE_NAME = 1


class RECT(ctypes.Structure):
    _fields_ = [
        ("left", ctypes.c_long),
        ("top", ctypes.c_long),
        ("right", ctypes.c_long),
        ("bottom", ctypes.c_long),
    ]


class MONITORINFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("rcMonitor", RECT),
        ("rcWork", RECT),
        ("dwFlags", wintypes.DWORD),
    ]


class MONITORINFOEXW(ctypes.Structure):
    """Gerätename pro Monitor — zuverlässig seit Win 8.1/XP (nicht Index-Raten)."""

    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("rcMonitor", RECT),
        ("rcWork", RECT),
        ("dwFlags", wintypes.DWORD),
        ("szDevice", wintypes.WCHAR * 32),
    ]


class DISPLAY_DEVICE(ctypes.Structure):
    _fields_ = [
        ("cb", wintypes.DWORD),
        ("DeviceName", wintypes.WCHAR * 32),
        ("DeviceString", wintypes.WCHAR * 128),
        ("StateFlags", wintypes.DWORD),
        ("DeviceID", wintypes.WCHAR * 128),
        ("DeviceKey", wintypes.WCHAR * 128),
    ]


class _Rect:
    def __init__(self, left, top, right, bottom):
        self.left = left
        self.top = top
        self.right = right
        self.bottom = bottom

    def as_tuple(self):
        return (self.left, self.top, self.right, self.bottom)

    def __repr__(self):
        return f"Rect({self.left},{self.top},{self.right},{self.bottom})"


class Monitor:
    def __init__(self, handle, rect, work, is_primary, dpi=96, device_name=""):
        self.handle = handle
        self.rect = _Rect(*rect)
        self.work = _Rect(*work)
        self.is_primary = is_primary
        self.dpi = dpi
        self.scale = dpi / 96.0
        self.device_name = device_name or ""

    @property
    def x(self):
        return self.rect.left

    @property
    def y(self):
        return self.rect.top

    @property
    def width(self):
        return self.rect.right - self.rect.left

    @property
    def height(self):
        return self.rect.bottom - self.rect.top

    @property
    def work_x(self):
        return self.work.left

    @property
    def work_y(self):
        return self.work.top

    @property
    def work_width(self):
        return self.work.right - self.work.left

    @property
    def work_height(self):
        return self.work.bottom - self.work.top

    def key(self):
        return self.device_name or f"{self.rect.left},{self.rect.top},{self.width}x{self.height}"

    def label(self):
        prim = " (primär)" if self.is_primary else ""
        return (
            f"{self.device_name or 'Monitor'}{prim} — "
            f"{self.width}x{self.height} @ {self.rect.left},{self.rect.top} "
            f"[Arbeitsbereich {self.work_width}x{self.work_height}]"
        )


_monitor_list = []
_monitor_handles = []


def _monitor_enum_proc(hMonitor, hdcMonitor, lprcMonitor, dwData):
    _monitor_handles.append(hMonitor)
    return True


MONITORENUMPROC = ctypes.WINFUNCTYPE(
    ctypes.c_bool,
    wintypes.HMONITOR,
    wintypes.HDC,
    ctypes.POINTER(RECT),
    wintypes.LPARAM,
)


def _get_dpi_for_monitor(hMonitor):
    """Win 8.1+: GetDpiForMonitor; sonst 96 (LogPixels-Fallback reicht für Leiste)."""
    dpi_x = ctypes.c_uint(0)
    dpi_y = ctypes.c_uint(0)
    try:
        shcore = ctypes.windll.shcore
        shcore.GetDpiForMonitor(hMonitor, 0, ctypes.byref(dpi_x), ctypes.byref(dpi_y))
        if dpi_x.value > 0:
            return dpi_x.value
    except Exception:
        pass
    return 96


def get_monitors():
    global _monitor_handles
    _monitor_handles = []
    cb = MONITORENUMPROC(_monitor_enum_proc)
    user32.EnumDisplayMonitors(None, None, cb, 0)

    monitors = []
    for hMonitor in _monitor_handles:
        info = MONITORINFOEXW()
        info.cbSize = ctypes.sizeof(MONITORINFOEXW)
        if not user32.GetMonitorInfoW(hMonitor, ctypes.byref(info)):
            continue

        rect = info.rcMonitor
        work = info.rcWork
        is_primary = bool(info.dwFlags & MONITORINFOF_PRIMARY)
        dpi = _get_dpi_for_monitor(hMonitor)
        device_name = (info.szDevice or "").strip()

        monitors.append(
            Monitor(
                handle=hMonitor,
                rect=(rect.left, rect.top, rect.right, rect.bottom),
                work=(work.left, work.top, work.right, work.bottom),
                is_primary=is_primary,
                dpi=dpi,
                device_name=device_name,
            )
        )
    return monitors


def monitor_count() -> int:
    """Angeschlossene Monitore (mindestens 1 wenn Enumeration leer)."""
    n = len(get_monitors())
    return max(1, n)


def get_primary_monitor():
    for m in get_monitors():
        if m.is_primary:
            return m
    monitors = get_monitors()
    if monitors:
        return monitors[0]
    return None


def reservierung_insets(monitor: Monitor | None) -> tuple[int, int, int, int]:
    """Pixel, die am Monitorrand schon belegt sind (Taskleiste, AppBars, …).

    Differenz rcMonitor vs. rcWork (Taskleiste, AppBars, Zusatzleisten — ohne Tool-Namen).
    Rückgabe: (oben, unten, links, rechts).
    """
    if monitor is None:
        return (0, 0, 0, 0)
    sl, st, sr, sb = monitor.rect.as_tuple()
    wl, wt, wr, wb = monitor.work.as_tuple()
    return (
        max(0, int(wt - st)),
        max(0, int(sb - wb)),
        max(0, int(wl - sl)),
        max(0, int(sr - wr)),
    )


def primary_monitor_frisch(vorher: Monitor | None = None) -> Monitor | None:
    """Hauptmonitor neu lesen — rcWork inkl. aller fremden Reservierungen."""
    return get_primary_monitor()


def monitor_at_point(x: int, y: int) -> Monitor | None:
    """Monitor unter Bildschirmkoordinate (nächster)."""
    u = user32
    rc = RECT(int(x), int(y), int(x) + 1, int(y) + 1)
    try:
        u.MonitorFromRect.restype = wintypes.HMONITOR
        hmon = u.MonitorFromRect(ctypes.byref(rc), 2)
    except Exception:
        hmon = None
    if not hmon:
        return get_primary_monitor()
    for m in get_monitors():
        if m.handle == hmon:
            return m
    return get_primary_monitor()


def is_point_on_primary(x: int, y: int) -> bool:
    """True, wenn (x,y) auf dem Windows-Hauptmonitor liegt (KVA 299)."""
    m = monitor_at_point(x, y)
    return bool(m and m.is_primary)


def is_point_on_monitor(m: Monitor | None, x: int, y: int) -> bool:
    if not m:
        return False
    return m.rect.left <= int(x) < m.rect.right and m.rect.top <= int(y) < m.rect.bottom


def monitors_overview_lines() -> list[str]:
    """Alle Monitore lesbar auflisten — Erkennung für Nutzer."""
    liste = get_monitors()
    if not liste:
        return ["Kein Monitor ermittelt."]
    zeilen = [f"{len(liste)} Monitor(e) erkannt:", ""]
    for m in liste:
        zeilen.append(f"• {m.label()}")
    prim = get_primary_monitor()
    if prim:
        oben, unten, links, rechts = reservierung_insets(prim)
        zeilen.append("")
        zeilen.append(
            "Rand am Hauptmonitor (Arbeitsfläche, alle Leisten/Taskleiste): "
            f"oben {oben} px, unten {unten} px, links {links} px, rechts {rechts} px"
        )
    zeilen.append("")
    zeilen.append("xlounger ist nur auf dem Hauptmonitor (primär) sichtbar.")
    return zeilen


def get_monitor_for_window(hwnd):
    hMonitor = user32.MonitorFromWindow(hwnd, 2)
    if not hMonitor:
        return get_primary_monitor()
    for m in get_monitors():
        if m.handle == hMonitor:
            return m
    return get_primary_monitor()


def find_monitor_by_key(key):
    for m in get_monitors():
        if m.key() == key:
            return m
    return None


def get_dpi_for_window(hwnd):
    """Win 10+; auf Win 8.1 immer 96 — bewusster Fallback."""
    try:
        dpi = user32.GetDpiForWindow(hwnd)
        if dpi > 0:
            return dpi
    except Exception:
        pass
    if win32api:
        try:
            return win32api.GetDpiForWindow(hwnd)
        except Exception:
            pass
    return 96


def select_monitor_dialog(monitors, parent=None):
    """Returns selected Monitor or None."""
    if not tk or not monitors:
        return get_primary_monitor()

    root = tk.Toplevel(parent) if parent else tk.Tk()
    root.title("xlounger — Monitor auswählen")
    root.resizable(False, False)
    if not parent:
        root.withdraw()

    selected = {"value": None}

    tk.Label(
        root,
        text="Wähle den Monitor für xlounger:",
        font=("Segoe UI", 10),
    ).pack(padx=12, pady=(12, 8))

    var = tk.StringVar(value=monitors[0].key())
    for m in monitors:
        tk.Radiobutton(
            root,
            text=m.label(),
            variable=var,
            value=m.key(),
            font=("Segoe UI", 9),
            anchor="w",
            justify=tk.LEFT,
        ).pack(fill=tk.X, padx=12, pady=2)

    def _ok():
        selected["value"] = find_monitor_by_key(var.get())
        root.destroy()

    tk.Button(root, text="OK", command=_ok).pack(pady=(8, 12))

    if not parent:
        root.deiconify()
    root.grab_set()
    root.transient(parent) if parent else None
    root.wait_window(root)

    return selected["value"] or get_primary_monitor()
