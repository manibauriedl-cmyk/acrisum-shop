"""Fenster zu Leisten-Eintraegen finden — einheitlicher Einstieg (KVA 164).

KVA 163  Browser-Titel-Matching (Chrome/Edge/Firefox-Suffixe abziehen)
KVA 165  Explorer: Fenstertitel = Ordnername
KVA 166  ms-settings: → Einstellungen-Fenster
KVA 167  Shell-Namespace (Papierkorb, Dieser PC) → Titel-Mapping
KVA 170  HWND merken und wieder fokussieren (mit window_focus)
KVA 172  LibreOffice-Suite (Writer/Calc/Impress am Titel)
KVA 173  Microsoft-Office-Suite (WINWORD/EXCEL/POWERPNT)
KVA 174  Thunderbird
KVA 175  Access (MSACCESS)
KVA 186  Lock-Datei-Erkennung bei Office-Dokumenten
KVA 187  Elevated-Fenster-Fokus (AttachThreadInput statt nur SetForegroundWindow)
KVA 338  Taskleisten-klassierte Fenster auch ohne Fenstertitel (Window-Walker-Analogie)
"""
from __future__ import annotations

import os
from pathlib import Path

GWL_EXSTYLE = -20
GW_OWNER = 4
WS_EX_TOOLWINDOW = 0x00000080
WS_EX_APPWINDOW = 0x00040000

_BROWSER_PROZESSE = {
    "chrome.exe": (" - Google Chrome",),
    "msedge.exe": (" - Microsoft Edge",),
    "firefox.exe": (" – Mozilla Firefox", " - Mozilla Firefox"),
    "brave.exe": (" - Brave",),
    "opera.exe": (" - Opera",),
}

# KVA 166 — ms-settings: Unterseite → erwarteter Titel-Baustein
_MS_SETTINGS_TITEL = {
    "ms-settings:display": ("Anzeige", "Einstellungen"),
    "ms-settings:network": ("Netzwerk", "Einstellungen"),
    "ms-settings:bluetooth": ("Bluetooth", "Einstellungen"),
    "ms-settings:windowsupdate": ("Windows Update", "Einstellungen"),
    "ms-settings:appsfeatures": ("Apps", "Einstellungen"),
    "ms-settings:personalization": ("Personalisierung", "Einstellungen"),
    "ms-settings:system": ("System", "Einstellungen"),
}

# KVA 167 — Shell-Namespace → Explorer-Fenstertitel
_SHELL_TITEL = {
    "shell:recyclebinfolder": ("Papierkorb",),
    "shell:mycomputerfolder": ("Dieser PC",),
    "shell:controlpanelfolder": ("Systemsteuerung",),
    "shell:downloads": ("Downloads",),
    "shell:documentslibrary": ("Dokumente",),
    "shell:pictureslibrary": ("Bilder",),
}

# KVA 173/175 — MS-Office Prozess → Suite-Name
_MS_OFFICE = {
    "winword.exe": "Word",
    "excel.exe": "Excel",
    "powerpnt.exe": "PowerPoint",
    "outlook.exe": "Outlook",
    "msaccess.exe": "Access",
    "mspub.exe": "Publisher",
    "onenote.exe": "OneNote",
}

# KVA 172 — LibreOffice Titel-Suffix → Teil
_LIBRE_SUFFIX = (
    " - LibreOffice Writer",
    " - LibreOffice Calc",
    " - LibreOffice Impress",
    " - LibreOffice Draw",
    " - LibreOffice Base",
    " - LibreOffice Math",
)

# Dokument-Endung → moegliche Prozesse (Suite-Erkennung)
_DOK_PROZESSE = {
    ".doc": ("winword.exe", "soffice.exe"), ".docx": ("winword.exe", "soffice.exe"),
    ".dotx": ("winword.exe", "soffice.exe"), ".rtf": ("winword.exe", "soffice.exe"),
    ".xls": ("excel.exe", "soffice.exe"), ".xlsx": ("excel.exe", "soffice.exe"),
    ".csv": ("excel.exe", "soffice.exe"),
    ".ppt": ("powerpnt.exe", "soffice.exe"), ".pptx": ("powerpnt.exe", "soffice.exe"),
    ".odt": ("soffice.exe",), ".ods": ("soffice.exe",), ".odp": ("soffice.exe",),
    ".accdb": ("msaccess.exe",), ".mdb": ("msaccess.exe",),
    ".eml": ("thunderbird.exe", "outlook.exe"),
}


def _prozessname_zu_pid(pid: int) -> str:
    # psutil zuerst (robust); win32process.OpenProcess existiert nicht in allen Builds!
    try:
        import psutil

        return (psutil.Process(int(pid)).name() or "").lower()
    except Exception:
        pass
    try:
        import win32api
        import win32process

        h = win32api.OpenProcess(0x0400 | 0x0010, False, int(pid))  # QUERY_INFORMATION | VM_READ
        try:
            return os.path.basename(win32process.GetModuleFileNameEx(h, 0)).lower()
        finally:
            h.Close()
    except Exception:
        return ""


def fenster_gehoert_zu_enum_pool(
    *,
    sichtbar: bool,
    minimiert: bool,
    titel: str,
    ex_style: int = 0,
    owner_hwnd: int = 0,
    owner_sichtbar: bool = False,
) -> bool:
    """KVA 338 — Aufnahme in ``alle_sichtbaren_fenster()`` (testbar ohne Win32).

    Mit Titel: wie bisher. Ohne Titel: nur wenn Windows die Fläche als
    Taskleisten-Anwendung führt (``WS_EX_APPWINDOW``), nicht reine Tool-Palette.
    """
    if not sichtbar or minimiert:
        return False
    if str(titel or "").strip():
        return True
    if (ex_style & WS_EX_TOOLWINDOW) and not (ex_style & WS_EX_APPWINDOW):
        return False
    if ex_style & WS_EX_APPWINDOW:
        return True
    if owner_hwnd and owner_sichtbar:
        return False
    if owner_hwnd and not owner_sichtbar:
        return True
    return False


def alle_sichtbaren_fenster() -> list[tuple[int, str, int, str]]:
    """(hwnd, titel, pid, prozessname) sichtbare Toplevel-Fenster (KVA 338: auch ohne Titel)."""
    import win32gui
    import win32process

    out: list[tuple[int, str, int, str]] = []

    def _enum(hwnd, _):
        if not win32gui.IsWindowVisible(hwnd) or win32gui.IsIconic(hwnd):
            return
        titel = win32gui.GetWindowText(hwnd) or ""
        try:
            ex_style = int(win32gui.GetWindowLong(hwnd, GWL_EXSTYLE))
        except Exception:
            ex_style = 0
        owner = int(win32gui.GetWindow(hwnd, GW_OWNER) or 0)
        owner_sichtbar = bool(owner and win32gui.IsWindowVisible(owner))
        if not fenster_gehoert_zu_enum_pool(
            sichtbar=True,
            minimiert=False,
            titel=titel,
            ex_style=ex_style,
            owner_hwnd=owner,
            owner_sichtbar=owner_sichtbar,
        ):
            return
        try:
            _tid, pid = win32process.GetWindowThreadProcessId(hwnd)
        except Exception:
            return
        out.append((hwnd, titel, pid, _prozessname_zu_pid(pid)))

    try:
        win32gui.EnumWindows(_enum, None)
    except Exception:
        pass
    return out


def _browser_titel_heilen(titel: str, prozess: str) -> str:
    """KVA 163 — Browser-Suffix abziehen: 'Seite - Google Chrome' → 'Seite'."""
    for suffix in _BROWSER_PROZESSE.get(prozess, ()):
        if titel.endswith(suffix):
            return titel[: -len(suffix)].strip()
    return titel


def _libre_titel_heilen(titel: str) -> str:
    """KVA 172 — 'Dok.odt - LibreOffice Writer' → 'Dok.odt'."""
    for suffix in _LIBRE_SUFFIX:
        if titel.endswith(suffix):
            return titel[: -len(suffix)].strip()
    return titel


def _norm(text: str) -> str:
    # Bindestriche/Unterstriche als Worttrenner behandeln: Dateiname
    # „telegram-pc-bruecke.bat" vs. Konsolen-Titel „telegram pc-bruecke"
    # (title-Befehl mit Leerzeichen) — sonst findet der
    # Laeuft-Dialog BAT-/CMD-Fenster nie (24.09.2026).
    t = str(text or "").replace("-", " ").replace("_", " ")
    return " ".join(t.casefold().split())


def _erwartete_prozesse(target: str) -> tuple[set[str], str]:
    """(Prozessnamen, Titel-Hinweis) fuer ein Ziel."""
    t = str(target or "").strip()
    low = t.lower()

    if low.startswith(("http://", "https://")):
        return set(_BROWSER_PROZESSE), t
    if low.startswith("ms-settings:"):
        return {"systemsettings.exe"}, t
    if low.startswith("shell:"):
        return {"explorer.exe"}, t

    p = Path(t)
    suffix = p.suffix.lower()
    if suffix == ".lnk":
        try:
            from .launcher import resolve_lnk

            ziel, _args = resolve_lnk(t)
            if ziel:
                zp = Path(ziel)
                if zp.suffix.lower() == ".exe":
                    return {zp.name.lower()}, zp.stem
                if zp.is_dir():
                    return {"explorer.exe"}, zp.name
        except Exception:
            pass
        return set(), p.stem
    if suffix == ".exe":
        return {p.name.lower()}, p.stem
    if suffix == ".msc":
        return {"mmc.exe"}, p.stem
    if p.is_dir():
        return {"explorer.exe"}, p.name
    if suffix in _DOK_PROZESSE:
        return set(_DOK_PROZESSE[suffix]), p.stem
    if p.is_file():
        return set(), p.stem
    return set(), p.stem


def _titel_passt(titel: str, prozess: str, hinweis: str, target: str) -> bool:
    """KVA 164 — geheilter Titel gegen Hinweis; kein falsches Matching."""
    if not hinweis:
        return True
    # Generischer Explorer-Hinweis darf nicht auf jeden Fenstertitel mit 'Datei-Explorer' anspringen
    if prozess == "explorer.exe" and hinweis.casefold() in ("explorer", "explorer.exe"):
        return False
    geheilt = _browser_titel_heilen(titel, prozess)
    geheilt = _libre_titel_heilen(geheilt)
    nt, nh = _norm(geheilt), _norm(hinweis)
    if not nh:
        return True
    if nh in nt or nt in nh:
        return True
    # KVA 165 — Explorer: Titel ist Ordnername
    if prozess == "explorer.exe":
        return _norm(Path(hinweis).name) in nt
    return False


def offene_explorer_fenster() -> list[tuple[int, str, str]]:
    """(hwnd, titel, ordnerpfad_normalisiert) aller offenen Explorer-Fenster via Shell.Application.
    Bei Fenstern ohne konkreten Dateisystempfad (z.B. 'Dieser PC', 'Schnellzugriff') ist der Pfad leer string ''.
    """
    out: list[tuple[int, str, str]] = []
    try:
        import pythoncom
        import win32com.client
        import win32gui
        pythoncom.CoInitialize()
        shell = win32com.client.Dispatch("Shell.Application")
        for w in shell.Windows():
            try:
                hwnd = int(getattr(w, "HWND", 0))
                if not hwnd or not win32gui.IsWindow(hwnd) or not win32gui.IsWindowVisible(hwnd):
                    continue
                loc_name = str(getattr(w, "LocationName", "") or "").strip()
                titel = (win32gui.GetWindowText(hwnd) or loc_name or "Explorer").strip()
                doc = getattr(w, "Document", None)
                folder = getattr(doc, "Folder", None)
                self_item = getattr(folder, "Self", None)
                raw_path = getattr(self_item, "Path", "") if self_item else ""
                norm_p = os.path.normcase(os.path.abspath(raw_path)) if raw_path and os.path.exists(raw_path) else ""
                out.append((hwnd, titel, norm_p))
            except Exception:
                pass
    except Exception:
        pass
    return out


def _ermittle_ordner_pfad(target: str) -> str | None:
    """Ermittelt den Zielordner-Pfad (normalisiert), falls target ein Ordner ist."""
    t = str(target or "").strip()
    if not t:
        return None
    try:
        if os.path.isdir(t):
            return os.path.normcase(os.path.abspath(t))
    except Exception:
        pass
    low = t.lower()
    if low.endswith(".lnk"):
        try:
            from .launcher import resolve_lnk
            ziel, args = resolve_lnk(t)
            if ziel:
                if os.path.isdir(ziel):
                    return os.path.normcase(os.path.abspath(ziel))
                if Path(ziel).name.lower() == "explorer.exe" and args:
                    clean = args.strip().strip('"')
                    if clean.lower().startswith("/select,"):
                        sp = clean[8:].strip().strip('"')
                        if os.path.isdir(sp):
                            return os.path.normcase(os.path.abspath(sp))
                        if os.path.isfile(sp):
                            return os.path.normcase(os.path.abspath(str(Path(sp).parent)))
                    elif os.path.isdir(clean):
                        return os.path.normcase(os.path.abspath(clean))
        except Exception:
            pass
    if low.startswith("explorer.exe ") or low.startswith("explorer "):
        parts = t.split(None, 1)
        if len(parts) > 1:
            clean = parts[1].strip().strip('"')
            if clean.lower().startswith("/select,"):
                sp = clean[8:].strip().strip('"')
                if os.path.isdir(sp):
                    return os.path.normcase(os.path.abspath(sp))
                if os.path.isfile(sp):
                    return os.path.normcase(os.path.abspath(str(Path(sp).parent)))
            elif os.path.isdir(clean):
                return os.path.normcase(os.path.abspath(clean))
    return None


def _ist_generischer_explorer(target: str) -> bool:
    """True wenn target den Windows Explorer ohne spezifischen Ordnerpfad startet."""
    t = str(target or "").strip()
    low = t.lower()
    if low in ("explorer", "explorer.exe"):
        return True
    if low.endswith(".lnk"):
        try:
            from .launcher import resolve_lnk
            ziel, args = resolve_lnk(t)
            if ziel and Path(ziel).name.lower() == "explorer.exe" and not (args or "").strip():
                return True
        except Exception:
            pass
    return False


def _ermittle_erwartete_args(target: str) -> list[str]:
    """Liefert signifikante Argument-Tokens für Programmstarts mit Parametern."""
    t = str(target or "").strip()
    low = t.lower()
    args_str = ""
    if low.endswith(".lnk"):
        try:
            from .launcher import resolve_lnk
            _ziel, args = resolve_lnk(t)
            if args:
                args_str = args
        except Exception:
            pass
    elif " " in t and not os.path.exists(t):
        parts = t.split(None, 1)
        if len(parts) > 1 and parts[0].lower().endswith(".exe"):
            args_str = parts[1]
    if not args_str.strip():
        return []
    tokens = []
    for part in args_str.strip().split():
        # Alle Anfuehrungszeichen raus — psutil.cmdline() liefert Argumente
        # ohne Quoting (…=-J-DjtsConfigDir=C:\x), sonst matcht der Token nie
        # (08.10.2026: Trading.lnk fand das laufende TWS nicht).
        clean = part.replace('"', "").replace("'", "").casefold()
        if len(clean) >= 3 and not clean.startswith("/"):
            tokens.append(clean)
    return tokens


def _prozess_cmdline(pid: int) -> str:
    try:
        import psutil
        return " ".join(psutil.Process(int(pid)).cmdline()).casefold()
    except Exception:
        return ""


def fenster_der_prozesse(pids: set[int]) -> list[tuple[int, str]]:
    """Fenster (sichtbar ODER minimiert) dieser Prozess-IDs.

    Fallback, wenn der Titel-/Prozess-Abgleich leer ausgeht, weil das
    Fenster einem Kindprozess oder einer Schwester-exe gehoert
    (OpenOffice: soffice.bin statt soffice.exe; TWS: java statt tws.exe).
    Fenster mit Titel zuerst.
    """
    if not pids:
        return []
    import win32gui
    import win32process

    mit_titel: list[tuple[int, str]] = []
    ohne_titel: list[tuple[int, str]] = []

    def _enum(hwnd, _):
        if not (win32gui.IsWindowVisible(hwnd) or win32gui.IsIconic(hwnd)):
            return
        try:
            _tid, pid = win32process.GetWindowThreadProcessId(hwnd)
        except Exception:
            return
        if pid not in pids:
            return
        titel = (win32gui.GetWindowText(hwnd) or "").strip()
        (mit_titel if titel else ohne_titel).append((hwnd, titel))

    try:
        win32gui.EnumWindows(_enum, None)
    except Exception:
        pass
    if mit_titel:
        return mit_titel
    return [(h, t or "(ohne Titel)") for h, t in ohne_titel]


def finde_fenster(target: str, name: str = "") -> list[tuple[int, str]]:
    """Einheitlicher Einstieg (KVA 164): sichtbare Fenster zum Eintrag.

    Rueckgabe: [(hwnd, titel)] — beste Treffer zuerst.
    """
    t = str(target or "").strip()
    low = t.lower()
    if not t:
        return []

    # KVA 165 — Exakte Ordnerprüfung für Explorer-Fenster (nur exakter Pfad!)
    ziel_ordner = _ermittle_ordner_pfad(t)
    if ziel_ordner:
        treffer = [
            (hwnd, titel)
            for hwnd, titel, win_p in offene_explorer_fenster()
            if win_p and win_p == ziel_ordner
        ]
        return treffer

    # Generischer Explorer: matcht NIEMALS spezifische Ordner (z. B. xlounger, 1.2.16)!
    # Nur echte generische Fenster (Dieser PC / Home ohne konkreten Dateisystempfad)
    if _ist_generischer_explorer(t):
        return [
            (hwnd, titel)
            for hwnd, titel, win_p in offene_explorer_fenster()
            if not win_p
        ]

    prozesse, hinweis = _erwartete_prozesse(t)
    anzeige = str(name or "").strip() or hinweis

    # KVA 166 — ms-settings: Titel-Mapping
    if low.startswith("ms-settings:"):
        erwartet = _MS_SETTINGS_TITEL.get(low, ("Einstellungen",))
        treffer = [
            (hwnd, titel)
            for hwnd, titel, _pid, proz in alle_sichtbaren_fenster()
            if proz == "systemsettings.exe" and any(_norm(e) in _norm(titel) for e in erwartet)
        ]
        return treffer

    # KVA 167 — Shell-Namespace: Titel-Mapping
    if low.startswith("shell:"):
        erwartet = _SHELL_TITEL.get(low, (anzeige,))
        return [
            (hwnd, titel)
            for hwnd, titel, _pid, proz in alle_sichtbaren_fenster()
            if proz == "explorer.exe" and any(_norm(e) in _norm(titel) for e in erwartet)
        ]

    fenster = alle_sichtbaren_fenster()
    erwartete_args = _ermittle_erwartete_args(t)
    if erwartete_args:
        kandidaten = []
        for h, ti, pid, pr in fenster:
            if prozesse and pr not in prozesse:
                continue
            cmd = _prozess_cmdline(pid)
            if cmd and any(tok in cmd for tok in erwartete_args):
                kandidaten.append((h, ti, pr))
    else:
        if prozesse:
            kandidaten = [(h, ti, pr) for h, ti, _pid, pr in fenster if pr in prozesse]
        else:
            kandidaten = [(h, ti, pr) for h, ti, _pid, pr in fenster]

    # Stufe 1: Titel passt auf Namen/Hinweis
    treffer = [
        (h, ti) for h, ti, pr in kandidaten
        if _titel_passt(ti, pr, anzeige, t) or _titel_passt(ti, pr, hinweis, t)
    ]
    if treffer:
        return treffer
    # Stufe 2: Prozess stimmt, Titel egal (z. B. frisch gestartet ohne Dokumenttitel)
    # explorer.exe niemals pauschal matchen — Explorer-Ordner wurden oben exakt abgeglichen!
    if any(pr != "explorer.exe" for pr in prozesse):
        return [(h, ti) for h, ti, pr in kandidaten if pr != "explorer.exe"]
    return []


def lock_datei_vorhanden(target: str) -> str:
    """KVA 186 — Lock-Datei eines Office-Dokuments; Rueckgabe: Pfad oder ''."""
    p = Path(str(target or ""))
    if not p.is_file() or p.suffix.lower() not in _DOK_PROZESSE:
        return ""
    kandidaten = (
        p.with_name(f"~${p.name}"),          # MS Office
        p.with_name(f".~lock.{p.name}#"),    # LibreOffice
    )
    for k in kandidaten:
        if k.exists():
            return str(k)
    return ""


def fenster_fokussieren(hwnd: int) -> bool:
    """KVA 187 — auch elevated Fenster: AttachThreadInput + ShowWindow."""
    if not hwnd:
        return False
    try:
        import win32con
        import win32gui
        import win32process

        h = int(hwnd)
        if not win32gui.IsWindow(h):
            return False
        if win32gui.IsIconic(h):
            win32gui.ShowWindow(h, win32con.SW_RESTORE)
        else:
            win32gui.ShowWindow(h, win32con.SW_SHOW)
        try:
            win32gui.SetForegroundWindow(h)
            return True
        except Exception:
            pass
        # Elevated/Focus-Steal-Schutz: Thread-Inputs koppeln
        import ctypes

        u32 = ctypes.windll.user32
        foreground = u32.GetForegroundWindow()
        tid_fore = win32process.GetWindowThreadProcessId(foreground)[0] if foreground else 0
        tid_ziel = win32process.GetWindowThreadProcessId(h)[0]
        tid_aktuell = ctypes.windll.kernel32.GetCurrentThreadId()
        gekoppelt = False
        try:
            if tid_fore and tid_fore != tid_aktuell:
                gekoppelt = bool(u32.AttachThreadInput(tid_aktuell, tid_fore, True))
            if tid_ziel and tid_ziel != tid_aktuell:
                u32.AttachThreadInput(tid_aktuell, tid_ziel, True)
            u32.BringWindowToTop(h)
            u32.SetForegroundWindow(h)
        finally:
            if gekoppelt and tid_fore:
                u32.AttachThreadInput(tid_aktuell, tid_fore, False)
            if tid_ziel and tid_ziel != tid_aktuell:
                u32.AttachThreadInput(tid_aktuell, tid_ziel, False)
        return True
    except Exception:
        return False
