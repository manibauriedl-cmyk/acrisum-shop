"""„Laeuft bereits"-Dialog (KVA 151-155).

KVA 151  Vor dem Start erkennen, ob das Ziel schon laeuft
KVA 152  [Fenster anzeigen] — bestehendes Fenster in den Vordergrund
KVA 153  [Abbrechen]
KVA 154  [Nochmal oeffnen] — zweite Instanz starten
KVA 155  „Fenster waehlen" bei mehreren Treffern
"""
from __future__ import annotations

import tkinter as tk

# Rueckgabe-Aktionen
AKTION_ANZEIGEN = "anzeigen"
AKTION_NOCHMAL = "nochmal"
AKTION_ABBRECHEN = "abbrechen"


def _basis_dialog(root: tk.Tk, titel: str, bg: str) -> tk.Toplevel:
    dlg = tk.Toplevel(root)
    dlg.title(titel)
    dlg.configure(bg=bg)
    dlg.resizable(False, False)
    dlg.attributes("-topmost", True)
    dlg.transient(root)
    return dlg


def _knopf(reihe: tk.Frame, text: str, befehl, bg: str, standard: bool = False) -> tk.Button:
    b = tk.Button(
        reihe,
        text=text,
        command=befehl,
        bg="#0a246a" if standard else "#505050",
        fg="white",
        font=("Segoe UI", 9),
        width=18,
    )
    b.pack(side=tk.LEFT, padx=4)
    return b


def _zentrieren(dlg: tk.Toplevel, root: tk.Tk) -> None:
    """Auf dem Bildschirm der Leiste zentrieren (nicht IN der 64-px-Leiste)."""
    try:
        dlg.withdraw()  # erst verbergen → Position greift zuverlaessig
        dlg.update_idletasks()
        rx, ry = root.winfo_rootx(), root.winfo_rooty()
        sw, sh = dlg.winfo_screenwidth(), dlg.winfo_screenheight()
        dw, dh = dlg.winfo_reqwidth(), dlg.winfo_reqheight()
        x = max(0, rx + (sw - dw) // 2) if rx < sw else max(0, (sw - dw) // 2)
        y = max(70, ry + (sh - dh) // 3) if ry < sh else max(70, (sh - dh) // 3)
        dlg.geometry(f"{dw}x{dh}+{x}+{y}")
        dlg.deiconify()
    except tk.TclError:
        pass
    dlg.lift()
    dlg.after(80, dlg.lift)


def fenster_waehlen(root: tk.Tk, treffer: list[tuple[int, str]], bg: str = "#1e1e1e") -> int | None:
    """KVA 155 — Liste der Treffer, Nutzer waehlt eines. Rueckgabe: hwnd oder None."""
    if not treffer:
        return None
    if len(treffer) == 1:
        return treffer[0][0]

    dlg = _basis_dialog(root, "Fenster wählen", bg)
    dlg.grab_set()
    ergebnis: dict[str, int | None] = {"hwnd": None}

    tk.Label(
        dlg, text="Mehrere Fenster passen — welches anzeigen?",
        bg=bg, fg="white", font=("Segoe UI", 9),
    ).pack(anchor="w", padx=10, pady=(10, 4))

    liste = tk.Listbox(
        dlg, width=58, height=min(8, len(treffer)),
        bg="#404040", fg="white", selectbackground="#0a246a",
        selectforeground="white", font=("Segoe UI", 9), activestyle="none",
    )
    for _hwnd, titel in treffer:
        liste.insert(tk.END, titel or "(ohne Titel)")
    liste.pack(fill=tk.BOTH, padx=10, pady=4)
    liste.selection_set(0)

    tk.Label(
        dlg, text="Tipp: Doppelklick oder Enter wählt das markierte Fenster.",
        bg=bg, fg="#cccccc", font=("Segoe UI", 9), justify="left",
    ).pack(anchor="w", padx=10, pady=(0, 4))

    def _ok(*_a):
        auswahl = liste.curselection()
        if auswahl:
            ergebnis["hwnd"] = treffer[auswahl[0]][0]
        dlg.destroy()

    def _abbruch(*_a):
        dlg.destroy()

    liste.bind("<Double-Button-1>", _ok)
    liste.bind("<Return>", _ok)
    dlg.bind("<Escape>", _abbruch)

    reihe = tk.Frame(dlg, bg=bg)
    reihe.pack(pady=(6, 10))
    _knopf(reihe, "Anzeigen", _ok, bg, standard=True)
    _knopf(reihe, "Abbrechen", _abbruch, bg)

    _zentrieren(dlg, root)
    liste.focus_set()
    root.wait_window(dlg)
    return ergebnis["hwnd"]


def frage_laeuft_bereits(
    root: tk.Tk,
    name: str,
    treffer: list[tuple[int, str]],
    bg: str = "#1e1e1e",
    hinweis: str = "",
) -> tuple[str, int | None]:
    """KVA 151-155 — Dialog 'Laeuft bereits'.

    Rueckgabe: (aktion, hwnd|None)
      (AKTION_ANZEIGEN, hwnd) — Fenster in den Vordergrund
      (AKTION_NOCHMAL, None)  — zweite Instanz starten
      (AKTION_ABBRECHEN, None)

    `hinweis` ohne Treffer (KVA 186, Sperrdatei): Dialog ohne 'Fenster anzeigen'.
    """
    if not treffer and not hinweis:
        return AKTION_ABBRECHEN, None

    dlg = _basis_dialog(root, "Läuft bereits", bg)
    dlg.grab_set()
    ergebnis: dict[str, object] = {"aktion": AKTION_ABBRECHEN, "hwnd": None}

    anzeige = name or "Dieses Ziel"
    if treffer:
        fenster_zeile = treffer[0][1] if len(treffer) == 1 else f"{len(treffer)} passende Fenster"
    else:
        fenster_zeile = hinweis
    tk.Label(
        dlg, text=f"„{anzeige}“ läuft bereits.", bg=bg, fg="white", font=("Segoe UI", 9, "bold"),
    ).pack(anchor="w", padx=10, pady=(10, 2))
    tk.Label(
        dlg, text=fenster_zeile, bg=bg, fg="#c0c0c0", font=("Segoe UI", 9),
    ).pack(anchor="w", padx=10, pady=(0, 6))

    # Erklaertexte zu den Knoepfen (gleicher Stil wie Eigenschaften-Dialog)
    erklaerung = []
    if treffer:
        erklaerung.append("Fenster anzeigen = das offene Fenster nach vorn holen.")
    erklaerung.append("Nochmal öffnen = eine weitere Kopie starten.")
    erklaerung.append("Abbrechen = nichts unternehmen.")
    tk.Label(
        dlg, text="\n".join(erklaerung), bg=bg, fg="#cccccc", font=("Segoe UI", 9), justify="left",
    ).pack(anchor="w", padx=10, pady=(0, 6))

    def _anzeigen():
        hwnd = treffer[0][0]
        if len(treffer) > 1:
            # KVA 155 — Auswahl-Dialog im selben Grab abloesen
            dlg.grab_release()
            gewaehlt = fenster_waehlen(root, treffer, bg)
            if gewaehlt is None:
                dlg.grab_set()
                return
            hwnd = gewaehlt
        ergebnis["aktion"] = AKTION_ANZEIGEN
        ergebnis["hwnd"] = hwnd
        dlg.destroy()

    def _nochmal():
        ergebnis["aktion"] = AKTION_NOCHMAL
        dlg.destroy()

    def _abbruch(*_a):
        dlg.destroy()

    dlg.bind("<Escape>", _abbruch)

    reihe = tk.Frame(dlg, bg=bg)
    reihe.pack(pady=(4, 10))
    if treffer:
        _knopf(reihe, "Fenster anzeigen", _anzeigen, bg, standard=True)   # KVA 152
    _knopf(reihe, "Nochmal öffnen", _nochmal, bg, standard=not treffer)  # KVA 154
    _knopf(reihe, "Abbrechen", _abbruch, bg)                              # KVA 153

    _zentrieren(dlg, root)
    dlg.focus_set()
    root.wait_window(dlg)
    return ergebnis["aktion"], ergebnis["hwnd"]  # type: ignore[return-value]
