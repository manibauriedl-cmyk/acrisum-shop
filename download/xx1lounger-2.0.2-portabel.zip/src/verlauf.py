"""Verlauf der letzten 20 gestarteten Programme (KVA 188)."""
from __future__ import annotations

import time

MAX_VERLAUF = 20


def verlauf_hinzufuegen(data: dict, target: str, name: str = "") -> None:
    """Start in den Verlauf — neueste oben, Duplikate nach vorn gezogen, max. 20."""
    target = str(target or "").strip()
    if not target:
        return
    liste = data.setdefault("verlauf", [])
    # alten Eintrag desselben Ziels entfernen (wird neu oben angelegt)
    liste[:] = [e for e in liste if e.get("target") != target]
    liste.insert(0, {"target": target, "name": name or target, "zeit": time.time()})
    del liste[MAX_VERLAUF:]


def verlauf_lesen(data: dict) -> list[dict]:
    """Neueste zuerst, nur Eintraege mit Ziel."""
    return [e for e in data.get("verlauf", []) if e.get("target")][:MAX_VERLAUF]
