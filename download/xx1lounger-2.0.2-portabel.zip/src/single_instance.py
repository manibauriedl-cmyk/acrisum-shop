import ctypes
from ctypes import wintypes

from .app_id import APP_NAME
from .install_pfad import mutex_name

MUTEX_NAME = mutex_name()

# Registrierte Windows-Message fuer Zweitstart → laufende Instanz anzeigen.
# RegisterWindowMessageW gibt bei gleichem String immer die gleiche ID.
WM_XLOUNGER_SHOW = ctypes.windll.user32.RegisterWindowMessageW(f"{APP_NAME}_show_bar")


class SingleInstance:
    def __init__(self):
        self.mutex = None

    def acquire(self):
        kernel32 = ctypes.windll.kernel32
        self.mutex = kernel32.CreateMutexW(None, False, MUTEX_NAME)
        err = kernel32.GetLastError()
        return err == 0

    def release(self):
        if self.mutex:
            ctypes.windll.kernel32.CloseHandle(self.mutex)
            self.mutex = None


def request_show_existing():
    """Broadcast an alle Top-Level-Fenster: xlounger soll sich zeigen."""
    HWND_BROADCAST = 0xFFFF
    ctypes.windll.user32.PostMessageW(
        HWND_BROADCAST, WM_XLOUNGER_SHOW, 0, 0,
    )
