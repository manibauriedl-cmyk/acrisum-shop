import ctypes
import logging
import time
import tkinter as tk
from pathlib import Path


from .config import Config
from . import layout
from .paths import get_appdata_dir
from .app_id import APP_NAME
from .appbar import (
    AppBar,
)
from . import drop
from . import tooltip
from . import desktop_platz_rahmen




# »-Hover: Poll faengt Maus auf >> ab, wenn Tk <Enter> verpasst (Rebuild/Transparenz).

from .leiste.monitor import MonitorMixin
from .leiste.darstellung import DarstellungMixin
from .leiste.fit import FitMixin
from .leiste.ueberlauf import UeberlaufMixin
from .leiste.aufbau import AufbauMixin
from .leiste.eintraege import EintraegeMixin
from .leiste.icon_drag import IconDragMixin
from .leiste.menues import MenueMixin
from .leiste.laufend import LaufendMixin
from .leiste.drop_hotkey import DropHotkeyMixin
from .leiste.zoom import ZoomMixin
from .leiste.dock import DockMixin
from .leiste.leiste_drag import LeisteDragMixin
from .leiste.aktualisierung import AktualisierungMixin


class Bar(
    MonitorMixin,
    DarstellungMixin,
    FitMixin,
    UeberlaufMixin,
    AufbauMixin,
    EintraegeMixin,
    IconDragMixin,
    MenueMixin,
    LaufendMixin,
    DropHotkeyMixin,
    ZoomMixin,
    DockMixin,
    LeisteDragMixin,
    AktualisierungMixin,
):
    BASE_DOCK_THICKNESS = 80
    BASE_FLOAT_W = 700
    BASE_FLOAT_H = 120

    def __init__(self, config: Config):
        self.cfg = config
        self.tray_icon = None
        # WM_CLOSE waehrend des Aufbaus (root.update() unten pumpt Nachrichten):
        # _quit wartet, bis __init__ fertig ist — sonst destroy() mitten im
        # Aufbau -> TclError -> Fehlerdialog haelt den Mutex (Zombie, 28.09.2026 23:13).
        self._init_fertig = False
        # Schrittzeiten des Aufbaus — Start dauerte 11-17 s (28.09.2026);
        # so steht im Log, welcher Schritt es ist, statt zu raten.
        _t0 = time.monotonic()
        _t = [_t0]
        _dauer: list[str] = []

        def _startschritt(name: str) -> None:
            jetzt = time.monotonic()
            ms = int((jetzt - _t[0]) * 1000)
            _t[0] = jetzt
            _dauer.append(f"{name}={ms}ms")
            if ms > 500:
                logging.warning("Start: Schritt %s dauerte %d ms", name, ms)

        # Zustand je Modul — jedes Mixin legt seine eigenen Felder an
        # (_init_<modul>_zustand). Reihenfolge ist Pflicht:
        # docked (dock) -> root -> monitor -> zoom_stufe (zoom) -> Darstellung.
        self._init_dock_zustand()

        self.root = tk.Tk()
        self.root.title(APP_NAME)
        self.root.withdraw()
        self.root.resizable(False, False)
        # Fenster-Schliessen (WM_CLOSE) muss den sauberen Weg nehmen —
        # sonst bleibt die AppBar-Reservierung als Geist im Explorer.
        self.root.protocol("WM_DELETE_WINDOW", lambda: self._quit(bestaetigung=False))

        self._init_monitor_zustand()
        self._init_zoom_zustand()
        self._init_darstellung_zustand()
        self._init_laufend_zustand()
        self._init_menue_zustand()
        self._init_ueberlauf_zustand()
        self._init_fit_zustand()
        self._init_leiste_drag_zustand()
        self._init_icon_drag_zustand()
        self._init_drop_hotkey_zustand()
        _startschritt("zustand")

        border = "red" if self.red_border else self.bg_color
        self.root.configure(bg=border)

        self.outer = tk.Frame(self.root, bg=border, bd=1)
        self.outer.pack(fill=tk.BOTH, expand=True)

        self.frame = tk.Frame(self.outer, bg=self.bg_color, bd=0)
        self.frame.pack(padx=1, pady=1, fill=tk.BOTH, expand=True)

        self.buttons = []
        self._eintraege_namen_reparieren()
        self._build_header()
        self._build_entries()
        self._build_footer()
        self._bind_events()
        self._ueberlauf_schliessen()
        _startschritt("widgets")

        self.appbar = AppBar(self.root.winfo_id())
        # Alte AppBar-Registrierung bereinigen (falls vorheriger Lauf unsauber beendet)
        self.appbar.unregister()
        _startschritt("appbar-unregister")

        if self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:
            self._dock_to(
                self.docked,
                save=False,
                platzbudget_w=self._horizontal_platzbudget_w,
                platzbudget_h=self._vertical_platzbudget_h,
            )
        else:
            self._float(save=False)
            self._schweben_am_rand_zur_kante_heilen()
        _startschritt("dock1")

        self._apply_appearance()
        self.root.overrideredirect(True)
        self._apply_borderless_style()
        self.root.deiconify()
        self.root.lift()
        self.root.update()
        _startschritt("sichtbar+update")

        if self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:
            # Nach Sichtbar-Werden hat Tk ein neues Top-Level-HWND — nur die
            # Shell-Anmeldung nachziehen, NICHT nochmal komplett andocken
            # (29.09.2026: das zweite sichtbare _dock_to kostete 5-9 s, das
            # Layout stand da schon; withdraw als Ausweg geht nicht, weil Tk
            # geometry() versteckt nicht anwendet und der Split falsch misst).
            # Einmaliger Nach-Fit: die Messung am versteckten Fenster lieferte
            # Stub-Hoehen (133x212 am 04.10.2026); jetzt sind die Widgets real.
            try:
                _x, _y, _w, _h = self._bar_geometry()
                self._fit_window_to_content(
                    _x, _y, _w, _h, nur_vergroessern=True
                )
            except tk.TclError:
                pass
            self._appbar_nach_sichtbar_nachziehen()
        _startschritt("appbar-nachziehen")

        hwnd = AppBar.toplevel_hwnd(self.root.winfo_id())
        # OLE ueber unsichtbare Fangflaeche (Overlay): Eintrag-Widgets sind
        # eigene Child-HWNDs (TkChild/Static) und decken die Leiste fast ganz
        # ab — OLE-Drag trifft sonst unregistrierte Kinder bzw. bei
        # chroma-transparenter Flaeche direkt den Desktop (Drop kommt nie an,
        # nur DragLeave im Log, 08.10.2026). Das Overlay ist registriertes
        # Drop-Target und HTTRANSPARENT -> Klicks gehen zu den Widgets durch.
        # sync() versteckt es, sobald die Leiste unsichtbar ist (war 25.09. der
        # "blockiert Desktop-Drops"-Effekt: Overlay blieb auf leerer Flaeche).
        try:
            self.ole_drop_target = drop.OLEDROP(hwnd, use_overlay=True)
        except Exception as exc:
            print(f"[xlounger] OLE-Drop nicht verfuegbar: {exc}", flush=True)
            self.ole_drop_target = None
        _startschritt("ole")
        # WM_DROPFILES (klassisch) + Hotkeys auf dem Leisten-HWND.
        # OLE-Drops werden vom Overlay aus in dieses HWND gepostet.
        # AppBar-Shell-Callback nur per Timer (WndProc + Tk = instabil)
        # Alle WndProc-Callbacks nur puffern (_aus_wndproc) — kein Tk im WndProc.
        self.drop_target = drop.DROPFILES(
            hwnd,
            self._on_drop,
            on_hotkey=lambda hid: self._aus_wndproc(self._on_hotkey, hid),
            on_show=lambda: self._aus_wndproc(self.show),
        )
        # Natives Tray (KVA 225–232) — laeuft im Tk-Thread, kein pystray mehr
        # (GIL-Crash 24.09.2026). Maus-Events kommen per WndProc herein.
        from . import tray_win32
        from .install_pfad import ist_entwicklung

        self.tray_icon = tray_win32.TrayWin32(
            hwnd,
            on_show=lambda: self._aus_wndproc(self.show),
            on_menu=lambda: self._aus_wndproc(self._tray_menue_oeffnen),
            dev=ist_entwicklung(),
        )
        self.drop_target.on_tray = self.tray_icon.handle_message
        _startschritt("dropfiles+tray-objekt")
        self.tray_icon.start()
        _startschritt("tray-start")
        self._register_hotkeys()
        self._sync_drop_overlay()
        self.root.bind("<Configure>", self._on_configure)
        self.root.bind("<Map>", lambda _e: self._sync_drop_overlay())
        self.root.bind("<Unmap>", lambda _e: self._sync_drop_overlay())
        self._start_running_check()
        from . import katalog

        # Frueh vorwaermen (Leiste steht nach ~1 s) — Katalog-Liste muss
        # beim Panel-Oeffnen komplett fertig sein, kein Warten beim Nutzer
        # (Nutzer 09.10.2026).
        self.root.after(1400, katalog.vorgewaermen_starten)
        # Erster Watch etwas verzoegert — AppBar-Sturm vermeiden, trotzdem fremde Leisten
        self.root.after(8000, self._reservierung_watch_tick)
        self._zurueck_auf_primaermonitor()
        self.root.after(400, self._multi_monitor_ersthinweis)
        # Autostart einmalig beim ersten Start fragen (Installations-Frage).
        self.root.after(2000, self._autostart_erstfrage)
        self.root.after(300, self._ueberlauf_hover_poll)
        # Eintraege/»-Zahl erst nach Dock — sonst falsche Breite und tote Klicks.
        self.root.after(120, self._nach_start_leiste_sync)
        # Reserve-Zonen links/rechts einmalig icon-frei halten (04.10.2026 —
        # Rueckbau: diese Zeile entfernen, Funktion bleibt ungenutzt).
        # Dock-Seite = echte Leistendicke, damit Icons direkt an der Kante
        # liegen (keine leere Spalte neben der Leiste).
        from . import desktop_icons as _di

        def _randstreifen():
            try:
                kw = {}
                if self.docked == "left":
                    kw["links"] = int(self.root.winfo_width())
                elif self.docked == "right":
                    kw["rechts"] = int(self.root.winfo_width())
                _di.randstreifen_freiraeumen(**kw)
            except Exception:
                pass

        self.root.after(2500, _randstreifen)

        # KVA 277/278 — Update-Pruefung 45 s nach Start (nur Kundenversion,
        # nicht im Dev-Profil; KVA 279: max 1×/24 h wird innen geprueft)
        from .install_pfad import ist_entwicklung

        if not ist_entwicklung():
            self.root.after(45_000, self._update_check_auto)

        self._drop_check()

        self.platz_rahmen = desktop_platz_rahmen.DesktopPlatzRahmen(
            self.root, self._platz_rahmen_state
        )
        # Testrahmen-Flag nie aktiv lassen — in Produktion keine Overlays
        bar_cfg = self.cfg.data.setdefault("bar", {})
        if bar_cfg.get("desktop_platz_testrahmen"):
            bar_cfg["desktop_platz_testrahmen"] = False
            self._cfg_save()
        self.platz_rahmen.set_aktiv(False)
        _startschritt("hotkeys+timer+rahmen")

        self.root.update_idletasks()
        _startschritt("update_idletasks")
        geom = (
            f"{self.root.winfo_width()}x{self.root.winfo_height()}"
            f"+{self.root.winfo_x()}+{self.root.winfo_y()}"
        )
        print(f"[xlounger] Leiste gestartet: {geom} dock={self.docked}", flush=True)
        logging.info("Leiste gestartet: %s dock=%s monitor=%s", geom, self.docked, self._monitor_desc())
        logging.info(
            "Start: gesamt=%dms %s", int((time.monotonic() - _t0) * 1000), " ".join(_dauer)
        )
        self._write_status(geom)
        self._init_fertig = True

    def _write_status(self, geom):
        try:
            status_path = Path(get_appdata_dir()) / "xlounger-status.txt"
            status_path.write_text(
                f"xlounger gestartet\n"
                f"Zeit: {__import__('datetime').datetime.now()}\n"
                f"Geometrie: {geom}\n"
                f"Dock: {self.docked}\n"
                f"Monitor: {self._monitor_desc()}\n"
                f"Sichtbar: ja\n",
                encoding="utf-8",
            )
        except Exception:
            pass

    def _cfg_save(self, *, entries_changed: bool = False, force: bool = False) -> bool:
        """Config auf Platte speichern.

        Schreibschutz (KVA 247/248) lehnt nur gefaehrliche Aenderungen an der
        Eintragsliste auf Platte ab — Hinzufuegen, Entfernen und Sortieren
        in der Leiste bleiben moeglich. Bei Ablehnung: Anzeige auf letzten
        gespeicherten Stand zuruecksetzen.
        """
        if self.cfg.save(force=force):
            if entries_changed:
                panel = getattr(self, "_katalog_panel", None)
                if panel is not None:
                    try:
                        panel._fuellen()
                    except Exception:
                        logging.exception("Anheften-Panel nicht aktualisiert")
            return True
        reason = self.cfg._last_save_block or ""
        logging.warning("Config nicht auf Platte geschrieben: %s", reason)
        if entries_changed:
            if self.cfg.restore_entries_from_disk():
                self._relayout()
            hint = self._save_block_user_hint(reason)
            if hint:
                self._show_drop_hint(hint)
        return False

    def _save_block_user_hint(self, reason: str) -> str:
        if "Leeren blockiert" in reason:
            return "Nicht gespeichert: Leiste darf nicht leer werden — Anzeige auf letzten Stand."
        if "Schrumpfung" in reason:
            return "Nicht gespeichert: zu viele Einträge auf einmal — Anzeige auf letzten Stand."
        if reason:
            return "Nicht auf Platte gespeichert."
        return ""

    def _bind_events(self):
        # Verschieben: Griff + leerer Leisten-Hintergrund (nicht Symbole / »).
        # KVA 22: Rechtsklick auf Leisten-Hintergrund (nicht Symbole — die haben eigenes Menü).
        self.root.bind("<Escape>", self._dismiss_context_menus)
        for w in (self.body, self.frame, self.outer):
            w.bind("<Button-3>", self._show_menu)
            w.bind("<Button-1>", self._hintergrund_drag_start, add="+")

    def _save_state(self):
        bar = self.cfg.data["bar"]
        bar["dock"] = self.docked
        bar["orientation"] = self.orientation
        # Vom Nutzer gezogene Breite/Hoehe (Platzbudget) persistieren — sonst
        # faellt der »-Split nach Neustart auf „alles sichtbar" zurueck und
        # die Start-Kaskade rechnet sich hoch (28.09.2026: „es muss
        # funktionieren"). Angedockt zaehlt das ECHTE Fenstermass — das
        # Budget-Attr kann durch Zwischen-Fits veraltet sein (06.10.2026:
        # 935 gedockt, 80 gespeichert — Inventur ueberlebte den Neustart
        # nicht).
        try:
            echt_w = int(self.root.winfo_width())
            echt_h = int(self.root.winfo_height())
        except tk.TclError:
            echt_w = echt_h = 0
        if self.docked in layout.DOCK_VERTICAL:
            if echt_h >= layout.MIN_CONTENT_LENGTH:
                self._vertical_platzbudget_h = echt_h
            if self._vertical_platzbudget_h:
                bar["platzbudget_h"] = int(self._vertical_platzbudget_h)
            else:
                bar.pop("platzbudget_h", None)
            bar.pop("platzbudget_w", None)
        elif layout.is_horizontal(self.docked) or self.docked in layout.DOCK_CORNER:
            if echt_w >= layout.MIN_CONTENT_LENGTH:
                self._horizontal_platzbudget_w = echt_w
            if self._horizontal_platzbudget_w:
                bar["platzbudget_w"] = int(self._horizontal_platzbudget_w)
            else:
                bar.pop("platzbudget_w", None)
            bar.pop("platzbudget_h", None)
        else:
            if self._horizontal_platzbudget_w:
                bar["platzbudget_w"] = int(self._horizontal_platzbudget_w)
            else:
                bar.pop("platzbudget_w", None)
            if self._vertical_platzbudget_h:
                bar["platzbudget_h"] = int(self._vertical_platzbudget_h)
            else:
                bar.pop("platzbudget_h", None)
        if self.monitor:
            bar["monitor"] = self.monitor.key()
        pos = bar.setdefault("position", {})
        try:
            if self.docked == layout.DOCK_FREE:
                pos["x"] = int(self.root.winfo_x())
                pos["y"] = int(self.root.winfo_y())
                # Die abgelegte FORM gehoert zur Position — ohne sie startet
                # die freie Leiste mit der Schaetzbreite als Stummel
                # (06.10.2026: »37-Stub nach Neustart).
                if echt_w >= layout.MIN_CONTENT_LENGTH:
                    pos["w"] = echt_w
                if echt_h >= layout.MIN_CONTENT_LENGTH:
                    pos["h"] = echt_h
            elif layout.is_horizontal(self.docked) or self.docked in layout.DOCK_CORNER:
                pos["x"] = int(self.root.winfo_x())
            elif self.docked in layout.DOCK_VERTICAL:
                pos["y"] = int(self.root.winfo_y())
        except tk.TclError:
            pass
        self._cfg_save()
        print(f"[xlounger] Zustand gespeichert: dock={self.docked}", flush=True)

    def _aus_wndproc(self, fn, *args) -> None:
        """Callback aus dem ctypes-WndProc: NICHT Tk aufrufen, nur puffern.

        Ein Tk-Aufruf im WndProc (mitten in Tcl_DoOneEvent) setzt in _tkinter
        den gemerkten Thread-State (tcl_tstate) auf NULL; der naechste
        Tcl->Python-Callback (z. B. der eigene `after 0`) stirbt dann mit
        „PyEval_RestoreThread … thread state is NULL" (Exit 0xc0000409).
        Reproduziert 28.09.2026 beim Zweitstart (Broadcast show). Gleiche
        Ursache fuer Tray-Klick und Hotkeys. _drop_check (80 ms, Tk-Takt)
        arbeitet den Puffer ab — wie _on_drop das schon immer macht.
        """
        self._wndproc_nachreichen.append((fn, args))

    def show(self):
        def _do():
            try:
                if str(self.root.state()) != "withdrawn" and self.root.winfo_viewable():
                    return
            except tk.TclError:
                pass
            self.root.deiconify()
            self.root.lift()
            self._apply_appearance()
        self.root.after(0, _do)

    def hide(self):
        def _do():
            self.root.withdraw()
        self.root.after(0, _do)

    def _on_configure(self, _event=None):
        if self._drag_offset is not None:
            return
        if getattr(self, "_icon_drag_state", None) is not None:
            return
        if getattr(self, "_zoom_vorschau_aktiv", False):
            return
        self._sync_drop_overlay()
        self._platz_rahmen_sync()
        if time.monotonic() < self._configure_relayout_block_until:
            return
        if self.slot_limit is not None or self._ueberlauf_feld is not None:
            return
        try:
            wh = (
                int(self.root.winfo_width()),
                int(self.root.winfo_height()),
            )
        except tk.TclError:
            return
        last = self._last_configure_wh
        if last is not None and (
            layout.is_horizontal(self.docked) or self.docked == layout.DOCK_FREE
        ):
            # Quer: nur Breite steuert »/Slots — Tk/AppBar-Hoehenzucken ignorieren.
            if wh[0] == last[0]:
                self._last_configure_wh = wh
                return
        if wh == last:
            return
        tooltip.aktiven_ausblenden()
        self._last_configure_wh = wh
        job = self._configure_rebuild_job
        if job is not None:
            try:
                self.root.after_cancel(job)
            except tk.TclError:
                pass
        self._configure_rebuild_job = self.root.after(
            150, self._nach_groesse_ueberlauf_anpassen
        )

    def _quit(self, *, bestaetigung: bool = True):
        logging.info("Beenden angefordert (bestaetigung=%s)", bestaetigung)
        if not getattr(self, "_init_fertig", True):
            # Aufbau laeuft noch (WM_CLOSE kam in root.update() aus __init__):
            # nach dem Aufbau vom Mainloop aus nachholen — nicht mitten drin
            # zerstoeren (TclError in __init__ -> Fehlerdialog haelt Mutex).
            logging.info("Beenden: Aufbau laeuft noch — nach dem Start nachholen")
            self.root.after(100, lambda: self._quit(bestaetigung=bestaetigung))
            return
        if getattr(self, "_menu_autoclose_id", None) is not None:
            # WM_CLOSE kam mitten im modalen Kontextmenue (tk_popup =
            # TrackPopupMenu). destroy() dort drin beendet den Prozess NICHT:
            # die Menue-Schleife laeuft weiter, bis das Menue zufaellig zugeht
            # (Waechter „stop: nach 12 s noch da", reproduziert 28.09.2026
            # 22:25 mit Tray-Menue). Menue beenden (EndMenu = aktives Menue
            # dieses Threads), Beenden nach dem Rueckweg aus tk_popup nachholen.
            logging.info("Beenden: Kontextmenue offen — erst Menue schliessen")
            try:
                ctypes.windll.user32.EndMenu()
            except Exception:
                pass
            self._dismiss_context_menus()
            self.root.after(50, lambda: self._quit(bestaetigung=bestaetigung))
            return
        if bestaetigung:
            from tkinter import messagebox

            if not messagebox.askyesno(
                "xlounger beenden",
                "xlounger wirklich beenden?",
                parent=self.root,
            ):
                return
        # Schrittzeiten mitschreiben — Beenden dauerte vereinzelt >12 s
        # (Wächter-Log 28.09.2026 „stop: nach 12 s noch da"); so ist der
        # Blocker im Log sichtbar statt geraten.
        _t = [time.monotonic()]
        _dauer: list[str] = []

        def _schritt(name: str) -> None:
            jetzt = time.monotonic()
            ms = int((jetzt - _t[0]) * 1000)
            _t[0] = jetzt
            _dauer.append(f"{name}={ms}ms")
            if ms > 500:
                logging.warning("Beenden: Schritt %s dauerte %d ms", name, ms)

        pr = getattr(self, "platz_rahmen", None)
        if pr is not None:
            pr.schliessen()
        self._ueberlauf_schliessen()
        if self._drop_check_id:
            try:
                self.root.after_cancel(self._drop_check_id)
            except Exception:
                pass
            self._drop_check_id = None
        self._unregister_hotkeys()
        _schritt("rahmen+ueberlauf+hotkeys")
        if self.appbar:
            self._sync_appbar_hwnd()
            self.appbar.unregister()
        _schritt("appbar")
        # Erst WM_DROPFILES-WndProc zuruecksetzen, dann Overlay zerstoeren.
        if self.drop_target:
            try:
                self.drop_target.close()
            except Exception:
                pass
        _schritt("drop")
        if self.ole_drop_target:
            try:
                self.ole_drop_target.close()
            except Exception:
                pass
        _schritt("ole")
        if self.tray_icon:
            try:
                self.tray_icon.stop()
            except Exception:
                pass
        _schritt("tray")
        # KVA 241 — Waichter darf nach sauberem Beenden nicht neu starten.
        # Der naechste Start (xx1lounger.py main) loescht das Flag wieder.
        try:
            d = get_appdata_dir()
            d.mkdir(parents=True, exist_ok=True)
            (d / "sauber-beendet.flag").write_text(
                time.strftime("%d.%m.%Y %H:%M:%S"), encoding="utf-8"
            )
        except OSError:
            pass
        _schritt("flag")
        # Erst Mainloop beenden, dann Fenster zerstoeren — sonst bleibt der
        # Prozess als Fenster-loser Zombie haengen (25.09.2026, WM_CLOSE-Weg).
        try:
            self.root.quit()
        except tk.TclError:
            pass
        self.root.destroy()
        _schritt("destroy")
        logging.info("Beenden: %s", " ".join(_dauer))

    def run(self):
        self.root.mainloop()
