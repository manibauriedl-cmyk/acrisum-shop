"""Strg+C/X/V/A fuer Tk-Eingabefelder (KVA 184)."""
from __future__ import annotations

import tkinter as tk


def entry_clipboard_bind(widget: tk.Misc) -> None:
    """Standard-Clipboard-Kuerzel an Entry/Text haengen."""

    def _copy(_event=None):
        try:
            widget.event_generate("<<Copy>>")
        except tk.TclError:
            pass
        return "break"

    def _cut(_event=None):
        try:
            widget.event_generate("<<Cut>>")
        except tk.TclError:
            pass
        return "break"

    def _paste(_event=None):
        try:
            widget.event_generate("<<Paste>>")
        except tk.TclError:
            pass
        return "break"

    def _select_all(_event=None):
        try:
            widget.select_range(0, tk.END)
            widget.icursor(tk.END)
        except tk.TclError:
            pass
        return "break"

    for seq, handler in (
        ("<Control-c>", _copy),
        ("<Control-C>", _copy),
        ("<Control-x>", _cut),
        ("<Control-X>", _cut),
        ("<Control-v>", _paste),
        ("<Control-V>", _paste),
        ("<Control-a>", _select_all),
        ("<Control-A>", _select_all),
    ):
        widget.bind(seq, handler, add="+")
