import os
from pathlib import Path

from .app_id import APP_NAME


def get_appdata_dir():
    appdata = os.environ.get("APPDATA")
    if not appdata:
        appdata = os.path.expanduser("~")
    return Path(appdata) / APP_NAME


def get_config_path():
    return get_appdata_dir() / "config.json"


def get_log_path():
    return get_appdata_dir() / "xlounger.log"


def get_cache_dir():
    d = get_appdata_dir() / "cache"
    d.mkdir(parents=True, exist_ok=True)
    return d
