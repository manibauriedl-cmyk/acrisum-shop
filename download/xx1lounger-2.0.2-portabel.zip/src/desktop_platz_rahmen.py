"""Sichtbarer Testrahmen: Leiste, AppBar-Streifen, Luecke, Arbeitsbereich (nur Debug).

Kein Produkt-Verhalten — nur zum Pruefen von Desktop-Platz / mehreren Leisten.
"""
from __future__ import annotations

import ctypes
import logging
import tkinter as tk
from typing import Callable

from . import layout, monitors

_LOG = logging.getLogger(__name__)

_FARBE_LEISTE = "#00CC44"
_FARBE_APPBAR = "#FFCC00"
_FARBE_LUECKE = "#FF4444"
_FARBE_ARBEIT = "#00AAFF"
_ALPHA_LEISTE = 0.55
_ALPHA_APPBAR = 0.35
_ALPHA_LUECKE = 0.28
_ALPHA_ARBEIT = 0.9


def _spi_work_rect() -> tuple[int, int, int, int]:
    try:
        class _RECT(ctypes.Structure):
            _fields_ = [
                ("left", ctypes.c_long),
                ("top", ctypes.c_long),
                ("right", ctypes.c_long),
                ("bottom", ctypes.c_long),
            ]

        r = _RECT()
        if ctypes.windll.user32.SystemParametersInfoW(48, 0, ctypes.byref(r), 0):
            return int(r.left), int(r.top), int(r.right), int(r.bottom)
    except Exception:
        pass
    m = monitors.get_primary_monitor()
    if m is not None:
        return int(m.work_x), int(m.work_y), int(m.work.right), int(m.work.bottom)
    return (0, 0, 1920, 1080)


class DesktopPlatzRahmen:
    """Halbtransparente Overlays auf dem Desktop — per Menue ein/aus."""

    def __init__(self, root: tk.Tk, state_fn: Callable[[], dict]):
        self._root = root
        self._state_fn = state_fn
        self._aktiv = False
        self._poll_id: str | None = None
        self._fenster: dict[str, tk.Toplevel] = {}
        self._labels: dict[str, tk.Label] = {}

    @property
    def aktiv(self) -> bool:
        return self._aktiv

    def set_aktiv(self, on: bool) -> None:
        self._aktiv = bool(on)
        if not self._aktiv:
            self._poll_stop()
            self._alle_schliessen()
            return
        self.sync()
        self._poll_start()

    def sync(self) -> None:
        if not self._aktiv:
            return
        try:
            st = self._state_fn()
        except Exception as exc:
            _LOG.debug("Platz-Rahmen state: %s", exc)
            return
        if not st.get("platz_an") or st.get("dock") not in layout.DOCK_HORIZONTAL:
            self._alle_schliessen()
            return
        if "top" not in str(st.get("dock", "")):
            self._alle_schliessen()
            return

        monitor = st.get("monitor")
        if monitor is None:
            return
        sl, st_mon, sr, sb = layout._monitor_tuple(monitor)
        sw = max(1, sr - sl)
        bx = int(st.get("bar_x", 0))
        by = int(st.get("bar_y", 0))
        bw = max(1, int(st.get("bar_w", 1)))
        bh = max(1, int(st.get("bar_h", 1)))
        dicke = int(st.get("appbar_dicke", bh))

        strip = layout.appbar_strip_rect(st["dock"], monitor, dicke)
        if not strip:
            return
        _sx, sy, _sws, sh = (int(v) for v in strip)

        wl, wt, wr, wb = _spi_work_rect()
        bar_unten = by + bh
        luecke_h = max(0, int(wt) - bar_unten)

        self._platziere(
            "leiste",
            bx,
            by,
            bw,
            bh,
            _FARBE_LEISTE,
            _ALPHA_LEISTE,
            f"Leiste {bw}×{bh} px",
        )
        self._platziere(
            "appbar",
            sl,
            sy,
            sw,
            sh,
            _FARBE_APPBAR,
            _ALPHA_APPBAR,
            f"AppBar-Streifen (Anmeldung) {sh} px",
        )
        if luecke_h > 4:
            self._platziere(
                "luecke",
                sl,
                bar_unten,
                sw,
                luecke_h,
                _FARBE_LUECKE,
                _ALPHA_LUECKE,
                f"Luecke bis Arbeitsbereich {luecke_h} px",
            )
        else:
            self._verstecken("luecke")
        self._platziere(
            "arbeit",
            wl,
            wt,
            wr - wl,
            3,
            _FARBE_ARBEIT,
            _ALPHA_ARBEIT,
            f"Arbeitsbereich beginnt y={wt}",
        )

    def _platziere(
        self,
        key: str,
        x: int,
        y: int,
        w: int,
        h: int,
        farbe: str,
        alpha: float,
        text: str,
    ) -> None:
        w = max(1, int(w))
        h = max(1, int(h))
        top = self._fenster.get(key)
        if top is None:
            top = tk.Toplevel(self._root)
            top.overrideredirect(True)
            top.attributes("-topmost", True)
            try:
                top.attributes("-alpha", alpha)
            except tk.TclError:
                pass
            lbl = tk.Label(
                top,
                text=text,
                bg=farbe,
                fg="black",
                font=("Segoe UI", 9, "bold"),
                anchor="w",
                padx=6,
                pady=2,
            )
            lbl.pack(fill=tk.BOTH, expand=True)
            self._fenster[key] = top
            self._labels[key] = lbl
        else:
            try:
                top.attributes("-alpha", alpha)
            except tk.TclError:
                pass
            lbl = self._labels.get(key)
            if lbl is not None:
                lbl.configure(text=text, bg=farbe)
                top.configure(bg=farbe)
        try:
            top.geometry(f"{w}x{h}+{x}+{y}")
            top.deiconify()
            top.lift()
        except tk.TclError:
            pass

    def _verstecken(self, key: str) -> None:
        top = self._fenster.get(key)
        if top is not None:
            try:
                top.withdraw()
            except tk.TclError:
                pass

    def _alle_schliessen(self) -> None:
        for key in list(self._fenster):
            try:
                self._fenster[key].destroy()
            except tk.TclError:
                pass
        self._fenster.clear()
        self._labels.clear()

    def _poll_start(self) -> None:
        self._poll_stop()

        def _tick():
            if self._aktiv:
                self.sync()
                self._poll_id = self._root.after(500, _tick)

        self._poll_id = self._root.after(500, _tick)

    def _poll_stop(self) -> None:
        if self._poll_id:
            try:
                self._root.after_cancel(self._poll_id)
            except tk.TclError:
                pass
            self._poll_id = None

    def schliessen(self) -> None:
        self.set_aktiv(False)
