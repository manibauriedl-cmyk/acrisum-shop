"""Browser-Fenster zu URL-Pins finden — Adressleisten-Abgleich (KVA 156-162).

KVA 156  Adressleiste Chrome/Edge per UI-Automation lesen (comtypes, optional uiautomation)
KVA 157  URL-Pin springt nicht auf falschen Tab — voller Link-Abgleich
KVA 158  Kein Titel-Fallback bei URL-Pins — nur Adressleisten-Vergleich
KVA 159  Adressleisten-Cache (2 s, Performance)
KVA 160  Bei mehreren Treffern: Titel-/Tab-Hints waehlen das passende Fenster
KVA 161  Browser-Tab fokussieren statt neues Fenster (Localhost-Dienste)
KVA 162  Live-Seitentitel von localhost-Seiten per HTTP GET + <title>
"""
from __future__ import annotations

import logging
import re
import time
from urllib.parse import urlparse

from .browser_url import is_localhost_hostname, is_web_url
from .fenster_finden import alle_sichtbaren_fenster

_BROWSER_PROZESSE = frozenset({"chrome.exe", "msedge.exe", "brave.exe", "opera.exe"})

# KVA 159 — kurzer Cache: hwnd -> (monotonic, adresse)
_ADRESS_CACHE: dict[int, tuple[float, str]] = {}
_CACHE_SEK = 2.0

# KVA 162 — Live-Titel-Cache: url -> (monotonic, titel)
_TITEL_CACHE: dict[str, tuple[float, str]] = {}
_TITEL_CACHE_SEK = 30.0


def _adressleiste_via_comtypes(hwnd: int) -> str:
    """Chrome/Edge-Adresse ueber Windows-UI-Automation (comtypes, kein Extra-Paket)."""
    try:
        from comtypes.client import CreateObject, GetModule

        GetModule("UIAutomationCore.dll")
        from comtypes.gen.UIAutomationClient import (  # type: ignore
            CUIAutomation,
            IUIAutomationValuePattern,
            TreeScope_Descendants,
            UIA_AutomationIdPropertyId,
            UIA_NamePropertyId,
            UIA_ValuePatternId,
        )

        uia = CreateObject(CUIAutomation)
        el = uia.ElementFromHandle(int(hwnd))
        if not el:
            return ""
        found = None
        for prop, wert in (
            (UIA_AutomationIdPropertyId, "view_1012"),       # Chrome/Edge Adressfeld
            (UIA_NamePropertyId, "Adress- und Suchleiste"),  # deutsch
            (UIA_NamePropertyId, "Address and search bar"),  # englisch
        ):
            try:
                cond = uia.CreatePropertyCondition(prop, wert)
                found = el.FindFirst(TreeScope_Descendants, cond)
                if found:
                    break
            except Exception:
                found = None
        if not found:
            return ""
        pattern = found.GetCurrentPattern(UIA_ValuePatternId)
        if not pattern:
            return ""
        vp = pattern.QueryInterface(IUIAutomationValuePattern)
        return (vp.CurrentValue or "").strip()
    except Exception:
        return ""


def _adressleiste_via_uiautomation(hwnd: int) -> str:
    """Optional ueber uiautomation-Paket (Dev)."""
    try:
        import uiautomation as auto

        vorher = getattr(auto, "TIME_OUT_SECOND", 10)
        auto.SetGlobalSearchTimeout(0.2)
        try:
            fenster = auto.ControlFromHandle(int(hwnd))
            leiste = fenster.EditControl(AutomationId="view_1012", searchDepth=10)
            if not leiste.Exists(0.15, 0.02):
                leiste = fenster.EditControl(Name="Adress- und Suchleiste", searchDepth=10)
            if not leiste.Exists(0.1, 0.02):
                leiste = fenster.EditControl(Name="Address and search bar", searchDepth=10)
            if leiste.Exists(0.1, 0.02):
                return (leiste.GetValuePattern().Value or "").strip()
        finally:
            auto.SetGlobalSearchTimeout(vorher)
    except Exception:
        return ""
    return ""


def browser_adressleiste(hwnd: int) -> str:
    """Adressleiste lesen (KVA 156), 2 s gecacht (KVA 159). Leer = nicht lesbar."""
    jetzt = time.monotonic()
    alt = _ADRESS_CACHE.get(int(hwnd))
    if alt and jetzt - alt[0] < _CACHE_SEK:
        return alt[1]
    url = _adressleiste_via_comtypes(hwnd)
    if not url:
        url = _adressleiste_via_uiautomation(hwnd)
    _ADRESS_CACHE[int(hwnd)] = (jetzt, url)
    return url


def _host_stamm(host: str) -> str:
    h = (host or "").casefold()
    return h[4:] if h.startswith("www.") else h


def _pfad_norm(path: str) -> str:
    p = (path or "").casefold().rstrip("/") or "/"
    for endung in ("/index.html", "/index.htm"):
        if p.endswith(endung):
            p = p[: -len(endung)] or "/"
    return p


def urls_gleiche_seite(roh: str, ziel_url: str) -> bool:
    """Voller Link-Abgleich (KVA 157) — Host-Stamm, Localhost-Port, Pfad."""
    if not roh or not ziel_url:
        return False
    if "://" not in roh:
        roh = "http://" + roh
    try:
        adresse = urlparse(roh)
        ziel = urlparse(ziel_url)
    except Exception:
        return False
    ah = _host_stamm(adresse.hostname or "")
    zh = _host_stamm(ziel.hostname or "")
    if not ah or not zh:
        return False
    a_lokal = is_localhost_hostname(adresse.hostname) or ah == "127.0.0.1"
    z_lokal = is_localhost_hostname(ziel.hostname) or zh == "127.0.0.1"
    if a_lokal != z_lokal:
        return False
    if a_lokal:
        ap = adresse.port or (443 if (adresse.scheme or "").lower() == "https" else 80)
        zp = ziel.port or (443 if (ziel.scheme or "").lower() == "https" else 80)
        if ap != zp:
            return False
        apath, zpath = _pfad_norm(adresse.path or ""), _pfad_norm(ziel.path or "")
        if zpath in ("", "/"):
            return apath in ("", "/")
        return zpath in apath or apath.startswith(zpath)
    if ah != zh:
        return False
    apath, zpath = _pfad_norm(adresse.path or ""), _pfad_norm(ziel.path or "")
    if zpath in ("", "/"):
        return apath in ("", "/")
    return apath == zpath or apath.startswith(zpath + "/") or zpath in apath


def adressleiste_widerspricht_ziel(hwnd: int, ziel_url: str) -> bool:
    """True = Adressleiste zeigt eine andere Seite als der Pin (KVA 157)."""
    roh = browser_adressleiste(hwnd)
    if not roh or not ziel_url:
        return False
    return not urls_gleiche_seite(roh, ziel_url)


def _titel_hint_score(titel: str, hints: tuple[str, ...]) -> int:
    """KVA 160 — Titel-/Tab-Hints waehlen unter mehreren Adress-Treffern."""
    t = (titel or "").casefold()
    score = 0
    for h in hints:
        h = (h or "").strip().casefold()
        if h and len(h) >= 3 and h in t:
            score += 10 + min(len(h), 40)
    return score


def finde_url_fenster(ziel_url: str, tab_hints: tuple[str, ...] = ()) -> list[tuple[int, str]]:
    """Browser-Fenster, deren Adressleiste die Pin-URL zeigt (KVA 156-158, 161).

    Kein Titel-Fallback (KVA 158): Fenster ohne lesbare Adressleiste zaehlen
    nicht als Treffer. Mehrere Treffer: Titel-Hints zuerst (KVA 160).
    """
    if not is_web_url(ziel_url):
        return []
    treffer: list[tuple[int, str]] = []
    for hwnd, titel, _pid, prozess in alle_sichtbaren_fenster():
        if prozess not in _BROWSER_PROZESSE:
            continue
        adresse = browser_adressleiste(hwnd)
        if adresse and urls_gleiche_seite(adresse, ziel_url):
            treffer.append((hwnd, titel))
    if len(treffer) > 1 and tab_hints:
        treffer.sort(key=lambda ht: _titel_hint_score(ht[1], tab_hints), reverse=True)
    return treffer


_TITEL_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.IGNORECASE | re.DOTALL)


def localhost_seitentitel(url: str, timeout: float = 1.5) -> str:
    """Live-<title> einer localhost-Seite (KVA 162). Leer bei Fehler/nicht lokal."""
    if not is_web_url(url):
        return ""
    try:
        host = urlparse(url).hostname
    except Exception:
        return ""
    if not (is_localhost_hostname(host) or (host or "").strip() == "127.0.0.1"):
        return ""
    jetzt = time.monotonic()
    alt = _TITEL_CACHE.get(url)
    if alt and jetzt - alt[0] < _TITEL_CACHE_SEK:
        return alt[1]
    titel = ""
    try:
        import urllib.request

        req = urllib.request.Request(url, headers={"User-Agent": "xlounger"})
        with urllib.request.urlopen(req, timeout=timeout) as antwort:  # noqa: S310 — nur localhost
            kopf = antwort.read(65536).decode("utf-8", errors="replace")
        m = _TITEL_RE.search(kopf)
        if m:
            titel = " ".join(m.group(1).split())
    except Exception as exc:
        logging.debug("Live-Titel %s nicht lesbar: %s", url, exc)
    _TITEL_CACHE[url] = (jetzt, titel)
    return titel
