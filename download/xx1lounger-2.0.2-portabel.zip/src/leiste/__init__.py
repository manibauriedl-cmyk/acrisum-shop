"""Leisten-Module — die Klasse Bar (src/bar.py) setzt sich aus diesen Mixins zusammen.

Jedes Modul ist ein Themenblock; Methodennamen sind unveraendert, alles haengt an self.
"""
