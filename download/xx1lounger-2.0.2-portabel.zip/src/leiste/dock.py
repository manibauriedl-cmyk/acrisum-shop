"""AppBar-Dock — Kanten, Reservierung, Shell-Notify, Schweben, Desktop-Platz."""
import logging
import os
import time
import traceback
import tkinter as tk
from .win32_optional import win32gui
from .. import monitors
from .. import layout
from ..appbar import (
    AppBar,
    ABE_LEFT,
    ABE_TOP,
    ABE_RIGHT,
    ABE_BOTTOM,
)
from .. import desktop_icons


class DockMixin:
    def _init_dock_zustand(self) -> None:
        """Zustand dieses Moduls — aus Bar.__init__, vor tk.Tk() (nur Config, kein Tk)."""
        self.appbar = None
        self._appbar_strip_rect: tuple[int, int, int, int] | None = None
        self.docked = self.cfg.data["bar"].get("dock", layout.DOCK_TOP)
        if self.docked not in layout.DOCK_ALL:
            self.docked = layout.DOCK_TOP
        self._last_reservierung: tuple[int, int, int, int] | None = None
        self._fenster_groesse_fix: tuple[int, int] = (0, 0)
        self._shell_notify_pending = False

    @staticmethod
    def _kva87_desktop_platz_auto_an(alt_dock: str, dock: str) -> bool:
        """KVA 87 — Desktop-Platz bei Rand-Andockung automatisch an (nicht bei Zoom auf gleicher Kante)."""
        if dock not in layout.DOCK_EDGE | layout.DOCK_CORNER:
            return False
        if alt_dock == layout.DOCK_FREE:
            return True
        if alt_dock in layout.DOCK_EDGE | layout.DOCK_CORNER:
            return desktop_icons.kante_key(alt_dock) != desktop_icons.kante_key(dock)
        return False

    def _desktop_platz_bei_andocken_sichern(self, alt_dock: str, dock: str, save: bool) -> None:
        if not self._kva87_desktop_platz_auto_an(alt_dock, dock):
            return
        bar = self.cfg.data["bar"]
        if bar.get("desktop_platz", True):
            return
        bar["desktop_platz"] = True
        if save:
            self._cfg_save()

    def _on_shell_notify(self, msg: int, wparam: int, lparam: int) -> bool:
        """Shell meldet: andere AppBar/Taskleiste hat Platz geaendert.
        
        WICHTIG (Nutzer 26.09.2026): Diese Leiste und fremde Leisten
        sind vollstaendig unabhaengig und haben nichts miteinander zu tun.
        Bewegungen oder Platzwechsel fremder Leisten duerfen diese Leiste NICHT
        verschieben, stauchen oder neu packen.
        """
        cab = self.appbar.callback_message if self.appbar else 0
        if not cab or int(msg) != cab:
            return False
        # Fremde AppBar-Bewegungen ignorieren — xLounger bleibt stabil.
        return False

    def _appbar_nach_explorer_neustart(self) -> None:
        """KVA 217 — eigene AppBar-Reservierung weg (Explorer-Neustart):
        komplett neu anmelden, nicht nur Platz anpassen (Shell hat uns
        vergessen — QUERYPOS/SETPOS ohne ABM_NEW wirkt nicht)."""
        if self.docked not in layout.DOCK_EDGE | layout.DOCK_CORNER:
            return
        logging.info("AppBar-Reservierung weg — neu anmelden (Explorer-Neustart?)")
        try:
            self._dock_to(self.docked, save=False)
        except Exception as exc:
            logging.warning(
                "AppBar-Neuanmeldung nach Explorer-Start fehlgeschlagen: %s", exc
            )

    def _leiste_interaktion_aktiv(self) -> bool:
        """Ziehen/Andocken — Shell-Watch darf nicht dazwischenfunken."""
        return (
            getattr(self, "_drag_offset", None) is not None
            or getattr(self, "_dragging", False)
            or getattr(self, "_appbar_abgemeldet", False)
            or getattr(self, "_icon_drag_state", None) is not None
            or getattr(self, "_zoom_vorschau_aktiv", False)
            or getattr(self, "_zoom_umbau_laeuft", False)
        )

    def _shell_platz_anpassen_entprellt(self) -> None:
        self._shell_notify_pending = False

    def _shell_platz_anpassen(self) -> None:
        """rcWork + AppBar-Position — entkoppelt von fremden Leisten."""
        pass

    def _arbeitsflaeche_aktuell_synchronisieren(self) -> None:
        """Aktuelles Fenstermanagement: rcWork neu, Geometrie klemmen, AppBar, »."""
        if self.docked not in layout.DOCK_EDGE | layout.DOCK_CORNER:
            return
        if not bool(self.cfg.data.get("bar", {}).get("desktop_platz", True)):
            return
        if self._leiste_interaktion_aktiv():
            return
        frisch = monitors.primary_monitor_frisch(self.monitor)
        if frisch:
            self.monitor = frisch
        self._last_reservierung = monitors.reservierung_insets(self.monitor)
        edge = layout.edge_for_dock(self.docked)
        if edge is None or not self.appbar:
            return
        try:
            x = int(self.root.winfo_rootx())
            y = int(self.root.winfo_rooty())
            w = int(self.root.winfo_width())
            h = int(self.root.winfo_height())
        except tk.TclError:
            return
        nx, ny, nw, nh = layout.clamp_bar_geometry(
            x, y, w, h, self.monitor, self.docked
        )
        if (nx, ny, nw, nh) != (x, y, w, h):
            self.root.geometry(f"{nw}x{nh}+{nx}+{ny}")
            self.root.update_idletasks()
            x, y, w, h = nx, ny, nw, nh
        dicke = h if layout.is_horizontal(self.docked) else w
        strip = layout.appbar_strip_rect(self.docked, self.monitor, dicke)
        if not strip:
            return
        self._sync_appbar_hwnd()
        self._fenster_an_shell_appbar(edge, strip, x, y, w, h)
        self._set_window_shape()
        self._sync_drop_overlay()
        if self._drag_offset is None and self.slot_limit is None:
            self.root.after(80, self._nach_groesse_ueberlauf_anpassen)

    def _reservierung_eigene_aenderung(self, neu: tuple[int, int, int, int]) -> bool:
        """True wenn rcWork sich vermutlich nur durch unsere AppBar verschoben hat."""
        alt = self._last_reservierung
        if alt is None:
            return True
        dock = self.docked
        kante_idx = {
            layout.DOCK_TOP: 0,
            layout.DOCK_TOP_LEFT: 0,
            layout.DOCK_TOP_RIGHT: 0,
            layout.DOCK_BOTTOM: 1,
            layout.DOCK_BOTTOM_LEFT: 1,
            layout.DOCK_BOTTOM_RIGHT: 1,
            layout.DOCK_LEFT: 2,
            layout.DOCK_RIGHT: 3,
        }.get(dock)
        if kante_idx is None:
            return False
        oben_a, unten_a, links_a, rechts_a = alt
        oben_n, unten_n, links_n, rechts_n = neu
        alt_t = (oben_a, unten_a, links_a, rechts_a)
        neu_t = (oben_n, unten_n, links_n, rechts_n)
        for i in range(4):
            if i != kante_idx and alt_t[i] != neu_t[i]:
                return False
        try:
            if layout.is_horizontal(dock):
                eig_dicke = int(self.root.winfo_height())
            else:
                eig_dicke = int(self.root.winfo_width())
        except tk.TclError:
            eig_dicke = 0
        delta = neu_t[kante_idx] - alt_t[kante_idx]
        return delta >= 0 and delta <= eig_dicke + 12

    def _reservierung_watch_tick(self) -> None:
        """Alle paar Sekunden rcWork pruefen — egal welches Tool reserviert hat."""
        try:
            if self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:
                frisch = monitors.primary_monitor_frisch(self.monitor)
                ins = monitors.reservierung_insets(frisch)
                if not self._leiste_interaktion_aktiv() and ins != self._last_reservierung:
                    if self._last_reservierung is None:
                        self._last_reservierung = ins
                    elif self._reservierung_eigene_aenderung(ins):
                        self._last_reservierung = ins
                    else:
                        logging.info(
                            "Rand-Reservierung geaendert: oben=%s unten=%s links=%s rechts=%s",
                            *ins,
                        )
                        self._last_reservierung = ins
                        if frisch:
                            self.monitor = frisch
                        # WICHTIG: Fremde Leisten duerfen diese Leiste
                        # NICHT stauchen, verschieben oder neu packen!
                # KVA 217 — eigene Reservierung weg (Explorer-Neustart)?
                # Nicht waehrend Drag — da ist die AppBar bewusst abgemeldet.
                if (
                    self.appbar
                    and not self._leiste_interaktion_aktiv()
                    and bool(self.cfg.data.get("bar", {}).get("desktop_platz", True))
                ):
                    kante = layout.edge_for_dock(self.docked)
                    belegt = {
                        ABE_TOP: ins[0],
                        ABE_BOTTOM: ins[1],
                        ABE_LEFT: ins[2],
                        ABE_RIGHT: ins[3],
                    }.get(kante, 1)
                    if kante is not None and belegt == 0:
                        self._appbar_nach_explorer_neustart()
            # KVA 229 — Tray-Icon nach Explorer-Neustart neu anmelden
            # (gilt auch im schwebenden Modus, daher ausserhalb des Dock-Blocks)
            tray = getattr(self, "tray_icon", None)
            if tray:
                tray.pruefe_explorer_neustart()
        except Exception as exc:
            logging.debug("reservierung_watch: %s", exc)
        try:
            self.root.after(4000, self._reservierung_watch_tick)
        except tk.TclError:
            pass

    def _snap_edge_geometry(
        self, x: int, y: int, w: int, h: int, dock: str
    ) -> tuple[int, int, int, int]:
        """Nach Fit/AppBar: an Dock-Kante kleben — Shell-Streifen vor physischem Rand."""
        strip = getattr(self, "_appbar_strip_rect", None)
        if (
            strip is not None
            and self.appbar
            and self.appbar.registered
            and dock in layout.DOCK_EDGE | layout.DOCK_CORNER
        ):
            # Der Shell-Streifen klemmt die LAENGSachse (fremde AppBars) —
            # die eigene Dicke darf er nicht auf den alten Stand festnageln:
            # nach Zoom groesser blieb die Leiste sonst 57 statt 67 px hoch
            # (Knoepfe abgeschnitten, 29.09.2026), weil der Streifen aus der
            # geklemmten Hoehe neu gemeldet wurde (Henne-Ei). Streifen-Dicke
            # mindestens auf die Plan-Dicke des aktuellen Zooms weiten; die
            # echte Meldung an die Shell folgt in _fenster_an_shell_appbar.
            sl, st, sw, sh = (int(v) for v in strip)
            plan = int(self._thickness_for(dock))
            if dock in layout.DOCK_VERTICAL:
                if plan > sw:
                    if dock == layout.DOCK_RIGHT:
                        sl = sl + sw - plan
                    sw = plan
            elif plan > sh:
                if dock in (
                    layout.DOCK_BOTTOM,
                    layout.DOCK_BOTTOM_LEFT,
                    layout.DOCK_BOTTOM_RIGHT,
                ):
                    st = st + sh - plan
                sh = plan
            return layout.snap_to_dock_strip(x, y, w, h, dock, (sl, st, sw, sh))
        sl, st, sr, sb = layout._monitor_tuple(self.monitor)
        if dock == layout.DOCK_BOTTOM:
            y = int(sb) - int(h)
        elif dock == layout.DOCK_TOP:
            y = int(st)
        elif dock == layout.DOCK_RIGHT:
            x = int(sr) - int(w)
        elif dock == layout.DOCK_LEFT:
            x = int(sl)
        return x, y, w, h

    def _fremd_leisten_fenster_korrigieren(self, dock: str) -> None:
        """Nach Fit/AppBar: gemessene Lage nicht in fremde rcWork-Insets."""
        try:
            self.root.update_idletasks()
            x = int(self.root.winfo_rootx())
            y = int(self.root.winfo_rooty())
            w = int(self.root.winfo_width())
            h = int(self.root.winfo_height())
        except tk.TclError:
            return
        x2, y2, w2, h2 = layout.clamp_bar_geometry(x, y, w, h, self.monitor, dock)
        if (x2, y2, w2, h2) != (x, y, w, h):
            try:
                self.root.geometry(f"{w2}x{h2}+{x2}+{y2}")
                self.root.update_idletasks()
            except tk.TclError:
                return
            try:
                x = int(self.root.winfo_rootx())
                y = int(self.root.winfo_rooty())
                w = int(self.root.winfo_width())
                h = int(self.root.winfo_height())
            except tk.TclError:
                return
        extra = layout.fremd_leisten_ueberlapp_kanten(x, y, w, h, dock, self.monitor)
        if not extra:
            return
        wl, _wt, wr, _wb = layout._work_tuple(self.monitor)
        if "rechts" in extra:
            w = max(layout.MIN_CONTENT_LENGTH, int(wr) - int(x))
        if "links" in extra:
            x = int(wl)
            w = max(layout.MIN_CONTENT_LENGTH, min(int(w), int(wr) - x))
        x, y, w, h = layout.clamp_bar_geometry(x, y, w, h, self.monitor, dock)
        try:
            self.root.geometry(f"{w}x{h}+{x}+{y}")
            self.root.update_idletasks()
        except tk.TclError:
            return

    def _fenster_an_shell_appbar(
        self,
        edge: int,
        strip: tuple[int, int, int, int],
        x: int,
        y: int,
        w: int,
        h: int,
        dock: str | None = None,
    ) -> tuple[int, int, int, int]:
        """Shell-Position nach ABM_QUERYPOS/SETPOS auf Tk-Fenster anwenden (Taskleiste)."""
        kante = dock or self.docked
        left, top, sw, sh = self.appbar.set_pos(edge, strip[0], strip[1], strip[2], strip[3])
        self._appbar_strip_rect = (int(left), int(top), int(sw), int(sh))
        w, h, x, y = layout.position_in_strip(
            kante,
            w,
            h,
            x,
            y,
            (int(left), int(top), int(sw), int(sh)),
            monitor=self.monitor,
        )
        x, y, w, h = self._snap_edge_geometry(x, y, w, h, kante)
        x, y, w, h = layout.clamp_bar_geometry(x, y, w, h, self.monitor, kante)
        self.root.geometry(f"{w}x{h}+{x}+{y}")
        try:
            self.root.update_idletasks()
        except tk.TclError:
            pass
        logging.info(
            "AppBar-Fenster angepasst edge=%s pos=%s,%s groesse=%sx%s",
            edge,
            x,
            y,
            w,
            h,
        )
        return x, y, w, h

    def _dock_to(
        self,
        dock,
        save=True,
        symbole_anordnen: bool = True,
        *,
        anchor_x: int | None = None,
        anchor_y: int | None = None,
        platzbudget_w: int | None = None,
        platzbudget_h: int | None = None,
        griff_ende: bool = False,
    ):
        # Schrittzeiten — _dock_to trug 1,4 + 6,3 s zum Start bei (29.09.2026);
        # Blocker im Log sichtbar machen statt raten.
        try:
            _st = traceback.extract_stack(limit=8)
            _caller = " <- ".join(
                f"{os.path.basename(f.filename)}:{f.name}" for f in _st[-4:-1]
            )
            logging.info("Andocken %s ausgeloest via %s", dock, _caller)
        except Exception:
            pass
        _t0 = time.monotonic()
        _t = [_t0]
        _dauer: list[str] = []

        def _schritt(name: str) -> None:
            jetzt = time.monotonic()
            ms = int((jetzt - _t[0]) * 1000)
            _t[0] = jetzt
            _dauer.append(f"{name}={ms}ms")

        # KVA 198 — vor Kantenwechsel Symbolpositionen der alten Kante sichern
        alt_dock = getattr(self, "docked", layout.DOCK_FREE)
        frisch = monitors.primary_monitor_frisch(self.monitor)
        if frisch:
            self.monitor = frisch
        self._last_reservierung = monitors.reservierung_insets(self.monitor)
        logging.info(
            "Rand-Reservierung (fremd, vor Andocken): oben=%s unten=%s links=%s rechts=%s",
            *self._last_reservierung,
        )
        _schritt("monitor+reservierung")
        # Kantenwechsel: eigene alte AppBar-Reservierung loesen BEVOR
        # gemessen wird — sonst zaehlt _work_tuple sie als "fremd" mit und
        # die Leiste dockt versetzt an (links gedockt -> top: Fenster startet
        # hinter der eigenen Alt-Reservierung, toter Streifen — Nutzer
        # 07.10.2026). Gleiche Kante bleibt unberuehrt: dort waere das
        # Zwischen-REMOVE nur Flackern (siehe appbar.set_pos-Kommentar).
        if (
            alt_dock in layout.DOCK_EDGE | layout.DOCK_CORNER
            and dock != alt_dock
            and self.appbar
        ):
            self.appbar.unregister()
        # KVA 87-Auto-Anschalten stillgelegt (Nutzer 04.10.2026): der Nutzer
        # will desktop_platz=False — sonst wuerde jeder Dock das Flag wieder
        # auf True drehen und Windows sortiert Icons um. 1:1 rueckbaubar:
        # Zeile unten wieder einkommentieren.
        # self._desktop_platz_bei_andocken_sichern(alt_dock, dock, save)
        _schritt("desktop-platz-sichern")
        self.docked = dock
        # Andocken beendet eine bewusste Frei-Ablage — der Start-Heiler
        # darf danach wieder normal arbeiten.
        self.cfg.data["bar"]["frei_gewaehlt"] = False
        thickness = self._thickness_for(dock)
        if platzbudget_w is not None or platzbudget_h is not None:
            platzbudget_w, platzbudget_h = self._platzbudget_fuer_dock_bereinigen(
                dock, platzbudget_w, platzbudget_h, griff_ende=griff_ende
            )
        else:
            self._horizontal_platzbudget_w = None
            self._vertical_platzbudget_h = None
        wl, wt, wr, wb = layout._work_tuple(self.monitor)
        sl, st, sr, sb = layout._monitor_tuple(self.monitor)
        if anchor_x is None and anchor_y is None:
            try:
                if dock in layout.DOCK_VERTICAL:
                    pos = self.cfg.data["bar"].get("position") or {}
                    sy = pos.get("y")
                    anchor_y = (
                        int(sy)
                        if sy is not None
                        else int(self.root.winfo_y())
                    )
                elif dock in (layout.DOCK_TOP, layout.DOCK_BOTTOM):
                    pos = self.cfg.data["bar"].get("position") or {}
                    sx = pos.get("x")
                    anchor_x = (
                        int(sx)
                        if sx is not None
                        else int(self.root.winfo_x())
                    )
            except tk.TclError:
                pass
        gleiche_richtung = (
            layout.is_horizontal(alt_dock) == layout.is_horizontal(dock)
            and (alt_dock in layout.DOCK_VERTICAL) == (dock in layout.DOCK_VERTICAL)
        )
        if self.slot_limit is None and dock in layout.DOCK_EDGE | layout.DOCK_CORNER:
            # Breitenmodus: nicht auf altes Fenster budgetieren — erst packen, dann fit.
            try:
                if layout.is_horizontal(dock):
                    ax = sl if anchor_x is None else max(sl, int(anchor_x))
                    basis = (sr - ax) if platzbudget_w is None else int(platzbudget_w)
                    max_len = max(
                        layout.MIN_CONTENT_LENGTH,
                        min(int(basis), sr - ax),
                    )
                    # Vorab-Messung entfernt (04.10.2026): sie hing am alten/
                    # noch nicht gebauten Layout und erzeugte Stubs
                    # (99x80, 133x212). Erst volle Kante, der Fit nach
                    # populate kuerzt auf den echten Inhalt.
                    content_len = max_len
                else:
                    ay = st if anchor_y is None else max(st, int(anchor_y))
                    if platzbudget_h is not None:
                        basis = int(platzbudget_h)
                    else:
                        basis = self._leiste_hoehe_max()
                    max_len = max(
                        layout.MIN_CONTENT_LENGTH,
                        min(int(basis), sb - ay),
                    )
                    content_len = max_len
            except tk.TclError:
                content_len = layout.MIN_CONTENT_LENGTH
        else:
            content_len = self._content_length()
        if dock in layout.DOCK_CORNER:
            if "right" in dock:
                anchor_x = wr - content_len
            else:
                anchor_x = wl
            length = layout.clamp_length(content_len, self.monitor, dock, bar_x=anchor_x)
        else:
            length = layout.clamp_length(
                content_len, self.monitor, dock, bar_x=anchor_x, bar_y=anchor_y
            )

        x, y, w, h, orient = layout.dock_rect(
            dock=dock,
            monitor=self.monitor,
            thickness=thickness,
            content_length=length,
            anchor_x=anchor_x,
            anchor_y=anchor_y,
        )
        x, y, w, h = layout.clamp_bar_geometry(x, y, w, h, self.monitor, dock)
        self.orientation = orient
        self._apply_leisten_pack_richtung()
        self.root.geometry(f"{w}x{h}+{x}+{y}")
        self.root.update_idletasks()
        _schritt("geometrie1")

        edge = layout.edge_for_dock(dock)
        platz_reservieren = bool(self.cfg.data["bar"].get("desktop_platz", True))
        if edge is not None and self.appbar:
            self._sync_appbar_hwnd()
            if platz_reservieren:
                strip = layout.appbar_strip_rect(dock, self.monitor, thickness)
                if strip:
                    x, y, w, h = self._fenster_an_shell_appbar(edge, strip, x, y, w, h)
                    if dock in layout.DOCK_CORNER:
                        x, y, w, h, _ = layout.dock_rect(
                            dock=dock,
                            monitor=self.monitor,
                            thickness=thickness,
                            content_length=length,
                        )
                        x, y, w, h = layout.clamp_bar_geometry(x, y, w, h, self.monitor, dock)
                        self.root.geometry(f"{w}x{h}+{x}+{y}")
                        self.root.update_idletasks()
                        x, y, w, h = self._fenster_an_shell_appbar(edge, strip, x, y, w, h)
            else:
                # KVA 86 — Desktop-Platz aus: keinen Streifen reservieren
                self.appbar.unregister()
                wl, wt, wr, wb = layout._work_tuple(self.monitor)
                if dock == layout.DOCK_TOP:
                    y = wt
                elif dock == layout.DOCK_BOTTOM:
                    y = wb - h
                elif dock == layout.DOCK_LEFT:
                    x = wl
                elif dock == layout.DOCK_RIGHT:
                    x = wr - w
                self.root.geometry(f"{w}x{h}+{x}+{y}")
                try:
                    self.root.update_idletasks()
                except tk.TclError:
                    pass

        _schritt("shell-appbar1")
        # Einmal durchrechnen (Nutzer 28.09.2026): Split und Inhaltshoehe
        # stimmen schon (z. B. zweites Andocken nach HWND-Sync beim Start)
        # → kein Widget-Umbau, kein erneuter Fit. Die AppBar-Meldung unten
        # laeuft trotzdem (Reservierung ist Pflicht).
        # Quer zaehlt „stimmt" nur bei gleicher Richtung — die Knoepfe einer
        # senkrechten Leiste sehen anders aus und muessen neu gebaut werden.
        layout_stimmt = gleiche_richtung and self._split_und_hoehe_stimmen()
        if not layout_stimmt:
            # Split gegen die GEPLANTE Geometrie rechnen, nicht gegen
            # winfo_y: am versteckten Fenster (Start) wendet Tk geometry()
            # nicht an, sonst misst der erste Populate-Durchlauf falsch,
            # und nach dem Sichtbarwerden baut <Configure> die Leiste ein
            # zweites Mal komplett (~280 ms, 04.10.2026).
            if self.slot_limit is None:
                # Dieselbe Funktion wie jeder andere Split — nur mit der
                # GEPLANTEN Position (Fenster haengt am alten Ort). Keine
                # dritte Budget-Rechnung hier: eine Formel, eine Stelle —
                # sonst widersprechen sich Populate und Spaet-Abgleich und
                # der »-Knopf flackert (Nutzer 04.10.2026).
                self._split_avail_override = (
                    self._leiste_hoehe_max(y)
                    if dock in layout.DOCK_VERTICAL
                    else self._leiste_breite_max(x)
                )
            try:
                self._populate_entries()
            finally:
                self._split_avail_override = None
        _schritt("populate" if not layout_stimmt else "split-ok")
        self._arrange(orient)
        self.root.update_idletasks()
        _schritt("arrange")
        if not layout_stimmt:
            x, y, w, h = self._fit_window_to_content(
                x,
                y,
                w,
                h,
                breite_min=platzbudget_w,
                hoehe_min=platzbudget_h,
            )
        x, y, w, h = self._leiste_platzbudget_erzwingen(
            x, y, w, h, dock, platzbudget_w, platzbudget_h
        )
        _schritt("fit1")
        # AppBar-Reservierung an die ECHTE Fenster-Dicke nachziehen: der Fit
        # kann die Leiste breiter/hoeher machen als die Plan-Dicke. Sonst ragt
        # sie in den Arbeitsbereich, maximierte Fenster liegen darunter und
        # die Auto-Transparenz klebt dauerhaft an (Schleier).
        if edge is not None and self.appbar and platz_reservieren:
            echte_dicke = h if layout.is_horizontal(dock) else w
            strip = layout.appbar_strip_rect(dock, self.monitor, echte_dicke)
            if strip:
                x, y, w, h = self._fenster_an_shell_appbar(edge, strip, x, y, w, h)
        x, y, w, h = self._leiste_platzbudget_erzwingen(
            x, y, w, h, dock, platzbudget_w, platzbudget_h
        )
        _schritt("shell-appbar2")
        if not layout_stimmt:
            if dock in layout.DOCK_VERTICAL and platzbudget_h is None:
                x, y, w, h = self._fit_window_to_content(x, y, w, h)
            elif layout.is_horizontal(dock) and platzbudget_h is None:
                x, y, w, h = self._fit_window_to_content(
                    x, y, w, h, breite_min=platzbudget_w,
                )
        _schritt("fit2")
        self._leiste_fenster_leerstreifen_sync()
        self._fremd_leisten_fenster_korrigieren(dock)
        self._set_window_shape()
        self._sync_drop_overlay()
        self._block_configure_relayout()
        _schritt("shape+overlay")

        # Einmal durchrechnen (Nutzer 28.09.2026, Regelverstoss): die
        # Endgroesse ist hier final. Ein spaetes Configure darf keinen
        # 150-ms-Rebuild mehr ausloesen — der fittete mit halb leerem Body
        # erneut und die Leiste sprang sichtbar (637 -> 159 -> 534).
        job = self._configure_rebuild_job
        if job is not None:
            try:
                self.root.after_cancel(job)
            except tk.TclError:
                pass
            self._configure_rebuild_job = None
        self._last_configure_wh = (int(w), int(h))

        # KVA 199-203 — volles Layout nur bei Kantenwechsel; sonst nur unter Leiste schieben.
        if edge is not None and symbole_anordnen:
            streifen = (x, y, w, h)
            if desktop_icons.kante_key(alt_dock) != desktop_icons.kante_key(dock):
                self._desktop_icons_nach_dock(dock, streifen)
            else:
                self._desktop_icons_unter_leiste_einmal(dock, streifen)
        _schritt("desktop-icons")

        if save:
            self._save_state()
        self._platz_rahmen_sync()
        self._apply_appearance()
        _schritt("save+rahmen")
        gesamt = int((time.monotonic() - _t0) * 1000)
        if gesamt > 300:
            logging.info("Andocken %s: gesamt=%dms %s", dock, gesamt, " ".join(_dauer))

    def _platz_rahmen_state(self) -> dict:
        dicke = 0
        try:
            dicke = int(self.root.winfo_height())
            if self.docked in layout.DOCK_VERTICAL:
                dicke = int(self.root.winfo_width())
        except tk.TclError:
            pass
        return {
            "dock": self.docked,
            "monitor": self.monitor,
            "platz_an": bool(self.cfg.data.get("bar", {}).get("desktop_platz", True)),
            "bar_x": int(self.root.winfo_rootx()),
            "bar_y": int(self.root.winfo_rooty()),
            "bar_w": int(self.root.winfo_width()),
            "bar_h": int(self.root.winfo_height()),
            "appbar_dicke": dicke,
        }

    def _platz_rahmen_sync(self) -> None:
        pr = getattr(self, "platz_rahmen", None)
        if pr is not None and pr.aktiv:
            pr.sync()

    def _toggle_platz_rahmen(self) -> None:
        bar = self.cfg.data.setdefault("bar", {})
        neu = not bool(bar.get("desktop_platz_testrahmen"))
        bar["desktop_platz_testrahmen"] = neu
        self._cfg_save()
        pr = getattr(self, "platz_rahmen", None)
        if pr is not None:
            pr.set_aktiv(neu)

    def _desktop_icons_unter_leiste_einmal(self, dock, streifen) -> None:
        """Nur Symbole unter dem Leisten-Streifen — kein komplettes JSON-Layout."""
        try:
            desktop_icons.icons_unter_leiste_nach_innen(streifen, dock)
        except Exception as exc:
            logging.debug("desktop-icons unter Leiste: %s", exc)

    def _desktop_icons_nach_dock(self, dock, streifen) -> None:
        """Nur Symbole UNTER der Leiste einen Tick nach innen — kein
        Voll-Layout-Restore. Ein Massen-Zuruecksetzen wirft alle Desktop-
        Positionen auf einen alten Stand um; der Nutzer findet nichts wieder
        (Nutzer 04.10.2026).

        Doppelt (sofort + 220 ms + 700 ms), weil der Explorer traege nachzieht.
        """
        def _einmal():
            try:
                desktop_icons.icons_unter_leiste_nach_innen(streifen, dock)
            except Exception as exc:
                logging.debug("desktop-icons unter Leiste: %s", exc)

        _einmal()
        self.root.after(220, _einmal)
        self.root.after(700, _einmal)

    def _float(
        self,
        save=True,
        *,
        platzbudget_w: int | None = None,
        platzbudget_h: int | None = None,
    ):
        if self.docked in layout.DOCK_ALL - {layout.DOCK_FREE}:
            if self.appbar:
                self._sync_appbar_hwnd()
                self.appbar.unregister()
        self.docked = layout.DOCK_FREE
        pos = self.cfg.data["bar"].get("position", {})
        x = pos.get("x", 100)
        y = pos.get("y", 100)
        form_w = int(pos.get("w") or 0)
        form_h = int(pos.get("h") or 0)
        if form_w >= layout.MIN_DOCK_THICKNESS and form_h > form_w:
            # Senkrecht abgelegte freie Leiste — Achse + Form uebernehmen
            # (Inventur-Ablage). Sonst kaeme sie als Quer-Schaetzung wieder.
            self.orientation = "vertical"
            fw = max(layout.MIN_DOCK_THICKNESS, form_w)
            fh = max(layout.MIN_CONTENT_LENGTH, form_h)
            fx, fy, fw, fh = layout.clamp_bar_geometry(
                x, y, fw, fh, self.monitor, layout.DOCK_FREE
            )
            self.root.geometry(f"{fw}x{fh}+{fx}+{fy}")
            self.root.update_idletasks()
            self._populate_entries()
            self._arrange("vertical")
            self.root.update_idletasks()
            self._set_window_shape()
            self._block_configure_relayout()
            if save:
                self._save_state()
            return
        self.orientation = "horizontal"
        float_h = self.dock_thickness + 8
        wl, wt, wr, wb = layout._work_tuple(self.monitor)
        est_w = max(self._header_width() + 80, layout.MIN_CONTENT_LENGTH)
        if form_w > layout.MIN_CONTENT_LENGTH:
            est_w = form_w
        if x == 100 and y == 100:
            bar_w = min(est_w, wr - wl)
            x = wl + (wr - wl - bar_w) // 2
            y = wt + (wb - wt - float_h) // 2
        else:
            max_w = layout.available_horizontal_span(self.monitor, x, est_w, layout.DOCK_FREE)
            bar_w = min(max(est_w, layout.MIN_CONTENT_LENGTH), max_w)
        if platzbudget_w is not None and platzbudget_w > layout.MIN_CONTENT_LENGTH:
            bar_w = max(bar_w, int(platzbudget_w))
        x, y, bar_w, float_h = layout.clamp_bar_geometry(
            x, y, bar_w, float_h, self.monitor, layout.DOCK_FREE,
        )
        self.root.geometry(f"{bar_w}x{float_h}+{x}+{y}")
        self.root.update_idletasks()
        self._populate_entries()
        self._arrange("horizontal")
        self.root.update_idletasks()
        x, y, bar_w, float_h = self._fit_window_to_content(
            x, y, bar_w, float_h, breite_min=platzbudget_w or bar_w
        )
        x, y, bar_w, float_h = self._leiste_platzbudget_erzwingen(
            x, y, bar_w, float_h, layout.DOCK_FREE, platzbudget_w, platzbudget_h
        )
        self._set_window_shape()
        self._block_configure_relayout()

        if save:
            self._save_state()

    def _float_geometry_at(self, x: int, y: int) -> tuple[int, int, int, int]:
        """KVA 35: Position + Live-Breite fuer freies Ziehen."""
        try:
            h = max(int(self.root.winfo_height()), self.dock_thickness + 8)
        except tk.TclError:
            h = self.dock_thickness + 8
        try:
            self.root.update_idletasks()
            req_w = max(
                self.outer.winfo_reqwidth(),
                self._header_width() + 80,
                layout.MIN_CONTENT_LENGTH,
            )
        except tk.TclError:
            req_w = layout.MIN_CONTENT_LENGTH
        w = layout.float_bar_width_at(self.monitor, x, req_w)
        return layout.clamp_bar_geometry(x, y, w, h, self.monitor, layout.DOCK_FREE)

    def _leiste_entlang_kante_verschieben(
        self,
        anchor_x: int,
        anchor_y: int,
        bar_w: int | None = None,
        bar_h: int | None = None,
    ) -> None:
        """Gleiche Kante: Streifen schieben — kein populate/Fit/Shell (1228, KVA 35)."""
        dock = self.docked
        if dock not in layout.DOCK_EDGE | layout.DOCK_CORNER:
            return
        try:
            w = int(bar_w if bar_w is not None else self.root.winfo_width())
            h = int(bar_h if bar_h is not None else self.root.winfo_height())
        except tk.TclError:
            return
        ax, ay = int(anchor_x), int(anchor_y)
        # Loslassen gleiche Kante, Alle: Anker + Rest bis Kante (KVA 35).
        # Live haelt Startmass — Commit dehnt und fuellt (05.10.2026).
        if self.slot_limit is None:
            if layout.is_horizontal(dock) or dock in layout.DOCK_CORNER:
                w = int(self._leiste_breite_max(ax))
            if dock in layout.DOCK_VERTICAL:
                h = int(self._leiste_hoehe_max(ay))
        strip = getattr(self, "_appbar_strip_rect", None)
        if strip is None:
            strip = layout.appbar_strip_rect(
                dock, self.monitor, int(self._thickness_for(dock))
            )
        if not strip:
            return
        w, h, x, y = layout.position_in_strip(
            dock,
            w,
            h,
            ax,
            ay,
            tuple(int(v) for v in strip),
            monitor=self.monitor,
        )
        x, y, w, h = layout.clamp_bar_geometry(
            x, y, w, h, self.monitor, dock, anker_halten=True
        )
        pos = self.cfg.data["bar"].setdefault("position", {})
        pos["x"] = int(x)
        pos["y"] = int(y)
        pb_w: int | None = None
        pb_h: int | None = None
        if self.slot_limit is None:
            if layout.is_horizontal(dock) or dock in layout.DOCK_CORNER:
                pb_w = max(
                    layout.MIN_CONTENT_LENGTH,
                    int(self._leiste_breite_max(x)),
                )
                self._horizontal_platzbudget_w = pb_w
            if dock in layout.DOCK_VERTICAL:
                pb_h = max(layout.MIN_CONTENT_LENGTH, int(self._leiste_hoehe_max(y)))
                self._vertical_platzbudget_h = pb_h
            self._split_avail_override = pb_h if dock in layout.DOCK_VERTICAL else pb_w
            try:
                self._populate_entries()
            finally:
                self._split_avail_override = None
            orient = "vertical" if dock in layout.DOCK_VERTICAL else "horizontal"
            self._arrange(orient)
            self.root.update_idletasks()
            x, y, w, h = self._fit_window_to_content(
                x, y, w, h, breite_min=pb_w, hoehe_min=pb_h
            )
            w, h, x, y = layout.position_in_strip(
                dock,
                w,
                h,
                int(x),
                int(y),
                tuple(int(v) for v in strip),
                monitor=self.monitor,
            )
            x, y, w, h = layout.clamp_bar_geometry(
                x, y, w, h, self.monitor, dock, anker_halten=True
            )
            pos["x"] = int(x)
            pos["y"] = int(y)
        try:
            self.root.geometry(f"{w}x{h}+{x}+{y}")
            self.root.update_idletasks()
        except tk.TclError:
            return
        self._leiste_fenster_leerstreifen_sync()
        logging.info(
            "Kanten-Slide %s -> %dx%d+%d+%d (kein Shell-Roundtrip)",
            dock,
            w,
            h,
            x,
            y,
        )
        self._last_configure_wh = (int(w), int(h))
        self._set_window_shape()
        self._sync_drop_overlay()
        self._block_configure_relayout()
        self._save_state()
        self._apply_appearance()

    def _float_at(self, x: int, y: int, w: int, h: int, save: bool = True) -> None:
        """Frei schweben — gezogene Groesse behalten (kein Fit-Nachzug beim Griff)."""
        if self.docked in layout.DOCK_ALL - {layout.DOCK_FREE} and self.appbar:
            self._sync_appbar_hwnd()
            self.appbar.unregister()
        self.docked = layout.DOCK_FREE
        x, y, w, h = layout.clamp_bar_geometry(x, y, w, h, self.monitor, layout.DOCK_FREE)
        pos = self.cfg.data["bar"].setdefault("position", {})
        pos["x"], pos["y"], pos["w"], pos["h"] = x, y, w, h
        self.root.geometry(f"{w}x{h}+{x}+{y}")
        self.root.update_idletasks()
        self._set_window_shape()
        self._sync_drop_overlay()
        self._apply_appearance()
        if save:
            self._save_state()

    def _schweben_am_rand_zur_kante_heilen(self) -> None:
        """Schwebend, aber am Rand — wieder andocken + Desktop-Platz (05.10.2026)."""
        if self.docked != layout.DOCK_FREE:
            return
        # Vom Nutzer bewusst frei abgelegt (z. B. teils unter der
        # Taskleiste): bleibt — kein automatisches Wieder-Andocken
        # (Nutzer 06.10.2026: „wo abgelegt = dort bleibt").
        if bool(self.cfg.data.get("bar", {}).get("frei_gewaehlt", False)):
            return
        if not bool(self.cfg.data.get("bar", {}).get("desktop_platz", True)):
            return
        try:
            x = int(self.root.winfo_rootx())
            y = int(self.root.winfo_rooty())
            w = int(self.root.winfo_width())
            h = int(self.root.winfo_height())
        except tk.TclError:
            return
        dock = layout.detect_dock(
            drop_x=x + w // 2,
            drop_y=y + h // 2,
            monitor=self.monitor,
            start_x=x,
            start_y=y,
            current_dock=layout.DOCK_FREE,
            bar_width=w,
            bar_height=h,
            bar_x=x,
            bar_y=y,
            rand_verankert=getattr(self, "slot_limit", None) is None,
        )
        if dock not in layout.DOCK_EDGE | layout.DOCK_CORNER:
            return
        logging.info("Schweben am Rand -> Andocken %s", dock)
        self._platzbudget_nach_zug(layout.DOCK_FREE, dock, w, h)
        self._dock_to(
            dock,
            anchor_x=x,
            anchor_y=y,
            platzbudget_w=(
                self._horizontal_platzbudget_w if layout.is_horizontal(dock) else None
            ),
            platzbudget_h=(
                self._vertical_platzbudget_h if dock in layout.DOCK_VERTICAL else None
            ),
            save=True,
        )

    def _toggle_desktop_platz(self):
        """KVA 86 — Desktop-Platz reservieren an/aus. Symbol-Positionen bleiben
        liegen (kein Voll-Restore — Nutzer 04.10.2026)."""
        bar = self.cfg.data["bar"]
        neu = not bool(bar.get("desktop_platz", True))
        bar["desktop_platz"] = neu
        self._cfg_save()
        if self.docked not in (layout.DOCK_EDGE | layout.DOCK_CORNER):
            return
        if neu:
            self._dock_to(self.docked)  # AppBar wieder anmelden + Symbole schieben
        else:
            if self.appbar:
                self._sync_appbar_hwnd()
                self.appbar.unregister()

    def _toplevel_hwnd(self) -> int:
        try:
            if win32gui:
                return AppBar.toplevel_hwnd(self.root.winfo_id())
        except Exception:
            pass
        return int(self.root.winfo_id())

    def _sync_appbar_hwnd(self) -> None:
        if not self.appbar:
            return
        try:
            self.appbar.hwnd = int(self.root.winfo_id())
        except (tk.TclError, TypeError, ValueError):
            pass

    def _appbar_nach_sichtbar_nachziehen(self) -> None:
        """Start: Shell-Anmeldung auf das sichtbare Fenster uebertragen.

        Tk erzeugt beim Sichtbarwerden (overrideredirect) ein neues
        Top-Level-HWND; die Reservierung aus dem ersten Andocken haengt am
        alten. Bis 29.09.2026 lief deshalb das komplette Andocken ein zweites
        Mal — sichtbar, mit Populate, Fit und ~10 Redraws (5-9 s). Layout und
        Geometrie stimmen aber schon; es fehlt nur ABM_NEW/SETPOS fuer das
        neue Handle. set_pos meldet bei geaendertem HWND selbst neu an.
        """
        dock = self.docked
        edge = layout.edge_for_dock(dock)
        if edge is None or not self.appbar:
            return
        if not bool(self.cfg.data["bar"].get("desktop_platz", True)):
            return
        alt = self.appbar._registered_hwnd
        self._sync_appbar_hwnd()
        neu = self.appbar._effective_hwnd()
        if alt is not None and int(alt) == int(neu):
            logging.info("AppBar: HWND unveraendert nach Sichtbarwerden (%s)", neu)
            return
        try:
            x, y, w, h = self._bar_geometry()
            self.root.update_idletasks()
            x, y, w, h = self._bar_geometry()
        except tk.TclError:
            return
        echte_dicke = h if layout.is_horizontal(dock) else w
        strip = layout.appbar_strip_rect(dock, self.monitor, echte_dicke)
        if not strip:
            return
        # Nur das alte ABM_NEW-HWND loesen — kein unregister() auf dem neuen
        # Fenster (sonst doppeltes ABM_REMOVE/NEW und Fremdleisten springen).
        if alt is not None and int(alt) != int(neu):
            self.appbar.remove_hwnd(int(alt))
        self._fenster_an_shell_appbar(edge, strip, x, y, w, h)
        self._block_configure_relayout()
        try:
            self._last_configure_wh = (
                int(self.root.winfo_width()), int(self.root.winfo_height()),
            )
        except tk.TclError:
            pass

    def _fenster_groesse_fixieren(self, w: int, h: int) -> None:
        try:
            ww, hh = max(1, int(w)), max(1, int(h))
        except (TypeError, ValueError):
            return
        if self._fenster_groesse_fix == (ww, hh):
            return
        try:
            # Schrumpfen beim Verschieben an die Kante erlauben (KVA 31/34)
            min_w = 80 if (layout.is_horizontal(self.docked) or self.docked == layout.DOCK_FREE) else ww
            min_h = 40 if (self.docked in layout.DOCK_VERTICAL or self.docked == layout.DOCK_FREE) else hh
            self.root.minsize(min_w, min_h)
            self.root.maxsize(10000, 10000)
            self._fenster_groesse_fix = (ww, hh)
        except tk.TclError:
            pass

    def _fenster_groesse_freigeben(self) -> None:
        if not self._fenster_groesse_fix:
            return
        try:
            self.root.minsize(0, 0)
            self.root.maxsize(0, 0)
        except tk.TclError:
            pass
        self._fenster_groesse_fix = (0, 0)
