"""Drag & Drop von aussen und globale Hotkeys."""
import logging
import time
import tkinter as tk
from pathlib import Path
from .win32_optional import win32con, win32gui
from .konstanten import VK_0, VK_OEM_MINUS, VK_OEM_PLUS
from .. import verbindung_profil
from .. import layout
from ..appbar import (
    AppBar,
)


class DropHotkeyMixin:
    def _init_drop_hotkey_zustand(self) -> None:
        """Zustand dieses Moduls — aus Bar.__init__, vor DROPFILES/OLE/Tray (die Objekte
        selbst entstehen in Bar.__init__, weil sie das fertige Leisten-HWND brauchen)."""
        self.drop_target = None
        self.ole_drop_target = None
        # Alle WndProc-Callbacks nur puffern (_aus_wndproc) — kein Tk im WndProc.
        self._wndproc_nachreichen: list = []
        self._pending_drop_paths: list[list[str]] = []
        self._drop_check_id = None

    def _on_drop(self, paths, point=None):
        # Drop-Callback kommt aus einem ctypes-WndProc waehrend der Message-Loop.
        # Keine Tk-Interaktion hier — nur puffern.
        self._pending_drop_paths.append((paths, point))

    def _drop_check(self):
        # Erst gepufferte WndProc-Callbacks (show, Tray, Hotkey) im Tk-Takt nachholen.
        nachreichen = list(getattr(self, "_wndproc_nachreichen", ()) or ())
        if nachreichen:
            self._wndproc_nachreichen.clear()
            for fn, args in nachreichen:
                try:
                    fn(*args)
                except Exception as exc:
                    logging.exception("WndProc-Callback nachgereicht fehlgeschlagen: %s", exc)
        pending = []
        if self.ole_drop_target:
            pending.extend(self.ole_drop_target.get_paths())
        pending.extend(self._pending_drop_paths)
        self._pending_drop_paths.clear()
        if pending:
            for item in pending:
                try:
                    # Tupel (Pfade, Ablegestelle) — alt: nur Pfade
                    if isinstance(item, tuple) and len(item) == 2:
                        paths, point = item
                    else:
                        paths, point = item, None
                    self._handle_dropped_paths(paths, point)
                except Exception as exc:
                    logging.exception("Fehler beim Verarbeiten des Drops: %s", exc)
        self._drop_check_id = self.root.after(80, self._drop_check)

    def _einfuege_index_fuer_point(self, point, entries):
        """Ablegestelle (Bildschirm-Koordinaten) -> Einfuege-Index in entries.

        Vertikale Leiste: nur die Hoehe (y) zaehlt, horizontale: nur x.
        Erster Eintrag, dessen Button-Mitte UNTERHALB/RECHTS der Ablegestelle
        liegt -> davor einfuegen. None = ans Ende.
        """
        if not point:
            return None
        px, py = point
        vertikal = self.orientation == "vertical" or self.docked in layout.DOCK_VERTICAL
        for btn in self.buttons:
            target = getattr(btn, "_target", None)
            if target is None:
                continue
            try:
                if vertikal:
                    mitte = btn.winfo_rooty() + max(1, btn.winfo_height()) // 2
                    trifft = py < mitte
                else:
                    mitte = btn.winfo_rootx() + max(1, btn.winfo_width()) // 2
                    trifft = px < mitte
            except tk.TclError:
                continue
            if trifft:
                for idx, e in enumerate(entries):
                    if e.get("target") == target:
                        return idx
                return None
        return None

    def _handle_dropped_paths(self, paths, point=None):
        try:
            entries = self.cfg.data.setdefault("entries", [])
            added = []
            added_entries = []
            moved = []
            skipped = []
            rejected = []
            # KVA 120 — Ablegestelle bestimmt die Einfuegestelle (nicht immer Ende)
            einfuege_idx = self._einfuege_index_fuer_point(point, entries)
            for path in paths:
                # Binaermuell/Steuerzeichen ablehnen — sonst landen kaputte
                # Eintraege in der Config (25.09.2026, FileNameW-HDROP-Bug).
                if any(ord(c) < 32 for c in str(path)):
                    logging.warning("Drop abgelehnt (Steuerzeichen): %r", path)
                    rejected.append(str(path))
                    continue
                name = Path(path).stem
                entry, neu = verbindung_profil.eintrag_einfuegen(
                    self.cfg.data, path, name
                )
                if not neu:
                    if einfuege_idx is not None:
                        try:
                            alt_idx = entries.index(entry)
                        except ValueError:
                            skipped.append(name)
                            continue
                        entries.pop(alt_idx)
                        neu_idx = einfuege_idx - 1 if alt_idx < einfuege_idx else einfuege_idx
                        neu_idx = max(0, min(neu_idx, len(entries)))
                        entries.insert(neu_idx, entry)
                        einfuege_idx = neu_idx + 1
                        moved.append(name)
                    else:
                        skipped.append(name)
                    continue

                if einfuege_idx is not None:
                    try:
                        entries.remove(entry)
                    except ValueError:
                        pass
                    entries.insert(
                        max(0, min(einfuege_idx, len(entries))), entry
                    )
                    einfuege_idx += 1
                added.append(entry.get("name") or name)
                added_entries.append(entry)
            if skipped and not added and not moved:
                names = ", ".join(skipped)
                self._show_drop_hint(f"{names} — ist schon auf der Leiste")
                logging.info("Drop-Duplikat: %s", skipped)
            if rejected:
                # KVA 124 — Ablehnung immer mit Begruendung zeigen (Murphy:
                # der seltene Fall tritt garantiert beim Nutzer auf).
                if len(rejected) > 2:
                    was = f"{len(rejected)} Dateien"
                else:
                    was = ", ".join(Path(r).name or "Datei" for r in rejected)
                self._show_drop_hint(
                    f"{was} — kann nicht angeheftet werden (ungueltiger Pfad)"
                )
            if added or moved:
                if not self._cfg_save(entries_changed=True):
                    return
                if moved:
                    # Reihenfolge geaendert — komplett neu aufbauen
                    self._rebuild_entries()
                else:
                    needs_layout = self._append_new_entries(added_entries)
                    if needs_layout:
                        if self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:
                            self._dock_to(self.docked)
                        else:
                            self._float()
                if added:
                    print(f"[xlounger] Per Drop hinzugefuegt: {added}", flush=True)
                    logging.info(
                        "Per Drop hinzugefuegt: %s (Ablegestelle %s, Einfuege-Index %s)",
                        added, point, einfuege_idx if point else "Ende",
                    )
                if moved:
                    logging.info(
                        "Per Drop verschoben: %s (Ablegestelle %s)", moved, point
                    )
                if skipped:
                    logging.info("Drop-Duplikate uebersprungen: %s", skipped)
        except Exception as exc:
            logging.exception("Fehler beim Verarbeiten des Drops: %s", exc)

    def _show_drop_hint(self, text):
        """Kurzen Hinweis als Overlay-Label anzeigen (verschwindet nach 3 s)."""
        hint = tk.Label(
            self.frame,
            text=text,
            bg="#cc3333",
            fg="white",
            font=("Segoe UI", 9, "bold"),
            padx=10,
            pady=4,
            relief=tk.SOLID,
            bd=1,
        )
        hint.place(relx=0.5, rely=0.5, anchor="center")
        self.root.after(3000, hint.destroy)

    def _register_hotkeys(self):
        if not win32gui or not win32con:
            return
        hwnd = AppBar.toplevel_hwnd(self.root.winfo_id())
        mod = win32con.MOD_CONTROL
        try:
            win32gui.RegisterHotKey(hwnd, 1, mod, win32con.VK_ADD)
            win32gui.RegisterHotKey(hwnd, 2, mod, win32con.VK_SUBTRACT)
            win32gui.RegisterHotKey(hwnd, 3, mod, win32con.VK_NUMPAD0)
            win32gui.RegisterHotKey(hwnd, 4, mod, VK_OEM_PLUS)
            win32gui.RegisterHotKey(hwnd, 5, mod, VK_OEM_MINUS)
            win32gui.RegisterHotKey(hwnd, 6, mod, VK_0)
        except Exception:
            pass

    def _unregister_hotkeys(self):
        if not win32gui:
            return
        hwnd = AppBar.toplevel_hwnd(self.root.winfo_id())
        for hid in (1, 2, 3, 4, 5, 6):
            try:
                win32gui.UnregisterHotKey(hwnd, hid)
            except Exception:
                pass

    def _on_hotkey(self, hotkey_id):
        now = time.monotonic()
        if now - self._last_zoom_time < 0.12:
            return
        if hotkey_id in (1, 4):
            self._zoom_in()
        elif hotkey_id in (2, 5):
            self._zoom_out()
        elif hotkey_id in (3, 6):
            self._zoom_reset()

    def _sync_drop_overlay(self):
        ole = getattr(self, "ole_drop_target", None)
        if ole:
            try:
                ole.sync()
            except Exception:
                pass
