"""Monitor-Bindung — Leiste nur auf dem Hauptmonitor (KVA 18/299/300)."""
import logging
import tkinter as tk
from .. import monitors
from .. import layout


class MonitorMixin:
    def _init_monitor_zustand(self) -> None:
        """Zustand dieses Moduls — aus Bar.__init__, nach tk.Tk()."""
        self.monitor = self._detect_monitor()
        self.scale = self.monitor.scale if self.monitor else 1.0
        self.float_w = int(round(self.BASE_FLOAT_W * self.scale))
        self.float_h = int(round(self.BASE_FLOAT_H * self.scale))

    def _detect_monitor(self):
        """Immer Hauptmonitor — Multi-Monitor wird erkannt, Leiste nur dort (KVA 18/299)."""
        primary = monitors.get_primary_monitor()
        if not primary:
            return None
        stored_key = self.cfg.data["bar"].get("monitor", "")
        if stored_key and stored_key != primary.key():
            alt = monitors.find_monitor_by_key(stored_key)
            if alt and not alt.is_primary:
                logging.info(
                    "Gespeicherter Zweitmonitor ignoriert (%s) — nur Hauptmonitor: %s",
                    alt.label(),
                    primary.label(),
                )
        self.cfg.data["bar"]["monitor"] = primary.key()
        logging.info("Hauptmonitor: %s", primary.label())
        return primary

    def _bind_primary_monitor(self) -> None:
        primary = monitors.get_primary_monitor()
        if not primary:
            return
        self.monitor = primary
        self.scale = primary.scale
        self.cfg.data["bar"]["monitor"] = primary.key()

    def _leiste_mitte_auf_primaer(self) -> bool:
        if not self.monitor:
            return True
        try:
            cx = int(self.root.winfo_rootx()) + int(self.root.winfo_width()) // 2
            cy = int(self.root.winfo_rooty()) + int(self.root.winfo_height()) // 2
        except tk.TclError:
            return True
        return monitors.is_point_on_primary(cx, cy)

    def _zurueck_auf_primaermonitor(self, grund: str = "") -> None:
        """Leiste sichtbar nur auf dem Hauptmonitor halten."""
        self._bind_primary_monitor()
        if self._leiste_mitte_auf_primaer():
            return
        if grund:
            logging.info("Zurueck auf Hauptmonitor: %s", grund)
        if self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:
            self._dock_to(self.docked)
            return
        try:
            w = int(self.root.winfo_width())
            h = int(self.root.winfo_height())
        except tk.TclError:
            w, h = self.float_w, self.float_h
        wl, wt, wr, wb = layout._work_tuple(self.monitor)
        x = wl + max(0, (wr - wl - w) // 2)
        y = wt + max(0, (wb - wt - h) // 2)
        self._float_at(x, y, w, h)

    def _multi_monitor_ersthinweis(self) -> None:
        """KVA 300 — einmalig bei mehreren Monitoren."""
        if monitors.monitor_count() < 2:
            return
        bar = self.cfg.data.setdefault("bar", {})
        if bar.get("multi_monitor_hinweis_gesehen"):
            return
        bar["multi_monitor_hinweis_gesehen"] = True
        self._cfg_save()
        from tkinter import messagebox

        messagebox.showinfo(
            "xlounger — mehrere Monitore",
            "\n".join(monitors.monitors_overview_lines()),
            parent=self.root,
        )

    def _monitor_desc(self):
        if not self.monitor:
            return "unbekannt"
        return (
            f"{self.monitor.width}x{self.monitor.height} "
            f"work={self.monitor.work_width}x{self.monitor.work_height} "
            f"dpi={self.monitor.dpi} scale={self.scale:.2f}"
        )

    def _show_monitors_info(self):
        from tkinter import messagebox

        messagebox.showinfo(
            "xlounger — Monitore",
            "\n".join(monitors.monitors_overview_lines()),
            parent=self.root,
        )
