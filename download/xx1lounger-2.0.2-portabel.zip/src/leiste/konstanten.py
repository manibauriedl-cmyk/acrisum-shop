"""Leisten-Konstanten — Hotkey-Codes und Ueberlauf-Timing."""

VK_OEM_PLUS = 0xBB
VK_OEM_MINUS = 0xBD
VK_0 = 0x30
UEBERLAUF_LINGER_MS = 90
UEBERLAUF_HOVER_POLL_MS = 80
UEBERLAUF_HOVER_MISS_MAX = 6
UEBERLAUF_HIT_PAD = 14
UEBERLAUF_WATCH_MS = 45
# 6 x 45 ms = ~270 ms Toleranz ausserhalb der Hitbox — vorher 2 x 45 ms
# (~90 ms): das Feld starb schon beim kurzen Ueberfahren einer Kante und
# unerreichbar schnell beim Weg ins Kontextmenue (Nutzer 11.10.2026).
UEBERLAUF_CLOSE_MISS = 6
