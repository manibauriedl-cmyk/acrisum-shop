"""Menues — Griff-Kontextmenue, Eintrags-Menue, Tray-Menue, Hilfe/Reparieren/Autostart/Version."""
import ctypes
import logging
import os
import tkinter as tk
from .. import layout
from ..app_id import APP_NAME
from ..install_pfad import INSTALL_ROOT
from ..appbar import (
    AppBar,
)
from .. import tooltip
from .. import verlauf
from .. import kontext_popup


class MenueMixin:
    def _init_menue_zustand(self) -> None:
        """Zustand dieses Moduls — aus Bar.__init__, nach tk.Tk() (Griff-Popup braucht root)."""
        self._menu_autoclose_id = None
        self._posted_menu: tk.Menu | None = None
        self._grip_menu_opened = False
        self._griff_kontext = kontext_popup.KontextPopup(self.root)
        self._griff_kontext._bei_schliessen = lambda: setattr(
            self, "_grip_menu_opened", False
        )

    def _make_menu(self, parent=None):
        """Einheitliches Kontextmenue im Win95/XP-Stil."""
        return tk.Menu(
            parent or self.root,
            tearoff=0,
            bg="#d4d0c8",
            fg="black",
            activebackground="#0a246a",
            activeforeground="white",
            relief=tk.RAISED,
            bd=2,
            font=("Segoe UI", 9),
        )

    def _dismiss_context_menus(self, _event=None, ueberlauf_schliessen: bool = True):
        """KVA 82 — Escape: offenes Kontextmenue und »-Feld schliessen."""
        kontext_popup.KontextPopup.schliesse_alle()
        self._icon_drag_abbrechen()
        if ueberlauf_schliessen:
            self._ueberlauf_schliessen()
        menu = self._posted_menu
        if menu is None:
            return "break"
        self._posted_menu = None
        try:
            menu.unpost()
        except tk.TclError:
            pass
        return "break"

    def _post_context_menu(
        self,
        menu: tk.Menu,
        x: int,
        y: int,
        *,
        ueberlauf_offen_lassen: bool = False,
    ) -> None:
        """Kontextmenue anzeigen und fuer Escape merken."""
        self._dismiss_context_menus(ueberlauf_schliessen=not ueberlauf_offen_lassen)
        # Offenen Tooltip loeschen — sonst schwebt er ueber/neben dem Menue
        # (Nutzer-Screenshot 28.09.2026: Tooltip + Kontextmenue gleichzeitig).
        tooltip.aktiven_ausblenden()
        self._posted_menu = menu
        try:
            self.root.update_idletasks()
            # Win32: Tk postet Menues modal per TrackPopupMenu. Der Owner (die
            # Leiste, overrideredirect) muss davor Vordergrund-Fenster sein —
            # sonst schliesst das Menue sofort wieder (MS KB135788-Muster).
            try:
                _u32 = ctypes.windll.user32
                # winfo_id() ist das INNERE Tk-Fenster; SetForegroundWindow
                # braucht das Top-Level (sonst schlaegt der Aufruf still fehl,
                # wenn gerade die Leiste selbst den Vordergrund hat — dann
                # schliesst TrackPopupMenu das Menue sofort wieder).
                if ueberlauf_offen_lassen and self._ueberlauf_feld is not None:
                    hwnd_owner = AppBar.toplevel_hwnd(self._ueberlauf_feld.winfo_id())
                else:
                    hwnd_owner = AppBar.toplevel_hwnd(self.root.winfo_id())
                _u32.SetForegroundWindow(hwnd_owner)
            except Exception:
                pass
            logging.info("Kontextmenue wird gepostet bei (%s, %s)", int(x), int(y))
            # KVA 108 — nach 10 s ohne Wahl automatisch schliessen. Tk verarbeitet
            # Timer-Events auch waehrend des modalen TrackPopupMenu weiter.
            self._menu_autoclose_cancel()
            self._menu_autoclose_id = self.root.after(10_000, self._menu_autoclose_tick)
            # Menue aus dem >>-Feld: waehrend TrackPopupMenu modal laeuft steht
            # die Maus UEBER DEM MENUE — ausserhalb der Feld-Hitbox. Der
            # Ueberlauf-Watch wuerde das Feld sonst nach ~90 ms zerstoeren und
            # „Eigenschaften" waere nicht erreichbar (Nutzer 11.10.2026).
            self._ueberlauf_menue_aktiv = ueberlauf_offen_lassen
            try:
                menu.tk_popup(int(x), int(y))  # modal (TrackPopupMenu) — kehrt erst nach Menue-Ende zurueck
            finally:
                self._ueberlauf_menue_aktiv = False
            self._menu_autoclose_cancel()
            logging.info("Kontextmenue geschlossen")
        except tk.TclError as exc:
            self._posted_menu = None
            self._menu_autoclose_cancel()
            logging.warning("Kontextmenue post fehlgeschlagen: %s", exc)

    def _menu_autoclose_cancel(self) -> None:
        job = self._menu_autoclose_id
        self._menu_autoclose_id = None
        if job is not None:
            try:
                self.root.after_cancel(job)
            except tk.TclError:
                pass

    def _menu_autoclose_tick(self) -> None:
        self._menu_autoclose_id = None
        menu = self._posted_menu
        if menu is None:
            return
        logging.info("Kontextmenue nach 10 s ohne Wahl geschlossen")
        self._dismiss_context_menus()

    def _show_menu_at(self, x_root: int, y_root: int) -> None:
        class _E:
            pass

        ev = _E()
        ev.x_root, ev.y_root = int(x_root), int(y_root)
        self._show_menu(ev)

    def _grip_menu_klick(self, event) -> str:
        """Rechtsklick Griff — Einstellungsmenue.

        Das Menue darf erst aufgehen, wenn das ausloesende Button-Release
        schon verarbeitet ist — sonst frisst die modale Menue-Schleife
        (TrackPopupMenu) das noch in der Queue stehende WM_RBUTTONUP und
        schliesst sich sofort wieder (Windows-Kontextmenues oeffnen
        standardmaessig erst bei Release)."""
        self._drag_abort()
        xr, yr = int(event.x_root), int(event.y_root)
        logging.info("Griff-Rechtsklick — Menue bei (%s, %s)", xr, yr)
        self.root.after(60, lambda: self._show_menu_at(xr, yr))
        return "break"

    def _tray_menue_oeffnen(self) -> None:
        """KVA 228 — Tray-Rechtsklick. Kommt aus der WndProc mitten in der
        Message-Loop: Menue erst nach Verarbeitung posten (Release-Problem,
        gleiches Muster wie Griff-Rechtsklick)."""
        self.root.after(60, self._tray_menue_posten)

    def _tray_menue_posten(self) -> None:
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label="Leiste anzeigen", command=self.show)
        menu.add_command(label="Beenden", command=self._quit)
        self._post_context_menu(
            menu, self.root.winfo_pointerx(), self.root.winfo_pointery()
        )

    def _grip_menu_nach_klick(self, x_root: int, y_root: int) -> None:
        """Linker Klick Griff ohne Zug — Einstellungsmenue."""
        if self._grip_menu_opened:
            return
        self._grip_menu_opened = True
        logging.info("Griff-Klick erkannt — Menue bei (%s, %s)", int(x_root), int(y_root))
        self.root.after(1, lambda: self._show_menu_at(x_root, y_root))

    def _grip_release(self, event) -> str:
        """Release am Griff — Klick oeffnet Menue, Zug endet normal."""
        if self._dragging:
            self._drag_end(event)
            return "break"
        if self._drag_offset is None:
            return "break"
        drop_x = int(getattr(event, "x_root", self._dx))
        drop_y = int(getattr(event, "y_root", self._dy))
        self._drag_abort()
        self._grip_menu_nach_klick(drop_x, drop_y)
        return "break"

    def _show_entry_menu(self, event, target):
        self._show_entry_menu_at(event.x_root, event.y_root, target)

    def _show_entry_menu_at(self, x: int, y: int, target: str, im_ueberlauf: bool = False):
        # Reihenfolge wie im Windows-Kontextmenue: Öffnen oben,
        # Umbenennen/Entfernen unten, Eigenschaften als letzter Punkt.
        parent = self.root
        if im_ueberlauf and self._ueberlauf_feld is not None:
            try:
                if self._ueberlauf_feld.winfo_exists():
                    parent = self._ueberlauf_feld
            except tk.TclError:
                pass
        menu = self._make_menu(parent=parent)
        menu.add_command(label="Öffnen", command=lambda: self._on_click(target))
        menu.add_separator()
        if im_ueberlauf:
            menu.add_command(
                label="An Leiste (vorne)",
                command=lambda: self._move_entry_from_ueberlauf_to_front(target),
            )
        else:
            menu.add_command(
                label="Nach hinten (ins >>-Menü)",
                command=lambda: self._move_entry_to_back(target),
            )
        menu.add_command(label="Verknüpfung auf Desktop", command=lambda: self._create_desktop_shortcut(target))
        menu.add_separator()
        menu.add_command(
            label="Umbenennen",
            command=lambda t=target, ax=x, ay=y: self._entry_properties_dialog(
                t, anchor_x=ax, anchor_y=ay, fokus_name=True
            ),
        )
        menu.add_command(label="Entfernen", command=lambda: self._remove_entry(target, aus_ueberlauf=im_ueberlauf))
        menu.add_separator()
        menu.add_command(
            label="Eigenschaften",
            command=lambda t=target, ax=x, ay=y: self._entry_properties_dialog(t, anchor_x=ax, anchor_y=ay),
        )
        self._post_context_menu(
            menu,
            x,
            y,
            ueberlauf_offen_lassen=im_ueberlauf,
        )

    def _menu_mark(self, active: bool) -> str:
        """* vor dem aktiven Eintrag."""
        return "* " if active else ""

    def _add_slot_menu_items(self, menu: tk.Menu) -> None:
        """KVA 64–69: Leisten-Slots als flache Punkte (kein Untermenue)."""
        for label, value in (
            ("0 Symbole — alles im »-Menü", 0),
            ("3 Symbole", 3),
            ("5 Symbole", 5),
            ("7 Symbole", 7),
            ("12 Symbole", 12),
            ("Alle", None),
        ):
            menu.add_command(
                label=f"{self._menu_mark(self.slot_limit == value)}{label}",
                command=lambda v=value: self._set_slot_limit(v),
            )

    def _build_griff_menue_eintraege(self) -> list[dict]:
        from src import autostart, taskleiste

        eintraege: list[dict] = [
            {
                "typ": "item",
                "text": "Verbindungen anheften…",
                "aktion": "anheften",
                "info": "Katalog: Programme, Ordner, Dateien und Internet-Links auf die Leiste legen.",
            },
            {
                "typ": "item",
                "text": "Erkunden",
                "aktion": "erkunden",
                "info": "Öffnet den Ordner im Explorer, in dem die Leiste gespeichert ist.",
            },
            {
                "typ": "item",
                "text": "Leiste reparieren",
                "aktion": "reparieren",
                "info": "Bei Anzeigeproblemen: meldet die Leiste bei Windows neu an und baut alle Symbole frisch auf.",
            },
            {"typ": "separator"},
        ]
        for text, dock in (
            ("Oben", layout.DOCK_TOP),
            ("Unten", layout.DOCK_BOTTOM),
            ("Links", layout.DOCK_LEFT),
            ("Rechts", layout.DOCK_RIGHT),
        ):
            eintraege.append(
                {
                    "typ": "checkbox",
                    "text": text,
                    "aktion": f"dock:{dock}",
                    "checked": self.docked == dock,
                }
            )
        eintraege.append({"typ": "separator"})
        for text, dock in (
            ("Oben links", layout.DOCK_TOP_LEFT),
            ("Oben rechts", layout.DOCK_TOP_RIGHT),
            ("Unten links", layout.DOCK_BOTTOM_LEFT),
            ("Unten rechts", layout.DOCK_BOTTOM_RIGHT),
        ):
            eintraege.append(
                {
                    "typ": "checkbox",
                    "text": text,
                    "aktion": f"dock:{dock}",
                    "checked": self.docked == dock,
                }
            )

        modus_aktuell = getattr(
            self, "anzeige_modus", "beide" if self.show_labels else "symbole"
        )
        for label, modus, info in (
            ("Symbole + Text", "beide", "Symbol und Name — die normale Ansicht."),
            ("Nur Symbole", "symbole", "Nur die Symbole — ohne Namen darunter."),
            ("Nur Text", "text", "Nur die Namen — die schmalste Leiste, ohne Symbole."),
        ):
            eintraege.append(
                {
                    "typ": "checkbox",
                    "text": label,
                    "checked": modus_aktuell == modus,
                    "aktion": f"anzeige_modus:{modus}",
                    "info": info,
                }
            )
        eintraege.append({"typ": "separator"})
        for label, value in (
            ("0 Symbole — alles im »-Menü", 0),
            ("3 Symbole", 3),
            ("5 Symbole", 5),
            ("7 Symbole", 7),
            ("12 Symbole", 12),
            ("Alle", None),
        ):
            eintrag = {
                "typ": "checkbox",
                "text": label,
                "checked": self.slot_limit == value,
                "aktion": f"slots:{value!r}",
            }
            if value == 0:
                eintrag["info"] = (
                    "Wie viele Einträge sichtbar sind — der Rest wandert ins »-Menü am Ende der Leiste."
                )
            eintraege.append(eintrag)

        eintraege.append({"typ": "separator"})
        eintraege.append(kontext_popup.zoom_slider_eintrag(self.zoom_stufe))
        eintraege.append(
            {
                "typ": "checkbox",
                "text": "Die Leiste immer sichtbar halten",
                "checked": bool(self.cfg.data["bar"].get("always_on_top", True)),
                "aktion": "toggle_topmost",
                "info": "An: andere Fenster können die Leiste nicht verdecken. Aus: Fenster dürfen darüber liegen.",
            }
        )
        platz_an = bool(self.cfg.data["bar"].get("desktop_platz", True))
        eintraege.append(
            {
                "typ": "checkbox",
                "text": "Desktop-Platz reservieren",
                "checked": platz_an,
                "aktion": "desktop_platz",
                "info": "Große Fenster füllen den Bildschirm nur bis zur Leiste — die Leiste bleibt frei und wird nicht verdeckt.",
            }
        )
        eintraege.append(
            {
                "typ": "item",
                "text": "Randstreifen freiräumen",
                "aktion": "randstreifen",
                "info": "Schiebt Desktop-Symbole vom Leistenrand weg, damit nichts unter der Leiste liegt.",
            }
        )
        gepinnt = taskleiste.taskleisten_link_pfad().is_file()
        eintraege.append(
            {
                "typ": "checkbox",
                "text": "An Windows-Taskleiste anheften",
                "checked": gepinnt,
                "aktion": "taskleiste_pin",
                "info": "Legt ein xlounger-Symbol in die Windows-Taskleiste.",
            }
        )
        eintraege.append(
            {
                "typ": "checkbox",
                "text": "Autostart",
                "checked": autostart.eingerichtet(),
                "aktion": "autostart",
                "info": "Die Leiste startet automatisch nach dem Anmelden bei Windows.",
            }
        )
        verlauf_eintraege = verlauf.verlauf_lesen(self.cfg.data)
        if verlauf_eintraege:
            kinder = [
                {
                    "typ": "item",
                    "text": str(ve.get("name") or ve.get("target")),
                    "aktion": f"verlauf:{ve['target']}",
                }
                for ve in verlauf_eintraege
            ]
            eintraege.append({"typ": "submenu", "text": "Verlauf", "eintraege": kinder})

        eintraege.append({"typ": "separator"})
        bg_aktuell = str(self.bg_color).lower()
        for label, color in self._COLOR_PRESETS.items():
            eintraege.append(
                {
                    "typ": "checkbox",
                    "text": f"Farbe: {label}",
                    "aktion": f"farbe:{color}",
                    "checked": bg_aktuell == color.lower(),
                }
            )

        eintraege.append({"typ": "separator"})
        trans_aktuell = float(self.cfg.data["bar"].get("transparency", 0.0))
        for text, val in (
            ("Transparenz: keine", 0.0),
            ("Transparenz: mittel", 0.4),
            ("Transparenz: stark", 0.7),
            ("Transparenz: ganz", 1.0),
        ):
            eintraege.append(
                {
                    "typ": "checkbox",
                    "text": text,
                    "aktion": f"transparenz:{val}",
                    "checked": abs(trans_aktuell - val) < 0.01,
                }
            )

        eintraege.append({"typ": "separator"})
        eintraege.append(
            {
                "typ": "item",
                "text": "Weitere Einstellungen…",
                "aktion": "settings",
                "info": "Öffnet das Einstellungsfenster mit allen Optionen.",
            }
        )
        eintraege.append({"typ": "separator"})
        eintraege.extend(
            [
                {
                    "typ": "item",
                    "text": "Monitore anzeigen",
                    "aktion": "monitore",
                    "info": "Übersicht der angeschlossenen Bildschirme.",
                },
                {
                    "typ": "item",
                    "text": "Nach Update suchen",
                    "aktion": "update_check",
                    "info": "Prüft, ob eine neue Version verfügbar ist.",
                },
                {
                    "typ": "item",
                    "text": "Hilfe",
                    "aktion": "hilfe",
                    "info": "Öffnet die ausführliche Anleitung im Browser.",
                },
                {
                    "typ": "item",
                    "text": "Fehlerbericht…",
                    "aktion": "fehlerbericht",
                    "info": "Problem melden — der Bericht wird vor dem Senden gezeigt.",
                },
                {"typ": "separator"},
                {
                    "typ": "item",
                    "text": "Leiste ausblenden",
                    "aktion": "ausblenden",
                    "info": "Versteckt die Leiste; zurückholen über das kleine Symbol unten rechts neben der Uhr.",
                },
                {"typ": "item", "text": "Beenden", "aktion": "beenden"},
                {"typ": "separator"},
                {"typ": "item", "text": self._build_version(), "aktion": "version"},
            ]
        )
        return eintraege

    def _griff_menue_aktion(self, aktion: str) -> None:
        if aktion == "zoom_stufe_flush":
            self._zoom_slider_fertig()
            return
        if aktion == "zoom_vorschau_start":
            self._zoom_vorschau_start()
            return
        if aktion == "zoom_vorschau_abbrechen":
            self._zoom_vorschau_abbrechen()
            return
        if aktion.startswith("zoom_stufe_"):
            self._set_zoom_stufe_vom_slider(int(aktion.rsplit("_", 1)[-1]))
            return
        if aktion.startswith("dock:"):
            self._dock_to(aktion[5:])
            return
        if aktion.startswith("verlauf:"):
            self._on_click(aktion[8:])
            return
        if aktion.startswith("farbe:"):
            self._set_bg(aktion[6:])
            return
        if aktion.startswith("transparenz:"):
            self._set_transparency(float(aktion[12:]))
            return
        if aktion.startswith("slots:"):
            import ast

            self._set_slot_limit(ast.literal_eval(aktion[6:]))
            return
        if aktion.startswith("anzeige_modus:"):
            self._set_anzeige_modus(aktion[14:])
            return
        if aktion.startswith("ueberlauf:"):
            entries = self.cfg.data.get("entries", [])
            _vis, _hid = self._split_entries_for_display(entries)
            if _hid:
                self._ueberlauf_oeffnen_vom_menue(list(_hid))
            return
        if aktion == "anheften":
            self._anheften_panel_oeffnen()
        elif aktion == "erkunden":
            self._erkunden()
        elif aktion == "reparieren":
            self._reparieren_menue()
        elif aktion == "abdocken":
            self._float()
        elif aktion == "toggle_labels":
            self._toggle_labels()
        elif aktion == "toggle_topmost":
            self._toggle_topmost()
        elif aktion == "desktop_platz":
            self._toggle_desktop_platz()
        elif aktion == "randstreifen":
            from .. import desktop_icons
            kw = {}
            try:
                if self.docked == "left":
                    kw["links"] = int(self.root.winfo_width())
                elif self.docked == "right":
                    kw["rechts"] = int(self.root.winfo_width())
            except tk.TclError:
                pass
            desktop_icons.randstreifen_freiraeumen(**kw)
        elif aktion == "taskleiste_pin":
            self._taskleiste_pin_menue()
        elif aktion == "autostart":
            self._autostart_menue()
        elif aktion == "settings":
            self._settings_dialog()
        elif aktion == "monitore":
            self._show_monitors_info()
        elif aktion == "update_check":
            self._update_check_manuell()
        elif aktion == "hilfe":
            self._hilfe_menue()
        elif aktion == "fehlerbericht":
            self._fehlerbericht_menue()
        elif aktion == "ausblenden":
            self._leiste_ausblenden_menue()
        elif aktion == "beenden":
            self._quit()
        elif aktion == "version":
            self._version_info()

    def _griff_menue_ist_offen(self) -> bool:
        km = self._griff_kontext
        try:
            return km._fenster is not None and bool(km._fenster.winfo_exists())
        except tk.TclError:
            return False

    def _show_menu(self, event):
        self._grip_menu_opened = True
        self.root.update_idletasks()
        leiste_rect = (
            int(self.root.winfo_rootx()),
            int(self.root.winfo_rooty()),
            int(self.root.winfo_width()),
            int(self.root.winfo_height()),
            str(self.docked),
        )
        logging.info("Griff-Kontextmenue bei (%s, %s)", int(event.x_root), int(event.y_root))
        self._griff_kontext.zeigen(
            int(event.x_root),
            int(event.y_root),
            self._build_griff_menue_eintraege(),
            self._griff_menue_aktion,
            leiste_rect=leiste_rect,
        )

    def _leiste_rect_fuer_menue(
        self,
    ) -> tuple[int, int, int, int, str] | None:
        try:
            return (
                int(self.root.winfo_rootx()),
                int(self.root.winfo_rooty()),
                int(self.root.winfo_width()),
                int(self.root.winfo_height()),
                str(self.docked),
            )
        except tk.TclError:
            return None

    def _erkunden(self):
        """KVA 85 — Programmordner im Explorer oeffnen."""
        try:
            os.startfile(str(INSTALL_ROOT))
        except Exception as exc:
            logging.warning("Erkunden fehlgeschlagen: %s", exc)

    def _hilfe_menue(self) -> None:
        """KVA 290 — HTML-Hilfe im Browser oeffnen (Fallback: Text-Dialog)."""
        from src import hilfe

        try:
            hilfe.hilfe_oeffnen(parent=self.root)
        except Exception as exc:
            logging.warning("Hilfe oeffnen fehlgeschlagen: %s", exc)
            hilfe._text_fallback(parent=self.root)

    def _fehlerbericht_menue(self) -> None:
        """KVA 253/254 — Fehlerbericht-Dialog (Vorschau vor dem Senden)."""
        from src import fehlerbericht

        server_url = str(self.cfg.data.get("fehlerbericht_url", "") or "")
        fehlerbericht.bericht_dialog(self.root, server_url=server_url)

    def _reparieren_menue(self) -> None:
        """Ein-Klick-Reparatur fuer Kunden — Klartext, kein Fachwissen noetig.

        Meldet die Leiste bei Windows frisch an (Platz an der Kante),
        baut die Symbole neu auf und prueft das Tray-Symbol.
        """
        logging.info("Leiste reparieren (Menue)")
        try:
            if self.docked != layout.DOCK_FREE:
                self._dock_to(self.docked)
            else:
                self._float()
            self._rebuild_entries()
            self._apply_appearance()
        except Exception as exc:
            logging.warning("Reparieren fehlgeschlagen: %s", exc)
        tray = getattr(self, "tray_icon", None)
        if tray is not None and not getattr(tray, "_aktiv", False):
            try:
                tray.start()
            except Exception as exc:
                logging.warning("Tray-Neustart beim Reparieren fehlgeschlagen: %s", exc)
        self._show_drop_hint("Leiste repariert")

    def _autostart_erstfrage(self) -> None:
        """Einmalig beim ersten Start fragen (Installation-Nachholen).

        Wer es hier nicht einschaltet, findet es später im Menü: „Autostart".
        """
        bar = self.cfg.data.setdefault("bar", {})
        if bar.get("autostart_gefragt"):
            return
        bar["autostart_gefragt"] = True
        self._cfg_save()
        from src import autostart

        if autostart.eingerichtet():
            return
        from tkinter import messagebox

        if messagebox.askyesno(
            "xlounger — Autostart",
            "Soll die Leiste bei jedem Windows-Start automatisch mitstarten?\n\n"
            "Du kannst das jederzeit ändern: Rechtsklick auf die Punkte\n"
            "in der Leiste → „Autostart“.",
            parent=self.root,
        ):
            if autostart.einrichten():
                self._show_drop_hint("Autostart eingerichtet — Leiste startet mit Windows")
            else:
                self._show_drop_hint("Autostart fehlgeschlagen — siehe Log")

    def _autostart_menue(self) -> None:
        """KVA 243 — Autostart um schalten (Menuepunkt)."""
        from src import autostart

        if autostart.eingerichtet():
            ok = autostart.entfernen()
            self._show_drop_hint(
                "Autostart ausgeschaltet" if ok else "Ausschalten fehlgeschlagen — siehe Log"
            )
        else:
            ok = autostart.einrichten()
            self._show_drop_hint(
                "Autostart eingerichtet — xlounger startet mit Windows"
                if ok
                else "Autostart fehlgeschlagen — siehe Log"
            )

    def _taskleiste_pin_menue(self) -> None:
        """KVA 102/220–223 — an Windows-Taskleiste anheften (Menuepunkt)."""
        from src import taskleiste

        if not taskleiste.anheften_moeglich():
            # KVA 223 — Win 8.1: OS-Grenze, manuelle Anleitung zeigen
            from tkinter import messagebox

            messagebox.showinfo(
                "An Taskleiste anheften",
                "Diese Windows-Version kann Programme nicht automatisch\n"
                "an die Taskleiste anheften. So geht es von Hand:\n\n"
                "1. Startmenü öffnen und „xlounger“ suchen\n"
                "2. Rechtsklick auf xlounger\n"
                "3. „An Taskleiste anheften“ wählen",
                parent=self.root,
            )
            return
        ergebnis = taskleiste.an_taskleiste_anheften()
        if ergebnis == "bereits":
            self._show_drop_hint("xlounger ist bereits angeheftet")
        elif ergebnis == "fallback":
            self._show_drop_hint(
                "Angeheftet — sichtbar nach Explorer-Neustart oder Ab-/Anmeldung"
            )
        elif ergebnis == "winrt":
            self._show_drop_hint("Anheften angefragt — bitte bestätigen")
        else:
            self._show_drop_hint("Anheften fehlgeschlagen — siehe Log")

    def _version_info(self):
        """KVA 97 — Info-Dialog mit Version."""
        from tkinter import messagebox

        messagebox.showinfo(
            APP_NAME,
            f"{APP_NAME}\nVersion {self._build_version()}",
            parent=self.root,
        )

    def _leiste_ausblenden_menue(self):
        """KVA 101 — Leiste ausblenden. Rueckweg: Tray oder erneuter xlounger-Start."""
        tray = self.tray_icon
        if tray is not None and getattr(tray, "icon", None) is None:
            try:
                tray.start(erzwingen=True)
            except Exception as exc:
                logging.warning("Tray-Start beim Ausblenden fehlgeschlagen: %s", exc)
        logging.info("Leiste ausgeblendet (Rueckweg: Tray oder erneuter Start)")
        self.hide()
