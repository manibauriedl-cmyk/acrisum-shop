"""Symbol ziehen — packen, Geist, umsortieren, in/aus Ueberlauf, auf Desktop abheften."""
import logging
import tkinter as tk
from .. import icons
from .. import monitors
from .. import layout
from .. import tooltip


class IconDragMixin:
    def _init_icon_drag_zustand(self) -> None:
        """Zustand dieses Moduls — aus Bar.__init__."""
        # Icon-Drag (packen & ziehen): Klick erst beim Loslassen ohne Zug
        self._icon_drag_state: dict | None = None
        self._icon_motion_bind = None
        self._icon_release_bind = None

    # --- Icon-Drag: packen, ziehen, umsortieren/abheften ---

    def _icon_drag_abbrechen(self) -> None:
        """Icon-Drag sauber beenden (z. B. wenn Griff-Ziehen startet)."""
        st = self._icon_drag_state
        if not st:
            return
        snap = st.get("entries_snapshot")
        self._icon_drag_state = None
        self._icon_drag_unbind()
        ghost = st.get("ghost")
        if ghost:
            try:
                ghost.destroy()
            except tk.TclError:
                pass
        self._icon_ghost_follow_stop()
        if st.get("dragging") and snap:
            self._icon_entries_aus_snapshot(snap)

    def _icon_ghost_follow_stop(self) -> None:
        job = getattr(self, "_icon_ghost_follow_job", None)
        if job:
            try:
                self.root.after_cancel(job)
            except tk.TclError:
                pass
        self._icon_ghost_follow_job = None

    def _icon_ghost_follow_tick(self) -> None:
        self._icon_ghost_follow_job = None
        st = self._icon_drag_state
        if not st or not st.get("dragging"):
            return
        ghost = st.get("ghost")
        if not ghost:
            self._icon_ghost_follow_start()
            return
        try:
            if not ghost.winfo_exists():
                return
            px, py = self.root.winfo_pointerxy()
            ghost.geometry(f"+{int(px) - int(ghost._dx)}+{int(py) - int(ghost._dy)}")
            ghost.lift()
        except tk.TclError:
            return
        self._icon_ghost_follow_start()

    def _icon_ghost_follow_start(self) -> None:
        if getattr(self, "_icon_ghost_follow_job", None):
            return
        try:
            self._icon_ghost_follow_job = self.root.after(16, self._icon_ghost_follow_tick)
        except tk.TclError:
            pass

    def _icon_press(self, target, event):
        """Button-1 auf Eintrag: noch NICHT starten. Erst beim Loslassen:
        kein Zug = Klick (Start mit Laeuft-Dialog), Zug = Drag (in der
        Leiste umsortieren / >48 px daneben = auf Desktop abheften)."""
        logging.info("Icon-Press: %s", target)
        if getattr(self, "_zoom_vorschau_aktiv", False):
            self._zoom_vorschau_abbrechen()
        self._drag_unbind()
        self._drag_offset = None
        self._dragging = False
        try:
            self.root.grab_release()
        except tk.TclError:
            pass
        aktiver = getattr(tooltip, "_aktiver", None)
        if aktiver is not None:
            try:
                aktiver._hide()
            except Exception:
                pass
        self._icon_drag_state = {
            "target": target,
            "sx": int(event.x_root),
            "sy": int(event.y_root),
            "dragging": False,
            "ghost": None,
            "up_ticks": 0,
            "entries_snapshot": list(self.cfg.data.get("entries", [])),
            "preview_idx": None,
            "from_ueberlauf": self._ueberlauf_feld is not None,
            "order_dirty": False,
        }
        self._icon_drag_symbol_vorladen(target)
        self._icon_drag_unbind()
        self._icon_motion_bind = self.root.bind_all("<B1-Motion>", self._icon_drag_motion)
        self._icon_release_bind = self.root.bind_all("<ButtonRelease-1>", self._icon_drag_release)
        try:
            self.root.after(60, self._icon_drag_poll_loslassen)
        except tk.TclError:
            pass

    def _icon_drag_unbind(self):
        if self._icon_motion_bind:
            try:
                self.root.unbind_all("<B1-Motion>")
            except tk.TclError:
                pass
            self._icon_motion_bind = None
        if self._icon_release_bind:
            try:
                self.root.unbind_all("<ButtonRelease-1>")
            except tk.TclError:
                pass
            self._icon_release_bind = None

    def _icon_drag_motion(self, event):
        st = self._icon_drag_state
        if not st:
            return
        if not st["dragging"]:
            if abs(int(event.x_root) - st["sx"]) < 2 and abs(int(event.y_root) - st["sy"]) < 2:
                return
            st["dragging"] = True
            logging.info("Icon-Drag startet: %s", st["target"])
            st["ghost"] = self._icon_ghost_erzeugen(st["target"], event)
            self._icon_ghost_follow_start()
            # »-Feld bleibt waehrend des Zugs OFFEN (Nutzer 25.09.2026).
            # Schliessen erst wenn Maus »-Bereich verlaesst — nicht jedes
            # Loslassen auf der Leiste (6 Slots / Heften / Sortieren).
        ghost = st.get("ghost")
        if ghost:
            try:
                ghost.geometry(
                    f"+{int(event.x_root) - ghost._dx}+{int(event.y_root) - ghost._dy}"
                )
                ghost.lift()
            except tk.TclError:
                pass
        if self._punkt_in_leiste_flaeche(int(event.x_root), int(event.y_root)):
            ziel = self._icon_drag_ziel_index(st["target"], int(event.x_root), int(event.y_root))
            if ziel is not None and ziel != st.get("preview_idx"):
                st["preview_idx"] = ziel
                self._icon_drag_preview_anwenden(st["target"], ziel)
                st["order_dirty"] = True

    def _icon_drag_ziel_index(self, target, x, y):
        entries = self.cfg.data.get("entries", [])
        alt = next((i for i, e in enumerate(entries) if e.get("target") == target), None)
        if alt is None:
            return None
        neu = self._einfuege_index_fuer_point((x, y), entries)
        if neu is None:
            neu = len(entries) - 1
        elif neu > alt:
            neu -= 1
        return neu

    def _icon_drag_preview_anwenden(self, target, neu_idx: int) -> None:
        """Lücke in der Leiste während des Ziehens — ohne Dock/Desktop."""
        entries = self.cfg.data.get("entries", [])
        alt = next((i for i, e in enumerate(entries) if e.get("target") == target), None)
        if alt is None or neu_idx == alt:
            return
        neue = list(entries)
        entry = neue.pop(alt)
        neue.insert(neu_idx, entry)
        self.cfg.data["entries"] = neue

        # Kein Live-Umbau der Leiste/Desktop — erst beim Loslassen (Nutzer 24.09.2026).

    def _icon_entries_aus_snapshot(self, snapshot) -> None:
        if not snapshot:
            return
        self.cfg.data["entries"] = list(snapshot)
        self._rebuild_entries(relayout_only=True)

    def _icon_photo_fuer_target(self, target: str):
        """Echtes Symbol — nicht das gemeinsame ? aus dem »-Raster."""
        entry = next(
            (e for e in self.cfg.data.get("entries", []) if e.get("target") == target),
            None,
        )
        if not entry:
            return icons.get_icon("?", str(target or ""), self.icon_size, False)
        return self._entry_icon_photo(entry, self.icon_size)

    def _icon_drag_symbol_vorladen(self, target: str) -> None:
        """»-Feld zeigt erst ? — vor dem Zug echtes Icon holen."""
        photo = self._icon_photo_fuer_target(target)
        if icons.ist_fragezeichen_platzhalter(photo, self.icon_size):
            return
        for btn in self.buttons:
            if getattr(btn, "_target", None) == target:
                try:
                    if hasattr(btn, "_xl_img"):
                        btn._xl_img = photo
                    for child in btn.winfo_children():
                        if isinstance(child, tk.Label) and child.cget("image"):
                            child.configure(image=photo)
                            child.image = photo
                except tk.TclError:
                    pass
                break
        for btn, entry in getattr(self, "_ueberlauf_feld_knoepfe", []) or []:
            if entry.get("target") != target:
                continue
            try:
                if btn.winfo_exists():
                    btn.configure(image=photo)
                    btn.image = photo
                    btn._xl_img = photo
            except tk.TclError:
                pass
            break

    def _icon_ghost_erzeugen(self, target, event=None):
        """Sichtbares Zieh-Symbol unter der Maus (Nutzer „greift“ das Icon)."""
        entry = next(
            (e for e in self.cfg.data.get("entries", []) if e.get("target") == target),
            None,
        )
        name = self._entry_name(entry) if entry else (target or "?")
        ghost_px = max(self.icon_size, 40)
        photo = self._entry_icon_photo(entry, ghost_px) if entry else icons.get_icon_fresh(name, target, ghost_px, False)
        if icons.ist_fragezeichen_platzhalter(photo, ghost_px):
            photo = self._icon_photo_fuer_target(target)
        leiste_bg = self._leiste_bg()
        fg = self._leiste_fg()
        try:
            ghost = tk.Toplevel(self.root)
            ghost.overrideredirect(True)
            ghost.attributes("-topmost", True)
            ghost.configure(bg="#c0c000", highlightthickness=2, highlightbackground="#ffff80")
            inner = tk.Frame(ghost, bg=leiste_bg, relief="raised", bd=2, padx=4, pady=3)
            inner.pack(fill="both", expand=True)
            if photo is not None and not icons.ist_fragezeichen_platzhalter(photo, ghost_px):
                lbl = tk.Label(
                    inner,
                    image=photo,
                    text=(name[:28] + "…") if len(name) > 29 else name,
                    compound=tk.TOP,
                    bg=leiste_bg,
                    fg=fg,
                    font=self._label_font(horizontal=True),
                )
                lbl.image = photo
            else:
                lbl = tk.Label(
                    inner,
                    text=name,
                    bg=leiste_bg,
                    fg=fg,
                    font=self._label_font(horizontal=True),
                    padx=6,
                    pady=6,
                )
            lbl.pack()
            ghost.update_idletasks()
            ghost._dx = max(ghost.winfo_width(), 48) // 2
            ghost._dy = max(ghost.winfo_height(), 48) // 2
            if event is not None:
                ghost.geometry(
                    f"+{int(event.x_root) - ghost._dx}+{int(event.y_root) - ghost._dy}"
                )
            ghost.lift()
            return ghost
        except tk.TclError:
            return None

    def _icon_drag_poll_loslassen(self):
        """Holt ein verlorenes <ButtonRelease-1> nach (AppBar/Transparenz
        schluckt es mitunter) — wie beim Leisten-Drag."""
        st = self._icon_drag_state
        if st is None:
            return
        if self._maus_links_unten():
            st["up_ticks"] = 0
            try:
                self.root.after(60, self._icon_drag_poll_loslassen)
            except tk.TclError:
                pass
            return
        st["up_ticks"] += 1
        if st["up_ticks"] < 4:
            try:
                self.root.after(60, self._icon_drag_poll_loslassen)
            except tk.TclError:
                pass
            return
        cx, cy = self._cursor_root()

        class _Ev:
            x_root = cx
            y_root = cy

        self._icon_drag_release(_Ev())

    def _icon_drag_release(self, event):
        st = self._icon_drag_state
        if not st:
            return
        self._icon_drag_state = None
        self._icon_drag_unbind()
        self._icon_ghost_follow_stop()
        ghost = st.get("ghost")
        if ghost:
            try:
                ghost.destroy()
            except tk.TclError:
                pass
        target = st["target"]
        snap = st.get("entries_snapshot")
        if not st["dragging"]:
            if st.get("from_ueberlauf"):
                # Klick im »-Feld: Feld BLEIBT offen, bis Maus es verlaesst
                # (Watch schliesst) oder angedockt wird — Nutzer 25.09.2026.
                # Kein Snapshot-Restore: Reihenfolge wurde nie angefasst, und
                # _rebuild_entries wuerde das Feld ueber _populate_entries
                # sofort wieder schliessen.
                pass
            else:
                self._icon_entries_aus_snapshot(snap)
                self._ueberlauf_schliessen()
            self._on_click(target)  # normaler Klick wie bisher
            return
        x, y = int(event.x_root), int(event.y_root)
        logging.info("Icon-Drag Release: %s bei (%s, %s)", target, x, y)
        # Eine Regel für Leiste und »-Feld: Desktop = Arbeitsbereich, nicht auf Leiste.
        if self._drag_loslassen_auf_desktop(x, y):
            if st.get("order_dirty") and snap:
                self.cfg.data["entries"] = list(snap)
            self._icon_abheften(
                target,
                x,
                y,
                von_ueberlauf=bool(st.get("from_ueberlauf")),
            )
            self._ueberlauf_schliessen()
            return
        if st.get("from_ueberlauf") and not self._punkt_in_leiste_flaeche(x, y):
            if self._punkt_in_ueberlauf_feld_rect(x, y):
                if self._icon_umsortieren_in_ueberlauf(target, x, y):
                    self.root.after(80, self._ueberlauf_nach_loeschen_neu_oeffnen)
                else:
                    self._icon_entries_aus_snapshot(snap)
                return
            self._icon_entries_aus_snapshot(snap)
            self._show_drop_hint(
                "Nicht auf der Leiste: Zum Anordnen Symbol auf die Leiste ziehen "
                "— oder im »-Feld loslassen zum Sortieren. Rechtsklick: „An Leiste (vorne)“."
            )
            return
        cur = self.cfg.data.get("entries", [])
        geaendert = bool(st.get("order_dirty")) or (
            snap and [e.get("target") for e in snap] != [e.get("target") for e in cur]
        )
        if geaendert:
            if not self._cfg_save(entries_changed=True):
                self._icon_entries_aus_snapshot(snap)
            else:
                try:
                    self._rebuild_entries(relayout_only=True)
                except tk.TclError as exc:
                    logging.debug("Icon-Drag Release rebuild: %s", exc)
                    self._rebuild_entries()
                neu = next(
                    (i for i, e in enumerate(cur) if e.get("target") == target),
                    None,
                )
                logging.info(
                    "Eintrag per Drag verschoben: %s -> Index %s",
                    target,
                    neu,
                )
        else:
            self._icon_umsortieren(target, x, y)
        if st.get("from_ueberlauf"):
            self._ueberlauf_outside_miss = 0
            try:
                self.root.after(80, self._ueberlauf_nach_loeschen_neu_oeffnen)
            except tk.TclError:
                pass
        else:
            self._ueberlauf_schliessen()

    def _punkt_in_leiste_flaeche(self, x_root: int, y_root: int, margin: int = 4) -> bool:
        try:
            l = int(self.root.winfo_rootx()) - margin
            t = int(self.root.winfo_rooty()) - margin
            r = l + int(self.root.winfo_width()) + 2 * margin
            b = t + int(self.root.winfo_height()) + 2 * margin
        except tk.TclError:
            return False
        return l <= x_root <= r and t <= y_root <= b

    def _punkt_in_ueberlauf_feld_rect(self, x_root: int, y_root: int) -> bool:
        feld = self._ueberlauf_feld
        if feld is None:
            return False
        try:
            if not feld.winfo_exists():
                return False
            fx = int(feld.winfo_rootx())
            fy = int(feld.winfo_rooty())
            fw = max(1, int(feld.winfo_width()))
            fh = max(1, int(feld.winfo_height()))
        except tk.TclError:
            return False
        return fx <= x_root <= fx + fw and fy <= y_root <= fy + fh

    def _drag_loslassen_auf_desktop(self, x_root: int, y_root: int) -> bool:
        """Gemeinsam für Leiste und »-Kiste — Punkt liegt auf einem Desktop/Monitor außerhalb der Leiste."""
        if self._punkt_in_leiste_flaeche(x_root, y_root):
            return False
        if self._punkt_in_ueberlauf_feld_rect(x_root, y_root):
            return False
        m = monitors.monitor_at_point(x_root, y_root)
        if m and monitors.is_point_on_monitor(m, x_root, y_root):
            return True
        sl, st, sr, sb = layout._monitor_tuple(self.monitor)
        return sl <= x_root <= sr and st <= y_root <= sb

    def _leiste_abstand(self, x, y):
        """0 = innerhalb der Leiste, sonst Pixel-Abstand zum Rechteck."""
        try:
            l, t = self.root.winfo_rootx(), self.root.winfo_rooty()
            r = l + max(1, self.root.winfo_width())
            b = t + max(1, self.root.winfo_height())
        except tk.TclError:
            return 0
        dx = max(l - x, 0, x - r)
        dy = max(t - y, 0, y - b)
        return max(dx, dy)

    def _ueberlauf_zelle_index_fuer_point(self, x_root: int, y_root: int) -> int | None:
        """Rasterzelle im offenen »-Feld unter dem Loslass-Punkt."""
        knoepfe = getattr(self, "_ueberlauf_feld_knoepfe", None) or []
        if not knoepfe:
            return None
        treffer: int | None = None
        best: int | None = None
        best_d: int | None = None
        for i, (btn, _entry) in enumerate(knoepfe):
            try:
                if not btn.winfo_exists():
                    continue
                bx = int(btn.winfo_rootx())
                by = int(btn.winfo_rooty())
                bw = max(1, int(btn.winfo_width()))
                bh = max(1, int(btn.winfo_height()))
            except tk.TclError:
                continue
            if bx <= x_root <= bx + bw and by <= y_root <= by + bh:
                treffer = i
                break
            cx = bx + bw // 2
            cy = by + bh // 2
            d = (x_root - cx) ** 2 + (y_root - cy) ** 2
            if best_d is None or d < best_d:
                best_d = d
                best = i
        return treffer if treffer is not None else best

    def _icon_umsortieren_in_ueberlauf(self, target: str, x_root: int, y_root: int) -> bool:
        """Reihenfolge unter den >>-Einträgen per Drag im »-Feld."""
        entries = list(self.cfg.data.get("entries", []))
        vis, hid = self._split_entries_for_display(entries)
        if not hid:
            return False
        alt_local = next(
            (i for i, e in enumerate(hid) if e.get("target") == target),
            None,
        )
        if alt_local is None:
            return False
        neu_local = self._ueberlauf_zelle_index_fuer_point(x_root, y_root)
        if neu_local is None or neu_local == alt_local:
            return False
        hid_neu = list(hid)
        item = hid_neu.pop(alt_local)
        neu_local = max(0, min(neu_local, len(hid_neu)))
        hid_neu.insert(neu_local, item)
        self.cfg.data["entries"] = vis + hid_neu
        if not self._cfg_save(entries_changed=True):
            return False
        logging.info(
            "Ueberlauf: Eintrag umsortiert: %s -> Position %s in »",
            target,
            neu_local,
        )
        return True

    def _icon_umsortieren(self, target, x, y):
        entries = self.cfg.data.get("entries", [])
        alt = next((i for i, e in enumerate(entries) if e.get("target") == target), None)
        if alt is None:
            return
        neu = self._einfuege_index_fuer_point((x, y), entries)
        if neu is None:
            neu = len(entries)  # hinter letztem losgelassen -> ans Ende
        if neu > alt:
            neu -= 1
        if neu == alt:
            return
        entry = entries.pop(alt)
        entries.insert(neu, entry)
        if not self._cfg_save(entries_changed=True):
            return
        self._rebuild_entries(relayout_only=True)
        logging.info(
            "Eintrag per Drag verschoben: %s -> Index %s",
            entry.get("name") or target, neu,
        )
