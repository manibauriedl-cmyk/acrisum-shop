"""pywin32 optional — fehlt es, sind die Namen None (Aufrufer pruefen `if not win32gui`)."""
try:
    import win32gui
    import win32con
    import win32api
    import win32process
except Exception:
    win32gui = None
    win32con = None
    win32api = None
    win32process = None
