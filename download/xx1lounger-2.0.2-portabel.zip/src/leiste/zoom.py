"""Zoom — Stufen, Slider-Vorschau, Hotkeys +/-/0."""
import time
import tkinter as tk
from .. import layout
from .. import masse
from .. import kontext_popup


class ZoomMixin:
    def _init_zoom_zustand(self) -> None:
        """Zustand dieses Moduls — aus Bar.__init__, vor der Darstellung (icon_size braucht zoom_stufe)."""
        self.zoom_stufe = masse.bar_zoom_stufe(self.cfg.data["bar"])
        self._last_zoom_time = 0.0
        self._zoom_slider_job: str | None = None
        self._zoom_slider_ziel: int | None = None
        self._zoom_umbau_laeuft = False
        self._zoom_umbau_job: str | None = None
        self._zoom_geometrie_job: str | None = None
        self._zoom_vorschau_aktiv = False
        self._zoom_vorschau_stufe = masse.bar_zoom_stufe(self.cfg.data["bar"])

    def _zoom_in(self):
        self._set_zoom(1)
        self._last_zoom_time = time.monotonic()

    def _zoom_out(self):
        self._set_zoom(-1)
        self._last_zoom_time = time.monotonic()

    def _zoom_reset(self):
        neu = masse.ZOOM_DEFAULT
        if masse.bar_zoom_stufe(self.cfg.data["bar"]) == neu:
            return
        self._set_zoom_stufe(neu)
        self._last_zoom_time = time.monotonic()

    def _zoom_vorschau_start(self) -> None:
        if self._zoom_vorschau_aktiv:
            return
        self._zoom_vorschau_aktiv = True
        self._zoom_vorschau_stufe = masse.bar_zoom_stufe(self.cfg.data["bar"])
        km = kontext_popup.KontextPopup._aktiv
        if km and km._fenster:
            # Menue bleibt offen; Position fix — kein Mitwandern/Jitter waehrend
            # der leichten Icon-Vorschau (AppBar erst nach Loslassen).
            km.menue_position_einfrieren(True)

    def _zoom_vorschau_menue_position_loesen(self) -> None:
        km = kontext_popup.KontextPopup._aktiv
        if km and km._fenster:
            km.menue_position_nach_vorschau(self._leiste_rect_fuer_menue())

    def _zoom_vorschau_abbrechen(self) -> None:
        if not self._zoom_vorschau_aktiv:
            return
        cfg_stufe = masse.bar_zoom_stufe(self.cfg.data["bar"])
        self._zoom_vorschau_aktiv = False
        self._zoom_slider_ziel = None
        for job_attr in ("_zoom_slider_job", "_zoom_umbau_job", "_zoom_geometrie_job"):
            job = getattr(self, job_attr, None)
            if job:
                try:
                    self.root.after_cancel(job)
                except tk.TclError:
                    pass
                setattr(self, job_attr, None)

        def _nach_abort() -> None:
            if self._zoom_umbau_laeuft:
                self.root.after(40, _nach_abort)
                return
            self._zoom_vorschau_menue_position_loesen()
            if self.zoom_stufe != cfg_stufe:
                self._set_zoom_stufe(cfg_stufe)

        if self.zoom_stufe != cfg_stufe:
            self._zoom_vorschau_stufe = cfg_stufe
            self._zoom_umbau_laeuft = True
            try:
                self.zoom_stufe = cfg_stufe
                self.icon_size = self._icon_groesse_leiste()
                self._fonts_aktualisieren()
                self.dock_thickness = self._calc_dock_thickness()
                self._rebuild_entries(relayout_only=True)
                self._leiste_nach_zoom_vorschau()
            finally:
                self._zoom_umbau_laeuft = False
            self.root.after(10, _nach_abort)
        else:
            _nach_abort()

    def _zoom_vorschau_commit(self) -> None:
        if not self._zoom_vorschau_aktiv:
            return
        neu = masse.zoom_clamp(int(self._zoom_vorschau_stufe))
        self._zoom_vorschau_aktiv = False
        self._zoom_slider_ziel = None
        gj = self._zoom_geometrie_job
        if gj:
            try:
                self.root.after_cancel(gj)
            except tk.TclError:
                pass
            self._zoom_geometrie_job = None
        self.cfg.data["bar"]["zoom_stufe"] = neu
        self.cfg.data["bar"].pop("zoom", None)
        self._cfg_save()
        if self.zoom_stufe != neu:
            self._set_zoom_stufe(neu)
        else:
            self._rebuild_entries(relayout_only=False)
            self._leiste_nach_zoom_vorschau(nach_vorschau_ende=True)
        self._zoom_vorschau_menue_position_loesen()

    def _zoom_platzbudget(self) -> tuple[int | None, int | None]:
        """Echtes Platzbudget fuer die Zoom-Wege — quer Breite, senkrecht Hoehe."""
        horizontal = layout.is_horizontal(self.docked) or self.docked == layout.DOCK_FREE
        if horizontal:
            return self._horizontal_platzbudget_w, None
        if self.docked in layout.DOCK_VERTICAL:
            return None, self._vertical_platzbudget_h
        return None, None

    def _leiste_nach_zoom_vorschau(self, *, nach_vorschau_ende: bool = False) -> None:
        # Nur ein echtes Platzbudget (Nutzer-Zug / »-Klick) zaehlt — NICHT die
        # aktuelle Fensterbreite: das Fenster folgt dem Inhalt, und die Breite
        # als Budget schrumpfte den »-Split mit jedem Regler-Tick (29.09.2026:
        # 13/0 -> 12/»1, nach Zurueckzoomen 9/»4, Budget klemmte bei 801 px).
        #
        # Waehrend Regler-Vorschau: keine AppBar/Geometrie (siehe
        # _zoom_vorschau_leicht_anwenden) — sonst DWM-Geister + „PC kaputt“.
        if self._zoom_vorschau_aktiv and not nach_vorschau_ende:
            return
        budget_w, budget_h = self._zoom_platzbudget()
        try:
            self.root.update_idletasks()
            x, y, w, h = self._bar_geometry()
            x, y, w, h = self._fit_window_to_content(
                x,
                y,
                w,
                h,
                breite_min=budget_w,
                hoehe_min=budget_h,
            )
            if nach_vorschau_ende and self.docked in layout.DOCK_VERTICAL:
                self._vertical_nach_fit_gegen_clip()
            x, y, w, h = self._leiste_platzbudget_erzwingen(
                x, y, w, h, self.docked, budget_w, budget_h
            )
            edge = layout.edge_for_dock(self.docked)
            platz_reservieren = bool(self.cfg.data["bar"].get("desktop_platz", True))
            if edge is not None and self.appbar and platz_reservieren:
                echte_dicke = h if layout.is_horizontal(self.docked) else w
                strip = layout.appbar_strip_rect(self.docked, self.monitor, echte_dicke)
                if strip:
                    x, y, w, h = self._fenster_an_shell_appbar(edge, strip, x, y, w, h)
            x, y, w, h = self._leiste_platzbudget_erzwingen(
                x, y, w, h, self.docked, budget_w, budget_h
            )
            self._leiste_fenster_leerstreifen_sync()
            self._set_window_shape()
            self._sync_drop_overlay()
            km = kontext_popup.KontextPopup._aktiv
            if km is self._griff_kontext and km._fenster:
                km.menue_position_nach_vorschau(self._leiste_rect_fuer_menue())
        except tk.TclError:
            pass

    def _zoom_vorschau_leicht_anwenden(self) -> None:
        self._zoom_umbau_job = None
        neu = masse.zoom_clamp(int(self._zoom_vorschau_stufe))
        self._zoom_umbau_laeuft = True
        try:
            self.zoom_stufe = neu
            self.icon_size = self._icon_groesse_leiste()
            self._fonts_aktualisieren()
            self.dock_thickness = self._calc_dock_thickness()
            self._rebuild_entries(
                relayout_only=True,
                fensterform_beibehalten=True,
            )
        finally:
            self._zoom_umbau_laeuft = False

    def _zoom_vorschau_umbau_planen(self) -> None:
        job = self._zoom_umbau_job
        if job:
            try:
                self.root.after_cancel(job)
            except tk.TclError:
                pass
        if self._zoom_vorschau_aktiv:
            ziel = self._zoom_vorschau_leicht_anwenden
        else:
            return
        self._zoom_umbau_job = self.root.after(16, ziel)

    def _set_zoom_stufe_vom_slider(self, neu: int) -> None:
        """Schieberegler — Vorschau ohne volles Andocken pro Tick."""
        self._zoom_vorschau_start()
        neu = masse.zoom_clamp(neu)
        if neu == self._zoom_vorschau_stufe:
            return
        self._zoom_vorschau_stufe = neu
        self._zoom_slider_ziel = neu
        job = self._zoom_slider_job
        if job is not None:
            try:
                self.root.after_cancel(job)
            except tk.TclError:
                pass
        delay = 70
        if self._zoom_umbau_laeuft:
            self._zoom_slider_job = self.root.after(delay, self._zoom_vorschau_slider_anwenden)
            return
        self._zoom_slider_job = self.root.after(delay, self._zoom_vorschau_slider_anwenden)

    def _zoom_vorschau_slider_anwenden(self) -> None:
        self._zoom_slider_job = None
        neu = self._zoom_slider_ziel
        if neu is None:
            return
        self._zoom_vorschau_stufe = masse.zoom_clamp(int(neu))
        if self._zoom_umbau_laeuft:
            self._zoom_slider_job = self.root.after(70, self._zoom_vorschau_slider_anwenden)
            return
        self._zoom_vorschau_umbau_planen()

    def _zoom_slider_fertig(self) -> None:
        job = self._zoom_slider_job
        if job is not None:
            try:
                self.root.after_cancel(job)
            except tk.TclError:
                pass
            self._zoom_slider_job = None
        neu = self._zoom_slider_ziel
        if neu is not None:
            self._zoom_vorschau_stufe = masse.zoom_clamp(int(neu))

        def _warten_und_commit() -> None:
            if self._zoom_umbau_laeuft:
                self.root.after(40, _warten_und_commit)
                return
            if self._zoom_umbau_job:
                self.root.after(40, _warten_und_commit)
                return
            if self._zoom_geometrie_job:
                self.root.after(40, _warten_und_commit)
                return
            self._zoom_vorschau_commit()

        self._zoom_vorschau_umbau_planen()
        self.root.after(50, _warten_und_commit)

    def _set_zoom_stufe(self, neu: int) -> None:
        neu = masse.zoom_clamp(neu)
        alt = masse.bar_zoom_stufe(self.cfg.data["bar"])
        if neu == alt:
            return
        if self._zoom_umbau_laeuft:
            self._zoom_slider_ziel = neu
            return
        self._zoom_umbau_laeuft = True
        try:
            # Kein Budget aus der Fensterbreite ableiten (siehe
            # _leiste_nach_zoom_vorschau) — nur ein vorhandenes echtes.
            platzbudget_w, platzbudget_h = self._zoom_platzbudget()
            self.cfg.data["bar"]["zoom_stufe"] = neu
            self.cfg.data["bar"].pop("zoom", None)
            self.zoom_stufe = neu
            self.icon_size = self._icon_groesse_leiste()
            self._fonts_aktualisieren()
            self.dock_thickness = self._calc_dock_thickness()
            self._cfg_save()
            self._block_configure_relayout(1.2)
            if self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:
                # Kein volles _dock_to bei Zoom — nur Fit + SETPOS (ein Shell-Puls,
                # Fremdleisten bleiben stabil).
                self._rebuild_entries(relayout_only=True)
                self._leiste_nach_zoom_vorschau(nach_vorschau_ende=True)
            else:
                self._float(platzbudget_w=platzbudget_w, platzbudget_h=platzbudget_h)
        finally:
            self._zoom_umbau_laeuft = False
            ziel = self._zoom_slider_ziel
            if ziel is not None and ziel != masse.bar_zoom_stufe(self.cfg.data["bar"]):
                self._zoom_slider_job = self.root.after(40, self._zoom_vorschau_slider_anwenden)

    def _set_zoom(self, delta):
        alt = masse.bar_zoom_stufe(self.cfg.data["bar"])
        self._set_zoom_stufe(masse.zoom_clamp(alt + delta))
