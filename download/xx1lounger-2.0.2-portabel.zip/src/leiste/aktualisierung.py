"""Update-Pruefung und -Dialog (KVA 277-294)."""
import logging
import tkinter as tk


class AktualisierungMixin:
    # ---------- Update (KVA 277–288, 293/294) ----------

    def _update_check_auto(self) -> None:
        """KVA 277/278/279 — Auto-Pruefung 45 s nach Start, max 1×/24 h."""
        from src import update

        if not update.pruefung_faellig():
            return
        self._update_pruefen(manuell=False)

    def _update_check_manuell(self) -> None:
        """KVA 280 — manuelle Pruefung aus dem Menue (immer, ohne 24-h-Sperre)."""
        self._update_pruefen(manuell=True)

    def _update_pruefen(self, manuell: bool) -> None:
        from tkinter import messagebox

        from src import update
        from src.version import get_version

        urls = self.cfg.data.get("update_urls") or []
        if not urls:
            if manuell:
                messagebox.showinfo(
                    "xlounger Update",
                    "Keine Update-Quelle eingerichtet.",
                    parent=self.root,
                )
            return
        latest = update.lade_latest_json(urls)
        update.pruefung_vermerken()
        if latest is None:
            if manuell:
                # KVA 294 — Hinweis auf lokale Update-Hilfe bei fehlendem Netz
                messagebox.showwarning(
                    "xlounger Update",
                    "Update-Prüfung fehlgeschlagen (kein Netz?).\n\n"
                    "Die Hilfe-Seite zum Update ist auch offline erreichbar:\n"
                    "Menue → Hilfe → Abschnitt „Update“.",
                    parent=self.root,
                )
            return
        if not update.update_verfuegbar(latest, get_version()):
            if manuell:
                messagebox.showinfo(
                    "xlounger Update",
                    f"xlounger ist aktuell (Version {get_version()}).",
                    parent=self.root,
                )
            return
        if not update.windows_passt(latest):
            if manuell:
                messagebox.showinfo(
                    "xlounger Update",
                    f"Version {latest['version']} braucht ein neueres Windows\n"
                    f"(Mindestens Windows {latest.get('win_min', '?')}).",
                    parent=self.root,
                )
            return
        # KVA 283 — abgelehnte Version 24 h nicht erneut anbieten
        if not manuell and update.ist_abgelehnt(latest["version"]):
            return
        self._update_dialog(latest)

    def _update_dialog(self, latest: dict) -> None:
        """KVA 278 — ein Klick genuegt; KVA 283: „nicht anbieten"; KVA 293: Hilfe."""

        from src.version import get_version

        version = latest["version"]
        dlg = tk.Toplevel(self.root)
        dlg.title("xlounger Update")
        dlg.transient(self.root)
        dlg.resizable(False, False)
        tk.Label(
            dlg,
            text=f"Version {version} ist verfügbar.\nInstalliert ist: {get_version()}",
            justify="left",
        ).pack(padx=14, pady=(12, 4), anchor="w")
        from src import update as _upd

        notes = _upd.hinweis(latest).strip()
        if notes:
            tk.Label(dlg, text=notes, justify="left", wraplength=380).pack(
                padx=14, pady=(0, 6), anchor="w"
            )
        zeile = tk.Frame(dlg)
        zeile.pack(fill="x", padx=10, pady=(4, 10))
        tk.Button(
            zeile,
            text="Jetzt aktualisieren",
            command=lambda: (dlg.destroy(), self._update_durchfuehren(latest)),
        ).pack(side="left", padx=4)
        tk.Button(zeile, text="Später", command=dlg.destroy).pack(side="left", padx=4)
        tk.Button(
            zeile,
            text="24 h nicht anbieten",
            command=lambda: (self._update_ablehnen(version), dlg.destroy()),
        ).pack(side="left", padx=4)
        # KVA 293 — Update-Hilfeseite (lokal, auch offline erreichbar)
        tk.Button(
            zeile, text="Hilfe", command=self._update_hilfe
        ).pack(side="right", padx=4)

    def _update_ablehnen(self, version: str) -> None:
        from src import update

        update.version_ablehnen(version)
        self._show_drop_hint(f"Version {version} wird 24 h nicht angeboten")

    def _update_hilfe(self) -> None:
        """KVA 293/294 — Update-Hilfeseite (lokal, geht auch ohne Netz)."""
        import webbrowser

        from src import hilfe

        if hilfe.hilfe_vorhanden():
            webbrowser.open(hilfe.hilfe_url().replace("index.html", "update.html"))
        else:
            hilfe._text_fallback(parent=self.root)

    def _update_durchfuehren(self, latest: dict) -> None:
        """KVA 281/282/285/288 — laden, pruefen, still installieren, ehrlich melden."""
        from tkinter import messagebox

        from src import update

        url = update.download_url(latest)
        if not url:
            messagebox.showerror(
                "xlounger Update",
                "Die Update-Info enthält keine Download-Adresse.",
                parent=self.root,
            )
            return
        setup = update.lade_setup_herunter(url, str(latest.get("sha256", "") or ""))
        if setup is None:
            messagebox.showerror(
                "xlounger Update",
                "Download fehlgeschlagen oder Prüfsumme falsch.\n"
                "Es wurde nichts verändert.",
                parent=self.root,
            )
            return
        try:
            rc = update.installiere_still(setup)
        except Exception as exc:
            rc = -1
            logging.error("Update-Installation Ausnahme: %s", exc)
        if rc != 0:
            # KVA 288 — klare Meldung bei kaputter Installation
            messagebox.showerror(
                "xlounger Update",
                f"Die Installation ist fehlgeschlagen (Code {rc}).\n\n"
                "xlounger ist möglicherweise nicht mehr vollständig.\n"
                "Bitte xlounger neu installieren (Menue → Hilfe → Update).",
                parent=self.root,
            )
