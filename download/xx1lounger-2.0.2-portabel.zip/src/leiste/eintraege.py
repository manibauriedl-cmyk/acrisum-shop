"""Eintraege verwalten — Hinzufuegen, Entfernen, Eigenschaften, Desktop-Verknuepfung, Klick/Start."""
import logging
import os
import shutil
import re
import time
import tkinter as tk
from pathlib import Path
from urllib.parse import urlparse
from .. import native_dialog
from .. import verbindung_profil
from ..browser_url import browser_url, is_web_url
from ..launcher import start, start_entry
from .. import layout
from .. import entry_hilfe
from .. import ui_clipboard
from .. import browser_tab
from .. import desktop_icons
from .. import fenster_finden
from .. import laeuft_dialog
from .. import port_dienst
from .. import verlauf
from .. import katalog_panel


# Shell-/Host-Programme: von ihnen laufen staendig Hintergrund-Instanzen
# (Kindprozesse fremder Apps, Skripte, der Desktop selbst bei explorer.exe).
# Ein laufender Prozess heisst hier NICHT „der Nutzer hat sein Fenster
# offen" — der „laeuft bereits"-Dialog soll fuer diese Eintraege nur bei
# gefundenem Fenster kommen (siehe _prozess_laeuft).
_FENSTER_HOSTS = frozenset({
    "cmd.exe", "powershell.exe", "pwsh.exe", "conhost.exe", "wt.exe",
    "windowsterminal.exe", "bash.exe", "wscript.exe", "cscript.exe",
    "mshta.exe", "rundll32.exe", "mmc.exe", "python.exe", "pythonw.exe",
    "py.exe", "explorer.exe",
})


class EintraegeMixin:
    def _on_click(self, target):
        entry = next(
            (e for e in self.cfg.data.get("entries", []) if e.get("target") == target),
            None,
        )
        custom = self._entry_custom(entry) if entry else {}
        name = (entry or {}).get("name") or target
        if entry and not custom.get("always_restart"):  # KVA 171 — Option ueberspringt Dialog
            treffer = self._laufende_fenster(target, entry, custom)
            hinweis = ""
            if not treffer:
                # KVA 186 — kein Fenster, aber Sperrdatei → Dokument ist geoeffnet
                sperre = fenster_finden.lock_datei_vorhanden(target)
                if sperre:
                    hinweis = "Dokument ist geoeffnet (Sperrdatei vorhanden)."
                elif self._prozess_laeuft(target):
                    # Prozess laeuft, aber kein Fenster gefunden (Launcher-
                    # Kindprozess, Tray-App): trotzdem fragen statt still
                    # neu starten (08.10.2026: Trading.lnk oeffnete 10x).
                    hinweis = "Das Programm läuft bereits."
            if treffer or hinweis:
                aktion, hwnd = laeuft_dialog.frage_laeuft_bereits(
                    self.root, name, treffer, bg=self.bg_color, hinweis=hinweis,
                )
                if aktion == laeuft_dialog.AKTION_ABBRECHEN:
                    return
                if aktion == laeuft_dialog.AKTION_ANZEIGEN and hwnd:
                    fenster_finden.fenster_fokussieren(hwnd)  # KVA 187 — auch elevated
                    self.cfg.data.setdefault("last_window_hwnds", {})[target] = hwnd
                    print(f"[xlounger] Fenster fokussiert: {target}", flush=True)
                    return
                # AKTION_NOCHMAL → normaler Start (KVA 154)
        if is_web_url(target):
            # KVA 168/169 — localhost: Port tot + Start-BAT hinterlegt → Dienst starten
            port = port_dienst.localhost_port(target)
            if port and not port_dienst.port_offen(port):
                bat = str(custom.get("dienst_bat") or "").strip()
                if bat:
                    port_dienst.dienst_starten_und_warten(bat, port)
            self._url_launched[browser_url(target)] = time.monotonic()
        print(f"[xlounger] Starte: {target}", flush=True)
        ok = start_entry(entry) if entry else start(target)
        if not ok:
            print(f"[xlounger] Fehler beim Starten: {target}", flush=True)
            return
        if entry and verbindung_profil.nach_erfolgreichem_start(entry):
            self._cfg_save()
        # KVA 188 — Verlauf der letzten 20 Starts
        verlauf.verlauf_hinzufuegen(self.cfg.data, target, name)
        self._cfg_save()

    def _prozess_laeuft(self, target: str) -> bool:
        """Lauf-Punkt-Status True und Eintrag ist kein URL-Ziel.

        URL-Eintraege (direkte Adresse, .url, .lnk mit Web-Adresse) brauchen
        den Adressleisten-Check — ein laufender Browser-Prozess heisst dort
        nicht, dass die Seite offen ist.

        Shell-/Host-Programme (cmd, PowerShell, Interpreter, Loader) werden
        nur ueber ein gefundenes Fenster gemeldet: von ihnen laufen dauernd
        Hintergrund-Instanzen als Kindprozesse fremder Programme — ohne
        sichtbares Fenster ist der Dialog nur Stoerung und „Fenster
        anzeigen" haette ohnehin kein Ziel (08.10.2026: „Eingabe" warnte
        wegen 15 fremden cmd.exe ohne ein einziges Konsolenfenster).
        """
        if not self._running.get(target):
            return False
        if is_web_url(target):
            return False
        exe, url = self._ziel_aufgeloest(target)
        if url:
            return False
        name = os.path.basename(exe) if exe else ""
        if not name and target.lower().endswith(".exe"):
            pfad = target if os.path.isfile(target) else shutil.which(target)
            name = os.path.basename(pfad or target)
        return name.lower() not in _FENSTER_HOSTS

    def _familie_pids(self, target: str, name: str = "") -> set[int]:
        """PIDs der Prozess-Familie eines Eintrags: Ziel-exe, Schwester-exe
        aus demselben Programmordner (nicht unter Windows/), Kindprozesse
        und Prozesse, deren Kommandozeile die Startargumente traegt.

        Schwester-exe zaehlt nur mit Fenster-Titel-Treffer — sonst
        behauptet der „laeuft bereits"-Dialog, Writer liefe, sobald
        Calc offen ist (Nutzer 09.10.2026 — zum zweiten Mal)."""
        import psutil

        low = str(target or "").lower()
        exe, _url = self._ziel_aufgeloest(target)
        if low.endswith(".exe"):
            p = target if os.path.isfile(target) else shutil.which(target)
            if p:
                exe = os.path.abspath(p)
        ziel_exe = ziel_dir = ziel_stem = ""
        if exe:
            # WindowsApps-Alias (0-Byte-Stub) → echte Paket-exe: deren
            # Kindprozesse/Fenster tragen den Paket-Pfad, nicht den Alias.
            try:
                from ..icons import _appexec_ziel

                echt = _appexec_ziel(exe)
                if echt:
                    exe = echt
            except Exception:
                pass
            ziel_exe = os.path.normcase(exe)
            ziel_dir = os.path.normcase(os.path.dirname(exe))
            ziel_stem = os.path.splitext(os.path.basename(exe))[0].lower()
        tokens: list[str] = []
        if low.endswith(".lnk"):
            try:
                from ..launcher import resolve_lnk

                _p, a = resolve_lnk(target)
                for tok in (a or "").split():
                    tok = tok.strip("\"'").lower()
                    wert = tok.split("=", 1)[-1]
                    for t in (tok, wert):
                        if len(t) > 3 and t not in tokens:
                            tokens.append(t)
            except Exception:
                pass
        elif not ziel_exe and not is_web_url(target):
            # .msc/.bat/Dokument: Fenster gehoert dem Launcher-Prozess
            # (mmc.exe, cmd.exe), die Kommandozeile traegt den Dateinamen.
            base = os.path.basename(low)
            if len(base) > 4:
                tokens.append(base)
        windir = os.path.normcase(os.environ.get("WINDIR", r"C:\Windows"))
        dir_ok = bool(ziel_dir) and not ziel_dir.startswith(windir)
        if not (ziel_exe or ziel_stem or tokens):
            return set()
        # Erkennungs-Tokens fuer den Schwester-Titel-Check: Eintragsname,
        # Verknuepfungs-/Datei-Stamm und exe-Stamm (Writer vs. Calc).
        ident_tokens: list[str] = []
        for wert in (
            name,
            os.path.splitext(os.path.basename(low))[0],
            ziel_stem,
        ):
            w = " ".join(str(wert or "").lower().split())
            if len(w) >= 4 and w not in ident_tokens:
                ident_tokens.append(w)
        direkt: set[int] = set()
        pmap: dict[int, int] = {}
        for proc in psutil.process_iter(["pid", "ppid", "name", "exe", "cmdline"]):
            try:
                pid = proc.info["pid"]
                pmap[pid] = proc.info.get("ppid") or 0
                pname = (proc.info.get("name") or "").lower()
                pexe = proc.info.get("exe")
                ok = False
                cmd = ""
                selber = False
                if pexe:
                    pexe_n = os.path.normcase(pexe)
                    if ziel_exe and pexe_n == ziel_exe:
                        selber = True
                    elif dir_ok and os.path.dirname(pexe_n) == ziel_dir:
                        # Suite-Schwester: nur mit passendem Fenster-Titel,
                        # sonst schreibt ein Calc-Fenster auch Writer zu.
                        titel = self._fenster_titel_von(pid)
                        if ident_tokens and any(
                            k in t for t in titel for k in ident_tokens
                        ):
                            ok = True
                if (
                    not selber
                    and ziel_stem
                    and os.path.splitext(pname)[0] == ziel_stem
                ):
                    selber = True
                if selber and not ok:
                    # Eintrag mit Startargumenten (MSACCESS.EXE „db.accdb"):
                    # die Kommandozeile muss die Parameter tragen, sonst
                    # markiert jede Instanz derselben exe den Eintrag.
                    if tokens:
                        cmd = " ".join(
                            proc.info.get("cmdline") or []
                        ).lower()
                        ok = all(t in cmd for t in tokens)
                    else:
                        ok = True
                if not ok and not selber and tokens:
                    if not cmd:
                        cmd = " ".join(
                            proc.info.get("cmdline") or []
                        ).lower()
                    if all(t in cmd for t in tokens):
                        ok = True
                if ok:
                    direkt.add(pid)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        fam = set(direkt)
        changed = True
        while changed:
            changed = False
            for pid, ppid in pmap.items():
                if ppid in fam and pid not in fam:
                    fam.add(pid)
                    changed = True
        return fam

    def _fremde_suite_fenster_raus(self, target, entry, treffer):
        """Fenster anderer Suite-Eintraege aus dem Treffer nehmen.

        Die Suite-Stamm-Prozesse (swriter.exe, soffice.exe) laufen nach
        dem Schliessen des Dokuments weiter — die Kind-Vererbung zieht
        soffice.bin dann auch in die Familie des Eintrags, und dessen
        Calc-Fenster wuerde fuer Writer angeboten (Nutzer 10.10.2026 —
        genau dieser Fall). Greift nur, wenn mehrere Eintraege exes aus
        demselben Programmordner anvisieren; sonst Rueckgabe unveraendert.
        """
        if not treffer:
            return treffer
        exe, _url = self._ziel_aufgeloest(target)
        if not exe and target.lower().endswith(".exe"):
            p = target if os.path.isfile(target) else shutil.which(target)
            if p:
                exe = os.path.abspath(p)
        if not exe:
            return treffer
        eigen_dir = os.path.normcase(os.path.dirname(exe))
        if not eigen_dir:
            return treffer

        def toks_fuer(name, tkey, ex):
            toks = []
            for wert in (
                name,
                os.path.splitext(os.path.basename(str(tkey or "").lower()))[0],
                os.path.splitext(os.path.basename(ex))[0],
            ):
                w = " ".join(str(wert or "").lower().split())
                if len(w) >= 4 and w not in toks:
                    toks.append(w)
            return toks

        eigene_toks = toks_fuer((entry or {}).get("name"), target, exe)
        fremde_toks: list[str] = []
        for e in self.cfg.data.get("entries", []):
            t2 = e.get("target", "")
            if not t2 or t2 == target:
                continue
            exe2, _u2 = self._ziel_aufgeloest(t2)
            if not exe2 or os.path.normcase(os.path.dirname(exe2)) != eigen_dir:
                continue
            for k in toks_fuer(e.get("name"), t2, exe2):
                if k not in eigene_toks and k not in fremde_toks:
                    fremde_toks.append(k)
        if not fremde_toks:
            return treffer

        def fremd(titel: str) -> bool:
            tl = " ".join(str(titel or "").lower().split())
            if any(k in tl for k in eigene_toks):
                return False
            return any(k in tl for k in fremde_toks)

        return [(h, t) for h, t in treffer if not fremd(t)]

    def _laufende_fenster(self, target, entry, custom):
        """KVA 151/164 — sichtbare Fenster zum Eintrag.

        URL-Pins: nur Adressleisten-Vergleich, kein Titel-Fallback (KVA 158).
        Gemerktes HWND (KVA 170) wird nach vorn sortiert.
        """
        if is_web_url(target):
            hints = tuple(custom.get("tab_hints") or ())
            return browser_tab.finde_url_fenster(browser_url(target), hints)
        # .lnk/.url mit Browser-Adresse (z. B. chrome.exe --new-window URL):
        # dieselbe Adressleisten-Erkennung wie bei URL-Pins — der Prozess-/
        # Titel-Abgleich findet solche Fenster nie, weil die URL nur in den
        # Startargumenten steht, nicht in der laufenden Kommandozeile
        # (08.10.2026: jeder Klick oeffnete still ein neues Fenster).
        _exe, url = self._ziel_aufgeloest(target)
        if url and is_web_url(url):
            hints = tuple(custom.get("tab_hints") or ())
            return browser_tab.finde_url_fenster(browser_url(url), hints)
        treffer = fenster_finden.finde_fenster(target, (entry or {}).get("name", ""))
        if not treffer:
            # Prozess laeuft, aber Titel-/Prozess-Abgleich findet das Fenster
            # nicht (OpenOffice: soffice.bin statt soffice.exe, Trading:
            # java-Kindprozess von tws.exe): Fenster der Prozess-Familie
            # anbieten, sonst fehlt „Fenster anzeigen" und der Nutzer sucht
            # das Fenster zwischen 40 anderen selbst (08.10.2026).
            fam = self._familie_pids(target, (entry or {}).get("name", ""))
            if fam:
                treffer = fenster_finden.fenster_der_prozesse(fam)
        treffer = self._fremde_suite_fenster_raus(target, entry, treffer)
        hwnd = (self.cfg.data.get("last_window_hwnds") or {}).get(target)
        if hwnd:
            for i, (h, _t) in enumerate(treffer):
                if h == hwnd:
                    treffer.insert(0, treffer.pop(i))
                    break
        if not treffer and hwnd and self._running.get(target):
            # Prozess laeuft, Fenster nicht matchbar (minimiert, Launcher-
            # Kindprozess): gemerktes hwnd anbieten, damit „Fenster anzeigen"
            # es wiederherstellen kann.
            try:
                import win32gui
                if win32gui.IsWindow(hwnd):
                    titel = win32gui.GetWindowText(hwnd) or (entry or {}).get("name") or target
                    return [(hwnd, titel)]
            except Exception:
                pass
        return treffer

    def _add_entry_dialog(self):
        dlg = tk.Toplevel(self.root)
        dlg.title("Neuer Eintrag")
        dlg.configure(bg=self.bg_color)
        dlg.resizable(False, False)
        dlg.attributes("-topmost", True)
        dlg.transient(self.root)
        dlg.grab_set()

        tk.Label(dlg, text="Ziel (Programm, Ordner, URL, .lnk):", bg=self.bg_color, fg="white", font=("Segoe UI", 9)).pack(anchor="w", padx=10, pady=(10, 2))
        target_var = tk.StringVar()
        target_entry = tk.Entry(dlg, textvariable=target_var, width=50, bg="#404040", fg="white", insertbackground="white")
        target_entry.pack(fill=tk.X, padx=10, pady=2)
        ui_clipboard.entry_clipboard_bind(target_entry)

        tk.Label(dlg, text="Name (optional):", bg=self.bg_color, fg="white", font=("Segoe UI", 9)).pack(anchor="w", padx=10, pady=(6, 2))
        name_var = tk.StringVar()
        name_entry = tk.Entry(dlg, textvariable=name_var, width=50, bg="#404040", fg="white", insertbackground="white")
        name_entry.pack(fill=tk.X, padx=10, pady=2)
        ui_clipboard.entry_clipboard_bind(name_entry)

        def _browse_file():
            path = native_dialog.askopenfilename(parent=dlg, title="Programm auswählen")
            if path:
                target_var.set(path)

        def _browse_folder():
            path = native_dialog.askdirectory(parent=dlg, title="Ordner auswählen")
            if path:
                target_var.set(path)

        btn_row = tk.Frame(dlg, bg=self.bg_color)
        btn_row.pack(fill=tk.X, padx=10, pady=(4, 0))
        tk.Button(btn_row, text="Datei...", command=_browse_file, bg="#505050", fg="white").pack(side=tk.LEFT, padx=(0, 4))
        tk.Button(btn_row, text="Ordner...", command=_browse_folder, bg="#505050", fg="white").pack(side=tk.LEFT)

        status = tk.Label(dlg, text="", bg=self.bg_color, fg="#ff6666", font=("Segoe UI", 9))
        status.pack(fill=tk.X, padx=10, pady=(4, 0))

        def _ok():
            target = target_var.get().strip()
            if not target:
                status.config(text="Bitte ein Ziel eingeben.")
                return
            name = name_var.get().strip()
            if not name:
                p = Path(target)
                if p.exists():
                    name = p.stem
                elif target.startswith(("http://", "https://", "ms-")):
                    name = target
                else:
                    name = target
            _entry, neu = verbindung_profil.eintrag_einfuegen(
                self.cfg.data, target, name
            )
            if not neu:
                status.config(text="Dieses Ziel ist bereits vorhanden.")
                return
            if not self._cfg_save(entries_changed=True):
                return
            self._rebuild_entries()
            if self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:
                self._dock_to(self.docked)
            else:
                self._float()
            print(f"[xlounger] Hinzugefuegt: {target}", flush=True)
            logging.info("Eintrag hinzugefuegt: %s", target)
            dlg.destroy()

        def _cancel():
            dlg.destroy()

        ok_cancel = tk.Frame(dlg, bg=self.bg_color)
        ok_cancel.pack(fill=tk.X, padx=10, pady=(10, 10))
        tk.Button(ok_cancel, text="Hinzufügen", command=_ok, bg="#505050", fg="white").pack(side=tk.RIGHT, padx=(4, 0))
        tk.Button(ok_cancel, text="Abbrechen", command=_cancel, bg="#505050", fg="white").pack(side=tk.RIGHT)

        # Sichtbar positionieren — sonst liegt der Dialog bei (0,0) UNTER der Leiste.
        # Erst verbergen, dann positionieren: geometry() auf das schon gemappte
        # transient-Fenster wird sonst verworfen (wie Eigenschaften / laeuft_dialog).
        dlg.update_idletasks()
        dw = dlg.winfo_reqwidth()
        dh = dlg.winfo_reqheight()
        x, y = layout.dialog_zentriert_arbeitsbereich(
            layout._work_tuple(getattr(self, "monitor", None)), dw, dh,
        )
        dlg.withdraw()
        dlg.update_idletasks()
        dlg.geometry(f"{dw}x{dh}+{x}+{y}")
        dlg.deiconify()
        dlg.lift(self.root)
        dlg.after(80, lambda: dlg.lift(self.root))

        target_entry.focus_set()
        dlg.bind("<Return>", lambda e: _ok())
        dlg.bind("<Escape>", lambda e: _cancel())

    def _remove_entry(self, target, *, aus_ueberlauf: bool = False, sanft: bool = False):
        entries = self.cfg.data.get("entries", [])
        entfernte = [e for e in entries if e.get("target") == target]
        new_entries = [e for e in entries if e.get("target") != target]
        if len(new_entries) == len(entries):
            return
        self.cfg.data["entries"] = new_entries
        verbindung_profil.entfernte_eintraege_merken(self.cfg.data, entfernte)
        if not self._cfg_save(entries_changed=True):
            return
        if sanft:
            # Abheften per Drag: Leiste neu messen, Desktop-Icons in Ruhe lassen.
            self._rebuild_entries(relayout_only=True)
            if self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:
                self._dock_to(self.docked, save=False, symbole_anordnen=False)
            elif self.docked == layout.DOCK_FREE:
                self._float(save=False)
        else:
            self._rebuild_entries()
            if self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:
                self._dock_to(self.docked)
            else:
                self._float()
        print(f"[xlounger] Entfernt: {target}", flush=True)
        logging.info("Eintrag entfernt: %s", target)
        if aus_ueberlauf:
            # >>-Feld mit den restlichen Eintraegen wieder oeffnen, damit man
            # mehrere nacheinander entfernen kann (statt dass der Rest weg ist).
            self.root.after(100, self._ueberlauf_nach_loeschen_neu_oeffnen)

    def _desktop_verknuepfung_dateiname(self, target: str, entry: dict) -> tuple[str, str]:
        name = entry.get("name") or "Verknuepfung"
        if name.lower().startswith(("http://", "https://")):
            name = urlparse(name).netloc or "Verknuepfung"
        name = re.sub(r'[\\/:*?"<>|]+', "-", name).strip(" .") or "Verknuepfung"
        ext = ".url" if target.lower().startswith(("http://", "https://")) else ".lnk"
        return name, ext

    @staticmethod
    def _desktop_ordner_pfade() -> list[str]:
        """Normcase-Pfade der Desktop-Ordner (User + Public)."""
        out = [os.path.normcase(os.path.join(os.path.expanduser("~"), "Desktop"))]
        public = os.environ.get("PUBLIC", "")
        if public:
            out.append(os.path.normcase(os.path.join(public, "Desktop")))
        return out

    def _finde_desktop_verknuepfung(self, target: str) -> str | None:
        """Vorhandene .lnk/.url — nur wenn sie WIRKLICH auf dem Desktop liegt.

        Das Leisten-Ziel selbst zaehlt nur, wenn es in einem Desktop-Ordner
        steckt — ein Startmenue-.lnk (ProgramData\\...) ist sonst „vorhanden",
        der Eintrag wird entfernt und kein Symbol erscheint (Nutzer
        08.10.2026: „nach Herausziehen komplett weg").
        """
        tpath = Path(target)
        if tpath.suffix.lower() in (".lnk", ".url") and tpath.is_file():
            if os.path.normcase(str(tpath.parent)) in self._desktop_ordner_pfade():
                return str(tpath)
        entry = next(
            (e for e in self.cfg.data.get("entries", []) if e.get("target") == target),
            None,
        )
        if not entry:
            entry = {"target": target, "name": Path(target).stem}
        name, ext = self._desktop_verknuepfung_dateiname(target, entry)
        kandidaten = [
            os.path.join(os.path.expanduser("~"), "Desktop", f"{name}{ext}"),
        ]
        public = os.environ.get("PUBLIC", "")
        if public:
            kandidaten.append(os.path.join(public, "Desktop", f"{name}{ext}"))
        for pfad in kandidaten:
            if os.path.isfile(pfad):
                return pfad
        return verbindung_profil.finde_desktop_verknuepfung_fuer_entry(entry)

    def _desktop_verknuepfung_sicherstellen(
        self, target: str
    ) -> tuple[str | None, bool, bool]:
        """(pfad, war_schon_da, abgebrochen) — abgebrochen = Leiste unveraendert."""
        vorhanden = self._finde_desktop_verknuepfung(target)
        if vorhanden:
            return vorhanden, True, False
        entry = next(
            (e for e in self.cfg.data.get("entries", []) if e.get("target") == target),
            {"target": target, "name": Path(target).stem},
        )
        name, ext = self._desktop_verknuepfung_dateiname(target, entry)
        kandidat = os.path.join(os.path.expanduser("~"), "Desktop", f"{name}{ext}")
        if os.path.isfile(kandidat):
            from tkinter import messagebox

            r = messagebox.askyesnocancel(
                "xlounger — Desktop",
                f"„{name}{ext}“ liegt schon auf dem Desktop.\n\n"
                "Ja = zweite Verknüpfung anlegen\n"
                "Nein = bestehende nutzen (nur von der Leiste entfernen)\n"
                "Abbrechen = Eintrag bleibt auf der Leiste",
                parent=self.root,
            )
            if r is None:
                return None, False, True
            if r is False:
                return kandidat, True, False
        neu = self._desktop_verknuepfung_neu(target)
        if neu:
            return neu, False, False
        return None, False, False

    def _desktop_verknuepfung_neu(self, target: str) -> str | None:
        try:
            entry = next(
                (e for e in self.cfg.data.get("entries", []) if e.get("target") == target),
                {"target": target, "name": Path(target).stem},
            )
            if isinstance(entry, dict) and not entry.get("launch"):
                verbindung_profil.migriere_entry(entry)
            felder = verbindung_profil.desktop_felder_aus_entry(entry)
            name, ext = self._desktop_verknuepfung_dateiname(target, entry)
            desktop = os.path.join(os.path.expanduser("~"), "Desktop")
            os.makedirs(desktop, exist_ok=True)
            path = self._unique_path(desktop, name, ext)

            if felder.get("kind") == "copy_lnk":
                quelle = str(felder.get("copy_from") or "")
                if not quelle or not os.path.isfile(quelle):
                    logging.warning("Desktop-Kopie: Quelle fehlt %s", quelle)
                    return None
                shutil.copy2(quelle, path)
                # Kopierte .lnk kann eine kaputte IconLocation mitbringen
                # („,0", tote Datei) -> Blanko-Icon auf dem Desktop, obwohl
                # das Ziel ein Icon hat (Nutzer 14.10.2026: VirtualBox).
                self._lnk_icon_sanitisieren(path)
            elif felder.get("kind") == "url" or ext == ".url":
                with open(path, "w", encoding="utf-8") as f:
                    f.write("[InternetShortcut]\n")
                    f.write(f"URL={felder.get('url') or target}\n")
                    ip = felder.get("icon_path") or ""
                    if ip:
                        f.write(f"IconFile={ip}\n")
                        f.write(f"IconIndex={felder.get('icon_index') or 0}\n")
                    hk = str(felder.get("hotkey") or "").strip()
                    if hk:
                        f.write(f"HotKey={hk}\n")
            else:
                import win32com.client

                shell = win32com.client.Dispatch("WScript.Shell")
                shortcut = shell.CreateShortcut(path)
                ziel_pfad = str(felder.get("target_path") or "")
                if not ziel_pfad:
                    logging.warning(
                        "Desktop-Verknuepfung ohne Ziel im Steckbrief: %s", target
                    )
                    return None
                shortcut.TargetPath = ziel_pfad
                shortcut.Arguments = str(felder.get("arguments") or "")
                wd = str(felder.get("workdir") or "")
                if wd and os.path.isdir(wd):
                    shortcut.WorkingDirectory = wd
                elif os.path.isfile(ziel_pfad):
                    shortcut.WorkingDirectory = os.path.dirname(ziel_pfad)
                icon_pfad = str(felder.get("icon_path") or "")
                icon_idx = int(felder.get("icon_index") or 0)
                if icon_pfad and os.path.exists(icon_pfad):
                    shortcut.IconLocation = f"{icon_pfad},{icon_idx}"
                # Restliche .lnk-Felder aus dem Steckbrief zurueckschreiben —
                # sonst verliert die exportierte Verknuepfung Fensterstil,
                # Tastenkuerzel und Kommentar beim Neubau.
                if felder.get("description"):
                    shortcut.Description = str(felder["description"])
                if felder.get("hotkey"):
                    shortcut.Hotkey = str(felder["hotkey"])
                if felder.get("window_style"):
                    shortcut.WindowStyle = int(felder["window_style"])
                shortcut.Save()

            print(f"[xlounger] Desktop-Verknuepfung erstellt: {path}", flush=True)
            logging.info("Desktop-Verknuepfung erstellt: %s", path)
            # KVA 209 — Desktop sofort aktualisieren, sonst erscheint das
            # Symbol erst nach manuellem F5.
            desktop_icons.item_aktualisieren(path)
            return path
        except Exception as exc:
            print(f"[xlounger] Fehler Desktop-Verknuepfung: {exc}", flush=True)
            logging.error("Fehler Desktop-Verknuepfung: %s", exc)
            return None

    def _lnk_icon_sanitisieren(self, lnk_path: str) -> None:
        """Kaputte IconLocation (leer/tote Datei) -> Icon des Ziels."""
        try:
            import win32com.client

            sc = win32com.client.Dispatch("WScript.Shell").CreateShortcut(
                str(lnk_path)
            )
            loc = str(sc.IconLocation or "").strip()
            pfad = loc.rsplit(",", 1)[0].strip().strip('"') if "," in loc else ""
            if pfad and os.path.exists(os.path.expandvars(pfad)):
                return
            ziel = str(sc.TargetPath or "")
            if ziel and os.path.exists(os.path.expandvars(ziel)):
                sc.IconLocation = f"{ziel},0"
                sc.Save()
                logging.info(
                    "Desktop-Verknuepfung: kaputte IconLocation %r -> %s",
                    loc,
                    ziel,
                )
        except Exception as exc:
            logging.warning("IconLocation-Sanierung fehlgeschlagen: %s", exc)

    def _create_desktop_shortcut(self, target):
        """Kontextmenue: Verknuepfung auf Desktop (mit Hinweis wenn schon da)."""
        vorhanden = self._finde_desktop_verknuepfung(target)
        if vorhanden:
            name = Path(vorhanden).stem
            self._show_drop_hint(f"{name} — Verknüpfung existiert bereits auf Desktop")
            logging.info("Desktop-Verknuepfung existiert bereits: %s", vorhanden)
            return vorhanden
        return self._desktop_verknuepfung_neu(target)

    @staticmethod
    def _unique_path(folder, base, ext):
        candidate = os.path.join(folder, f"{base}{ext}")
        if not os.path.exists(candidate):
            return candidate
        i = 2
        while True:
            candidate = os.path.join(folder, f"{base} ({i}){ext}")
            if not os.path.exists(candidate):
                return candidate
            i += 1

    def _detect_entry_type(self, target):
        """Typ eines Eintrags bestimmen."""
        t = target.lower()
        if t.endswith(".lnk"):
            return "Verknuepfung (.lnk)"
        if t.endswith(".url"):
            return "Internet-Verknuepfung (.url)"
        if t.endswith(".exe"):
            return "Programm (.exe)"
        if t.endswith(".msc"):
            return "Verwaltungskonsole (.msc)"
        if t.startswith(("http://", "https://")):
            return "URL"
        if t.startswith("ms-settings:"):
            return "Windows-Einstellung"
        if os.path.isdir(target):
            return "Ordner"
        if os.path.isfile(target):
            return f"Datei ({Path(target).suffix})"
        return "Unbekannt"

    def _is_system_file(self, target):
        """Pruefen ob target in System-Verzeichnissen liegt."""
        t = os.path.normpath(target).lower()
        sys_dirs = [
            os.path.normpath(os.environ.get("WINDIR", r"C:\Windows")).lower(),
            os.path.normpath(os.environ.get("PROGRAMFILES", r"C:\Program Files")).lower(),
            os.path.normpath(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")).lower(),
        ]
        return any(t.startswith(d) for d in sys_dirs)

    def _entry_windows_properties_pfad(self, entry: dict) -> str | None:
        """Datei/Ordner fuer Windows-Eigenschaften (nicht reine URLs)."""
        target = str(entry.get("target") or "").strip()
        if not target:
            return None
        low = target.lower()
        if low.startswith(("http://", "https://", "ms-settings:", "mailto:")):
            return None
        if low.endswith(".lnk") and Path(target).is_file():
            return target
        if low.endswith(".url") and Path(target).is_file():
            return target
        resolved = self._entry_display_target(entry)
        if resolved and Path(resolved).exists():
            p = Path(resolved)
            if p.is_dir() or p.suffix.lower() in (".exe", ".msc", ".bat", ".cmd", ".lnk"):
                return str(p)
        if Path(target).exists():
            p = Path(target)
            if p.is_dir() or p.suffix.lower() in (".exe", ".msc", ".bat", ".cmd"):
                return str(p)
        return None

    def _open_windows_properties(self, path: str, hwnd: int = 0) -> bool:
        """Windows-Shell-Eigenschaften-Dialog (ShellExecuteEx, auch .msc).

        hwnd: optionaler Besitzer — haelt den Dialog ueber topmost-Fenstern.
        """
        if not path or not os.path.exists(path):
            return False
        try:
            import ctypes
            from ctypes import wintypes

            class SHELLEXECUTEINFOW(ctypes.Structure):
                _fields_ = [
                    ("cbSize", wintypes.DWORD),
                    ("fMask", ctypes.c_ulong),
                    ("hwnd", wintypes.HWND),
                    ("lpVerb", wintypes.LPCWSTR),
                    ("lpFile", wintypes.LPCWSTR),
                    ("lpParameters", wintypes.LPCWSTR),
                    ("lpDirectory", wintypes.LPCWSTR),
                    ("nShow", ctypes.c_int),
                    ("hInstApp", wintypes.HINSTANCE),
                    ("lpIDList", ctypes.c_void_p),
                    ("lpClass", wintypes.LPCWSTR),
                    ("hkeyClass", wintypes.HKEY),
                    ("dwHotKey", wintypes.DWORD),
                    ("hIcon", wintypes.HANDLE),
                    ("hProcess", wintypes.HANDLE),
                ]

            SEE_MASK_INVOKEIDLIST = 0x0000000C
            sei = SHELLEXECUTEINFOW()
            sei.cbSize = ctypes.sizeof(sei)
            sei.fMask = SEE_MASK_INVOKEIDLIST
            sei.hwnd = hwnd
            sei.lpVerb = "properties"
            sei.lpFile = path
            sei.nShow = 1
            return bool(ctypes.windll.shell32.ShellExecuteExW(ctypes.byref(sei)))
        except Exception as exc:
            logging.debug("Windows-Eigenschaften Fehler: %s", exc)
            return False

    def _entry_properties_dialog(self, target, anchor_x=None, anchor_y=None, fokus_name: bool = False):
        entry = next((e for e in self.cfg.data.get("entries", []) if e.get("target") == target), None)
        if not entry:
            return

        dlg = tk.Toplevel(self.root)
        custom = self._entry_custom(entry)
        name = self._entry_name(entry)
        original = entry.get("name") or entry.get("target") or "?"

        # Layout: hell, Sektionen mit Erklaerung
        BG = "#d4d0c8"
        FG = "#000000"
        FG_ERK = "#505050"   # Erklaerungen
        FG_NAME = "#008000"  # Angezeigter Name (Produktgruen)
        FONT = ("Tahoma", 9)
        FONT_FETT = ("Tahoma", 9, "bold")

        dlg.title(f"Eigenschaften: {name}")
        dlg.configure(bg=BG)
        dlg.resizable(False, False)
        dlg.attributes("-topmost", True)
        dlg.transient(self.root)
        dlg.grab_set()

        rahmen = tk.Frame(dlg, bg="#404040", padx=1, pady=1)
        rahmen.pack(fill="both", expand=True, padx=8, pady=8)
        innen = tk.Frame(rahmen, bg=BG, padx=12, pady=10)
        innen.pack(fill="both", expand=True)

        # Inhalt scrollbar + Fusszeile fest: auf kleinen Bildschirmen
        # (z. B. 1366x768) ragte der Dialog unten aus dem Bild — Buttons
        # unerreichbar (Nutzer 11.10.2026, Kundenfoto vom 8.1-PC).
        fuss = tk.Frame(innen, bg=BG)
        fuss.pack(side="bottom", fill="x", pady=(10, 0))
        canvas = tk.Canvas(innen, bg=BG, highlightthickness=0, borderwidth=0)
        scroll = tk.Scrollbar(innen, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        canvas.pack(side="top", fill="both", expand=True)
        _inhalt = tk.Frame(canvas, bg=BG)
        canvas.create_window(0, 0, window=_inhalt, anchor="nw", tags="inhalt")
        _inhalt.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure("inhalt", width=e.width))
        innen = _inhalt  # alle folgenden Inhalte landen im Scroll-Frame

        def _sektion(text):
            tk.Label(innen, text=text, font=FONT_FETT, bg=BG, fg=FG,
                     anchor="w").pack(fill="x", pady=(0, 2))

        def _erklaerung(text):
            tk.Label(innen, text=text, font=FONT, bg=BG, fg=FG_ERK, anchor="w",
                     wraplength=380, justify="left").pack(fill="x", pady=(0, 4))

        # --- Angezeigter Name ---
        _sektion("Angezeigter Name")
        _erklaerung("Dieser Name steht unter dem Symbol in der Leiste. Leer lassen = Originalname.")
        name_var = tk.StringVar(value=name)
        name_entry = tk.Entry(
            innen, textvariable=name_var, font=FONT_FETT, fg=FG_NAME,
            insertbackground=FG_NAME, width=42, exportselection=True,
        )
        name_entry.pack(fill="x", pady=(0, 4))
        ui_clipboard.entry_clipboard_bind(name_entry)
        orig_grid = tk.Frame(innen, bg=BG)
        orig_grid.pack(fill="x", pady=(0, 4))
        tk.Label(
            orig_grid, text="Originalname:", font=FONT, bg=BG, fg=FG, width=14, anchor="w",
        ).grid(row=0, column=0, sticky="w")
        original_var = tk.StringVar(value=str(entry.get("name") or original))
        # Originalname nur anzeigen, nicht editierbar — grau hinterlegt,
        # sonst „aendert sich nichts = kaputt"-Anrufe (Nutzer 03.10.2026).
        original_entry = tk.Entry(
            orig_grid, textvariable=original_var, font=FONT, width=32,
            exportselection=True, state="readonly",
            readonlybackground="#e8e8e8",
        )
        original_entry.grid(row=0, column=1, sticky="ew", padx=(4, 0))
        orig_grid.columnconfigure(1, weight=1)
        ui_clipboard.entry_clipboard_bind(original_entry)
        tk.Label(
            innen,
            text="Original bleibt im Steckbrief; Tooltip zeigt ihn, wenn der Anzeigename abweicht.",
            font=FONT, bg=BG, fg=FG_ERK, anchor="w", wraplength=380, justify="left",
        ).pack(fill="x", pady=(0, 10))

        # --- Beschriftung ---
        _sektion("Beschriftung")
        _erklaerung("Häkchen = Name unter dem Symbol zeigen. Kein Häkchen = nur das Symbol.")
        show_var = tk.BooleanVar(value=self._entry_show_label(entry))
        tk.Checkbutton(
            innen, text="Name unter dem Symbol anzeigen", variable=show_var,
            font=FONT, bg=BG, fg=FG, anchor="w", activebackground=BG, selectcolor="white",
        ).pack(fill="x", pady=(0, 2))
        if not self.show_labels:
            tk.Label(
                innen,
                text="Hinweis: Im Griff-Menü ist „Namen ausblenden“ aktiv — einzelne Namen "
                "erscheinen erst, wenn das wieder aus ist.",
                font=FONT, bg=BG, fg=FG_ERK, anchor="w", wraplength=380, justify="left",
            ).pack(fill="x", pady=(0, 6))
        else:
            tk.Frame(innen, bg=BG, height=4).pack()

        # --- Verhalten beim Klick ---
        _sektion("Programmstart")
        _erklaerung(
            "Läuft das Ziel schon, entscheidet diese Einstellung.\n"
            "An = kein Dialog „läuft bereits“, Programm startet direkt.\n"
            "Aus = Fenster anzeigen / Abbrechen / Nochmal öffnen."
        )
        restart_var = tk.BooleanVar(value=bool(custom.get("always_restart", False)))
        tk.Checkbutton(
            innen, text="Immer neu starten", variable=restart_var,
            font=FONT, bg=BG, fg=FG, anchor="w", activebackground=BG, selectcolor="white",
        ).pack(fill="x", pady=(0, 10))

        # --- Details ---
        _sektion("Details")
        info_grid = tk.Frame(innen, bg=BG)
        info_grid.pack(fill="x", pady=(0, 4))
        ziel_roh = str(entry.get("target") or "")
        detail_zeilen = [
            ("Typ", entry_hilfe.entry_typ_label(ziel_roh)),
            ("Gruppe", entry_hilfe.entry_gruppe(entry)),
            ("Ziel", self._entry_display_target(entry)),
        ]
        icon_pfad = entry_hilfe.entry_icon_pfad(ziel_roh, entry)
        if icon_pfad:
            detail_zeilen.append(("Icon", icon_pfad))
        detail_zeilen.append(("Quelle", entry_hilfe.entry_quelle_anzeige(entry)))
        eid = str(entry.get("id") or "").strip()
        if eid:
            detail_zeilen.append(("ID", eid))
        for row, (label, wert) in enumerate(detail_zeilen):
            tk.Label(
                info_grid, text=f"{label}:", font=FONT, bg=BG, fg=FG, anchor="nw", width=10,
            ).grid(row=row, column=0, sticky="nw", pady=1)
            tk.Label(
                info_grid, text=str(wert), font=FONT, bg=BG, fg=FG, anchor="nw",
                justify="left", wraplength=300,
            ).grid(row=row, column=1, sticky="nw", pady=1)

        windows_pfad = self._entry_windows_properties_pfad(entry)
        if windows_pfad:
            tk.Frame(innen, bg="#808080", height=1).pack(fill="x", pady=(10, 8))
            _sektion("Windows-Original")
            tk.Label(
                innen,
                text="Achtung: Das ist Windows selbst — nicht xlounger. Änderungen "
                "(Symbol, Freigabe, Sicherheit) gelten für die echte Datei auf dem PC.",
                font=FONT, bg=BG, fg="#b00000", anchor="w", wraplength=380, justify="left",
            ).pack(fill="x", pady=(0, 8))

            def _windows_oeffnen(wp=windows_pfad) -> None:
                from tkinter import messagebox

                if not self._open_windows_properties(wp):
                    messagebox.showwarning(
                        "Windows-Eigenschaften",
                        "Windows konnte die Eigenschaften nicht öffnen.\n"
                        f"Pfad: {wp}",
                        parent=dlg,
                    )

            tk.Button(
                innen, text="Windows-Eigenschaften öffnen …", font=FONT, command=_windows_oeffnen,
            ).pack(fill="x", anchor="w", pady=(0, 4))

        # Systemdatei-Warnung (Schutzfunktion, bleibt)
        if self._is_system_file(target):
            tk.Label(innen, text="⚠ Systemdatei — Änderungen mit Vorsicht",
                     font=FONT, bg=BG, fg="#b00000", anchor="w").pack(fill="x", pady=(4, 0))

        def _save():
            from tkinter import messagebox

            cid = entry.get("id")
            if not cid:
                return
            neuer_original = original_var.get().strip()
            if not neuer_original:
                messagebox.showwarning(
                    "Eigenschaften",
                    "Originalname darf nicht leer sein.",
                    parent=dlg,
                )
                return
            entry["name"] = neuer_original
            user = self.cfg.data.setdefault("user_customizations", {})
            custom = user.setdefault(cid, {})
            new_name = name_var.get().strip()
            if new_name and new_name != neuer_original:
                custom["name"] = new_name
            else:
                custom.pop("name", None)
            name_unter_symbol = bool(show_var.get())
            custom["show_labels"] = name_unter_symbol
            custom["always_restart"] = restart_var.get()
            if not name_unter_symbol:
                self.show_labels = False
                self.anzeige_modus = "symbole"
                self._nur_text = False
                self.cfg.data["bar"]["show_labels"] = False
                self.cfg.data["bar"]["anzeige_modus"] = "symbole"
                self._fonts_aktualisieren()
                self.dock_thickness = self._calc_dock_thickness()
                self._horizontal_platzbudget_w = None
                self._vertical_platzbudget_h = None
            self._cfg_save()
            self._block_configure_relayout(0.9)
            self._rebuild_entries()
            if self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:
                self._dock_to(
                    self.docked,
                    platzbudget_w=None,
                    platzbudget_h=None,
                )
            else:
                self._float(platzbudget_w=None, platzbudget_h=None)
            dlg.destroy()

        def _cancel():
            dlg.destroy()

        btn_row = tk.Frame(fuss, bg=BG)
        btn_row.pack(fill="x", pady=(12, 0))
        tk.Button(btn_row, text="Speichern", font=FONT, width=10,
                  command=_save, default=tk.ACTIVE).pack(side=tk.LEFT)
        tk.Button(btn_row, text="Verwerfen", font=FONT, width=10,
                  command=_cancel).pack(side=tk.LEFT, padx=(6, 0))

        tk.Label(
            fuss, text="Änderungen wirken sofort und bleiben nach Neustart erhalten.",
            font=FONT, bg=BG, fg=FG_ERK, anchor="w",
        ).pack(fill="x", pady=(10, 0))

        dlg.bind("<Return>", lambda e: _save())
        dlg.bind("<Escape>", lambda e: _cancel())

        # Dialog-Position: neben die Leiste, egal wo sie dockt (KVA 185,
        # dock-abhaengig seit 28.09.2026 — vorher „unter" der Leiste, was bei
        # senkrechter Leiste am Bildschirmrand unsinnig klemmte).
        dlg.update_idletasks()
        _inhalt.update_idletasks()
        fuss.update_idletasks()
        # Hoehe auf den Arbeitsbereich begrenzen — sonst ragt der Dialog
        # auf kleinen Bildschirmen unten raus und der Fuss ist weg.
        work_t = layout._work_tuple(getattr(self, "monitor", None))
        max_dh = max(320, (work_t[3] - work_t[1]) - 40)
        chrom = fuss.winfo_reqheight() + 42  # Fuss + Rahmen/Padding
        brauch_scroll = (_inhalt.winfo_reqheight() + chrom) > max_dh
        canvas.configure(
            width=_inhalt.winfo_reqwidth(),
            height=min(_inhalt.winfo_reqheight(), max(160, max_dh - chrom)),
        )
        if not brauch_scroll:
            scroll.pack_forget()
        else:
            def _rad(e, c=canvas):
                c.yview_scroll(int(-e.delta / 120), "units")

            def _rad_an(e):
                canvas.bind_all("<MouseWheel>", _rad)

            def _rad_aus(e):
                canvas.unbind_all("<MouseWheel>")

            for w in (canvas, _inhalt):
                w.bind("<Enter>", _rad_an)
                w.bind("<Leave>", _rad_aus)
            dlg.bind("<Destroy>", lambda e: canvas.unbind_all("<MouseWheel>"))

        dlg.update_idletasks()
        dw = dlg.winfo_reqwidth()
        dh = dlg.winfo_reqheight()
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        # Bei offenem >>-Feld zaehlt dessen Lage: Dialog auf die freie Seite
        # des Feldes, nicht unter die Leiste/das Feld (Nutzer 11.10.2026:
        # „Abstand von Eigenschaften zum Ueberlauffenster sinnvoll").
        feld_rect = None
        feld = getattr(self, "_ueberlauf_feld", None)
        if feld is not None:
            try:
                if feld.winfo_exists():
                    feld_rect = (
                        feld.winfo_rootx(), feld.winfo_rooty(),
                        feld.winfo_width(), feld.winfo_height(),
                    )
            except tk.TclError:
                feld_rect = None
        if feld_rect is not None:
            x, y = layout.dialog_neben_feld(
                *feld_rect, dw, dh, sw, sh, anchor_y=anchor_y,
            )
            # ... aber nie in den von der Leiste belegten Bereich rutschen.
            wx, wy, wr, wb = layout._work_tuple(getattr(self, "monitor", None))
            x = min(max(x, wx + 4), max(wx + 4, wr - dw - 4))
            y = min(max(y, wy + 4), max(wy + 4, wb - dh - 4))
        else:
            # Mittig im freien Arbeitsbereich: monitor.work enthaelt die
            # Leiste nicht — nie am Rand, nie ueber der Leiste, egal wo sie
            # dockt (Nutzer 11.10.2026: „immer am Rand, nicht gesteuert
            # nach Lage der Leiste, so nicht benutzbar").
            x, y = layout.dialog_zentriert_arbeitsbereich(
                layout._work_tuple(getattr(self, "monitor", None)), dw, dh,
            )
        logging.info(
            "Eigenschaften-Dialog position=%dx%d%+d%+d feld=%s work=%s",
            dw, dh, x, y, feld_rect,
            layout._work_tuple(getattr(self, "monitor", None)),
        )
        # Erst verbergen, dann positionieren: geometry() auf das schon
        # gemappte transient-Fenster wird hier verworfen — der Dialog
        # blieb real bei (0,0) obwohl +x+y gesetzt war (Nutzer 11.10.2026,
        # Muster wie laeuft_dialog._zentrieren).
        dlg.withdraw()
        dlg.update_idletasks()
        dlg.geometry(f"{dw}x{dh}+{x}+{y}")
        dlg.deiconify()
        # Nicht unter die Leiste rutschen (beide topmost): Dialog nach vorn heben
        dlg.lift(self.root)
        dlg.after(80, lambda: dlg.lift(self.root))

        if fokus_name:
            # „Umbenennen" aus dem Kontextmenue: Cursor direkt ins Namensfeld,
            # vorhandener Text markiert — tippen ersetzt ihn sofort.
            # Verzoegert: focus_set vor dem Fenster-Mapping geht verloren.
            def _fokus_name_setzen():
                try:
                    # focus_force: greift auch, wenn die Leiste (overrideredirect)
                    # gerade nicht den Windows-Eingabefokus hat.
                    name_entry.focus_force()
                    name_entry.select_range(0, tk.END)
                except tk.TclError:
                    pass

            dlg.after(60, _fokus_name_setzen)

    def _anheften_panel_oeffnen(self):
        from .. import katalog

        katalog.vorgewaermen_starten()
        inst = getattr(self, "_katalog_panel", None)
        if inst is None:
            inst = katalog_panel.KatalogPanel(self)
            self._katalog_panel = inst
        inst.oeffnen()

    def _icon_abheften(
        self,
        target,
        x_root: int,
        y_root: int,
        *,
        von_ueberlauf: bool = False,
    ):
        """Von der Leiste abziehen: Pin weg. Loslassen auf Desktop = Symbol **hier**.

        Verknüpfung existiert schon → nicht zweimal anlegen, Symbol an Wunschplatz
        schieben und kurz erklären (auch wenn es nur in » war).
        """
        pfad, war_schon_da, abgebrochen = self._desktop_verknuepfung_sicherstellen(target)
        if abgebrochen:
            logging.info("Abheften abgebrochen (Nutzer): %s", target)
            return
        self._remove_entry(target, sanft=True)
        if pfad is None:
            self._show_drop_hint(
                "Von der Leiste entfernt — Desktop-Verknüpfung konnte nicht angelegt werden"
            )
            logging.warning("Abheften: Eintrag weg, Desktop fehlgeschlagen: %s", target)
            return
        stem = Path(pfad).stem
        desktop_icons.item_aktualisieren(pfad)
        desktop_icons.ansicht_aktualisieren()
        self.root.after(200, lambda: self._desktop_icon_platzieren(pfad, x_root, y_root))
        if war_schon_da:
            self._show_drop_hint(
                f"{stem}: Liegt schon auf dem Desktop — keine zweite Verknüpfung. "
                "Nur von der Leiste entfernt, Symbol an diese Stelle verschoben."
            )
        else:
            self._show_drop_hint(
                f"{stem}: Verknüpfung neu auf dem Desktop — Symbol am Loslass-Punkt."
            )
        logging.info(
            "Eintrag per Drag abgeheftet: %s (Desktop %s, neu=%s)",
            target,
            pfad,
            not war_schon_da,
        )

    def _desktop_icon_platzieren(self, pfad: str, x_root: int, y_root: int, versuch: int = 0):
        """Desktop-Symbol an die Stelle ziehen, wo der Nutzer losgelassen hat."""
        name = Path(pfad).stem
        pos = desktop_icons.pos_von_drop(x_root, y_root)
        if desktop_icons.setzen({name: pos}) > 0:
            return
        if versuch < 7:
            self.root.after(400, lambda: self._desktop_icon_platzieren(pfad, x_root, y_root, versuch + 1))
