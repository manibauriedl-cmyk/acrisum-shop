"""Widget-Aufbau — Kopf, Eintrags-Knoepfe, Fuss, Neuaufbau, Eintrags-Anzeige (Name/Label/Tooltip)."""
import logging
import os
import tkinter as tk
from pathlib import Path
from .. import icons
from ..install_pfad import INSTALL_ROOT
from .. import layout
from .. import tooltip
from .. import masse
from .. import entry_hilfe


class AufbauMixin:
    def _build_header(self):
        # Header ist jetzt kein eigener Streifen mehr,
        # sondern ein unsichtbarer Container (0px) — Grip/Title/Add
        # werden als erste/letzte Elemente in die Body-Reihe gepackt.
        self.header = tk.Frame(self.frame, bg=self.bg_color, height=0)
        self.header.pack(side=tk.TOP)

        # Grip + Title + Add werden spaeter in _populate_entries eingebaut
        self.grip = None
        self.grip_sep = None
        self._grip_img = None
        self.preview_badge = None
        self.title_label = None
        self.add_btn = None

    def _build_entries(self):
        self.body = tk.Frame(self.frame, bg=self.bg_color, padx=0, pady=0)
        self.body.pack(fill=tk.BOTH, expand=True)
        self._populate_entries()

    @staticmethod
    def _build_version() -> str:
        """Kurze Menue-Zeile — nur Produktversion und ggf. „Entwicklung“."""
        from src.install_pfad import ist_entwicklung
        from src.version import get_version_menuzeile

        return get_version_menuzeile(entwicklung=ist_entwicklung())

    def _build_footer(self):
        # Kein separater Footer — spart Platz. Tooltip am Grip reicht.
        self.footer = tk.Frame(self.frame, bg=self.bg_color, height=0)
        self.footer.pack(side=tk.BOTTOM)

    def _populate_entries(self):
        # Echte Slot-Hoehe merken, BEVOR die Buttons zerstoert werden —
        # die Schaetzung (_estimate_entry_heights) liegt deutlich ueber der
        # Realitaet. Populate-Split und »-Abgleich kamen sonst zu
        # verschiedenen Ergebnissen -> Endlos-Rebuild im Sekundentakt
        # (Nutzer 28.09.2026: „einmal durchrechnen reicht").
        try:
            echte = self._measure_button_heights()
            if echte:
                schnitt = int(round(sum(echte) / len(echte)))
                if schnitt > 4 and schnitt != self._entry_hoehe_schnitt:
                    self._entry_hoehe_schnitt = schnitt
                    bar_cfg = self.cfg.data.get("bar", {})
                    if bar_cfg.get("slot_hoehe_px") != schnitt:
                        bar_cfg["slot_hoehe_px"] = schnitt
                        self._cfg_save()
        except Exception:
            pass
        # Quer dasselbe wie oben bei der Hoehe: echte Button-Breiten sichern,
        # BEVOR die Widgets zerstoert werden — sonst splittet der Rebuild
        # wieder auf Schaetzung (keep=15) waehrend der Abgleich misst (12)
        # und die Leiste oszilliert ohne je zu konvergieren (14.10.2026).
        try:
            self._breiten_vor_rebuild = self._measure_button_widths()
        except Exception:
            self._breiten_vor_rebuild = []
        tooltip.aktiven_ausblenden()
        self._ueberlauf_schliessen()
        for btn in list(self.buttons):
            btn.destroy()
        self.buttons.clear()
        # Alte inline-Header aufräumen
        if self.grip:
            try:
                self.grip.destroy()
            except Exception:
                pass
        if self.grip_sep:
            try:
                self.grip_sep.destroy()
            except Exception:
                pass
        if self.preview_badge:
            try:
                self.preview_badge.destroy()
            except Exception:
                pass
            self.preview_badge = None
        if self.add_btn:
            try:
                self.add_btn.destroy()
            except Exception:
                pass
        if self.title_label:
            try:
                self.title_label.destroy()
            except Exception:
                pass
        filler = getattr(self, "_body_filler", None)
        if filler is not None:
            try:
                filler.destroy()
            except Exception:
                pass
            self._body_filler = None

        entries = self.cfg.data.get("entries", [])
        grip_bg = self._grip_bg()
        vertical = self._leiste_ist_senkrecht()
        badge_text = self._preview_badge_text()
        if badge_text:
            leiste_bg = self._leiste_bg()
            self.preview_badge = tk.Label(
                self.body,
                text=badge_text,
                bg=leiste_bg,
                fg=self._leiste_fg(),
                font=self._label_font(horizontal=not vertical),
                anchor="center",
                borderwidth=0,
                highlightthickness=0,
                padx=2,
                pady=2,
                cursor="fleur",
            )
            self.preview_badge.pack(
                side=tk.TOP if vertical else tk.LEFT,
                fill=tk.X if vertical else tk.NONE,
                anchor=tk.N if vertical else tk.CENTER,
            )
            self._bind_drag_handle(self.preview_badge)
            self.preview_badge.bind(
                "<Enter>",
                lambda e, bg=leiste_bg: self.preview_badge.config(bg=self._leiste_hover_bg()),
            )
            self.preview_badge.bind(
                "<Leave>",
                lambda e, bg=leiste_bg: self.preview_badge.config(bg=bg),
            )

        self._griff_bild_bg = None
        grip_pad = 4 if not vertical else 0
        if not vertical and getattr(self, "_nur_text", False):
            grip_pad = 1
        self.grip = tk.Label(
            self.body,
            bg=grip_bg,
            cursor="fleur",
            borderwidth=0,
            highlightthickness=0,
            padx=grip_pad,
        )
        self._griff_bild_mit_hintergrund(grip_bg)
        self.grip.pack(
            side=tk.TOP if vertical else tk.LEFT,
            fill="x" if vertical else "none",
            anchor=tk.N if vertical else tk.CENTER,
        )
        hover_bg = self._leiste_hover_bg()
        self.grip.bind("<Enter>", self._griff_hover_enter)
        self.grip.bind("<Leave>", self._griff_hover_leave)
        self._bind_drag_handle(self.grip)

        self.grip_sep = tk.Frame(self.body, bg=grip_bg, width=1, highlightthickness=0, borderwidth=0)
        if vertical:
            self.grip_sep.configure(height=4)
            self.grip_sep.pack(side=tk.TOP, fill=tk.X, padx=0, pady=0)
            self._bind_drag_handle(self.grip_sep)
        else:
            self.grip_sep.configure(width=4)
            self.grip_sep.pack(side=tk.LEFT, fill=tk.NONE, padx=0, anchor=tk.CENTER)
            self._bind_drag_handle(self.grip_sep)

        self.title_label = tk.Label(
            self.body, text="", bg=self._leiste_bg(), fg=self._leiste_bg(), width=0,
        )

        # Anheften-Zelle: nur die Stecknadel als Button — das Label darunter
        # frass eine ganze Zeile Platz („diesen Platz braucht kein Mensch,
        # wenn nur Buttons", Nutzer 28.09.2026). Erklaerung bleibt im Tooltip.
        # Pin folgt der Icon-Groesse (dynamisch mit dem Zoom) — kein fixes
        # 31px-Minimum, das bei kleinem Zoom die Leisten-Hoehe aufblaeht
        # (Totraum unter den Icons, Nutzer 28.09.2026: „nur diese Hoehe").
        # Kleines Minimum 16, damit der Pin klickbar bleibt.
        if not vertical and getattr(self, "_nur_text", False):
            pin_px = max(10, int(round(self.icon_size * 0.55)))
        else:
            pin_px = max(16, int(round(self.icon_size * 1.33)))
        self._add_img = icons.icon_anheften(size=pin_px)
        add_pad = 1 if (not vertical and getattr(self, "_nur_text", False)) else 4
        self.add_btn = tk.Label(
            self.body,
            image=self._add_img,
            bg=grip_bg,
            cursor="hand2",
            padx=add_pad,
        )
        if vertical:
            # Senkrecht: direkt unter den Griff (6 Punkte) packen — nicht ans
            # Leistenende, dort sucht ihn niemand (Nutzer-Auftrag 28.09.2026).
            self.add_btn.pack(side=tk.TOP, fill=tk.X, padx=0, pady=0)
        else:
            self.add_btn.pack(
                side=tk.LEFT,
                fill="none",
                anchor=tk.CENTER,
                padx=0,
                pady=0,
            )
        self.add_btn.bind("<Enter>", lambda e: self.add_btn.config(bg=hover_bg))
        self.add_btn.bind("<Leave>", lambda e: self.add_btn.config(bg=grip_bg))
        self.add_btn.bind("<Button-1>", lambda e: self._anheften_panel_oeffnen())
        tooltip.Tooltip(
            self.add_btn,
            "Eintrag anheften — Katalog oeffnen",
            show_ms=1500,
            dock=self.docked,
            hilfe_text=(
                "Anheften\n\n"
                "Hier kommen eigene Eintraege auf die Leiste:\n"
                "Programme, Ordner, Dateien oder Internet-Links.\n\n"
                "Linksklick oeffnet den Katalog mit Vorschlaegen.\n"
                "Dateien koennen Sie auch direkt auf die Leiste ziehen."
            ),
        )

        visible, hidden = self._split_entries_for_display(entries)

        leiste_bg = self._leiste_bg()
        self.body.configure(bg=leiste_bg)

        # » steht IMMER da wenn Eintraege existieren — bei leerem Rest „»0".
        # Nutzer 04.10.2026: verschwindet der Knopf bei „alles sichtbar",
        # wirkt die Leiste kaputt; »0 sagt ehrlich „nichts versteckt".
        # Pack-Reihenfolge: » ZUERST (rechts/unten), dann Eintraege — Tk
        # verteilt Platz in Pack-Reihenfolge, so kann der Knopf bei einer
        # zu optimistischen Breiten-Schaetzung nie hinter die Fensterkante
        # rutschen (Nutzer 14.10.2026: letzter Eintrag + » am Schirmrand
        # abgeschnitten, Ueberlauf unerreichbar).
        overflow = None
        if visible or hidden:
            self._ueberlauf_liste = list(hidden)
            overflow = self._create_overflow_button(hidden)
            if vertical:
                overflow.pack(side=tk.BOTTOM, fill=tk.X, padx=0, pady=0)
            else:
                overflow.pack(side=tk.RIGHT, fill=tk.NONE, padx=0, pady=0)
            self.buttons.append(overflow)

        for entry in visible:
            btn = self._create_entry_button(entry)
            self._pack_slot(btn)
            self.buttons.append(btn)

        if visible or hidden:
            # »N klebt am Leistenende (senkrecht: unten, quer: rechts) —
            # der Füller schiebt ihn ran; Totraum hinter »N ist verboten.
            # Leiste breiter -> »N wandert mit dem Rand (Nutzer 07.10.2026).
            self._body_filler = tk.Frame(
                self.body, bg=leiste_bg, borderwidth=0, highlightthickness=0,
            )
            if vertical:
                self._body_filler.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
            else:
                self._body_filler.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
            # » steht an der Body-Kante, doch ein zu breiter letzter Eintrag
            # wird bis zur Frame-Kante geclippt und uebermalt den Knopf —
            # lift haelt ihn sichtbar+klickbar, egal wie der Split lag.
            try:
                overflow.lift()
            except tk.TclError:
                pass
            self._ueberlauf_liste_aktualisieren()
        elif vertical:
            self._body_filler = tk.Frame(
                self.body, bg=leiste_bg, borderwidth=0, highlightthickness=0,
            )
            self._body_filler.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        else:
            self._ueberlauf_liste = []

        if self.slot_limit is None and entries:
            self.root.after(1, self._ueberlauf_split_abgleichen)

    def _append_new_entries(self, new_entries):
        """Neue Eintraege ohne kompletten Neuaufbau hinzufuegen."""
        if not new_entries:
            return False
        entries = self.cfg.data.get("entries", [])
        visible, hidden = self._split_entries_for_display(entries)
        if hidden or any(self._ist_ueberlauf_knopf(b) for b in self.buttons):
            self._rebuild_entries()
            return True
        old_total = len(entries) - len(new_entries)
        needs_layout = False
        for i, entry in enumerate(new_entries):
            if old_total + i < len(visible):
                btn = self._create_entry_button(entry)
                self._pack_slot(btn)
                self.buttons.append(btn)
                needs_layout = True
            else:
                self._rebuild_entries()
                return True
        return needs_layout

    def _create_entry_button(self, entry):
        target = entry.get("target", "")
        running = self._running.get(target, False)
        photo = self._entry_icon_photo(entry, self.icon_size)
        show_label = self._entry_show_label(entry)
        horizontal = not self._leiste_ist_senkrecht()
        leiste_bg = self._leiste_bg()
        fg = self._leiste_fg()
        pad = max(1, int(round(2 * masse.zoom_factor(self.zoom_stufe))))
        if getattr(self, "_nur_text", False) and not self._leiste_ist_senkrecht():
            pad = 1
        text = self._entry_label_text(entry) if show_label else ""
        zellen_pady = 0 if (getattr(self, "_nur_text", False) and not self._leiste_ist_senkrecht()) else max(1, pad - 1)

        zelle = tk.Frame(
            self.body,
            bg=leiste_bg,
            cursor="hand2",
            padx=pad,
            pady=zellen_pady,
            highlightthickness=0,
            borderwidth=0,
            relief="flat",
        )
        zelle._xl_zelle = True
        zelle._xl_laeuft = running
        zelle._xl_img = photo

        icon_lbl = tk.Label(zelle, image=photo, bg=leiste_bg, cursor="hand2", borderwidth=0)
        icon_lbl.image = photo
        if not getattr(self, "_nur_text", False):
            icon_lbl.pack(anchor="center")

        text_lbl = tk.Label(
            zelle,
            text=text,
            bg=leiste_bg,
            fg=fg,
            font=self._label_font(horizontal=horizontal),
            cursor="hand2",
            anchor="center",
            borderwidth=0,
            padx=2,
        )
        if show_label and text:
            text_lbl.pack(anchor="center")

        d = max(5, round(photo.height() * 0.35))
        punkt = tk.Canvas(zelle, width=d, height=d, bg=leiste_bg, highlightthickness=0, borderwidth=0)
        punkt._xl_punkt = True
        nur_text_quer = getattr(self, "_nur_text", False) and not self._leiste_ist_senkrecht()
        punkt._xl_overlay = not nur_text_quer
        if nur_text_quer:
            # Nur Text: Punkt VOR dem Namen — place() wuerde ihn ueber die
            # Schrift legen und den ersten Buchstaben verdecken (08.10.2026).
            if text_lbl.winfo_manager():
                punkt.pack(side=tk.LEFT, before=text_lbl)
            else:
                punkt.pack(side=tk.LEFT)
        self._sync_running_dot(punkt, running=running, bg=leiste_bg)
        zelle._running_dot = punkt

        for w in (zelle, icon_lbl, text_lbl, punkt):
            # Nicht sofort starten: erst beim Loslassen Klick vs. Ziehen
            # unterscheiden — sonst geht das Programm schon beim Packen auf
            # und Rausziehen ist unmoeglich (Nutzer 24.09.2026).
            w.bind("<Button-1>", lambda e, t=target: self._icon_press(t, e))
            w.bind("<Button-3>", lambda e, t=target: self._show_entry_menu(e, t) or "break")

        self._symbol_hover_bind(zelle, normal_bg=leiste_bg)

        zelle._target = target
        tip = self._entry_tooltip_text(entry)
        # Beschreibung erst nach 3 s — sonst poppt sie beim Ueberfahren
        # staendig auf (Nutzer 09.10.2026, MS-Empfehlung fuer Rich-Tips
        # ~2 s; Nutzer-Wunsch 3 s).
        tooltip.Tooltip(zelle, tip, dock=self.docked, auch=(icon_lbl, text_lbl, punkt), show_ms=1500)
        return zelle

    def _entry_label_text(self, entry) -> str:
        """Leisten-Beschriftung kurz und lesbar."""
        # Nutzer-Name (Eigenschaften-Dialog) schlaegt Original (03.10.2026).
        lang = (
            self._entry_custom(entry).get("name") or entry.get("name") or ""
        ).strip()
        kurz = (entry.get("kurz") or self._entry_custom(entry).get("kurz") or "").strip()
        horizontal = not self._leiste_ist_senkrecht()
        return masse.lesbar_kurz(lang, kurz, mit_text=True, horizontal=horizontal)

    def _entry_icon_photo(self, entry: dict, size: int | None = None):
        target = entry.get("target", "")
        name = self._entry_name(entry)
        px = size if size is not None else self.icon_size
        # Helle Shell-Symbole (z. B. Netzwerkbruecke) verschwinden auf heller
        # Leiste — Kontrast gegen den eigenen Hintergrund sichern (28.09.2026).
        bg = self._leiste_bg()
        custom = self._entry_custom(entry)
        icon_path = custom.get("icon_path") or entry.get("icon_path") or (entry.get("launch") or {}).get("icon_path")
        if icon_path and os.path.exists(str(icon_path)):
            # IconIndex mitnehmen — „imageres.dll,20" wurde sonst zum
            # generischen DLL-Blatt statt zum gewaehlten Symbol.
            try:
                idx = int(
                    custom.get("icon_index")
                    or entry.get("icon_index")
                    or (entry.get("launch") or {}).get("icon_index")
                    or 0
                )
            except (TypeError, ValueError):
                idx = 0
            return icons.get_icon_index(str(icon_path), idx, name, px, sichtbar_auf=bg)
        return icons.get_icon(name, target, px, False, sichtbar_auf=bg)

    def _relayout(self):
        self._rebuild_entries()
        if self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:
            self._dock_to(self.docked)
        else:
            self._float()

    def _rebuild_entries(
        self,
        *,
        relayout_only: bool = False,
        ueberlauf_wieder: bool = True,
        fensterform_beibehalten: bool = False,
    ):
        war_offen = bool(ueberlauf_wieder and self._ueberlauf_feld_ist_offen())
        self._populate_entries()
        if relayout_only:
            self._arrange(self.orientation)
            if not fensterform_beibehalten:
                self._set_window_shape()
                self._sync_drop_overlay()
            if war_offen:
                try:
                    self.root.after(50, self._ueberlauf_nach_loeschen_neu_oeffnen)
                except tk.TclError:
                    pass
            return
        if self.docked == layout.DOCK_FREE:
            self._float(save=False)
        elif self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:
            self._dock_to(self.docked, save=False)
        else:
            self._set_window_shape()
        if war_offen:
            try:
                self.root.after(50, self._ueberlauf_nach_loeschen_neu_oeffnen)
            except tk.TclError:
                pass

    def _set_slot_limit(self, value):
        self.slot_limit = value
        self._horizontal_platzbudget_w = None
        self._vertical_platzbudget_h = None
        if value is None:
            self.cfg.data["bar"].pop("slots", None)
        else:
            self.cfg.data["bar"]["slots"] = int(value)
        self._cfg_save()
        self._rebuild_entries()
        if self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:
            self._dock_to(self.docked)
        else:
            self._float()

    def _entry_custom(self, entry):
        cid = entry.get("id", "")
        return self.cfg.data.get("user_customizations", {}).get(cid, {})

    def _entry_name(self, entry):
        custom = self._entry_custom(entry)
        roh = custom.get("name") or entry.get("name") or entry.get("target") or ""
        return entry_hilfe.name_lesbar_fuer_anzeige(
            str(roh),
            str(entry.get("target") or ""),
        )

    def _entry_display_target(self, entry):
        """Menschenlesbares Ziel fuer Anzeige (Tooltip, Eigenschaften).

        Bei .lnk: echtes Ziel + Argumente statt den .lnk-Pfad zeigen.
        """
        target = entry.get("target", "")
        if Path(target).suffix.lower() == ".lnk" and Path(target).exists():
            from ..launcher import resolve_lnk
            path, args = resolve_lnk(target)
            if path:
                # Explorer mit Ordner-Argument → nur den Ordner zeigen
                if os.path.basename(path).lower() == "explorer.exe" and args:
                    return args.strip()
                # Chrome/Edge App-URL → URL zeigen
                if args and "--app=" in args:
                    for part in args.split():
                        if part.startswith("--app="):
                            return part[6:]
                if args:
                    return f"{path} {args}"
                return path
        return target

    def _entry_show_label(self, entry):
        if getattr(self, "_nur_text", False):
            # „Nur Text"-Modus: Name immer zeigen — sonst waere der Eintrag leer.
            return True
        if not self.show_labels:
            return False
        custom = self._entry_custom(entry)
        if "show_labels" in custom:
            return bool(custom["show_labels"])
        return True

    def _entry_tooltip_text(self, entry) -> str:
        custom = self._entry_custom(entry)
        return entry_hilfe.entry_tooltip_text(
            entry,
            name=self._entry_name(entry),
            display_target=self._entry_display_target(entry),
            typ=entry_hilfe.entry_typ_label(entry.get("target", "")),
            always_restart=bool(custom.get("always_restart")),
        )

    def _eintraege_namen_reparieren(self) -> None:
        entries = self.cfg.data.get("entries")
        if not isinstance(entries, list):
            return
        n = entry_hilfe.entry_namen_in_liste_reparieren(entries)
        if n <= 0:
            return
        logging.info("Eintrags-Namen in config bereinigt: %s", n)
        self._cfg_save()
