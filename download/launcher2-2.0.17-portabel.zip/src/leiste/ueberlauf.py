"""Ueberlauf » — Knopf, Feld, Hover/Klick, Liste der versteckten Eintraege."""
import ctypes
import logging
import time
import tkinter as tk
from .konstanten import UEBERLAUF_CLOSE_MISS, UEBERLAUF_HIT_PAD, UEBERLAUF_HOVER_MISS_MAX, UEBERLAUF_HOVER_POLL_MS, UEBERLAUF_LINGER_MS, UEBERLAUF_WATCH_MS
from .. import icons
from .. import layout
from ..appbar import (
    AppBar,
)
from .. import tooltip
from .. import masse


class UeberlaufMixin:
    def _init_ueberlauf_zustand(self) -> None:
        """Zustand dieses Moduls — aus Bar.__init__."""
        self._ueberlauf_feld = None
        self._ueberlauf_feld_bilder: list = []
        self._ueberlauf_knopf = None
        self._ueberlauf_watch_id = None
        self._ueberlauf_feld_anker = None
        self._ueberlauf_feld_knoepfe = []
        self._ueberlauf_btn = None
        self._ueberlauf_liste: list = []
        self._ueberlauf_hover_seit = 0.0
        self._ueberlauf_hover_miss = 0
        self._ueberlauf_hover_poll_job = None
        self._split_abgleich_serie = 0
        self._split_abgleich_zuletzt: tuple[int, bool] | None = None

    @staticmethod
    def _ist_ueberlauf_knopf(btn: tk.Widget) -> bool:
        return bool(getattr(btn, "_xl_ueberlauf", False))

    def _nach_start_leiste_sync(self) -> None:
        """Leiste nach erstem Dock: »-Zahl + Slots — Breite/Hoehe nicht einklappen."""
        try:
            # Einmal durchrechnen (Nutzer 28.09.2026): stimmt der Stand schon,
            # wird nicht noch einmal gebaut — frueher lief hier blind ein
            # kompletter Rebuild aller Buttons mit identischem Ergebnis.
            if self._split_und_hoehe_stimmen():
                return
            self._rebuild_entries(relayout_only=True)
            self._apply_leisten_pack_richtung()
            if self.docked in layout.DOCK_VERTICAL:
                self._vertical_leiste_inhalt_hoehe()
            else:
                self._leiste_fenster_leerstreifen_sync()
        except tk.TclError:
            pass

    def _finde_ueberlauf_knopf(self) -> tk.Widget | None:
        btn = getattr(self, "_ueberlauf_btn", None)
        try:
            if btn is not None and btn.winfo_exists():
                return btn
        except tk.TclError:
            pass
        for b in reversed(self.buttons):
            if not self._ist_ueberlauf_knopf(b):
                continue
            try:
                if b.winfo_exists():
                    self._ueberlauf_btn = b
                    return b
            except tk.TclError:
                continue
        self._ueberlauf_btn = None
        return None

    def _pointer_auf_ueberlauf_knopf(self, knopf: tk.Widget | None = None) -> bool:
        """Treffer per Bildschirm-Rechteck (Tk winfo_containing scheitert oft auf AppBar)."""
        knopf = knopf or self._finde_ueberlauf_knopf()
        if knopf is None:
            return False
        try:
            knopf.update_idletasks()
            px, py = self.root.winfo_pointerxy()
            bx, by = int(knopf.winfo_rootx()), int(knopf.winfo_rooty())
            bw = max(int(knopf.winfo_width()), int(knopf.winfo_reqwidth()), 8)
            bh = max(int(knopf.winfo_height()), int(knopf.winfo_reqheight()), 8)
            pad = UEBERLAUF_HIT_PAD
            return (
                bx - pad <= px <= bx + bw + pad
                and by - pad <= py <= by + bh + pad
            )
        except tk.TclError:
            return False

    def _ueberlauf_knopf_hover_an(self, knopf: tk.Widget | None = None) -> None:
        tooltip.aktiven_ausblenden()
        knopf = knopf or self._finde_ueberlauf_knopf()
        if knopf is None:
            return
        try:
            knopf.configure(bg=self._leiste_hover_bg())
        except tk.TclError:
            pass

    def _ueberlauf_knopf_hover_aus(self, knopf: tk.Widget | None = None) -> None:
        if self._ueberlauf_feld_ist_offen():
            return
        knopf = knopf or self._finde_ueberlauf_knopf()
        if knopf is None:
            return
        try:
            knopf.configure(bg=self._leiste_bg())
        except tk.TclError:
            pass

    def _ueberlauf_feld_ist_offen(self) -> bool:
        feld = self._ueberlauf_feld
        if feld is None:
            return False
        try:
            return bool(feld.winfo_exists() and feld.winfo_viewable())
        except tk.TclError:
            return False

    def _ueberlauf_hover_poll(self) -> None:
        """Poll: Maus auf » → Linger; kein harter Reset bei einem verpassten Tick."""
        self._ueberlauf_hover_poll_job = None
        try:
            knopf = self._finde_ueberlauf_knopf()
            auf_knopf = (
                knopf is not None
                and not self._maus_links_unten()
                and self._icon_drag_state is None
                and self._pointer_auf_ueberlauf_knopf(knopf)
            )
            if auf_knopf and not self._ueberlauf_feld_ist_offen():
                self._ueberlauf_hover_miss = 0
                self._ueberlauf_knopf_hover_an(knopf)
                hid = self._ueberlauf_liste_aktualisieren()
                if hid:
                    seit = float(getattr(self, "_ueberlauf_hover_seit", 0.0) or 0.0)
                    jetzt = time.time()
                    if seit <= 0.0:
                        self._ueberlauf_hover_seit = jetzt
                        logging.info("Ueberlauf-Hover: Maus auf » (Linger startet)")
                    elif jetzt - seit >= UEBERLAUF_LINGER_MS / 1000.0:
                        self._ueberlauf_hover_seit = 0.0
                        self._ueberlauf_aufklappen(knopf)
            elif not self._ueberlauf_feld_ist_offen():
                miss = int(getattr(self, "_ueberlauf_hover_miss", 0)) + 1
                self._ueberlauf_hover_miss = miss
                if miss >= UEBERLAUF_HOVER_MISS_MAX:
                    self._ueberlauf_hover_seit = 0.0
                    self._ueberlauf_hover_miss = 0
                    self._ueberlauf_knopf_hover_aus(knopf)
            self._ueberlauf_hover_poll_job = self.root.after(
                UEBERLAUF_HOVER_POLL_MS, self._ueberlauf_hover_poll
            )
        except tk.TclError:
            self._ueberlauf_hover_seit = 0.0
            self._ueberlauf_hover_miss = 0

    def _ueberlauf_hidden_from_bar(self, entries: list) -> list:
        """Rest = gleiche Logik wie beim Aufbau (_split_entries_for_display)."""
        if not entries:
            return []
        _vis, hid = self._split_entries_for_display(entries)
        return list(hid)

    def _ueberlauf_liste_aktualisieren(self) -> list:
        """Zahl am » = len(Rest); Quelle: Leiste, nicht Monitor-Vollbreite."""
        entries = self.cfg.data.get("entries", [])
        knopf = self._finde_ueberlauf_knopf()
        if knopf is not None:
            hid = self._ueberlauf_hidden_from_bar(entries)
        else:
            _vis, hid = self._split_entries_for_display(entries)
            hid = list(hid)
        self._ueberlauf_liste = list(hid)
        if knopf is not None:
            n = len(self._ueberlauf_liste)
            try:
                # »0 steht da, wenn nichts versteckt ist — Knopf verschwindet nie.
                knopf.configure(text=f"\u00bb{n}")
            except tk.TclError:
                pass
            knopf._overflow_hidden = self._ueberlauf_liste
        return self._ueberlauf_liste

    def _ueberlauf_aufklappen(self, knopf: tk.Widget | None = None) -> bool:
        """Klick oder Hover — ein Pfad."""
        self._ueberlauf_hover_timer_stop(knopf)
        self._icon_drag_abbrechen()
        knopf = knopf or self._finde_ueberlauf_knopf()
        if knopf is None:
            return False
        if self._ueberlauf_feld_ist_offen():
            self._ueberlauf_schliessen()
            return True
        hid = self._ueberlauf_liste_aktualisieren()
        if not hid:
            # »0 ist Normalzustand — kurzer Hinweis statt Warnung.
            try:
                self._show_drop_hint("Nichts versteckt — alles sichtbar.")
            except Exception:
                pass
            return False
        logging.info("Ueberlauf-Aufklappen: %d Eintraege", len(hid))
        self._ueberlauf_oeffnen(knopf, hid)
        return True

    def _ueberlauf_klick_direkt(self) -> None:
        """Linker Klick auf » — Liste der versteckten Eintraege auf/zu.

        Frueher fuellte der Klick die Leiste bis Fensterende — im „Alle“-
        Modus passiert das beim Andocken automatisch, der Klick wirkte
        daher tot (Nutzer 03.10.2026). Jetzt wie Rechtsklick: Liste.
        """
        self._ueberlauf_hover_zuruecksetzen()
        self._icon_drag_abbrechen()
        if self._ueberlauf_feld is not None:
            self._ueberlauf_schliessen()
            return
        knopf = self._finde_ueberlauf_knopf()
        if knopf is None:
            return
        hid = self._ueberlauf_liste_aktualisieren()
        if hid:
            self._ueberlauf_oeffnen(knopf, hid)
        else:
            # »0: ehrlich sagen statt stumm nichts tun (Nutzer 04.10.2026).
            try:
                self._show_drop_hint("Nichts versteckt — alles sichtbar.")
            except Exception:
                pass

    def _create_overflow_button(self, hidden):
        leiste_bg = self._leiste_bg()
        n = len(hidden)
        horizontal = not self._leiste_ist_senkrecht()
        overflow = tk.Button(
            self.body,
            text=f"\u00bb{n}",
            command=self._ueberlauf_klick_direkt,
            bg=leiste_bg,
            fg=self._leiste_fg(),
            activebackground=self._leiste_hover_bg(),
            activeforeground=self._leiste_fg(),
            font=self._label_font(horizontal=self.orientation != "vertical"),
            relief=tk.FLAT,
            padx=0 if horizontal else 3,
            pady=0 if horizontal else 2,
            cursor="hand2",
            borderwidth=0,
            highlightthickness=0,
        )
        overflow._xl_ueberlauf = True
        overflow._hover_id = None
        overflow._hover_leave_job = None

        def _enter(_e):
            lj = getattr(overflow, "_hover_leave_job", None)
            if lj:
                try:
                    self.root.after_cancel(lj)
                except tk.TclError:
                    pass
                overflow._hover_leave_job = None
            self._ueberlauf_knopf_hover_an(overflow)
            if self._ueberlauf_hover_seit <= 0.0:
                self._ueberlauf_hover_seit = time.time()
            self._ueberlauf_hover_miss = 0
            self._ueberlauf_hover_planen(overflow)

        def _leave(_e):
            def _pruefen() -> None:
                overflow._hover_leave_job = None
                if self._pointer_auf_ueberlauf_knopf(overflow):
                    return
                self._ueberlauf_hover_zuruecksetzen(overflow)

            lj = getattr(overflow, "_hover_leave_job", None)
            if lj:
                try:
                    self.root.after_cancel(lj)
                except tk.TclError:
                    pass
            overflow._hover_leave_job = self.root.after(100, _pruefen)

        overflow.bind("<Enter>", _enter, add="+")
        overflow.bind("<Leave>", _leave, add="+")
        overflow.bind(
            "<Button-3>",
            lambda e, h=list(hidden): self._ueberlauf_toggle(overflow, h),
        )
        overflow._overflow_hidden = list(hidden)
        self._ueberlauf_btn = overflow
        # Kein Hover-Tooltip am » — Liste kommt per Draufhalten, Klick = breiter (sonst klebt Text).
        return overflow

    def _ueberlauf_leiste_maximal_fuellen(self) -> None:
        """»-Klick: Platzbudget erweitern, maximal viele Icons, Rest »N."""
        self._icon_drag_abbrechen()
        self._ueberlauf_schliessen()
        if self.slot_limit is not None:
            self.slot_limit = None
            self.cfg.data["bar"].pop("slots", None)
            self._cfg_save()
        entries = self.cfg.data.get("entries", [])
        _vis, hid = self._split_entries_for_display(entries)
        if not hid:
            return
        self._leiste_breite_auf_max_setzen()
        self._split_avail_override = self._max_split_available()
        try:
            if self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:
                self._dock_to(self.docked)
            elif self.docked == layout.DOCK_FREE:
                self._float()
            else:
                self._rebuild_entries()
        finally:
            self._split_avail_override = None

    def _ueberlauf_breite_nachpass(self) -> bool:
        """Alle-Modus: freie Monitorbreite/-hoehe nutzen bevor >>-Liste aufgeht."""
        if self.slot_limit is not None:
            return False
        entries = self.cfg.data.get("entries", [])
        _vis, hid = self._split_entries_for_display(entries)
        if not hid:
            return False
        self._split_avail_override = self._max_split_available()
        try:
            if self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:
                self._dock_to(self.docked)
            else:
                self._float()
        finally:
            self._split_avail_override = None
        _vis2, hid2 = self._split_entries_for_display(entries)
        return len(hid2) < len(hid)

    def _ueberlauf_hidden_fuer(self, widget=None) -> list:
        return self._ueberlauf_liste_aktualisieren()

    def _ueberlauf_liste_jetzt(self, widget) -> None:
        hid = self._ueberlauf_liste_aktualisieren()
        if not hid:
            return
        self._ueberlauf_oeffnen(widget, hid)

    def _ueberlauf_hover_timer_stop(self, widget=None) -> None:
        w = widget or getattr(self, "_ueberlauf_knopf", None) or self._finde_ueberlauf_knopf()
        if w is None:
            return
        hid = getattr(w, "_hover_id", None)
        if not hid:
            return
        try:
            self.root.after_cancel(hid)
        except tk.TclError:
            pass
        w._hover_id = None

    def _ueberlauf_hover_zuruecksetzen(self, widget=None) -> None:
        self._ueberlauf_hover_seit = 0.0
        self._ueberlauf_hover_miss = 0
        self._ueberlauf_hover_timer_stop(widget)
        self._ueberlauf_knopf_hover_aus(widget)

    def _ueberlauf_hover_planen(self, widget) -> None:
        """Enter-Backup: Timer ohne Linger-Zeit zu loeschen (war 2/50-Erfolg)."""
        self._ueberlauf_hover_timer_stop(widget)
        if self._ueberlauf_feld is not None:
            self._ueberlauf_outside_miss = 0
            return
        widget._hover_id = self.root.after(
            UEBERLAUF_LINGER_MS,
            lambda w=widget: self._ueberlauf_hover_oeffnen(w),
        )

    def _ueberlauf_hover_oeffnen(self, widget) -> None:
        widget._hover_id = None
        if self._ueberlauf_feld is not None or self._icon_drag_state is not None:
            return
        try:
            if not widget.winfo_exists():
                return
        except tk.TclError:
            return
        self._ueberlauf_aufklappen(widget)

    def _ueberlauf_klick_liste(self, widget, hidden):
        """Ein Klick »: Liste sofort (ohne vorher Leiste/Slots umzubauen)."""
        self._ueberlauf_hover_timer_stop(widget)
        self._icon_drag_abbrechen()
        if self._ueberlauf_feld is not None:
            self._ueberlauf_schliessen()
            return "break"
        self._ueberlauf_liste_jetzt(widget)
        return "break"

    def _ueberlauf_klick_erweitern(self, widget, hidden):
        """Doppelklick »: Slot-Stufe hoch oder Alle, dann ggf. Liste."""
        self._icon_drag_abbrechen()
        self._ueberlauf_schliessen()
        if self.slot_limit is not None:
            neu = self._naechste_slot_stufe(self.slot_limit)
            if neu is not None and neu != self.slot_limit:
                self._set_slot_limit(neu)
            else:
                self._set_slot_limit(None)
            entries = self.cfg.data.get("entries", [])
            _vis, hid = self._split_entries_for_display(entries)
            if not hid:
                return "break"
        if self._ueberlauf_breite_nachpass():
            return "break"
        entries = self.cfg.data.get("entries", [])
        _vis, hid = self._split_entries_for_display(entries)
        if not hid:
            return "break"
        return self._ueberlauf_oeffnen(widget, hid)

    def _ueberlauf_split_abgleichen(self) -> None:
        """»-Knopf/Zahl an echte Fensterbreite/-hoehe — nach Pack korrigieren."""
        if self.slot_limit is not None:
            return
        if self.orientation == "vertical" or self.docked in layout.DOCK_VERTICAL:
            self._vertical_leiste_inhalt_hoehe()
        if getattr(self, "_icon_drag_state", None) is not None:
            return
        entries = self.cfg.data.get("entries", [])
        if not entries:
            return
        vis, hid = self._split_entries_for_display(entries)
        hat_knopf = self._finde_ueberlauf_knopf() is not None
        sichtbar = [b for b in self.buttons if not self._ist_ueberlauf_knopf(b)]
        # Der Knopf steht immer da (»0) — uneinig, wenn MEHR Eintraege
        # gepackt sind als der gemessene Split erlaubt: der letzte wird
        # abgeschnitten und uebermalt » (14.10.2026). Nie wegen „zu wenig"
        # rebuilden — die Schaetzung des naechsten Eintrags ist zu
        # optimistisch, Schrumpfen-und-Wachsen sonst Ping-Pong (12<->13)
        # ohne Konvergenz. »N sagt den Rest ehrlich.
        uneinig = (
            bool(vis or hid) != hat_knopf or len(sichtbar) > len(vis)
        )
        if uneinig:
            zustand = (len(vis), len(hid), hat_knopf, len(sichtbar))
            if zustand == self._split_abgleich_zuletzt:
                self._split_abgleich_serie += 1
            else:
                self._split_abgleich_serie = 0
            self._split_abgleich_zuletzt = zustand
            if self._split_abgleich_serie >= 2:
                # Derselbe Widerspruch zum dritten Mal in Folge — das ist
                # strukturell (Schaetzung/Messung), kein Pack-Fehler. Nicht
                # endlos weiter rebuilden (Loop im Sekundentakt, 28.09.2026).
                return
            self._rebuild_entries(relayout_only=True)
            return
        self._split_abgleich_serie = 0
        self._split_abgleich_zuletzt = None
        self._ueberlauf_liste_aktualisieren()
        if self.orientation == "vertical" or self.docked in layout.DOCK_VERTICAL:
            return

    def _ueberlauf_schliessen(self):
        """»-Icon-Feld schliessen (KVA 70–74)."""
        self._ueberlauf_hover_timer_stop()
        _st = self._icon_drag_state
        if _st is None or not _st.get("dragging"):
            # Kein laufender Zug: aufräumen wie bisher. Läuft ein Drag aus
            # dem »-Feld, darf das Schliessen den Zug NICHT abbrechen —
            # sonst geht das Loslassen auf der Leiste verloren (25.09.2026).
            self._icon_drag_abbrechen()
        feld = self._ueberlauf_feld
        if feld is None:
            return
        self._ueberlauf_feld = None
        self._ueberlauf_knopf = None
        self._ueberlauf_feld_anker = None
        self._ueberlauf_hit_rect = None
        self._ueberlauf_outside_miss = 0
        self._ueberlauf_feld_knoepfe = []
        tooltip.aktiven_ausblenden()
        watch_id = getattr(self, "_ueberlauf_watch_id", None)
        if watch_id:
            try:
                self.root.after_cancel(watch_id)
            except tk.TclError:
                pass
            self._ueberlauf_watch_id = None
        try:
            feld.destroy()
        except tk.TclError:
            pass
        self._ueberlauf_feld_bilder.clear()

    def _ueberlauf_ersteinweisung(self, parent: tk.Widget, bg: str, feld: tk.Toplevel) -> None:
        """Einmalig beim ersten »-Fenster — danach nur noch die kurze Zeile oben."""
        bar = self.cfg.data.setdefault("bar", {})
        if bar.get("ueberlauf_hinweis_ok"):
            return
        dunkel = self._bar_luminance() < 0.45
        box_bg = "#3d5a80" if dunkel else "#dce6f0"
        box_fg = "#f5f5f5" if dunkel else "#1a1a1a"
        box = tk.Frame(parent, bg=box_bg, padx=10, pady=8)
        box.pack(fill=tk.X, padx=4, pady=(4, 2))
        tk.Label(
            box,
            text=(
                "So geht’s mit den weiteren Symbolen:\n"
                "Linksklick — Programm starten\n"
                "Ziehen — auf die Leiste legen oder auf den Desktop\n"
                "Rechtsklick — Menü (Entfernen, Eigenschaften …)"
            ),
            bg=box_bg,
            fg=box_fg,
            font=("Segoe UI", 9),
            justify=tk.LEFT,
            anchor="w",
        ).pack(fill=tk.X)

        def _hinweis_ok() -> None:
            bar["ueberlauf_hinweis_ok"] = True
            self._cfg_save()
            try:
                box.destroy()
                feld.update_idletasks()
            except tk.TclError:
                pass

        tk.Button(
            box,
            text="Alles klar",
            command=_hinweis_ok,
            bg="#d4d0c8",
            fg="black",
            activebackground="#0a246a",
            activeforeground="white",
            font=("Segoe UI", 9),
            relief=tk.RAISED,
            padx=12,
            pady=2,
            cursor="hand2",
        ).pack(anchor=tk.E, pady=(8, 0))

    def _ueberlauf_toggle(self, widget, hidden):
        if self._ueberlauf_feld is not None:
            self._ueberlauf_schliessen()
            return "break"
        return self._ueberlauf_oeffnen(widget, hidden)

    def _ueberlauf_oeffnen(self, widget, hidden):
        """»-Feld oeffnen (Klick/Hover)."""
        tooltip.aktiven_ausblenden()
        self._icon_drag_abbrechen()
        self._dismiss_context_menus()
        if not hidden:
            logging.warning("Ueberlauf-oeffnen: hidden leer")
            return "break"
        if self._ueberlauf_feld is not None:
            return "break"
        try:
            if not widget.winfo_exists():
                return "break"
        except tk.TclError:
            return "break"

        rest = list(hidden)
        logging.info("Ueberlauf-Feld oeffnet: %d Symbole", len(rest))
        bg = self._leiste_bg()
        fg = self._leiste_fg()
        horizontal = self._ist_horizontal()
        pad = max(1, int(round(2 * masse.zoom_factor(self.zoom_stufe))))

        feld = tk.Toplevel(self.root)
        feld.withdraw()
        feld.overrideredirect(True)
        try:
            feld.attributes("-topmost", True)
        except tk.TclError:
            pass
        feld.configure(bg=bg)
        rahmen = tk.Frame(feld, bg=bg, highlightbackground="#8a8a8a", highlightthickness=1)
        rahmen.pack(fill="both", expand=True)
        self._ueberlauf_ersteinweisung(rahmen, bg, feld)
        hint_fg = "#c8c8c8" if self._bar_luminance() < 0.45 else "#444444"
        tk.Label(
            rahmen,
            text="Linksklick = starten · Ziehen = an Leiste oder Desktop · Rechtsklick = Menü",
            bg=bg,
            fg=hint_fg,
            font=("Segoe UI", 8),
            anchor="w",
            padx=8,
        ).pack(fill=tk.X, pady=(6, 2))
        raster = tk.Frame(rahmen, bg=bg)
        raster.pack(padx=5, pady=(0, 5))

        spalten = max(1, min(8, int(len(rest) ** 0.5 + 0.999)))
        knoepfe: list[tuple[tk.Button, dict]] = []
        for i, entry in enumerate(rest):
            target = entry.get("target", "")
            show_label = self._entry_show_label(entry)
            text = self._entry_label_text(entry) if show_label else ""
            try:
                photo = self._entry_icon_photo(entry, self.icon_size)
            except Exception:
                photo = icons.get_icon("?", "", self.icon_size, False)
            self._ueberlauf_feld_bilder.append(photo)
            btn = tk.Frame(
                raster,
                bg=bg,
                cursor="hand2",
                padx=pad,
                pady=max(1, pad - 1),
                highlightthickness=0,
                borderwidth=0,
                relief="flat",
            )
            btn._xl_zelle = True
            btn._target = target
            btn._xl_img = photo
            icon_lbl = tk.Label(btn, image=photo, bg=bg, cursor="hand2", borderwidth=0)
            icon_lbl.image = photo
            icon_lbl.pack(anchor="center")
            if text:
                tk.Label(
                    btn,
                    text=text,
                    bg=bg,
                    fg=fg,
                    font=self._label_font(horizontal=horizontal),
                    cursor="hand2",
                    anchor="center",
                    borderwidth=0,
                    padx=2,
                ).pack(anchor="center")

            # Lauf-Punkt wie in den Leisten-Zellen — der »-Ueberlauf zeigte
            # bisher gar keinen Status (Nutzer 09.10.2026). Stand = Moment
            # des Oeffnens; das Feld lebt ohnehin nur kurz.
            d = max(5, round(photo.height() * 0.35))
            punkt = tk.Canvas(
                btn, width=d, height=d, bg=bg,
                highlightthickness=0, borderwidth=0, cursor="hand2",
            )
            punkt._xl_punkt = True
            punkt._xl_overlay = True
            self._sync_running_dot(
                punkt,
                running=bool(self._running.get(target)),
                bg=bg,
            )
            btn._running_dot = punkt

            def _menu(ev, t=target):
                xr, yr = int(ev.x_root), int(ev.y_root)
                # Erst nach Release posten — sonst frisst TrackPopupMenu das
                # WM_RBUTTONUP und das Menue blitzt nur auf (Griff-Muster).
                self.root.after(
                    60,
                    lambda: self._show_entry_menu_at(xr, yr, t, im_ueberlauf=True),
                )
                return "break"

            for w in (btn, icon_lbl) + tuple(btn.winfo_children()):
                w.bind("<Button-1>", lambda ev, t=target: self._icon_press(t, ev))
                w.bind("<Button-3>", _menu)
            tip = self._entry_tooltip_text(entry)
            tooltip.Tooltip(btn, tip, dock=self.docked, auch=(icon_lbl,), show_ms=1500)
            btn.grid(row=i // spalten, column=i % spalten, padx=2, pady=2, sticky="nsew")
            knoepfe.append((btn, entry))

        feld.update_idletasks()
        fb = feld.winfo_reqwidth()
        fh = feld.winfo_reqheight()
        try:
            kx = widget.winfo_rootx()
            ky = widget.winfo_rooty()
            kb = widget.winfo_width()
            kh = widget.winfo_height()
        except tk.TclError:
            feld.destroy()
            return "break"

        ml, mt, mr, mb = layout._work_tuple(self.monitor)
        if horizontal:
            x = (kx + kb) - fb
            y = ky + kh
            if x < ml:
                x = ml
            if x + fb > mr:
                x = max(ml, mr - fb)
            if y + fh > mb:
                y = max(mt, ky - fh)
        else:
            x = kx + kb
            y = ky
            if x + fb > mr:
                x = max(ml, kx - fb)
            if y + fh > mb:
                y = max(mt, mb - fh)

        feld.geometry(f"{fb}x{fh}+{x}+{y}")
        feld.deiconify()
        feld.lift()
        try:
            _u32 = ctypes.windll.user32
            hwnd_bar = AppBar.toplevel_hwnd(self.root.winfo_id())
            _u32.SetForegroundWindow(hwnd_bar)
        except Exception:
            pass
        def _maus_im_bereich(_e=None) -> None:
            self._ueberlauf_outside_miss = 0

        feld.bind("<Enter>", _maus_im_bereich)
        rahmen.bind("<Enter>", _maus_im_bereich)
        feld.bind("<Escape>", lambda _e: self._ueberlauf_schliessen())
        self._ueberlauf_feld = feld
        self._ueberlauf_knopf = widget
        self._ueberlauf_feld_anker = (kx - 8, ky - 8, kx + kb + 8, ky + kh + 8)
        self._ueberlauf_hit_rect = None
        self._ueberlauf_outside_miss = 0
        self._ueberlauf_feld_knoepfe = knoepfe
        # Echte Icons nachladen — beim Bau stehen erst ?-Platzhalter drin
        # (fehlte seit Frame-Umbau, Nutzer 25.09.2026: „symbole nix richtig").
        self.root.after(0, lambda: self._ueberlauf_icons_nachladen(0))
        self._ueberlauf_watch_start(UEBERLAUF_WATCH_MS)
        return "break"

    def _ueberlauf_watch_start(self, delay_ms: int = 400):
        self._ueberlauf_watch_id = self.root.after(delay_ms, self._ueberlauf_watch)

    def _ueberlauf_feld_maus_im_bereich(self, px: int, py: int) -> bool:
        """Nur Kästchen + »-Knopf (schmal) — kein riesiger Hit-Schlauch."""
        m = 4

        def _in_rect(x1: int, y1: int, x2: int, y2: int, pad: int) -> bool:
            return (x1 - pad) <= px <= (x2 + pad) and (y1 - pad) <= py <= (y2 + pad)

        feld = self._ueberlauf_feld
        if feld is not None:
            try:
                fx = feld.winfo_rootx()
                fy = feld.winfo_rooty()
                fw = max(1, feld.winfo_width())
                fh = max(1, feld.winfo_height())
                if _in_rect(fx, fy, fx + fw, fy + fh, m):
                    return True
            except tk.TclError:
                pass
        knopf = getattr(self, "_ueberlauf_knopf", None)
        if knopf is not None:
            try:
                kx = knopf.winfo_rootx()
                ky = knopf.winfo_rooty()
                kw = max(1, knopf.winfo_width())
                kh = max(1, knopf.winfo_height())
                if _in_rect(kx, ky, kx + kw, ky + kh, UEBERLAUF_HIT_PAD):
                    return True
            except tk.TclError:
                pass
        return False

    def _ueberlauf_watch(self):
        feld = self._ueberlauf_feld
        if feld is None:
            self._ueberlauf_watch_id = None
            return
        try:
            if not feld.winfo_exists():
                self._ueberlauf_schliessen()
                return
            px, py = self.root.winfo_pointerxy()
        except tk.TclError:
            self._ueberlauf_schliessen()
            return
        if self._icon_drag_state is not None:
            self._ueberlauf_watch_start(200)
            return
        # Nicht schliessen, waehrend das Kontextmenue des Feldes modal laeuft
        # oder ein modaler Dialog (Eigenschaften etc.) den Grab haelt — die
        # Maus steht dann zwangslaeufig ausserhalb der Hitbox (Nutzer
        # 11.10.2026: „Eigenschaften nicht aufrufbar, Feld geht sofort zu").
        try:
            grab_offen = self.root.grab_current() is not None
        except tk.TclError:
            grab_offen = False
        if getattr(self, "_ueberlauf_menue_aktiv", False) or grab_offen:
            self._ueberlauf_outside_miss = 0
            self._ueberlauf_watch_start(UEBERLAUF_WATCH_MS)
            return
        if self._ueberlauf_feld_maus_im_bereich(px, py):
            self._ueberlauf_outside_miss = 0
            self._ueberlauf_watch_start(UEBERLAUF_WATCH_MS)
            return
        miss = int(getattr(self, "_ueberlauf_outside_miss", 0)) + 1
        self._ueberlauf_outside_miss = miss
        if miss >= UEBERLAUF_CLOSE_MISS:
            self._ueberlauf_schliessen()
        else:
            self._ueberlauf_watch_start(UEBERLAUF_WATCH_MS)

    def _ueberlauf_icons_nachladen(self, index: int = 0):
        knoepfe = getattr(self, "_ueberlauf_feld_knoepfe", None) or []
        if not knoepfe or self._ueberlauf_feld is None:
            return
        if index >= len(knoepfe):
            return
        btn, entry = knoepfe[index]
        try:
            if not btn.winfo_exists():
                return
            photo = self._entry_icon_photo(entry, self.icon_size)
            self._ueberlauf_feld_bilder.append(photo)
            btn._xl_img = photo
            for child in btn.winfo_children():
                if isinstance(child, tk.Label) and child.cget("image"):
                    child.configure(image=photo)
                    child.image = photo
        except tk.TclError:
            return
        except Exception as exc:
            logging.debug("Ueberlauf-Icon %s fehlgeschlagen: %s", index, exc)
        self.root.after(15, lambda i=index + 1: self._ueberlauf_icons_nachladen(i))

    def _ueberlauf_oeffnen_vom_menue(self, hidden):
        knopf = None
        for btn in self.buttons:
            if self._ist_ueberlauf_knopf(btn):
                knopf = btn
                break
        if knopf is None:
            knopf = self.grip or self.body
        self._ueberlauf_oeffnen(knopf, hidden)

    def _move_entry_to_front(self, target):
        entries = self.cfg.data.get("entries", [])
        for idx, entry in enumerate(entries):
            if entry.get("target") == target:
                entries.insert(0, entries.pop(idx))
                break
        self._cfg_save()
        self._relayout()

    def _move_entry_to_back(self, target):
        entries = self.cfg.data.get("entries", [])
        for idx, entry in enumerate(entries):
            if entry.get("target") == target:
                entries.append(entries.pop(idx))
                break
        self._cfg_save()
        self._relayout()

    def _move_entry_from_ueberlauf_to_front(self, target: str) -> None:
        """Symbol aus » an den Anfang der Leiste (sichtbar wenn Platz)."""
        self._move_entry_to_front(target)
        if self._ueberlauf_feld is not None:
            self.root.after(80, self._ueberlauf_nach_loeschen_neu_oeffnen)

    def _ueberlauf_nach_loeschen_neu_oeffnen(self):
        """»-Feld mit aktuellem Rest neu (Entfernen, 6 Slots, Heften, Drag …)."""
        entries = self.cfg.data.get("entries", [])
        _vis, hid = self._split_entries_for_display(entries)
        if not hid:
            return
        knopf = next(
            (b for b in self.buttons if self._ist_ueberlauf_knopf(b)),
            None,
        )
        if knopf is None:
            return
        try:
            if not knopf.winfo_exists():
                return
        except tk.TclError:
            return
        self._ueberlauf_oeffnen(knopf, hid)

    def _nach_groesse_ueberlauf_anpassen(self) -> None:
        self._configure_rebuild_job = None
        if self._drag_offset is not None or self.slot_limit is not None:
            return
        # Fensterbreite = Nutzer-Budget; darin max. Icons, »N — nicht schrumpfen (Zoom/»).
        self._rebuild_entries(relayout_only=True)
        self._apply_leisten_pack_richtung()
        self._leiste_fenster_leerstreifen_sync()
