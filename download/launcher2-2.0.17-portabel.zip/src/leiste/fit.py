"""Masse und Platz — Kapazitaet, Split sichtbar/versteckt, Messung (Regel: pixelgenau, winfo_*)."""
import logging
import time
import tkinter as tk
from .. import layout
from .. import masse


class FitMixin:
    def _init_fit_zustand(self) -> None:
        """Zustand dieses Moduls — aus Bar.__init__ (Platzbudget, Split, Slots aus der Config)."""
        self._configure_rebuild_job = None
        self._last_configure_wh: tuple[int, int] | None = None
        self._split_avail_override: int | None = None
        self._configure_relayout_block_until: float = 0.0
        bar_cfg = self.cfg.data["bar"]
        # Gemessene Slot-Hoehe (28.09.2026): die Schaetzung liegt ~60 % ueber
        # der Realitaet — Populate-Split und »-Abgleich stritten sich sonst
        # im Sekundentakt (Endlos-Rebuild). In Config, damit schon der
        # Start-Split mit echter Hoehe rechnet (einmal durchrechnen).
        try:
            _sh = int(bar_cfg.get("slot_hoehe_px") or 0)
        except (TypeError, ValueError):
            _sh = 0
        self._entry_hoehe_schnitt: int | None = _sh if _sh > 4 else None
        # Gezogene Leisten-Breite/-Hoehe aus der Config — ueberlebt den
        # Neustart (28.09.2026). Wird den Start-_dock_to-Aufrufen uebergeben,
        # damit die Bereinigung sie nicht als vermisst loescht.
        try:
            _bw = int(bar_cfg.get("platzbudget_w") or 0)
        except (TypeError, ValueError):
            _bw = 0
        try:
            _bh = int(bar_cfg.get("platzbudget_h") or 0)
        except (TypeError, ValueError):
            _bh = 0
        self._horizontal_platzbudget_w = _bw if _bw >= layout.MIN_CONTENT_LENGTH else None
        self._vertical_platzbudget_h = _bh if _bh >= layout.MIN_CONTENT_LENGTH else None
        # Gemerkte Quer-Breite — ueberlebt einen senkrechten Ausflug
        self._letzte_quer_breite = self._horizontal_platzbudget_w
        if "slots" in bar_cfg and bar_cfg["slots"] is not None:
            # 0 = nur Griff/+ (KVA 64); None/fehlend = alle (KVA 69)
            self.slot_limit = int(bar_cfg["slots"])
        else:
            self.slot_limit = None

    _SLOT_LIMITS = [None, 3, 5, 7, 12]

    def _truncate_label(self, text, max_px, font):
        """Beschriftung auf max_px Breite kuerzen mit Ellipsis."""
        if not text:
            return ""
        # Messen via temporaeres Label
        try:
            import tkinter.font as tkfont
            f = tkfont.Font(font=font)
            if f.measure(text) <= max_px:
                return text
            while len(text) > 1 and f.measure(text + "\u2026") > max_px:
                text = text[:-1]
            return text + "\u2026"
        except Exception:
            return text[:8] + "\u2026" if len(text) > 8 else text

    def _slot_width(self):
        base = masse.slot_step(self.icon_size)
        if self.orientation == "vertical" or self.docked in layout.DOCK_VERTICAL:
            try:
                inner = max(32, self.root.winfo_width() - 8)
                return min(base, inner)
            except tk.TclError:
                pass
        return base

    def _slot_height(self) -> int:
        pad = max(1, int(round(2 * masse.zoom_factor(self.zoom_stufe)))) * 2
        if getattr(self, "_nur_text", False):
            # „Nur Text": Zelle ist nur die Schriftzeile, kein Icon.
            return self._label_height() + (2 if self._leiste_ist_senkrecht() else 0)
        h = self.icon_size + pad + 3
        if self.show_labels:
            h += self._label_height() + 2
        return h

    def _preview_badge_text(self) -> str | None:
        """Schriftzug links auf der Leiste — abgeschaltet (Nutzer 08.10.2026:
        „will das nicht haben"). Kein Badge, kein Platzverbrauch."""
        return None

    def _leiste_ist_senkrecht(self) -> bool:
        live = getattr(self, "_drag_live_dock", None)
        if getattr(self, "_dragging", False) and live:
            # Waehrend des Zugs zaehlt die gezeigte Form: Zonen-Vorschau
            # packt fuer die ZIEL-Achse, frei fuer die gezogene Form — sonst
            # stapelt die Vorschau quer in einem senkrechten Fenster und »
            # haengt ausserhalb (Nutzer 06.10.2026: » fehlte).
            if live in layout.DOCK_VERTICAL:
                return True
            if layout.is_horizontal(live) or live in layout.DOCK_CORNER:
                return False
            if live == layout.DOCK_FREE:
                rect = getattr(self, "_drag_free_rect", None) or getattr(
                    self, "_drag_last_rect", None
                )
                if rect is not None:
                    return int(rect[3]) > int(rect[2])
        return getattr(self, "orientation", None) == "vertical" or getattr(
            self, "docked", None
        ) in layout.DOCK_VERTICAL

    def _apply_leisten_pack_richtung(self) -> None:
        """Horizontal: kein Quer-Stretch (sonst gruener Leerstreifen + falsches reqwidth)."""
        vertical = self._leiste_ist_senkrecht()
        if vertical:
            fill_o, fill_f, fill_b = tk.X, tk.X, tk.X
            side = tk.TOP
            exp = False
            outer_exp = False
            anker = tk.N
        else:
            # Quer: Breite mit Fenster, Hoehe = Inhalt, nicht BOTH
            # (sonst gruener Riesenstreifen). expand nur am outer, damit der
            # Streifen in der Leistenhoehe mittig sitzt (Nutzer 05.10.2026).
            fill_o, fill_f, fill_b = tk.X, tk.X, tk.X
            side = tk.TOP
            exp = False
            outer_exp = True
            anker = tk.CENTER
        try:
            self.outer.pack_configure(
                fill=fill_o, expand=outer_exp, side=side, anchor=anker
            )
            self.frame.pack_configure(fill=fill_f, expand=exp, side=side, anchor=anker)
            self.body.pack_configure(fill=fill_b, expand=exp, side=side, anchor=anker)
        except tk.TclError:
            pass

    def _gemessene_leisten_groesse(self) -> tuple[int, int]:
        """Summe (quer) bzw. Stapelhoehe (senkrecht) der Body-Kinder."""
        try:
            self.root.update_idletasks()
            vertical = (
                self.orientation == "vertical"
                or self.docked in layout.DOCK_VERTICAL
            )
            bw = 0
            bh = 0
            filler = getattr(self, "_body_filler", None)
            kinder = self.body.winfo_children()
            for w in kinder:
                # Quer: expand-Fueller fuellt nur Breite — winfo_reqheight()
                # folgt der Fensterhoehe und erzeugt falschen Totraum (64 px
                # Band bei 16 px Text, Nutzer 24.10.2026).
                if not vertical and w is filler:
                    continue
                rw = max(1, int(w.winfo_reqwidth()))
                rh = max(1, int(w.winfo_reqheight()))
                if vertical:
                    bw = max(bw, rw)
                    bh += rh
                else:
                    bw += rw
                    bh = max(bh, rh)
            extra = (
                3
                if not vertical and getattr(self, "_nur_text", False)
                else 8
            )
            return bw + extra, bh + extra
        except tk.TclError:
            return 0, 0

    def _leiste_fensterbreite_sync(self) -> None:
        self._leiste_fenster_leerstreifen_sync()

    def _leiste_fenster_leerstreifen_sync(self) -> None:
        """Leerstreifen entfernen (quer: zu breit oder zu hoch — z. B. alter Platzbudget).

        Auch bei fester Slot-Zahl (Nutzer 5): Totraum hinter » ist verboten.
        """
        # Frei ohne Slot-Fix: die Form reicht konstruktionsbedingt bis zum
        # Arbeitsbereich-Rand (Nutzer 07.10.2026 — „immer die Wahrheit zum
        # Rand"). Der Raum vor »N ist Verankerung, kein Totraum.
        # Mit Slot-Fixzahl bleibt das Eindampfen aktiv: „0/3/5/… Symbole"
        # heisst Leiste = Inhalt (Nutzer 07.10.2026 — Einstellung muss greifen).
        if self.docked == layout.DOCK_FREE and self.slot_limit is None:
            return
        try:
            self.root.update_idletasks()
            gem_w, gem_h = self._gemessene_leisten_groesse()
            aw = int(self.root.winfo_width())
            ah = int(self.root.winfo_height())
        except tk.TclError:
            return
        horizontal = layout.is_horizontal(self.docked)
        platzbudget_w = (
            int(self._horizontal_platzbudget_w)
            if horizontal and self._horizontal_platzbudget_w
            else None
        )
        platzbudget_h = (
            int(self._vertical_platzbudget_h)
            if self.docked in layout.DOCK_VERTICAL and self._vertical_platzbudget_h
            else None
        )
        schrumpfen = False
        if horizontal:
            # Totraum rechts vom Inhalt wird immer entfernt — das Platzbudget
            # schuetzt nur den »-Split, nicht die Fensterbreite (28.09.2026).
            if layout.leerstreifen_soll_schrumpfen(aw, gem_w):
                schrumpfen = True
            if layout.leerstreifen_soll_schrumpfen(ah, gem_h):
                schrumpfen = True
        elif self.docked in layout.DOCK_VERTICAL:
            return
        else:
            return
        if not schrumpfen:
            return
        try:
            x, y, w, h = self._bar_geometry()
            x, y, w, h = self._fit_window_to_content(
                x,
                y,
                w,
                h,
                breite_min=platzbudget_w,
                hoehe_min=platzbudget_h,
            )
            edge = layout.edge_for_dock(self.docked)
            if (
                edge is not None
                and self.appbar
                and self.cfg.data["bar"].get("desktop_platz", True)
                and self.docked != layout.DOCK_FREE
            ):
                echte_dicke = h if horizontal else w
                strip = layout.appbar_strip_rect(self.docked, self.monitor, echte_dicke)
                if strip:
                    x, y, w, h = self._fenster_an_shell_appbar(
                        edge, strip, x, y, w, h
                    )
            self.root.geometry(f"{w}x{h}+{x}+{y}")
            self._set_window_shape()
            self._sync_drop_overlay()
            self._block_configure_relayout(0.6)
            self._last_configure_wh = (int(w), int(h))
        except tk.TclError:
            pass

    def _pack_slot(self, widget) -> None:
        """Symbol-Zelle ohne Zwischenraum an die Reihe haengen."""
        vertical = self._leiste_ist_senkrecht()
        widget.pack(
            side=tk.TOP if vertical else tk.LEFT,
            padx=0,
            pady=0,
            # Quer: nicht in Y strecken — sonst Icons oben, Namen am Leistenrand unten.
            fill=tk.X if vertical else tk.NONE,
            anchor=tk.N if vertical else tk.CENTER,
        )

    def _bar_geometry(self) -> tuple[int, int, int, int]:
        try:
            return (
                self.root.winfo_x(),
                self.root.winfo_y(),
                self.root.winfo_width(),
                self.root.winfo_height(),
            )
        except tk.TclError:
            return (0, 0, self.float_w, self.dock_thickness + 8)

    def _horizontal_capacity(self) -> int:
        """KVA 31: Breite ab Leistenposition bis rechter Arbeitsflaechen-Rand."""
        x, _y, w, _h = self._bar_geometry()
        return layout.available_horizontal_span(self.monitor, x, w, self.docked)

    def _leiste_hoehe_max(self, y0: int | None = None) -> int:
        """Senkrecht: Platz ab Leisten-Y bis untere Arbeitsflaeche.

        EINZIGE Budget-Formel senkrecht (Nutzer 04.10.2026: „es darf keinen
        Zufall geben, welche Berechnungsgrundlage zugrunde liegt"). Wer den
        Split fuer eine GEPLANTE Position rechnet (Andocken), uebergibt y0 —
        alle anderen lesen das aktuelle Fenster. Ergebnis immer identisch.
        """
        _wl, wt, _wr, wb = layout._work_tuple(self.monitor)
        if y0 is None:
            try:
                y0 = int(self.root.winfo_y())
            except tk.TclError:
                y0 = int(wt)
        y0 = max(int(wt), int(y0))
        return max(60, int(wb) - y0 - layout.TASKLEISTE_LUFT_PX)

    def _leiste_platzbudget_erzwingen(
        self,
        x: int,
        y: int,
        w: int,
        h: int,
        dock: str,
        budget_w: int | None,
        budget_h: int | None,
    ) -> tuple[int, int, int, int]:
        if budget_w is not None and (
            layout.is_horizontal(dock) or dock == layout.DOCK_FREE
        ):
            # Nur das Budget fuer den »-Split merken — das Fenster NICHT auf
            # das Budget aufblaehen: es folgt dem Inhalt (Totraum-Fix
            # 28.09.2026, gleiches Muster wie senkrecht). Sonst steht rechts
            # vom »-Knopf ein leerer Streifen (UX).
            self._horizontal_platzbudget_w = int(budget_w)
        # Senkrecht kein Erzwingen mehr: das Fenster folgt dem Inhalt
        # (Totraum-Fix 28.09.2026) — ein Budget zog die Leiste sonst nach
        # jedem Zoom wieder laenger als ihr Inhalt.
        return x, y, w, h

    def _leiste_breite_max(self, x0: int | None = None) -> int:
        """Platz ab Leisten-X bis rechter Arbeitsflaechen-Rand (fremde Leisten).

        Quer-Budget und Live-Zug dieselbe Messung (Nutzer 05.10.2026).
        """
        wl, wt, wr, wb = layout._work_tuple(self.monitor)
        if x0 is None:
            try:
                x0 = int(self.root.winfo_x())
            except tk.TclError:
                x0 = int(wl)
        links = int(wl)
        rechts = int(wr)
        x0 = max(links, min(int(x0), rechts - 80))
        dock = self.docked
        if dock in layout.DOCK_CORNER and "right" in dock:
            return max(layout.MIN_CONTENT_LENGTH, rechts - links)
        if layout.is_horizontal(dock) or dock == layout.DOCK_FREE:
            return max(layout.MIN_CONTENT_LENGTH, rechts - x0)
        return max(layout.MIN_CONTENT_LENGTH, rechts - links)

    def _ueberlauf_knopf_breite_px(self, n_rest: int) -> int:
        n = max(1, int(n_rest))
        try:
            import tkinter.font as tkfont

            f = tkfont.Font(font=self._label_font(horizontal=True))
            return max(34, int(f.measure(f"\u00bb{n}")) + 10)
        except Exception:
            return 34

    def _ueberlauf_knopf_hoehe_px(self, n_rest: int) -> int:
        _n = max(1, int(n_rest))
        if not getattr(self, "show_labels", True):
            return max(26, int(self.icon_size) + 10)
        try:
            import tkinter.font as tkfont

            f = tkfont.Font(font=self._label_font(horizontal=False))
            return max(32, int(f.metrics("linespace")) + 14)
        except Exception:
            return 36

    def _fit_visible_horizontal(self, entries: list) -> tuple[list, list]:
        """So viele Eintraege wie in die aktuelle Breite passen — Rest »N.

        Messgrundlage wie senkrecht: echte Button-Breiten (winfo_reqwidth —
        Schrift, Ohren, Icon schon drin) zuerst; Schaetzung nur fuer Eintraege,
        die noch nie gepackt waren (bzw. wenn noch keine Messung existiert).
        """
        if not entries:
            return [], []
        verfuegbar = self._split_available_horizontal()
        kopf = self._header_width()
        measured_w = self._measure_button_widths()
        if not measured_w:
            # Direkt nach Populate stehen keine Widgets — Breiten wurden
            # vor dem Zerstoeren gesichert (Oszillation 15<->12, 14.10.2026).
            measured_w = list(getattr(self, "_breiten_vor_rebuild", []) or [])
        est = self._estimate_entry_widths(entries)
        if measured_w and len(measured_w) == len(entries):
            widths = measured_w
        elif measured_w and len(measured_w) < len(entries):
            widths = list(measured_w) + est[len(measured_w) :]
        else:
            widths = est
        keep = layout.fit_horizontal_visible_count(
            len(entries),
            verfuegbar,
            kopf,
            widths,
            self._ueberlauf_knopf_breite_px,
            immer_ueberlauf=True,
        )
        logging.info(
            "Split quer: verf=%s kopf=%s n=%d keep=%d summe=%d (gemessen=%d/%d ov=%s budget=%s)",
            verfuegbar, kopf, len(entries), keep, sum(widths),
            len(measured_w), len(entries),
            getattr(self, "_split_avail_override", None),
            getattr(self, "_horizontal_platzbudget_w", None),
        )
        n = len(entries)
        if keep >= n:
            return entries, []
        return entries[:keep], entries[keep:]

    def _leiste_breite_auf_max_setzen(self) -> None:
        """»-Klick: Fenster bis Bildschirmrand verbreitern (Budget fuer max. Icons)."""
        if not (
            layout.is_horizontal(self.docked) or self.docked == layout.DOCK_FREE
        ):
            return
        budget = self._leiste_breite_max()
        try:
            x, y, w, h = self._bar_geometry()
            if w >= budget - 2:
                return
            w = budget
            x, y, w, h = layout.clamp_bar_geometry(
                x, y, w, h, self.monitor, self.docked
            )
            self.root.geometry(f"{w}x{h}+{x}+{y}")
            self.root.update_idletasks()
            self._horizontal_platzbudget_w = int(w)
            self._block_configure_relayout()
        except tk.TclError:
            pass

    def _leiste_nach_drag_quer(self) -> None:
        """Nur noch manuell/Tests — nicht mehr 80 ms nach Griff-Loslassen.

        Der zweite Tick hat nach dem KVA-35-Commit nochmal Fit/Rebuild
        ausgeloest (Sprung). Parken 05.10.2026: ein Commit, dann still.
        """
        try:
            self._rebuild_entries(relayout_only=True)
            self._apply_leisten_pack_richtung()
            x, y, w, h = self._bar_geometry()
            self._fit_window_to_content(x, y, w, h)
        except tk.TclError:
            pass

    def _split_available_horizontal(self) -> int:
        """Icon-Budget in px: gezogenes Platzbudget, sonst Platz ab Leisten-X
        bis zum rechten Rand (Regel 36: „Alle Symbole" = so viele wie auf die
        Kante passen).

        Nicht die Fensterbreite — die folgt seit dem Totraum-Fix (28.09.2026)
        dem Inhalt. Mit winfo_width als Budget lief beim Start eine
        Abwaertsspirale (29.09.2026, gemessen): 10/0 -> Fenster auf Inhalt
        -> Abgleich 9/1 -> Fenster kleiner -> 8/2 ... mit einem Rebuild je
        Stufe. Senkrecht war das schon so geloest (_split_available_vertical).
        """
        ov = self._split_avail_override
        if ov is not None:
            return int(ov)
        if getattr(self, "docked", None) == layout.DOCK_FREE:
            if self.slot_limit is not None:
                # Slot-Modus: die Form ist das ERGEBNIS der Slotzahl,
                # kein Budget — sonst Ratsche Fenster->Split->Fenster.
                # Physische Wahrheit bleibt die Kante (Regel 37, K1).
                return self._leiste_breite_max()
            # Frei: die committete Ablage-Form ist die Wahrheit — was ueber
            # die Arbeitsflaeche ragt, bleibt trotzdem Inhalt (Abschnitt,
            # kein Umbau; Nutzer 06.10.2026: „darf nie kleiner werden").
            # Erst die persistierte Form (Start, Fenster noch nicht
            # gesetzt), dann das echte Fenstermass.
            try:
                form_w = int(
                    self.cfg.data["bar"].get("position", {}).get("w") or 0
                )
            except (AttributeError, TypeError, ValueError):
                form_w = 0
            if form_w > 1:
                return form_w
            try:
                ww = int(self.root.winfo_width())
            except tk.TclError:
                ww = 0
            if ww > 1:
                return ww
        if getattr(self, "_horizontal_platzbudget_w", None):
            return int(self._horizontal_platzbudget_w)
        return self._leiste_breite_max()

    def _split_available_vertical(self) -> int:
        """Icon-Budget in px: Platzbudget, sonst Platz ab Leisten-Y bis
        untere Arbeitsflaeche — symmetrisch zu _split_available_horizontal.

        Nicht die aktuelle Fensterhoehe — die ist seit dem Totraum-Fix
        (28.09.2026) nur so hoch wie der Inhalt. Sonst Henne-Ei: ein neuer
        Eintrag landete sofort in »1, obwohl die Kante Platz haette.
        Ohne Budget-Abfrage wurde die gezogene/Inventur-Hoehe ignoriert —
        die Leiste fuellte immer bis zur Kante (Nutzer 06.10.2026).
        """
        ov = self._split_avail_override
        if ov is not None:
            return int(ov)
        if getattr(self, "docked", None) == layout.DOCK_FREE:
            if self.slot_limit is not None:
                # Slot-Modus: Form = Ergebnis der Slotzahl, kein Budget
                # (symmetrisch zu _split_available_horizontal).
                return self._leiste_hoehe_max()
            # Frei: eigene Form — symmetrisch zu _split_available_horizontal.
            try:
                form_h = int(
                    self.cfg.data["bar"].get("position", {}).get("h") or 0
                )
            except (AttributeError, TypeError, ValueError):
                form_h = 0
            if form_h > 1:
                return form_h
            try:
                wh = int(self.root.winfo_height())
            except tk.TclError:
                wh = 0
            if wh > 1:
                return wh
        if getattr(self, "_vertical_platzbudget_h", None):
            return int(self._vertical_platzbudget_h)
        return self._leiste_hoehe_max()

    def _vertical_capacity(self) -> int:
        """KVA 37: Hoehe ab Leistenposition bis unterer Arbeitsflaechen-Rand."""
        _x, y, _w, h = self._bar_geometry()
        return layout.available_vertical_span(self.monitor, y, h, self.docked)

    def _footer_height_vertical(self) -> int:
        """Senkrecht: Fuss unter den Symbolen (Anheften sitzt seit 28.09.2026 oben)."""
        return 6

    def _header_height(self) -> int:
        vertical = self.orientation == "vertical" or self.docked in layout.DOCK_VERTICAL
        if vertical:
            h = 6
            if self.preview_badge:
                try:
                    self.root.update_idletasks()
                    h += int(self.preview_badge.winfo_reqheight()) + 2
                except tk.TclError:
                    pass
            if self.grip:
                try:
                    self.root.update_idletasks()
                    h += int(self.grip.winfo_reqheight()) + 2
                except tk.TclError:
                    pass
            if self.grip_sep:
                try:
                    h += int(self.grip_sep.winfo_reqheight()) + 2
                except tk.TclError:
                    pass
            if self.add_btn:
                # Anheften-Knopf gehoert zum Kopf (direkt unter dem Griff).
                try:
                    self.root.update_idletasks()
                    h += int(self.add_btn.winfo_reqheight()) + 2
                except tk.TclError:
                    h += 28
            return h
        h = 0
        if self.preview_badge:
            try:
                self.root.update_idletasks()
                h += int(self.preview_badge.winfo_reqheight()) + 2
            except tk.TclError:
                pass
        if self.grip and self.add_btn:
            try:
                self.root.update_idletasks()
                gh = int(self.grip.winfo_reqheight())
                ah = int(self.add_btn.winfo_reqheight())
                h = max(h, gh, ah) + 2
            except tk.TclError:
                h = max(h, 24)
        elif self.grip:
            try:
                self.root.update_idletasks()
                h = max(h, int(self.grip.winfo_reqheight()) + 2)
            except tk.TclError:
                pass
        return max(h, 12)

    def _estimate_entry_widths(self, entries: list) -> list[int]:
        """KVA 30: Breite pro Eintrag schaetzen (Beschriftung zaehlt mit)."""
        horizontal = self.orientation != "vertical" and self.docked not in layout.DOCK_VERTICAL
        font = self._label_font(horizontal=horizontal)
        pad = max(1, int(round(2 * masse.zoom_factor(self.zoom_stufe))))
        widths: list[int] = []
        for entry in entries:
            show_label = self._entry_show_label(entry)
            text = self._entry_label_text(entry) if show_label else ""
            tw = (int(font.measure(text)) + 4) if text else 0
            # „Nur Text": Zelle ist nur so breit wie der Text (kein Icon-Mindestmaß).
            basis = max(tw, 24) if getattr(self, "_nur_text", False) else max(self.icon_size, tw)
            widths.append(basis + pad * 2)
        return widths

    def _estimate_entry_heights(self, entries: list) -> list[int]:
        """KVA 38: Hoehe pro Eintrag schaetzen (senkrecht, Beschriftung mit)."""
        horizontal = self.orientation != "vertical" and self.docked not in layout.DOCK_VERTICAL
        font = self._label_font(horizontal=horizontal)
        pad = max(1, int(round(2 * masse.zoom_factor(self.zoom_stufe))))
        cell_w = max(24, self._thickness_for(self.docked) - pad * 4)
        heights: list[int] = []
        for entry in entries:
            show_label = self._entry_show_label(entry)
            text = self._entry_label_text(entry) if show_label else ""
            if getattr(self, "_nur_text", False):
                # „Nur Text": nur Zeilen, kein Icon (09.10.2026).
                lh = int(font.metrics("linespace")) + 4
                tw = int(font.measure(text)) + 4 if text else 0
                lines = max(1, (tw + cell_w - 1) // max(1, cell_w)) if text else 1
                heights.append(lines * lh + pad * 2)
                continue
            ih = self.icon_size + pad * 2
            dot = max(5, round(self.icon_size * 0.35))
            if show_label and text:
                lh = int(font.metrics("linespace")) + 4
                tw = int(font.measure(text)) + 4
                lines = max(1, (tw + cell_w - 1) // max(1, cell_w))
                text_h = lines * lh
                h = ih + text_h + pad + dot // 2
            else:
                h = ih + pad + dot // 2
            floor = layout.estimate_entry_height(
                self.icon_size, show_label and bool(text)
            )
            heights.append(max(h, floor))
        return heights

    def _planned_visible_hidden(self, entries: list) -> tuple[list, list]:
        """KVA 64–68: feste Slot-Grenze — unabhaengig von Fensterbreite."""
        if not entries:
            return [], []
        n = layout.visible_entry_count(len(entries), self.slot_limit)
        if n >= len(entries):
            return entries, []
        return entries[:n], entries[n:]

    def _slot_sichtbar_versteckt(self, entries: list) -> tuple[list, list]:
        """Slot-Fixzahl durch die feste Mess-Pipeline (Regel 37/38).

        Der Slot-Wert ist die Nutzer-Obergrenze UEBER dem gemessenen
        Platz-Fit — nicht daneben. Passen die N Slots physisch nicht bis
        zur Kante (Slider/Zoom!), wandert der Rest in »N — sonst clippt
        der Knopf unter die Fensterkante (Nutzer 07.10.2026: » fehlte
        nach Symbol-Zoom, slots=12 in 717px).
        """
        vis, hid = self._planned_visible_hidden(entries)
        if not vis:
            return vis, hid
        passt = self._slot_fit_messbar(entries)
        if passt is not None and passt < len(vis):
            return entries[:passt], entries[passt:]
        return vis, hid

    def _slot_fit_messbar(self, entries: list) -> int | None:
        """Gemessener Platz-Fit der Pipeline (E2/E3). None = nicht
        messbar (kein Fenster/Widgets) — dann gilt der Slot-Plan pur."""
        try:
            if self._leiste_ist_senkrecht():
                self.root.update_idletasks()
                header_est = self._header_height() + self._footer_height_vertical()
                avail = self._split_available_vertical()
                measured_h = self._measure_button_heights()
                est = self._estimate_entry_heights(entries)
                if self._entry_hoehe_schnitt:
                    est = [self._entry_hoehe_schnitt] * len(entries)
                if measured_h and len(measured_h) == len(entries):
                    heights = measured_h
                elif measured_h and len(measured_h) < len(entries):
                    heights = list(measured_h) + est[len(measured_h) :]
                else:
                    heights = est
                return layout.fit_vertical_visible_count(
                    len(entries),
                    avail,
                    header_est,
                    heights,
                    self._ueberlauf_knopf_hoehe_px,
                    immer_ueberlauf=True,
                )
            vis, _hid = self._fit_visible_horizontal(entries)
            return len(vis)
        except (tk.TclError, AttributeError, TypeError):
            return None

    def _split_entries_for_display(self, entries: list) -> tuple[list, list]:
        """Sichtbare Eintraege und >>-Ueberlauf (KVA 69: Breite; Slots: feste Grenze)."""
        if not entries:
            return [], []
        if self.slot_limit is not None:
            return self._slot_sichtbar_versteckt(entries)
        if self.grip and self.add_btn:
            try:
                self.root.update_idletasks()
            except tk.TclError:
                pass
        if self._leiste_ist_senkrecht():
            header_est = self._header_height() + self._footer_height_vertical()
            avail = self._split_available_vertical()
            measured_h = self._measure_button_heights()
            est = self._estimate_entry_heights(entries)
            if self._entry_hoehe_schnitt:
                # Gemessene Slot-Hoehe statt Schaetzung fuer unbekannte
                # Eintraege — sonst streiten Populate (Schaetzung) und
                # »-Abgleich (Messung) endlos (28.09.2026).
                est = [self._entry_hoehe_schnitt] * len(entries)
            if measured_h and len(measured_h) == len(entries):
                heights = measured_h
            elif measured_h and len(measured_h) < len(entries):
                heights = list(measured_h) + est[len(measured_h) :]
            else:
                heights = est
            visible_n = layout.fit_vertical_visible_count(
                len(entries),
                avail,
                header_est,
                heights,
                self._ueberlauf_knopf_hoehe_px,
                immer_ueberlauf=True,
            )
        else:
            return self._fit_visible_horizontal(entries)
        if visible_n >= len(entries):
            return entries, []
        return entries[:visible_n], entries[visible_n:]

    def _split_und_hoehe_stimmen(self) -> bool:
        """True wenn sichtbare Eintraege, »-Knopf und Fensterhoehe schon zum
        aktuellen Split passen — dann sind populate+fit ueberfluessig.

        Billige Vorabpruefung ohne Widget-Umbau (Nutzer 28.09.2026: „unendlich
        viel Berechnung" — populate lief beim Start 4x mit identischem
        Ergebnis, jedes Mal alle Buttons zerstoert und neu gebaut).
        """
        if self.slot_limit is not None:
            return False
        quer = layout.is_horizontal(self.docked)
        if not quer and self.docked not in layout.DOCK_VERTICAL:
            return False
        if getattr(self, "_vertical_platzbudget_h", None) or getattr(
            self, "_horizontal_platzbudget_w", None
        ):
            return False
        entries = self.cfg.data.get("entries", [])
        if not entries:
            return False
        try:
            vis, hid = self._split_entries_for_display(entries)
            hat_knopf = self._finde_ueberlauf_knopf() is not None
            # » steht immer da (»0) — fehlt er, ist ein Rebuild faellig.
            if hat_knopf != bool(vis or hid):
                return False
            sichtbar = [
                b for b in self.buttons if not self._ist_ueberlauf_knopf(b)
            ]
            if len(sichtbar) != len(vis):
                return False
            self.root.update_idletasks()
            gem_w, gem_h = self._gemessene_leisten_groesse()
            if quer:
                # Quer (29.09.2026): Fensterbreite = Inhalt + 6 (Fit-Pad),
                # sonst lief nach jedem Start ein blinder Rebuild.
                aw = int(self.root.winfo_width())
                if abs((gem_w + 6) - aw) > 4:
                    return False
                ah = int(self.root.winfo_height())
                if abs((gem_h + 6) - ah) > 4:
                    return False
                return True
            ah = int(self.root.winfo_height())
            if abs((gem_h + 6) - ah) > 4:
                return False
        except tk.TclError:
            return False
        return True

    def _vertical_leiste_inhalt_hoehe(self) -> None:
        """Senkrecht: Fenster auf Inhaltshoehe — kein leerer Totraum (28.09.2026).

        Frueher „volle Hoehe" (Leiste bis an die untere Arbeitsflaeche), damit
        der »-Split Platz hat. Das Fit-Budget ist seitdem immer die volle
        Kante (_split_available_vertical) — das Fenster selbst bleibt so hoch
        wie sein Inhalt.
        """
        if self.slot_limit is not None:
            return
        # Frei bleibt die abgelegte Form — kein Fit-Nachzug (Inventur-Ablage
        # darf nicht auf Inhaltshoehe wachsen, Nutzer 06.10.2026).
        if self.docked == layout.DOCK_FREE:
            return
        if self.orientation != "vertical" and self.docked not in layout.DOCK_VERTICAL:
            return
        try:
            x, y, w, h = self._bar_geometry()
            self._fit_window_to_content(x, y, w, h)
            self._ueberlauf_liste_aktualisieren()
        except tk.TclError:
            pass

    def _header_width(self):
        # Grip + Add sind jetzt inline — deren Breite zaehlt
        w = 0
        badge = getattr(self, "preview_badge", None)
        if badge is not None:
            try:
                bw = badge.winfo_reqwidth()
                if bw and bw > 0:
                    w += bw + 4
            except Exception:
                pass
        if self.grip:
            try:
                gw = self.grip.winfo_reqwidth()
                if gw and gw > 0:
                    w += gw + 4
            except Exception:
                pass
        if self.grip_sep:
            try:
                w += self.grip_sep.winfo_reqwidth() + 5
            except Exception:
                w += 8
        if self.add_btn:
            try:
                aw = self.add_btn.winfo_reqwidth()
                if aw and aw > 0:
                    w += aw + 4
            except Exception:
                pass
        return w if w > 20 else int(round(60 * self.scale))

    def _measure_button_widths(self):
        """Echte Breiten der sichtbaren Entry-Buttons messen (Beschriftung zaehlt mit)."""
        widths = []
        for btn in self.buttons:
            if self._ist_ueberlauf_knopf(btn):
                continue
            try:
                w = btn.winfo_reqwidth()
                if w and w > 0:
                    widths.append(w)
            except Exception:
                pass
        return widths

    def _measure_button_heights(self):
        """Echte Hoehen der sichtbaren Entry-Buttons messen."""
        heights = []
        for btn in self.buttons:
            if self._ist_ueberlauf_knopf(btn):
                continue
            try:
                ht = btn.winfo_reqheight()
                if ht and ht > 0:
                    heights.append(ht)
            except Exception:
                pass
        return heights

    def _content_length(self):
        """KVA 30/36: Inhaltslaenge fuer Dock-Geometrie (Slots + >>-Knopf)."""
        entries = self.cfg.data.get("entries", [])
        # Ein Pfad (Regel 37/38): Slot-Fixzahl laeuft ueber denselben
        # Split — gekappt auf den gemessenen Platz, nie rohe Slotzahl
        # als Dock-Laenge (sonst Fenster fuer 12 Zoom-Slots gebaut,
        # »N clippt — Nutzer 07.10.2026).
        visible, hidden = self._split_entries_for_display(entries)
        widths = self._measure_button_widths()
        if len(widths) != len(visible):
            widths = self._estimate_entry_widths(visible)
        if hidden:
            widths = list(widths) + [48]
        return layout.content_length_for_entries(
            entry_count=len(visible) + (1 if hidden else 0),
            icon_size=self.icon_size,
            labels=self.show_labels,
            header_width=self._header_width(),
            slot_limit=None,
            measured_widths=widths if widths else None,
        )

    def _anheften_zellen_breite(self) -> int:
        """Breite der Anheften-Zelle (Pin + „Anheften"-Label).

        Messen, wenn der Knopf schon existiert (Regel: pixelgenau, nicht
        schaetzen) — sonst konservativ schaetzen. Ohne diese Untergrenze
        schaetzt _thickness_for zu schmal und die Leiste pendelt beim Start
        (46 <-> 80, „Schleife aus", Nutzer 28.09.2026).
        """
        btn = getattr(self, "add_btn", None)
        if btn is not None:
            try:
                w = int(btn.winfo_reqwidth())
                if w > 1:
                    return w + 8
            except Exception:
                pass
        # Nur noch Pin-Bild + padx — Label ist weggefallen. Pin folgt der
        # Icon-Groesse (dynamisch), kein fixes 31px-Minimum (Nutzer 28.09.2026).
        return int(round((max(16, self.icon_size * 1.33) + 10) * self.scale))

    def _thickness_for(self, dock):
        if layout.is_horizontal(dock):
            return self.dock_thickness
        # Senkrecht: breit genug für Icon + Beschriftung (kein seitliches Abschneiden).
        label_pad = 10 if getattr(self, "show_labels", True) else 10
        base = max(self.dock_thickness, int(round((self.icon_size + label_pad) * self.scale)))
        # Anheften-Zelle steckt nicht in entries — als Untergrenze mitrechnen.
        base = max(base, self._anheften_zellen_breite())
        try:
            measured = self._measure_button_widths()
            if measured:
                return max(base, max(measured) + 8)
        except Exception:
            pass
        entries = self.cfg.data.get("entries", [])
        if entries:
            try:
                need = max(self._estimate_entry_widths(entries))
                return max(base, int(need))
            except Exception:
                pass
        return base

    def _vertical_rand_packen(self) -> None:
        """Senkrecht: Griff + Anheften oben, dann Symbole, » unten — Rest Fueller.

        Der Anheften-Knopf bleibt direkt unter dem Griff (Erstellungsreihenfolge
        = Pack-Reihenfolge) — nicht am Leistenende (Nutzer-Auftrag 28.09.2026).
        """
        leiste_bg = self._leiste_bg()
        filler = getattr(self, "_body_filler", None)
        if filler is None or not filler.winfo_exists():
            filler = tk.Frame(self.body, bg=leiste_bg, borderwidth=0, highlightthickness=0)
            self._body_filler = filler
        for w in self.body.winfo_children():
            if w is filler:
                continue
            if getattr(w, "_xl_ueberlauf", False):
                continue
            w.pack_forget()
            w.pack(side=tk.TOP, padx=0, pady=0, fill=tk.X, anchor=tk.N)
        filler.pack_forget()
        filler.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        ov = self._finde_ueberlauf_knopf()
        if ov is not None:
            ov.pack_forget()
            ov.pack(side=tk.BOTTOM, fill=tk.X, padx=0, pady=0)

    def _arrange(self, orientation):
        vertical = self._leiste_ist_senkrecht()
        if vertical:
            self._vertical_rand_packen()
            self._apply_leisten_pack_richtung()
            return
        filler = getattr(self, "_body_filler", None)
        knopf = self._finde_ueberlauf_knopf()
        for w in self.body.winfo_children():
            if w is filler or w is knopf:
                continue
            w.pack_forget()
            w.pack(
                side=tk.LEFT,
                padx=0,
                pady=0,
                fill=tk.NONE,
                anchor=tk.CENTER,
            )
        if filler is not None and filler.winfo_exists():
            filler.pack_forget()
            filler.pack(side=tk.LEFT, padx=0, pady=0, fill=tk.BOTH, expand=True)
        if knopf is not None:
            # »N klebt am rechten Ende — wandert mit der Leistenbreite,
            # kein Totraum dahinter (Nutzer 07.10.2026).
            knopf.pack_forget()
            knopf.pack(side=tk.RIGHT, padx=0, pady=0, fill=tk.NONE, anchor=tk.CENTER)
        self._apply_leisten_pack_richtung()

    def _fit_window_to_content(
        self,
        x: int,
        y: int,
        w: int,
        h: int,
        *,
        breite_min: int | None = None,
        hoehe_min: int | None = None,
        nur_vergroessern: bool = False,
    ) -> tuple[int, int, int, int]:
        """Inhalt einpassen; breite_min = Zoom/Platzbudget (Leiste nicht einklappen)."""
        _w_alt, _h_alt = int(w), int(h)
        try:
            self.root.update_idletasks()
            req_h = int(self.outer.winfo_reqheight() or 0)
            req_w = int(self.outer.winfo_reqwidth() or 0)
            gem_w, gem_h = self._gemessene_leisten_groesse()
            if gem_w > 0:
                req_w = gem_w
            if gem_h > 0:
                req_h = gem_h
            pad = (
                3
                if getattr(self, "_nur_text", False)
                and layout.is_horizontal(self.docked)
                else 6
            )
            # Freie Leiste hat keine Dock-Achse — ihre FORM entscheidet
            # (h>w = senkrecht geformt, z. B. Inventur-Ablage rechts).
            frei_senkrecht = (
                self.docked == layout.DOCK_FREE and int(h) > int(w)
            )
            if layout.is_horizontal(self.docked) or (
                self.docked == layout.DOCK_FREE and not frei_senkrecht
            ):
                # Breite folgt dem Inhalt — kein Budget-Minimum (Totraum-Fix
                # 28.09.2026, gleiches Muster wie senkrecht): das Platzbudget
                # ist nur die »-Split-Obergrenze, nicht die Fensterbreite.
                w = layout.fenster_breite_nach_inhalt(req_w, pad, None)
                # Hoehe folgt dem Inhalt (Icon-Zeile), nicht der globalen
                # Mindest-Dicke 40 — sonst haengt unter den Icons ein leerer
                # Streifen (Totraum, Nutzer 28.09.2026: „nur diese Hoehe").
                # dock_thickness (31 bei 23px-Icons ohne Label) bleibt die
                # Untergrenze, damit die Leiste bedienbar bleibt.
                h = max(int(self.dock_thickness), req_h + pad)
            elif self.docked in layout.DOCK_VERTICAL or frei_senkrecht:
                dicke = max(
                    self._thickness_for(self.docked),
                    layout.MIN_DOCK_THICKNESS,
                )
                # Breite nie unter Inhalt drücken — sonst Icons/Beschriftung abgeschnitten (UX).
                w = max(dicke, req_w + pad)
                # Ziel-Y VOR h_max bestimmen: _leiste_hoehe_max misst den
                # Platz ab Leisten-Y — beim Andocken aus einer anderen Kante
                # steht in y noch die alte Position (bottom -> left gab
                # h_max=60 → 80px-Stub, Nutzer 10.10.2026). Dieselbe
                # Snap+Clamp-Strecke wie unten, damit die Messung die echte
                # Endposition trifft.
                _z_x, z_y, _z_w, _z_h = layout.clamp_bar_geometry(
                    *self._snap_edge_geometry(x, y, w, h, self.docked),
                    self.monitor,
                    self.docked,
                )
                h_max = self._leiste_hoehe_max(z_y)
                inhalt_h = max(layout.MIN_CONTENT_LENGTH, req_h + pad)
                logging.info(
                    "Fit senkrecht: dicke=%s req_w=%s req_h=%s h_max=%s "
                    "inhalt_h=%s budget=%s -> w=%s",
                    dicke,
                    req_w,
                    req_h,
                    h_max,
                    inhalt_h,
                    getattr(self, "_vertical_platzbudget_h", None),
                    w,
                )
                # Anker halten (Regel 38): nicht nach oben schieben, wenn
                # unter dem Anker der Inhalt nicht passt — Rest gehoert in ».
                h = min(inhalt_h, h_max)
            x, y, w, h = self._snap_edge_geometry(x, y, w, h, self.docked)
            x, y, w, h = layout.clamp_bar_geometry(x, y, w, h, self.monitor, self.docked)
            # Nach-Fit beim Sichtbarwerden (Start/HWND-Wechsel): nur stub-
            # Messungen nach oben korrigieren — eine fertige Dock-Geometrie
            # darf eine Messung nie verkleinern (88x163-Stummel 06.10.2026).
            if nur_vergroessern:
                w = max(w, _w_alt)
                h = max(h, _h_alt)
            # Geometrie nur bei echter Aenderung setzen — ein gleiches
            # geometry() wirft sonst jedes Mal ein Configure + AppBar-Zyklus
            # (Nutzer 28.09.2026: „unendlich viel Berechnung").
            try:
                unveraendert = (
                    int(self.root.winfo_rootx()) == int(x)
                    and int(self.root.winfo_rooty()) == int(y)
                    and int(self.root.winfo_width()) == int(w)
                    and int(self.root.winfo_height()) == int(h)
                )
            except tk.TclError:
                unveraendert = False
            if not unveraendert:
                self.root.geometry(f"{w}x{h}+{x}+{y}")
                self.root.update_idletasks()
            if self.docked in layout.DOCK_VERTICAL and not getattr(
                self, "_zoom_vorschau_aktiv", False
            ):
                self._vertical_nach_fit_gegen_clip(h)
            self._block_configure_relayout()
            return x, y, w, h
        except tk.TclError:
            return x, y, w, h

    def _vertical_clip_erkannt(self, fenster_h: int | None = None) -> bool:
        try:
            self.root.update_idletasks()
            _gw, gem_h = self._gemessene_leisten_groesse()
            # fenster_h bevorzugen: am versteckten/withdrawn Fenster (Start,
            # AppBar-HWND-Wechsel) liefert winfo_height den ALTEN Wert — die
            # frisch per geometry() gesetzte Hoehe ist der wahre Stand.
            if fenster_h is not None:
                ah = int(fenster_h)
            else:
                ah = int(self.root.winfo_height())
            return gem_h > ah + 6
        except tk.TclError:
            return False

    def _vertical_nach_fit_gegen_clip(self, fenster_h: int | None = None) -> None:
        """Einmal neu splitten wenn Fensterhoehe < Inhalt — Icons nicht abschneiden."""
        if getattr(self, "_vertical_clip_rebuild", False):
            return
        if not self._vertical_clip_erkannt(fenster_h):
            self._vertical_clip_serie = 0
            return
        serie = int(getattr(self, "_vertical_clip_serie", 0))
        if serie >= 2:
            # Derselbe Clip zum dritten Mal in Folge — strukturell (Budget-
            # Zwist), kein Pack-Fehler: nicht endlos rebuilden (04.10.2026:
            # Stummel-Loop 30 ms — fit→clip→rebuild→populate→abgleich→fit).
            if serie == 2:
                logging.warning(
                    "Vertikal-Clip bleibt nach 2 Rebuilds — Loop abgebrochen"
                )
            self._vertical_clip_serie = serie + 1
            return
        if fenster_h is not None:
            ah = int(fenster_h)
        else:
            try:
                ah = int(self.root.winfo_height())
            except tk.TclError:
                return
        self._vertical_clip_serie = serie + 1
        self._vertical_clip_rebuild = True
        try:
            self._split_avail_override = max(60, ah)
            self._rebuild_entries(relayout_only=True)
        finally:
            self._split_avail_override = None
            self._vertical_clip_rebuild = False

    def _ist_horizontal(self) -> bool:
        return self.orientation != "vertical" and self.docked not in layout.DOCK_VERTICAL

    def _icon_groesse_leiste(self) -> int:
        return masse.icon_groesse_leiste(self.zoom_stufe, horizontal=self._ist_horizontal())

    def _calc_dock_thickness(self) -> int:
        """Leistenhoehe: Icon + echte Schriftzeile + Zellen-Padding (nicht abschneiden)."""
        if getattr(self, "_nur_text", False):
            # „Nur Text": nur die Schriftzeile, kein Icon (09.10.2026).
            try:
                label_h = int(self._label_font(horizontal=True).metrics("linespace"))
            except Exception:
                label_h = max(14, min(28, self.icon_size // 3))
            kopf = masse.leiste_quer_nur_text_kopf_px(self.icon_size)
            pin = max(10, int(round(self.icon_size * 0.55)))
            return max(label_h + 1, kopf, pin)
        if not getattr(self, "show_labels", True):
            return masse.dock_thickness(self.icon_size, False)
        pad = max(1, int(round(2 * masse.zoom_factor(self.zoom_stufe))))
        pady = max(1, pad - 1)
        try:
            label_h = int(self._label_font(horizontal=True).metrics("linespace"))
        except Exception:
            label_h = max(14, min(28, self.icon_size // 3))
        return self.icon_size + label_h + pad * 2 + pady * 2 + 4

    def _platzbudget_fuer_dock_bereinigen(
        self,
        dock: str,
        budget_w: int | None,
        budget_h: int | None,
        *,
        griff_ende: bool = False,
    ) -> tuple[int | None, int | None]:
        """Quer-Dicke (~97) nicht als senkrechte Hoehe — UI sonst nur Griff/+/(»)."""
        if griff_ende:
            if layout.is_horizontal(dock) or dock in layout.DOCK_CORNER:
                w = int(budget_w or 0)
                if w >= layout.MIN_CONTENT_LENGTH:
                    self._horizontal_platzbudget_w = w
                    return w, None
            if dock in layout.DOCK_VERTICAL:
                h = int(budget_h or 0)
                if h >= layout.MIN_CONTENT_LENGTH:
                    self._vertical_platzbudget_h = h
                    return None, h
        if getattr(self, "slot_limit", None) is not None:
            self._horizontal_platzbudget_w = None
            self._vertical_platzbudget_h = None
            return None, None
        min_lang = max(400, layout.MIN_CONTENT_LENGTH * 3)
        root = getattr(self, "root", None)
        cw, ch = 0, 0
        if root is not None:
            try:
                cw = int(root.winfo_width() or 0)
                ch = int(root.winfo_height() or 0)
            except tk.TclError:
                cw, ch = 0, 0
        if dock in layout.DOCK_VERTICAL:
            # Quer-Breite nicht als Senkrecht-Hoehe — sonst leerer Streifen (Icons oben, + unten).
            h = int(budget_h or 0)
            if h <= 0 or (budget_w and h < min_lang and int(budget_w or 0) >= min_lang):
                self._vertical_platzbudget_h = None
                return None, None
            # Aus der Config geladene (vom Nutzer gezogene) Hoehe ist legitim —
            # nicht verwerfen, nur weil das Fenster beim Start noch quer/klein
            # ist (Persistenz-Fix 28.09.2026). Nur der exakt persistierte Wert:
            # die Kantenwechsel-Erkennung (Quer-Dicke != Hoehe) bleibt aktiv.
            if h >= layout.MIN_CONTENT_LENGTH and h == self._platzbudget_config_wert("platzbudget_h"):
                h = min(max(h, layout.MIN_CONTENT_LENGTH), self._leiste_hoehe_max())
                self._vertical_platzbudget_h = h
                return None, h
            if ch > cw and abs(h - ch) <= 8:
                h = min(max(h, layout.MIN_CONTENT_LENGTH), self._leiste_hoehe_max())
                self._vertical_platzbudget_h = h
                return None, h
            self._vertical_platzbudget_h = None
            return None, None
        if layout.is_horizontal(dock) or dock == layout.DOCK_FREE:
            w = int(budget_w or 0)
            h_old = int(budget_h or 0)
            if w < min_lang:
                # Nur echte Verwechslungen verwerfen: die Dock-Dicke (~46) ist
                # keine Quer-Breite. Ein vom Nutzer gezogener Wert (deutlich
                # ueber der Dicke, >= MIN_CONTENT_LENGTH) ist legitim und
                # bleibt — sonst koennte die Leiste nie schmaler als 400 px
                # sein (28.09.2026: gezogene Breite muss Neustart ueberleben).
                dicke = int(getattr(self, "dock_thickness", 0) or 0) or 40
                if not (w >= layout.MIN_CONTENT_LENGTH and w > dicke + 24):
                    if h_old >= min_lang:
                        w = h_old
                    elif ch >= min_lang and ch > cw:
                        w = ch
                    else:
                        w = self._leiste_breite_max()
            w = max(w, layout.MIN_CONTENT_LENGTH)
            self._horizontal_platzbudget_w = w
            return w, None
        return budget_w, budget_h

    def _platzbudget_config_wert(self, key: str) -> int:
        """In der Config persistierter Budget-Wert (0 = keiner / keine Config)."""
        cfg = getattr(self, "cfg", None)
        data = getattr(cfg, "data", None) if cfg is not None else None
        try:
            return int((data or {}).get("bar", {}).get(key) or 0)
        except (TypeError, ValueError, AttributeError):
            return 0

    def _platzbudget_nach_zug(self, alt_dock: str, new_dock: str, w: int, h: int) -> None:
        """Budget beim Kantenwechsel: Quer-Breite wird senkrecht Hoehe (nicht Dicke ~97)."""
        wi, hi = int(w), int(h)
        # „Alle"-Modus: die gezogene (ggf. am Bildschirmrand gestutzte)
        # Fenstergroesse ist kein dauerhaftes Limit — die Leiste fuellt sich
        # beim Andocken wieder bis zum gemessenen Inhalt (Nutzer 03.10.2026).
        # Nur die Quer-Breite fuer den Richtungswechsel merken.
        if getattr(self, "slot_limit", None) is None:
            if (
                layout.is_horizontal(alt_dock)
                or alt_dock in layout.DOCK_CORNER
                or (alt_dock == layout.DOCK_FREE and wi >= hi)
            ):
                merk = self._horizontal_platzbudget_w or wi
                if merk:
                    self._letzte_quer_breite = merk
            # Gleiche Kante: Budget/Dehnen in _leiste_entlang_kante_verschieben
            # (gemessen) — nicht die schmale Live-Masse (05.10.2026).
            if (
                alt_dock == new_dock
                and new_dock in layout.DOCK_EDGE | layout.DOCK_CORNER
            ):
                return
            # Griff-Ende: gezogene Masse fuer _dock_to durchreichen (KVA 35) —
            # sonst springt der Anker auf x=0 / volle Kante (Nutzer 05.10.2026).
            # Frei->Kante traegt die gezogene Laenge (Inventur: »N wie
            # abgelegt); nur Quer-Dicke ist keine senkrechte Laenge (und
            # umgekehrt) — sonst Stummel wie 88x163 (05.10.2026).
            # Eine FREIE Quelle hat keine Dock-Achse — ihre Form entscheidet:
            # quer geformt (w>=h) -> wi ist Breite, kein senkrechter Wert;
            # senkrecht geformt -> hi ist Laenge (z. B. Zonen-Vorschau 90x636).
            if new_dock in layout.DOCK_EDGE | layout.DOCK_CORNER:
                quelle_quer = (
                    layout.is_horizontal(alt_dock)
                    or alt_dock in layout.DOCK_CORNER
                    or (alt_dock == layout.DOCK_FREE and wi >= hi)
                )
                quelle_senkrecht = (
                    alt_dock in layout.DOCK_VERTICAL
                    or (alt_dock == layout.DOCK_FREE and hi > wi)
                )
                if (
                    layout.is_horizontal(new_dock) or new_dock in layout.DOCK_CORNER
                ) and quelle_quer:
                    self._horizontal_platzbudget_w = max(
                        layout.MIN_CONTENT_LENGTH, int(wi)
                    )
                if new_dock in layout.DOCK_VERTICAL and quelle_senkrecht:
                    self._vertical_platzbudget_h = max(
                        layout.MIN_CONTENT_LENGTH, int(hi)
                    )
            else:
                self._horizontal_platzbudget_w = None
                self._vertical_platzbudget_h = None
            return
        if layout.is_horizontal(new_dock) or new_dock == layout.DOCK_FREE:
            if alt_dock in layout.DOCK_VERTICAL:
                # Lange Quer-Leiste wiederherstellen — die alte Breite geht
                # sonst beim Ausflug an die Seite verloren (Nutzer 03.10.2026).
                gemerkt = getattr(self, "_letzte_quer_breite", 0) or 0
                self._horizontal_platzbudget_w = max(hi, wi, gemerkt)
            else:
                self._horizontal_platzbudget_w = wi
                self._letzte_quer_breite = wi
        if new_dock in layout.DOCK_VERTICAL:
            if layout.is_horizontal(alt_dock) or alt_dock in layout.DOCK_CORNER:
                if self._horizontal_platzbudget_w or wi:
                    self._letzte_quer_breite = self._horizontal_platzbudget_w or wi
                self._vertical_platzbudget_h = None
            else:
                self._vertical_platzbudget_h = hi

    _SLOT_STUFEN = (0, 3, 5, 7, 12, None)

    def _naechste_slot_stufe(self, aktuell):
        if aktuell is None:
            return None
        for stufe in self._SLOT_STUFEN:
            if stufe is not None and aktuell is not None and stufe > aktuell:
                return stufe
        return None

    def _block_configure_relayout(self, sekunden: float = 0.45) -> None:
        """Nach programmatischem geometry() kein Configure-Rebuild (sonst: lang → kurz)."""
        bis = time.monotonic() + sekunden
        if bis > self._configure_relayout_block_until:
            self._configure_relayout_block_until = bis

    def _max_split_available(self) -> int:
        """»-Klick: Platzbudget bis Bildschirmrand."""
        if self.orientation == "vertical" or self.docked in layout.DOCK_VERTICAL:
            wl, wt, wr, wb = layout._work_tuple(self.monitor)
            try:
                y = int(self.root.winfo_y())
            except tk.TclError:
                y = wt
            if self.docked in layout.DOCK_CORNER and "bottom" in self.docked:
                return max(layout.MIN_CONTENT_LENGTH, wb - max(wt, y))
            if self.docked == layout.DOCK_FREE:
                return max(layout.MIN_CONTENT_LENGTH, wb - max(wt, y))
            return max(layout.MIN_CONTENT_LENGTH, wb - wt)
        return self._leiste_breite_max()
