from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VERSION_FILE = ROOT / "VERSION"
# Zuletzt an Kunden ausgelieferte Stufe — bei neuer Auslieferung T8, T9, … (Nutzer 27.10.2026).
AUSLIEFERUNG_T_FILE = ROOT / "AUSLIEFERUNG-T"


def get_version(default="0.0.0"):
    try:
        return VERSION_FILE.read_text(encoding="utf-8").strip()
    except Exception:
        return default


def _git_kurz_hash(root: Path) -> str:
    try:
        import subprocess

        r = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True,
            text=True,
            timeout=2,
            cwd=str(root),
        )
        if r.returncode == 0:
            return (r.stdout or "").strip()
    except Exception:
        pass
    return ""


def _git_unsauber(root: Path) -> bool:
    try:
        import subprocess

        r = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True,
            text=True,
            timeout=2,
            cwd=str(root),
        )
        return r.returncode == 0 and bool((r.stdout or "").strip())
    except Exception:
        return False


def get_auslieferung_stufe(default: int = 7) -> int:
    """Letzte ausgelieferte T-Stufe (T7, T8, …) — siehe AUSLIEFERUNG-T im Programmordner."""
    try:
        roh = AUSLIEFERUNG_T_FILE.read_text(encoding="utf-8").strip()
        if roh.upper().startswith("T"):
            roh = roh[1:].strip()
        n = int(roh)
        return n if n > 0 else default
    except Exception:
        return default


def auslieferung_t_label() -> str:
    return f"T{get_auslieferung_stufe()}"


def get_version_menuzeile(*, entwicklung: bool) -> str:
    """Menue: Auslieferung = „{ver} Tn“; Entwickler = „{ver} Tn Dev“ (Dev am Schluss, Nutzer 31.10.2026)."""
    ver = get_version("?.?.?")
    t = auslieferung_t_label()
    if entwicklung:
        return f"{ver} {t} Dev"
    return f"{ver} {t}"


def get_version_detail(root: Path | None = None, *, entwicklung: bool) -> str:
    """Info-Dialog — T-Schema in Klartext."""
    basis = root or ROOT
    ver = get_version("?.?.?")
    t = auslieferung_t_label()
    zeilen = [
        f"Produktversion: {ver}",
        f"Zuletzt ausgeliefert: {t}",
    ]
    if entwicklung:
        zeilen.append(
            f"Aktuell: {ver} {t} Dev — Entwickler-Baum (Basis Auslieferung {t})"
        )
        zeilen.append(f"Programmordner:\n{basis}")
        if _git_unsauber(basis):
            zeilen.append("")
            zeilen.append(
                "Programmcode wurde geaendert.\n"
                "xlounger beenden und neu starten, sonst laeuft der alte Stand weiter."
            )
    else:
        zeilen.append(f"Aktuell: {t} — Auslieferungs-Paket (Kundenstand)")
    return "\n".join(zeilen)


def get_version_tuple(default=(0, 0, 0)):
    v = get_version(default="0.0.0")
    parts = v.lstrip("v").split(".")
    try:
        return tuple(int(p) for p in parts[:3])
    except ValueError:
        return default
