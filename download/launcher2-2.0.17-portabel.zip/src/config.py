import copy
import json
import logging
import os
import shutil
import hashlib
from pathlib import Path
from .paths import get_config_path, get_appdata_dir


DEFAULT_CONFIG = {
    "version": 1,
    "profile": "default",
    "bar": {
        "position": {"x": 100, "y": 100},
        "orientation": "horizontal",
        "dock": "top",
        "zoom_stufe": 7,
        "leiste_hintergrund": "grau",
        "background_color": "#606060",
        "transparency": 0,
        "always_on_top": True,
        "show_labels": True,
        "anzeige_modus": "beide",
        "red_border": False,
        "desktop_platz": True,
        "slots": None,
        "monitor": "",
    },
    "entries": [],
    "removed_entries": [],
    "user_customizations": {},
    "last_window_hwnds": {},
    "anheften_panel": {
        "width": 420,
        "height": 520,
        "x": 100,
        "y": 100,
        "user_placed": False,
        "schrift_pt": 11,
        "gruppen_zuklapp": {},
    },
}


def stable_id(target):
    return hashlib.md5(str(target).lower().encode("utf-8")).hexdigest()[:16]


def _entries_len(data: dict) -> int:
    entries = data.get("entries")
    if not isinstance(entries, list):
        return 0
    return sum(1 for e in entries if isinstance(e, dict) and e.get("target"))


def _entries_write_guard(new: dict, old: dict | None) -> str | None:
    """KVA 247/248 — Schreibschutz nur fuer config.json auf Platte.

    None = Schreiben erlaubt. Sonst Grund — die Datei bleibt unangetastet;
    die Leiste darf im Programm weiter bearbeitet werden (Einzelentfernen usw.).
    """
    if old is None:
        return None
    n_new = _entries_len(new)
    n_old = _entries_len(old)
    if n_old <= 0:
        return None
    if n_new == 0:
        return f"entries {n_old}->0 (Leeren blockiert)"
    if n_old >= 6 and n_new < (n_old + 1) // 2:
        return f"entries {n_old}->{n_new} (Schrumpfung >50 % blockiert)"
    return None


class Config:
    def __init__(self):
        self.path = get_config_path()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.backup_path = self.path.with_suffix(".json.bak")
        self.last_good_path = self.path.with_suffix(".json.lastgood")
        self.data = self._load()
        self._last_save_block: str | None = None

    def _default(self):
        return copy.deepcopy(DEFAULT_CONFIG)

    def _read_json(self, path: Path) -> dict | None:
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
        except Exception:
            pass
        return None

    def _load(self):
        if not self.path.exists():
            return self._default()
        data = self._read_json(self.path)
        if data is not None:
            try:
                if self._migrate(data):
                    self._validate(data)
                    self.data = data
                    self.save(force=True)
                else:
                    self._validate(data)
                self._backup(self.path, self.last_good_path)
                return data
            except Exception:
                pass
        data = self._read_json(self.last_good_path)
        if data is not None:
            try:
                if self._migrate(data):
                    self._validate(data)
                    self.data = data
                    self.save(force=True)
                else:
                    self._validate(data)
                logging.warning("Config aus lastgood geladen: %s", self.last_good_path)
                return data
            except Exception:
                pass
        data = self._read_json(self.backup_path)
        if data is not None:
            try:
                if self._migrate(data):
                    self._validate(data)
                    self.data = data
                    self.save(force=True)
                else:
                    self._validate(data)
                logging.warning("Config aus Backup geladen: %s", self.backup_path)
                return data
            except Exception:
                pass
        return self._default()

    def _migrate(self, data) -> bool:
        changed = False
        if "version" not in data:
            data["version"] = 1
        for key, default in DEFAULT_CONFIG.items():
            if key not in data:
                data[key] = copy.deepcopy(default)
                changed = True
            elif isinstance(default, dict) and isinstance(data[key], dict):
                for k, v in default.items():
                    if k not in data[key]:
                        data[key][k] = copy.deepcopy(v)
                        changed = True

        bar = data.get("bar")
        if isinstance(bar, dict):
            # zoom → zoom_stufe (gleiche Stufen 0–12)
            if "zoom_stufe" not in bar and "zoom" in bar:
                bar["zoom_stufe"] = bar.pop("zoom")
                changed = True
            elif "zoom" in bar:
                bar.pop("zoom", None)
                changed = True

            # Farb-Standard einmalig setzen (leiste_hintergrund)
            if "leiste_hintergrund" not in bar:
                from . import masse

                bar["leiste_hintergrund"] = masse.LEISTE_BG_STANDARD
                bar["background_color"] = masse.leiste_bg(bar)
                changed = True
            # Liefer-Seed hatte faelschlich desktop_platz false (01.11.2026) — ohne
            # bewusstes Abschalten (desktop_platz_user_off) wieder einschalten.
            if bar.get("desktop_platz") is False and not bar.get(
                "desktop_platz_user_off"
            ):
                bar["desktop_platz"] = True
                changed = True
        # KVA 249 — favoriten/leiste → entries
        if _entries_len(data) == 0:
            migrated = self._migrate_legacy_entries(data)
            if migrated:
                data["entries"] = migrated
                changed = True
        try:
            from .verbindung_profil import migriere_config

            if migriere_config(data):
                changed = True
        except Exception as exc:
            logging.warning("Verbindungs-Steckbrief-Migration: %s", exc)
        return changed

    def _migrate_legacy_entries(self, data: dict) -> list:
        """Alte Keys favoriten oder leiste in entries ueberfuehren."""
        raw = data.get("favoriten") or data.get("leiste")
        if not raw or not isinstance(raw, list):
            return []
        out = []
        for item in raw:
            if isinstance(item, str):
                target = item.strip()
                if not target:
                    continue
                name = Path(target).stem or target
                out.append({"name": name, "target": target, "id": stable_id(target)})
            elif isinstance(item, dict):
                target = str(item.get("target") or item.get("pfad") or "").strip()
                if not target:
                    continue
                name = str(item.get("name") or Path(target).stem or target).strip()
                eid = item.get("id") or stable_id(target)
                out.append({"name": name, "target": target, "id": eid})
        return out

    def _validate(self, data):
        if not isinstance(data.get("entries"), list):
            data["entries"] = []
        for entry in data["entries"]:
            if not isinstance(entry, dict):
                continue
            if "id" not in entry and "target" in entry:
                entry["id"] = stable_id(entry["target"])

    def entries_from_disk(self) -> list | None:
        data = self._read_json(self.path) or self._read_json(self.last_good_path)
        if not data:
            return None
        entries = data.get("entries")
        if not isinstance(entries, list):
            return None
        return copy.deepcopy(entries)

    def restore_entries_from_disk(self) -> bool:
        """Eintragsliste im Speicher auf letzten Platten-Stand zuruecksetzen."""
        entries = self.entries_from_disk()
        if entries is None:
            return False
        self.data["entries"] = entries
        return True

    def save(self, *, force: bool = False) -> bool:
        """Atomar auf Platte schreiben. False = abgelehnt/Fehler — Datei unveraendert."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._last_save_block = None

        previous = self._read_json(self.path)
        if previous is None:
            previous = self._read_json(self.last_good_path)

        if not force:
            reason = _entries_write_guard(self.data, previous)
            if reason:
                self._last_save_block = reason
                logging.warning("Config-Speichern blockiert: %s", reason)
                return False

        tmp = self.path.with_suffix(".json.tmp")
        text = json.dumps(self.data, ensure_ascii=False, indent=2)
        try:
            tmp.write_text(text, encoding="utf-8")
            probe = json.loads(tmp.read_text(encoding="utf-8"))
            if not isinstance(probe, dict):
                raise ValueError("tmp kein Objekt")
            os.replace(str(tmp), str(self.path))
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            self._last_save_block = str(exc)
            logging.warning("Config-Speichern fehlgeschlagen: %s", exc)
            try:
                if tmp.is_file():
                    tmp.unlink()
            except OSError:
                pass
            return False

        self._backup(self.path, self.backup_path)
        self._backup(self.path, self.last_good_path)
        return True

    def _backup(self, src, dst):
        if src.exists():
            try:
                shutil.copy2(src, dst)
            except Exception:
                pass
