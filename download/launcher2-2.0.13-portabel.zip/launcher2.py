#!/usr/bin/env python3
import sys
import os
import logging
import tkinter as tk
from tkinter import messagebox

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

from src.version import get_version
from src.paths import get_log_path, get_appdata_dir
from src.error_handler import install as install_error_handler
from src.single_instance import SingleInstance, request_show_existing
from src.config import Config
from src.bar import Bar


def setup_logging():
    get_appdata_dir().mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        filename=str(get_log_path()),
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        encoding="utf-8",
    )
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(logging.INFO)
    logging.getLogger().addHandler(console)


def main():
    setup_logging()
    install_error_handler()
    version = get_version()
    logging.info("xlounger %s startet", version)

    single = SingleInstance()
    if not single.acquire():
        logging.warning("xlounger laeuft bereits — zeige laufende Leiste")
        request_show_existing()
        return 0

    # KVA 241 — frischer Start: Sauber-beendet-Flag loeschen,
    # damit der Waechter ab jetzt wieder nachstarten darf.
    try:
        flag = get_appdata_dir() / "sauber-beendet.flag"
        if flag.exists():
            flag.unlink()
            logging.info("Sauber-beendet-Flag geloescht (frischer Start)")
    except OSError:
        pass

    # KVA 224 — eigene AUMID: Taskleiste gruppiert das Fenster als „xlounger"
    try:
        from src.taskleiste import aumid_setzen

        aumid_setzen()
    except Exception:
        logging.exception("AUMID-Setzen fehlgeschlagen")

    # KVA 193 — Startmenue-Verknuepfung pflegen (anlegen/reparieren).
    # Fehler hier duerfen den Start nie verhindern.
    try:
        from src.startmenue import pflegen as startmenue_pflegen

        ergebnis = startmenue_pflegen()
        if ergebnis != "ok":
            logging.info("Startmenue-Verknuepfung: %s", ergebnis)
    except Exception:
        logging.exception("Startmenue-Pflege fehlgeschlagen")

    config = Config()
    # 28.10.2026: Das Setup legt config_seed.json als config.json an (Update-URL,
    # Fehlerbericht-URL) — dann existierte die Datei und der Kunde bekam eine
    # LEERE Leiste (81 px Griff-Stummel, "es taucht kein Launcher auf").
    # Standard-Eintraege daher immer dann, wenn noch kein einziger Eintrag da ist.
    # Sicher: config._entries_write_guard blockiert Leeren >0 -> 0 auf Platte,
    # eine Datei ohne Eintraege ist also immer "nie befuellt".
    hat_eintraege = any(
        isinstance(e, dict) and e.get("target")
        for e in (config.data.get("entries") or [])
    )
    if not config.path.exists() or not hat_eintraege:
        config.data["entries"] = [
            {"name": "Editor", "target": "notepad.exe"},
            {"name": "Explorer", "target": "explorer.exe"},
            {"name": "Rechner", "target": "calc.exe"},
        ]
        config.save()
        logging.info("Standard-Eintraege angelegt")

    print(f"[xlounger] Config: {config.path}", flush=True)
    print(f"[xlounger] Log: {get_log_path()}", flush=True)
    print("[xlounger] Leiste wird angezeigt...", flush=True)

    bar = Bar(config)

    # Tk-Callback-Exceptions landen sonst nur auf stderr (pythonw = /dev/null)
    def _tk_callback_fehler(exc, val, tb):
        logging.exception("Tk-Callback-Fehler", exc_info=(exc, val, tb))
        try:
            from src.error_handler import fehler_dialog

            fehler_dialog(exc, val, tb)
        except Exception:
            pass

    bar.root.report_callback_exception = _tk_callback_fehler

    # Tray wird nativ in Bar erstellt (tray_win32, kein pystray-Thread).

    try:
        bar.run()
    finally:
        if bar.tray_icon:
            bar.tray_icon.stop()
        single.release()
    return 0


if __name__ == "__main__":
    sys.exit(main())
