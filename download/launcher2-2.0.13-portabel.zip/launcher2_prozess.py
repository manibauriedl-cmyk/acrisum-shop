#!/usr/bin/env python3
"""Launcher 2 — Prozess-Hilfen (läuft? starten wenn tot, Wächter).

Log: %%APPDATA%%\\launcher2\\xlounger-waechter.log
"""
from __future__ import annotations

import argparse
import ctypes
import json
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent

sys.path.insert(0, str(ROOT))
from src.app_id import APP_DISPLAY_NAME, APP_NAME, LEGACY_APP_SLUG  # noqa: E402
from src.appbar_persist import shell_appbar_bereinigen  # noqa: E402
from src.install_pfad import legacy_mutex_name, mutex_name, pythonw_exe  # noqa: E402
from src.prozess_beenden import geist_leiste_beenden, waechter_beenden  # noqa: E402
from src.single_instance import request_show_existing  # noqa: E402

MUTEX_NAME = mutex_name()
# 29.10.2026: Fenstersuche NUR auf Tk-Hauptfenster. Ohne Klasse traf
# FindWindowW(None, "launcher2") unter Windows 10 ein Explorer-Fenster des
# Ordners C:\Program Files\launcher2 (Titel = Ordnername) -> "Leiste laeuft
# bereits", nichts startete. Alle Versionen (auch 1.x) sind Tk -> TkTopLevel.
TK_FENSTER_KLASSE = "TkTopLevel"
SYNCHRONIZE = 0x00100000
WAECHTER_INTERVAL = 30
FAILS_BEFORE_START = 2
START_COOLDOWN_SEC = 45


def _appdata() -> Path:
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    d = Path(base) / APP_NAME
    d.mkdir(parents=True, exist_ok=True)
    return d


def _log(msg: str) -> None:
    line = f"[{datetime.now().strftime('%d.%m.%Y %H:%M:%S')}] {msg}\n"
    try:
        with (_appdata() / "xlounger-waechter.log").open("a", encoding="utf-8") as f:
            f.write(line)
    except OSError:
        pass
    print(line.rstrip(), flush=True)


def lebt() -> bool:
    """True wenn Launcher-2-Mutex existiert (= Instanz läuft, inkl. Legacy-Name)."""
    kernel32 = ctypes.windll.kernel32
    for name in (MUTEX_NAME, legacy_mutex_name()):
        handle = kernel32.OpenMutexW(SYNCHRONIZE, False, name)
        if handle:
            kernel32.CloseHandle(handle)
            return True
    return False


def pythonw() -> str:
    return pythonw_exe()


def _fenster_hwnd() -> int:
    user32 = ctypes.windll.user32
    for titel in (APP_DISPLAY_NAME, APP_NAME, LEGACY_APP_SLUG):
        h = user32.FindWindowW(TK_FENSTER_KLASSE, titel)
        if h:
            return int(h)
    return 0


def _fenster_in_sicht_bringen(hwnd: int) -> None:
    if not hwnd:
        request_show_existing()
        return
    user32 = ctypes.windll.user32
    user32.ShowWindow(hwnd, 5)  # SW_SHOW
    user32.SetForegroundWindow(hwnd)
    request_show_existing()


def _warte_auf_fenster(sek: float = 20.0) -> int:
    """Kalstart: Mutex/Fenster kommen oft erst nach Sekunden — nicht sofort aufgeben."""
    t0 = time.monotonic()
    deadline = t0 + sek
    min_bootstrap = 10.0
    while time.monotonic() < deadline:
        h = _fenster_hwnd()
        if h:
            return h
        if not lebt() and (time.monotonic() - t0) >= min_bootstrap:
            return 0
        time.sleep(0.25)
    return _fenster_hwnd()


def _postinstall_modus() -> bool:
    return os.environ.get("LAUNCHER2_POSTINSTALL", "").strip() in ("1", "true", "yes")


def start_if_down(*, quiet: bool | None = None) -> int:
    if quiet is None:
        quiet = _postinstall_modus()
    waechter_beenden()
    hwnd = _fenster_hwnd()
    if lebt():
        if hwnd:
            _log("start-if-down: xlounger läuft bereits — Fenster nach vorne")
            _fenster_in_sicht_bringen(hwnd)
            return 0
        hwnd = _warte_auf_fenster(20.0)
        if hwnd:
            _log("start-if-down: Start lief — Fenster jetzt da")
            _fenster_in_sicht_bringen(hwnd)
            return 0
        _log("start-if-down: Geist-Mutex ohne Fenster (nach Wartezeit) — bereinigen")
        stop()
    elif hwnd:
        _log("start-if-down: Fenster ohne Mutex (Altlast) — schließen")
        stop()
    if lebt() or _fenster_hwnd():
        _log("start-if-down: blockiert — Wächter/Geist aufräumen")
        waechter_beenden()
        stop()
        time.sleep(1.0)
        if lebt() and not _fenster_hwnd():
            n = geist_leiste_beenden()
            _log(f"start-if-down: Geist-Prozesse beendet: {n}")
            time.sleep(0.5)
    if lebt() or _fenster_hwnd():
        _log("start-if-down: Start blockiert nach Aufräumen")
        if not quiet:
            _start_blockiert_hinweis()
        return 1 if not quiet else 0
    exe = pythonw()
    script = str(ROOT / "launcher2.py")
    _log(f"start-if-down: starte {exe} {script}")
    subprocess.Popen(
        [exe, script],
        cwd=str(ROOT),
        creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
    )
    hwnd = _warte_auf_fenster(25.0)
    if hwnd:
        _log("start-if-down: Leiste gestartet (Fenster sichtbar)")
        _fenster_in_sicht_bringen(hwnd)
    elif lebt():
        _log("start-if-down: Mutex da, Fenster noch nicht — bitte 10 s warten")
    else:
        _log("start-if-down: Start fehlgeschlagen — siehe Log unter AppData")
        if not quiet:
            _start_blockiert_hinweis()
        return 1 if not quiet else 0
    return 0


def _start_blockiert_hinweis() -> None:
    try:
        ctypes.windll.user32.MessageBoxW(
            0,
            "Launcher 2 konnte nicht starten.\r\n\r\n"
            "Bitte Setup von acrisum.com erneut ausführen (neueste Version) "
            "oder PC einmal neu starten.\r\n\r\n"
            f"Log: {_appdata() / 'xlounger-waechter.log'}",
            APP_DISPLAY_NAME,
            0x00000030,
        )
    except OSError:
        pass


def stop() -> int:
    """Sauber beenden per WM_CLOSE — _quit meldet die AppBar ab.

    Kein harter Kill: der hinterlaesst die AppBar-Reservierung als
    Geist im Explorer (25.09.2026 — Arbeitsbereich oben wuchs 134→212 px).
    """
    nw = waechter_beenden()
    if nw:
        _log(f"stop: Wächter beendet: {nw}")
    user32 = ctypes.windll.user32
    hwnd = 0
    # Fenstertitel ist APP_DISPLAY_NAME („Launcher 2“, bar.py) — 28.10.2026:
    # stop() suchte APP_NAME („launcher2“) und fand das Fenster nie, Update/
    # Deinstall liess die Leiste als Geist mit Mutex laufen (Kunde: „öffnet nicht“).
    # Mutex kommt beim Start SEKUNDEN vor dem Fenster (Kalteinstart ~7–10 s) —
    # deshalb bis zu 15 s auf das Fenster warten, sonst schliesst stop() eine
    # gerade startende Leiste nicht (Deinstall waehrend des Starts).
    for _ in range(60):
        for titel in (APP_DISPLAY_NAME, APP_NAME, LEGACY_APP_SLUG):
            hwnd = user32.FindWindowW(TK_FENSTER_KLASSE, titel)
            if hwnd:
                break
        if hwnd:
            break
        time.sleep(0.25)
    if not hwnd:
        if lebt():
            _log("stop: Mutex ohne Fenster — Geist-Leiste beenden")
            n = geist_leiste_beenden()
            _log(f"stop: Geist-Prozesse beendet: {n}")
            time.sleep(0.5)
            if lebt():
                shell_appbar_bereinigen()
                return 1
            shell_appbar_bereinigen()
            return 0
        _log("stop: xlounger läuft nicht")
        shell_appbar_bereinigen()
        return 0
    user32.PostMessageW(hwnd, 0x0010, 0, 0)  # WM_CLOSE
    # 25.09.2026: 5 s waren zu knapp, wenn der Nutzer die Leiste gerade
    # bedient (Menü offen) — WM_CLOSE wird dann verzögert angenommen.
    for _ in range(120):
        if not lebt() and not _fenster_hwnd():
            _log("stop: sauber beendet")
            shell_appbar_bereinigen()
            return 0
        time.sleep(0.1)
    _log("stop: nach 12 s noch da — bitte prüfen (kein harter Kill)")
    n = shell_appbar_bereinigen()
    if n:
        _log(f"stop: Shell-AppBar-Nachzug ABM_REMOVE x{n}")
    return 1


def appbar_cleanup() -> int:
    """Deinstall/Alt-Launcher: reservierte Streifen ohne laufende Leiste lösen."""
    n = shell_appbar_bereinigen()
    _log(f"appbar-cleanup: ABM_REMOVE Versuche={n}")
    return 0


def legacy_bereinigung_cmd(*, programmordner: bool = True) -> int:
    """Vor Neuinstallation: alte Namen unter AppData/Programs/Autostart + AppBar."""
    from src.legacy_bereinigung import legacy_bereinigung

    rep = legacy_bereinigung(programmordner=programmordner)
    _log(f"legacy-bereinigung: {rep}")
    return 0


def legacy_bereinigung_leicht_cmd() -> int:
    return legacy_bereinigung_cmd(programmordner=False)


def post_install_start_cmd() -> int:
    """Setup [Run]: nur Leiste starten — kein Wächter, kein start-if-down-Rennen."""
    waechter_beenden()
    geist_leiste_beenden()
    time.sleep(0.4)
    if lebt() or _fenster_hwnd():
        _log("post-install-start: Leiste laeuft bereits")
        return 0
    exe = pythonw()
    script = str(ROOT / "launcher2.py")
    _log(f"post-install-start: starte Leiste direkt ({exe})")
    subprocess.Popen(
        [exe, script],
        cwd=str(ROOT),
        creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
    )
    return 0


def uninstall_cleanup_cmd() -> int:
    from src.legacy_bereinigung import deinstall_rest

    rep = deinstall_rest()
    _log(f"uninstall-cleanup: {rep}")
    return 0


def _waechter_lock_nehmen() -> bool:
    lock = _appdata() / "xlounger_waechter.lock"
    if lock.is_file():
        try:
            old = json.loads(lock.read_text(encoding="utf-8"))
            pid = int(old.get("pid") or 0)
            if pid > 0:
                kernel32 = ctypes.windll.kernel32
                h = kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
                if h:
                    kernel32.CloseHandle(h)
                    return False
        except (OSError, ValueError, TypeError):
            pass
    lock.write_text(
        json.dumps({"pid": os.getpid(), "seit": datetime.now().isoformat(timespec="seconds")}),
        encoding="utf-8",
    )
    return True


def neustart_erlaubt() -> bool:
    """KVA 241 — False wenn sauber beendet (Flag); Start loescht das Flag."""
    return not (_appdata() / "sauber-beendet.flag").is_file()


def boot_check(warte_sek: float = 10.0) -> int:
    """KVA 240 — Nachstart, wenn der Mutex nach 10 s noch fehlt.

    Fuer den Autostart-Eintrag: erst dem normalen Startweg Zeit geben,
    dann pruefen. Ein Boot ist eine neue Session — ein altes
    sauber-beendet.flag gilt hier nicht mehr und wird entfernt.
    """
    flag = _appdata() / "sauber-beendet.flag"
    try:
        flag.unlink(missing_ok=True)
    except OSError:
        pass
    time.sleep(warte_sek)
    if lebt():
        _log("boot-check: Mutex da — nichts zu tun")
        return 0
    _log(f"boot-check: Mutex fehlt nach {warte_sek:.0f} s — starte nach")
    return start_if_down()


def waechter() -> int:
    if not _waechter_lock_nehmen():
        _log("waechter: zweite Kopie — Ende")
        return 0
    _log("waechter: gestartet")
    fails = 0
    last_start = 0.0
    flag_gemeldet = False
    while True:
        if lebt():
            fails = 0
            flag_gemeldet = False
        else:
            fails += 1
            if fails >= FAILS_BEFORE_START:
                now = time.monotonic()
                if now - last_start >= START_COOLDOWN_SEC:
                    if not neustart_erlaubt():
                        if not flag_gemeldet:
                            _log("waechter: sauber beendet — kein Neustart")
                            flag_gemeldet = True
                    else:
                        _log("waechter: xlounger tot — Neustart")
                        start_if_down()
                    last_start = now
                    fails = 0
        time.sleep(WAECHTER_INTERVAL)


def main() -> int:
    parser = argparse.ArgumentParser(description="xlounger Prozess-Hilfen")
    parser.add_argument(
        "aktion",
        choices=(
            "status",
            "start-if-down",
            "waechter",
            "stop",
            "boot-check",
            "appbar-cleanup",
            "legacy-bereinigung",
            "legacy-bereinigung-leicht",
            "uninstall-cleanup",
            "post-install-start",
        ),
        help=(
            "status | start-if-down | waechter | stop | boot-check | "
            "appbar-cleanup | legacy-bereinigung | legacy-bereinigung-leicht | "
            "uninstall-cleanup | post-install-start"
        ),
    )
    args = parser.parse_args()
    if args.aktion == "status":
        print("ok" if lebt() else "tot")
        return 0 if lebt() else 1
    if args.aktion == "start-if-down":
        return start_if_down()
    if args.aktion == "stop":
        return stop()
    if args.aktion == "appbar-cleanup":
        return appbar_cleanup()
    if args.aktion == "legacy-bereinigung":
        return legacy_bereinigung_cmd()
    if args.aktion == "legacy-bereinigung-leicht":
        return legacy_bereinigung_leicht_cmd()
    if args.aktion == "post-install-start":
        return post_install_start_cmd()
    if args.aktion == "uninstall-cleanup":
        return uninstall_cleanup_cmd()
    if args.aktion == "boot-check":
        return boot_check()
    return waechter()


if __name__ == "__main__":
    raise SystemExit(main())
