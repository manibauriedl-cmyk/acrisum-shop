# xlounger — eingebettetes Python 3.11 inkl. tkinter (KVA 313)
param([switch]$Quiet)

$ErrorActionPreference = "Stop"
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
} catch { }

$Root = Split-Path $PSScriptRoot -Parent
if (-not (Test-Path (Join-Path $Root "launcher2.py"))) {
    $Root = Split-Path $Root -Parent
}
$PyDir = Join-Path $Root "python"
$PyExe = Join-Path $PyDir "python.exe"
$Version = "3.11.9"
$ZipName = "python-$Version-embed-amd64.zip"
$Url = "https://www.python.org/ftp/python/$Version/$ZipName"
$FullUrl = "https://www.python.org/ftp/python/$Version/python-$Version-amd64.exe"

function Say($t) { if (-not $Quiet) { Write-Host $t } }

function Expand-Zip($ZipPfad, $Ziel) {
    if (Get-Command Expand-Archive -ErrorAction SilentlyContinue) {
        Expand-Archive -Path $ZipPfad -DestinationPath $Ziel -Force
        return
    }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPfad)
    try {
        foreach ($eintrag in $zip.Entries) {
            $zielDatei = Join-Path $Ziel $eintrag.FullName
            $ordner = Split-Path $zielDatei -Parent
            if (-not (Test-Path $ordner)) { New-Item -ItemType Directory -Force -Path $ordner | Out-Null }
            if ($eintrag.Name) {
                [System.IO.Compression.ZipFileExtensions]::ExtractToFile($eintrag, $zielDatei, $true)
            }
        }
    } finally {
        $zip.Dispose()
    }
}

function Enable-PipPth {
    $Pth = Get-ChildItem $PyDir -Filter "python*._pth" | Select-Object -First 1
    if (-not $Pth) { return }
    $lines = @("python311.zip", ".", "Lib", "Lib\site-packages", "", "import site")
    Set-Content -Path $Pth.FullName -Value ($lines -join "`r`n") -Encoding ASCII
}

function Test-Tkinter {
    if (-not (Test-Path $PyExe)) { return $false }
    # cmd /c statt & -Aufruf: natives stderr wird unter EAP=Stop zum
    # NativeCommandError und bricht ab, bevor Install-Tkinter laeuft
    # (Nutzer 07.10.2026: Setup scheiterte am tkinter-Test).
    cmd /c ""$PyExe" -c "import tkinter" >NUL 2>NUL" | Out-Null
    return ($LASTEXITCODE -eq 0)
}

function Install-EmbedPython {
    Say "Lade Python-Embed ..."
    $Temp = Join-Path $env:TEMP "xlounger-python-setup"
    New-Item -ItemType Directory -Force -Path $Temp, $PyDir | Out-Null
    $ZipPath = Join-Path $Temp $ZipName
    Invoke-WebRequest -Uri $Url -OutFile $ZipPath -UseBasicParsing
    Expand-Zip $ZipPath $PyDir
    Enable-PipPth
    $GetPip = Join-Path $Temp "get-pip.py"
    Invoke-WebRequest -Uri "https://bootstrap.pypa.io/get-pip.py" -OutFile $GetPip -UseBasicParsing
    $p = Start-Process -FilePath $PyExe -ArgumentList @($GetPip, "--no-warn-script-location") -Wait -PassThru -WindowStyle Hidden
    if ($null -eq $p -or $p.ExitCode -ne 0) { exit 1 }
}

function Install-Tkinter {
    Say "Tkinter nachziehen ..."
    $Temp = Join-Path $env:TEMP "xlounger-python-setup"
    $Exe = Join-Path $Temp "python-$Version-amd64.exe"
    $FullDir = Join-Path $Temp "py-full-$Version"
    if (-not (Test-Path $Exe)) {
        Invoke-WebRequest -Uri $FullUrl -OutFile $Exe -UseBasicParsing
    }
    if (Test-Path $FullDir) { Remove-Item $FullDir -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $FullDir | Out-Null
    $p = Start-Process -FilePath $Exe -ArgumentList @(
        "/quiet", "TargetDir=$FullDir", "InstallAllUsers=0", "PrependPath=0",
        "Include_doc=0", "Include_test=0", "Include_launcher=0", "Include_pip=0",
        "Include_tcltk=1", "AssociateFiles=0", "Shortcuts=0"
    ) -Wait -PassThru
    if ($p.ExitCode -ne 0) { Write-Error "Vollinstaller Exit $($p.ExitCode)" }
    Copy-Item (Join-Path $FullDir "DLLs\_tkinter.pyd") (Join-Path $PyDir "_tkinter.pyd") -Force
    foreach ($dll in @("tcl86t.dll", "tk86t.dll")) {
        $src = Join-Path $FullDir "DLLs\$dll"
        if (Test-Path $src) { Copy-Item $src (Join-Path $PyDir $dll) -Force }
    }
    $TclDst = Join-Path $PyDir "tcl"
    if (Test-Path $TclDst) { Remove-Item $TclDst -Recurse -Force }
    Copy-Item (Join-Path $FullDir "tcl") $TclDst -Recurse -Force
    New-Item -ItemType Directory -Force -Path (Join-Path $PyDir "Lib") | Out-Null
    $TkDst = Join-Path $PyDir "Lib\tkinter"
    if (Test-Path $TkDst) { Remove-Item $TkDst -Recurse -Force }
    Copy-Item (Join-Path $FullDir "Lib\tkinter") $TkDst -Recurse -Force
    Enable-PipPth
    try { Start-Process -FilePath $Exe -ArgumentList "/uninstall", "/quiet" -Wait -ErrorAction SilentlyContinue | Out-Null } catch { }
    if (Test-Path $FullDir) { Remove-Item $FullDir -Recurse -Force -ErrorAction SilentlyContinue }
    if (-not (Test-Tkinter)) { Write-Error "tkinter fehlt nach Nachzug" }
}

$marker = Join-Path $PyDir "xlounger-python-version.txt"
if ((Test-Path $PyExe) -and (Test-Tkinter)) {
    Set-Content -Path $marker -Value $Version -Encoding ASCII
    if (Test-Path $PyDir) { cmd /c "attrib +h `"$PyDir`"" | Out-Null }
    Say "Laufzeit OK ($Version)."
    exit 0
}

if (-not (Test-Path $PyExe)) { Install-EmbedPython }
if (-not (Test-Tkinter)) { Install-Tkinter }
Set-Content -Path $marker -Value $Version -Encoding ASCII
if (Test-Path $PyDir) { cmd /c "attrib +h `"$PyDir`"" | Out-Null }
Say "Fertig."
exit 0
