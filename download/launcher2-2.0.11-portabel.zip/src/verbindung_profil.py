"""Vollständiger Verbindungs-Steckbrief (Enterprise) — xlounger.

Eine Leisten-Verbindung = entries[]-Zeile + launch-Profil + user_customizations.
Desktop-.lnk ist nur eine Ansicht; Start und Desktop-Neuanlage nutzen launch.

profil_version 1 in jedem launch-Block.
"""
from __future__ import annotations

import copy
import functools
import logging
import os
import shutil
from pathlib import Path
from typing import Any

from .browser_url import browser_url, is_web_url
from .config import stable_id
from .paths import get_appdata_dir

PROFIL_VERSION = 1


def verknuefungen_cache_dir() -> Path:
    d = get_appdata_dir() / "verknuefungen_cache"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _lnk_pfad_kandidaten(entry: dict, launch: dict[str, Any] | None = None) -> list[str]:
    launch = launch or launch_aus_entry(entry)
    out: list[str] = []
    for cand in (
        launch.get("source_lnk"),
        entry.get("target"),
        launch.get("cached_lnk"),
    ):
        p = pfad_lang(str(cand or ""))
        if p and Path(p).suffix.lower() in (".lnk", ".url") and p not in out:
            out.append(p)
    return out


def cache_verknuepfung_fuer_entry(entry: dict) -> str:
    """Kopie der .lnk/.url nach AppData — Start/Desktop auch ohne Desktop-Datei."""
    eid = str(entry.get("id") or stable_id(str(entry.get("target") or "")))
    if not eid:
        return ""
    quelle = ""
    for cand in _lnk_pfad_kandidaten(entry):
        if Path(cand).is_file():
            quelle = cand
            break
    if not quelle:
        alt = str((entry.get("launch") or {}).get("cached_lnk") or "")
        return alt if alt and Path(alt).is_file() else ""

    ext = Path(quelle).suffix.lower()
    ziel = verknuefungen_cache_dir() / f"{eid}{ext}"
    try:
        shutil.copy2(quelle, ziel)
        return str(ziel)
    except OSError as exc:
        logging.warning("Verknuepfungs-Cache fehlgeschlagen %s: %s", quelle, exc)
        return str((entry.get("launch") or {}).get("cached_lnk") or "")


def launch_cache_aktualisieren(entry: dict) -> bool:
    """cached_lnk setzen; optional Pfad aus Cache-.lnk nachlesen."""
    if not isinstance(entry, dict):
        return False
    launch = entry.setdefault("launch", {})
    alt = str(launch.get("cached_lnk") or "")
    cached = cache_verknuepfung_fuer_entry(entry)
    changed = cached != alt
    if cached:
        launch["cached_lnk"] = cached
        if not str(launch.get("path") or "").strip():
            try:
                from .launcher import resolve_lnk

                pth, arg = resolve_lnk(cached)
                if pth:
                    launch["path"] = pfad_lang(pth)
                    changed = True
                if arg and not str(launch.get("args") or "").strip():
                    launch["args"] = str(arg)
                    changed = True
            except Exception:
                pass
    return changed


def pfad_lang(pfad: str) -> str:
    roh = (pfad or "").strip().strip('"')
    if not roh:
        return ""
    try:
        norm = os.path.normpath(roh)
        if os.name == "nt" and os.path.exists(norm):
            buf = __import__("ctypes").create_unicode_buffer(32768)
            if __import__("ctypes").windll.kernel32.GetLongPathNameW(norm, buf, 32768):
                if buf.value:
                    return buf.value
        return norm
    except Exception:
        return os.path.normpath(roh)


def _args_norm(args: str) -> str:
    return " ".join(str(args or "").split())


def _lese_lnk_wscript(lnk_pfad: str) -> dict[str, Any]:
    import win32com.client

    shell = win32com.client.Dispatch("WScript.Shell")
    sc = shell.CreateShortcut(lnk_pfad)
    icon_pfad, icon_index = "", 0
    icon_loc = str(sc.IconLocation or "")
    if icon_loc:
        if "," in icon_loc:
            teile = icon_loc.rsplit(",", 1)
            icon_pfad = teile[0].strip()
            try:
                icon_index = int(teile[1].strip())
            except ValueError:
                icon_index = 0
        else:
            icon_pfad = icon_loc.strip()
    return {
        "profil_version": PROFIL_VERSION,
        "kind": "shortcut",
        "source_lnk": pfad_lang(lnk_pfad),
        "path": pfad_lang(str(sc.TargetPath or "")),
        "args": str(sc.Arguments or ""),
        "workdir": pfad_lang(str(sc.WorkingDirectory or "")),
        "icon_path": pfad_lang(icon_pfad),
        "icon_index": int(icon_index),
        "window_style": int(sc.WindowStyle or 1),
        "hotkey": str(getattr(sc, "Hotkey", "") or ""),
        "description": str(getattr(sc, "Description", "") or ""),
    }


def _lese_url_datei(url_pfad: str) -> dict[str, Any]:
    url = ""
    icon = ""
    icon_index = 0
    hotkey = ""
    try:
        with open(url_pfad, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                if line.startswith("URL="):
                    url = line[4:].strip()
                elif line.startswith("IconFile="):
                    icon = line[9:].strip()
                elif line.startswith("IconIndex="):
                    try:
                        icon_index = int(line[10:].strip())
                    except ValueError:
                        icon_index = 0
                elif line.startswith("HotKey="):
                    hotkey = line[7:].strip()
    except OSError:
        pass
    if url and is_web_url(url):
        url = browser_url(url)
    return {
        "profil_version": PROFIL_VERSION,
        "kind": "url",
        "url": url,
        "source_url_file": pfad_lang(url_pfad),
        # IconFile darf eine Web-URL sein (Favicon) — nicht durch pfad_lang zerlegen
        "icon_path": icon if is_web_url(icon) else pfad_lang(icon),
        "icon_index": int(icon_index),
        "hotkey": hotkey,
        "path": "",
        "args": "",
        "workdir": "",
    }


def profil_aus_quelle(quelle: str) -> dict[str, Any]:
    """Startprofil aus Pfad/URL lesen (Shell, Datei, Verknüpfung)."""
    roh = (quelle or "").strip()
    if not roh:
        return {"profil_version": PROFIL_VERSION, "kind": "unknown"}

    if is_web_url(roh):
        return {
            "profil_version": PROFIL_VERSION,
            "kind": "url",
            "url": browser_url(roh),
            "path": "",
            "args": "",
            "workdir": "",
            "icon_path": "",
            "icon_index": 0,
        }

    low = roh.lower()
    if low.startswith(("ms-settings:", "shell:", "mailto:")):
        return {
            "profil_version": PROFIL_VERSION,
            "kind": "shell",
            "path": roh,
            "args": "",
            "workdir": "",
            "icon_path": "",
            "icon_index": 0,
        }

    lang = pfad_lang(roh)
    p = Path(lang)
    suf = p.suffix.lower()

    if suf == ".lnk":
        if p.is_file():
            try:
                profil = _lese_lnk_wscript(str(p))
                if not str(profil.get("path") or "").strip():
                    try:
                        from .launcher import resolve_lnk

                        pth, arg = resolve_lnk(str(p))
                        if pth:
                            profil["path"] = pfad_lang(pth)
                        if arg:
                            profil["args"] = str(arg)
                    except Exception:
                        pass
                return profil
            except Exception as exc:
                logging.warning("lnk lesen fehlgeschlagen %s: %s", lang, exc)
        return {
            "profil_version": PROFIL_VERSION,
            "kind": "shortcut",
            "source_lnk": lang,
            "path": "",
            "args": "",
            "workdir": "",
            "icon_path": "",
            "icon_index": 0,
        }

    if suf == ".url" and p.is_file():
        return _lese_url_datei(str(p))

    workdir = ""
    if p.is_file():
        workdir = pfad_lang(str(p.parent))
    elif p.is_dir():
        workdir = lang

    return {
        "profil_version": PROFIL_VERSION,
        "kind": "file",
        "path": lang,
        "args": "",
        "workdir": workdir,
        "icon_path": lang if p.is_file() else "",
        "icon_index": 0,
        "source_lnk": "",
    }


def launch_aus_entry(entry: dict | None) -> dict[str, Any]:
    if not entry or not isinstance(entry, dict):
        return {"profil_version": PROFIL_VERSION, "kind": "unknown"}
    launch = entry.get("launch")
    if isinstance(launch, dict) and launch.get("kind"):
        return copy.deepcopy(launch)
    return profil_aus_quelle(str(entry.get("target") or ""))


@functools.lru_cache(maxsize=256)
def _loese_bare_name(name: str) -> str:
    """Kurzname (calc.exe) -> voller PATH-Treffer, sonst leer."""
    try:
        return shutil.which(name) or ""
    except Exception:
        return ""


def ziel_schluessel(launch: dict[str, Any]) -> str:
    """Ein logisches Programm — ein Schlüssel (Duplikat-Erkennung)."""
    kind = str(launch.get("kind") or "")
    if kind == "url":
        return "url:" + browser_url(str(launch.get("url") or "")).casefold()
    if kind == "shell":
        return "shell:" + str(launch.get("path") or "").casefold()
    path = pfad_lang(str(launch.get("path") or "")).casefold()
    if path and not os.path.dirname(path):
        # Kurzname ohne Ordner: auf PATH-Ziel aufloesen — sonst zerfaellt
        # „calc.exe" (Katalog) und „C:\\Windows\\System32\\calc.exe"
        # (aufgeloester Leisten-Eintrag) in zwei Schluessel: Katalog
        # zeigt keinen Haken, Anheften legt ein Duplikat an
        # (Nutzer 07.10.2026: „gruen obwohl nicht auf der Leiste").
        aufgeloest = _loese_bare_name(path)
        if aufgeloest:
            path = pfad_lang(aufgeloest).casefold()
    args = _args_norm(str(launch.get("args") or "")).casefold()
    if not path and kind == "shortcut":
        path = pfad_lang(str(launch.get("source_lnk") or "")).casefold()
    return f"exec:{path}|{args}"


@functools.lru_cache(maxsize=4096)
def ziel_schluessel_fuer_quelle(quelle: str) -> str:
    """Ergebnis gecacht — der Pool-Dedup loest jedes .lnk einmal auf;
    ohne Cache zahlt jede weitere Stelle (Panel „auf Leiste?“ je Zeile)
    denselben COM-Aufruf nochmal (Nutzer 09.10.2026: ~20 s)."""
    return ziel_schluessel(profil_aus_quelle(quelle))


def ziel_fuer_config(quelle: str, launch: dict[str, Any]) -> str:
    """Persistierter target-String — .lnk-Pfad bleibt .lnk."""
    kind = launch.get("kind")
    if kind == "shortcut":
        sl = launch.get("source_lnk") or quelle
        return pfad_lang(str(sl)) or pfad_lang(quelle)
    if kind == "url":
        if launch.get("source_url_file") and Path(str(launch["source_url_file"])).is_file():
            return pfad_lang(str(launch["source_url_file"]))
        return str(launch.get("url") or quelle)
    if kind == "shell":
        return str(launch.get("path") or quelle)
    if launch.get("path"):
        return pfad_lang(str(launch["path"]))
    return pfad_lang(quelle)


def profil_zusammenfuehren(alt: dict[str, Any], neu: dict[str, Any]) -> dict[str, Any]:
    """Neues Profil einarbeiten — vorhandene Felder nicht mit Leerem überschreiben."""
    out = copy.deepcopy(alt) if alt else {}
    for k, v in (neu or {}).items():
        if v is None:
            continue
        if isinstance(v, str) and not v.strip() and out.get(k):
            continue
        if k == "profil_version":
            out[k] = PROFIL_VERSION
            continue
        out[k] = copy.deepcopy(v) if isinstance(v, dict) else v
    out["profil_version"] = PROFIL_VERSION
    return out


def _customizations_verschieben(data: dict, alt_id: str, neu_id: str) -> None:
    if not alt_id or alt_id == neu_id:
        return
    user = data.setdefault("user_customizations", {})
    alt = user.pop(alt_id, None)
    if not alt:
        return
    neu = user.setdefault(neu_id, {})
    for k, v in alt.items():
        if k not in neu:
            neu[k] = v
        elif neu[k] in (None, "", False) and v not in (None, "", False):
            neu[k] = v


def _hwnd_map_verschieben(data: dict, alt_target: str, neu_target: str) -> None:
    if not alt_target or alt_target == neu_target:
        return
    hwnds = data.setdefault("last_window_hwnds", {})
    if alt_target in hwnds and neu_target not in hwnds:
        hwnds[neu_target] = hwnds.pop(alt_target)


def finde_entry_nach_schluessel(entries: list, schluessel: str) -> dict | None:
    for e in entries:
        if not isinstance(e, dict):
            continue
        if ziel_schluessel(launch_aus_entry(e)) == schluessel:
            return e
    return None


def finde_entry_nach_target(entries: list, target: str) -> dict | None:
    t = pfad_lang(target)
    for e in entries:
        if not isinstance(e, dict):
            continue
        et = pfad_lang(str(e.get("target") or ""))
        if et and et == t:
            return e
    return None


_ENTFERNT_MAX = 50


def entfernte_eintraege_merken(data: dict, entfernte: list) -> None:
    """Entfernte Einträge parken — Wieder-Anheften stellt sie vollständig her.

    Ohne das gehen beim Entfernen Launch-Profil-Details (args, icon_path,
    source_lnk, cached_lnk) verloren; ist die Quelle inzwischen weg
    (Desktop-.lnk gelöscht), liefe ein frisch aufgebautes Profil leer.
    """
    if not entfernte:
        return
    removed = data.setdefault("removed_entries", [])
    if not isinstance(removed, list):
        return
    for e in entfernte:
        if not isinstance(e, dict) or not str(e.get("target") or "").strip():
            continue
        schl = ziel_schluessel(launch_aus_entry(e))
        rt = pfad_lang(str(e.get("target") or ""))
        removed[:] = [
            r for r in removed
            if not (
                isinstance(r, dict)
                and (
                    (schl and ziel_schluessel(launch_aus_entry(r)) == schl)
                    or (rt and pfad_lang(str(r.get("target") or "")) == rt)
                )
            )
        ]
        removed.append(copy.deepcopy(e))
    del removed[: max(0, len(removed) - _ENTFERNT_MAX)]


def entfernten_eintrag_nehmen(data: dict, schluessel: str, target: str = "") -> dict | None:
    """Geparkten Eintrag per Ziel-Schlüssel oder Zielpfad herausnehmen (oder None)."""
    removed = data.get("removed_entries")
    if not isinstance(removed, list):
        return None
    rt = pfad_lang(str(target or ""))
    for i, r in enumerate(removed):
        if not isinstance(r, dict):
            continue
        if schluessel and ziel_schluessel(launch_aus_entry(r)) == schluessel:
            return removed.pop(i)
        if rt and pfad_lang(str(r.get("target") or "")) == rt:
            return removed.pop(i)
    return None


def _desktop_ordner() -> list[Path]:
    out: list[Path] = [Path.home() / "Desktop"]
    public = os.environ.get("PUBLIC", "")
    if public:
        out.append(Path(public) / "Desktop")
    return [p for p in out if p.is_dir()]


def finde_desktop_verknuepfung_fuer_entry(entry: dict) -> str | None:
    """Vorhandene Desktop-.lnk/.url mit gleichem Start-Ziel (nicht nur Dateiname)."""
    if not isinstance(entry, dict):
        return None
    target = pfad_lang(str(entry.get("target") or ""))
    if target:
        tpath = Path(target)
        if tpath.suffix.lower() in (".lnk", ".url") and tpath.is_file():
            # Nur wenn die Datei SELBST auf dem Desktop liegt — eine
            # Startmenue-.lnk ist sonst „vorhanden", das Abheften entfernt
            # den Eintrag ohne sichtbares Symbol (08.10.2026).
            desks = {os.path.normcase(str(d)) for d in _desktop_ordner()}
            if os.path.normcase(str(tpath.parent)) in desks:
                return target
    try:
        key = ziel_schluessel(launch_aus_entry(entry))
    except Exception:
        return None
    if not key or key == "exec:|":
        return None
    for desk in _desktop_ordner():
        try:
            for f in desk.iterdir():
                if f.suffix.lower() not in (".lnk", ".url"):
                    continue
                try:
                    fk = ziel_schluessel(profil_aus_quelle(str(f)))
                except Exception:
                    continue
                if fk == key:
                    return pfad_lang(str(f))
        except OSError:
            continue
    return None


def eintrag_einfuegen(
    data: dict,
    quelle: str,
    name: str,
    *,
    insert_idx: int | None = None,
) -> tuple[dict, bool]:
    """Verbindung anlegen oder bestehende anreichern. (entry, neu_angelegt)."""
    entries = data.setdefault("entries", [])
    quelle = (quelle or "").strip()
    neu_launch = profil_aus_quelle(quelle)
    schluessel = ziel_schluessel(neu_launch)
    target = ziel_fuer_config(quelle, neu_launch)
    anzeige = (name or "").strip() or Path(target).stem or target

    bestehend = finde_entry_nach_schluessel(entries, schluessel)
    if bestehend is None:
        bestehend = finde_entry_nach_target(entries, target)

    if bestehend is not None:
        alt_id = str(bestehend.get("id") or "")
        alt_target = str(bestehend.get("target") or "")
        bestehend["launch"] = profil_zusammenfuehren(
            launch_aus_entry(bestehend), neu_launch
        )
        neuer_target = ziel_fuer_config(quelle, bestehend["launch"])
        if neuer_target:
            bestehend["target"] = neuer_target
        if not (bestehend.get("name") or "").strip():
            bestehend["name"] = anzeige
        neue_id = stable_id(str(bestehend.get("target") or ""))
        if neue_id != alt_id:
            bestehend["id"] = neue_id
            _customizations_verschieben(data, alt_id, neue_id)
            _hwnd_map_verschieben(data, alt_target, str(bestehend.get("target") or ""))
        launch_cache_aktualisieren(bestehend)
        return bestehend, False

    # Früher entfernter Eintrag? -> vollständig wiederherstellen (Launch-Profil,
    # eigene Felder, id) statt nur neuem Minimal-Eintrag (Nutzer 07.10.2026).
    wieder = entfernten_eintrag_nehmen(data, schluessel, target)
    if wieder is not None:
        alt_id = str(wieder.get("id") or "")
        alt_target = str(wieder.get("target") or "")
        wieder["launch"] = profil_zusammenfuehren(
            launch_aus_entry(wieder), neu_launch
        )
        neuer_target = ziel_fuer_config(quelle, wieder["launch"])
        if neuer_target:
            wieder["target"] = neuer_target
        if not (wieder.get("name") or "").strip():
            wieder["name"] = anzeige
        neue_id = stable_id(str(wieder.get("target") or ""))
        if neue_id != alt_id:
            wieder["id"] = neue_id
            _customizations_verschieben(data, alt_id, neue_id)
            _hwnd_map_verschieben(data, alt_target, str(wieder.get("target") or ""))
        idx = len(entries) if insert_idx is None else max(0, min(insert_idx, len(entries)))
        entries.insert(idx, wieder)
        launch_cache_aktualisieren(wieder)
        return wieder, True

    entry = {
        "name": anzeige,
        "target": target,
        "id": stable_id(target),
        "launch": neu_launch,
    }
    if insert_idx is None:
        entries.append(entry)
    else:
        entries.insert(max(0, min(insert_idx, len(entries))), entry)
    launch_cache_aktualisieren(entry)
    return entry, True


def migriere_entry(entry: dict) -> bool:
    """launch-Profil nachrüsten / aktualisieren."""
    if not isinstance(entry, dict):
        return False
    target = str(entry.get("target") or "").strip()
    if not target:
        return False
    alt = launch_aus_entry(entry)
    neu = profil_aus_quelle(target)
    merged = profil_zusammenfuehren(alt, neu)
    changed = merged != alt or "launch" not in entry
    entry["launch"] = merged
    if not entry.get("id"):
        entry["id"] = stable_id(target)
    if launch_cache_aktualisieren(entry):
        changed = True
    return changed


def nach_erfolgreichem_start(entry: dict) -> bool:
    """Nach Start: Profil + Cache aus noch vorhandener Quelle aktualisieren."""
    if not isinstance(entry, dict):
        return False
    changed = False
    target = str(entry.get("target") or "").strip()
    if target and Path(target).is_file():
        neu = profil_aus_quelle(target)
        entry["launch"] = profil_zusammenfuehren(launch_aus_entry(entry), neu)
        changed = True
    if launch_cache_aktualisieren(entry):
        changed = True
    return changed


def migriere_config(data: dict) -> bool:
    """Alle Einträge + HWND-Keys auf Steckbrief-Stand bringen."""
    changed = False
    entries = data.get("entries")
    if not isinstance(entries, list):
        return False
    for e in entries:
        if migriere_entry(e):
            changed = True
        elif launch_cache_aktualisieren(e):
            changed = True
    return changed


def effektive_verknuepfung(launch: dict[str, Any]) -> str:
    """Beste .lnk/.url zum Starten: Cache, Quelle, Ziel."""
    for key in ("cached_lnk", "source_lnk"):
        p = pfad_lang(str(launch.get(key) or ""))
        if p and Path(p).is_file():
            return p
    return ""


def icon_fuer_entry(entry: dict) -> tuple[str, int]:
    launch = launch_aus_entry(entry)
    ip = pfad_lang(str(launch.get("icon_path") or ""))
    idx = int(launch.get("icon_index") or 0)
    if ip and os.path.exists(ip):
        return ip, idx
    path = str(launch.get("path") or entry.get("target") or "")
    if path:
        p = Path(pfad_lang(path))
        if p.is_file():
            return str(p), 0
    sl = str(launch.get("source_lnk") or "")
    if sl and Path(sl).is_file():
        return sl, 0
    return "", 0


def desktop_felder_aus_entry(entry: dict) -> dict[str, str]:
    """Felder für WScript.Shell CreateShortcut."""
    launch = launch_aus_entry(entry)
    name = str(entry.get("name") or "Verknüpfung")
    kind = launch.get("kind")
    if kind == "url":
        cached = str(launch.get("cached_lnk") or "")
        if cached and Path(cached).suffix.lower() == ".url" and Path(cached).is_file():
            return {"kind": "copy_lnk", "copy_from": cached, "name": name}
        quelle = str(launch.get("source_url_file") or "")
        if quelle and Path(quelle).is_file():
            return {"kind": "copy_lnk", "copy_from": quelle, "name": name}
        return {
            "kind": "url",
            "url": str(launch.get("url") or ""),
            "icon_path": str(launch.get("icon_path") or ""),
            "icon_index": str(launch.get("icon_index") or 0),
            "hotkey": str(launch.get("hotkey") or ""),
            "name": name,
        }
    if kind == "shortcut":
        kopie = effektive_verknuepfung(launch)
        if kopie and Path(kopie).is_file() and Path(kopie).suffix.lower() == ".lnk":
            return {"kind": "copy_lnk", "copy_from": kopie, "name": name}
    ziel = str(launch.get("path") or "")
    args = str(launch.get("args") or "")
    workdir = str(launch.get("workdir") or "")
    icon_path, icon_index = icon_fuer_entry(entry)
    if kind == "shell":
        # shell:RecycleBinFolder ist kein Dateipfad — als .lnk-Target kaeme
        # ein toter Link raus (Nutzer 07.10.2026: Desktop-„Drucker" zeigte
        # Blanko-Icon, Ziel „C:\…\Desktop\control printers").
        args = (ziel + " " + args).strip()
        ziel = str(Path(os.environ.get("WINDIR", r"C:\Windows")) / "explorer.exe")
    elif ziel and not os.path.dirname(ziel) and not os.path.isfile(ziel):
        # Bare-Kommandos („control printers", „taskmgr") auf PATH aufloesen.
        treffer = _loese_bare_name(ziel)
        if not treffer and " " in ziel:
            kopf, _, rest = ziel.partition(" ")
            treffer = _loese_bare_name(kopf)
            if treffer:
                rest = rest.strip()
                if rest:
                    args = (rest + " " + args).strip()
        if treffer:
            ziel = treffer
        elif ":" in ziel:
            # Protokoll-Ziel (ms-settings:) — ueber explorer.exe startbar.
            args = (ziel + " " + args).strip()
            ziel = str(Path(os.environ.get("WINDIR", r"C:\Windows")) / "explorer.exe")
        else:
            # Unloesbares Kommando -> lieber keine kaputte Verknuepfung.
            ziel = ""
    if not ziel and kind == "shortcut":
        kopie = effektive_verknuepfung(launch)
        if kopie:
            return {"kind": "copy_lnk", "copy_from": kopie, "name": name}
        ziel = str(entry.get("target") or "")
    return {
        "kind": "lnk",
        "target_path": ziel,
        "arguments": args,
        "workdir": workdir,
        "icon_path": icon_path,
        "icon_index": icon_index,
        "window_style": str(launch.get("window_style") or ""),
        "hotkey": str(launch.get("hotkey") or ""),
        "description": str(launch.get("description") or ""),
        "name": name,
    }
