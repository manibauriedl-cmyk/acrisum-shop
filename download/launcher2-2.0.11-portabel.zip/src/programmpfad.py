"""Installationspfad — fehlende/veraltete Ziele auflösen (lokal, UNC, Netz; kein C:-Zwang)."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

from .browser_url import is_web_url

_STRATA_EXE_SCRIPT = Path(
    os.environ.get("WINSU_SCRIPTS", r"C:\zzz-winsu-entwickler\scripts")
) / "strata_desktop_exe.py"


def _ist_datei(pfad: str) -> bool:
    if not pfad:
        return False
    try:
        return os.path.isfile(pfad)
    except OSError:
        return False


def menue_punkt_sinnvoll(target: str) -> bool:
    """Rechtsklick „Installationspfad aktualisieren…“ — für alles außer Web/System-URLs."""
    t = (target or "").strip()
    if not t:
        return False
    low = t.lower()
    if is_web_url(t):
        return False
    if low.startswith(("ms-settings:", "shell:", "mailto:")):
        return False
    return True


def _strata_desktop_exe() -> str | None:
    if not _STRATA_EXE_SCRIPT.is_file():
        return None
    py = sys.executable if (sys.executable or "").strip() else "python"
    try:
        out = subprocess.check_output(
            [py, str(_STRATA_EXE_SCRIPT), "--print"],
            text=True,
            errors="replace",
            timeout=30,
            cwd=str(_STRATA_EXE_SCRIPT.parent),
        ).strip()
    except (subprocess.SubprocessError, OSError):
        return None
    return out if out and _ist_datei(out) else None


def _exe_kandidat_aus_target(stored: str) -> str:
    """Aus .lnk oder Pfad die startbare EXE ableiten."""
    z = (stored or "").strip().strip('"')
    if not z:
        return z
    if z.lower().endswith(".lnk") and _ist_datei(z):
        try:
            from .launcher import resolve_lnk

            pth, _args = resolve_lnk(z)
            if pth:
                return pth.strip()
        except Exception:
            pass
    return z


def programm_ziel_aufgeloest(ziel: str) -> str:
    """Echten Pfad finden, wenn gespeicherter fehlt — UNC/lokal unverändert wenn vorhanden."""
    z = (ziel or "").strip().strip('"')
    if not z:
        return z
    if _ist_datei(z):
        return z

    inner = _exe_kandidat_aus_target(z)
    if inner != z and _ist_datei(inner):
        return inner

    name = Path(inner or z).name
    if name.lower().endswith(".exe"):
        if name.casefold() == "strata-desktop.exe":
            resolved = _strata_desktop_exe()
            if resolved:
                return resolved
        w = shutil.which(name)
        if w and _ist_datei(w):
            return w

    if Path(z).name.casefold() == "strata-desktop.exe":
        resolved = _strata_desktop_exe()
        if resolved:
            return resolved

    return z


def eintrag_installationspfad_aktualisieren(
    entry: dict,
    *,
    manuell: str | None = None,
) -> tuple[dict, str, bool]:
    stored = str(entry.get("target") or "").strip()
    if not stored:
        return entry, "Kein Ziel gespeichert.", False

    resolved = (manuell or "").strip().strip('"') or programm_ziel_aufgeloest(
        _exe_kandidat_aus_target(stored)
    )
    if not resolved or not _ist_datei(resolved):
        return (
            entry,
            "Kein Programm gefunden.\n\n"
            f"Gespeichert:\n{stored}\n\n"
            "Bitte die .exe oder Verknüpfung manuell wählen.",
            False,
        )

    if stored == resolved and _ist_datei(stored):
        return entry, f"Pfad ist bereits aktuell:\n{resolved}", False

    neu = dict(entry)
    neu["target"] = resolved
    neu.pop("launch", None)
    return neu, f"Installationspfad aktualisiert:\n\n{resolved}", True
