"""Startmenü-Verknüpfung automatisch pflegen (KVA 193).

Beim Start prüfen: liegt eine aktuelle xlounger-Verknüpfung im
Startmenü? Fehlt sie oder zeigt sie noch auf einen alten Pfad
(z. B. nach Ordner-Umzug), wird sie (neu) geschrieben.

Fehler hier dürfen den xlounger-Start nie verhindern — Aufrufer
fangt alles ab und loggt nur.
"""
from __future__ import annotations

import gc
import logging
import os
from pathlib import Path

from .app_id import APP_DISPLAY_NAME, APP_NAME

ROOT = Path(__file__).resolve().parent.parent
LINK_NAME = f"{APP_NAME}.lnk"


def startmenue_ordner() -> Path:
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return Path(base) / "Microsoft" / "Windows" / "Start Menu" / "Programs"


def link_pfad() -> Path:
    return startmenue_ordner() / LINK_NAME


def _pythonw() -> str:
    import launcher2_prozess

    return launcher2_prozess.pythonw()


def _norm(p: str) -> str:
    return os.path.normcase(os.path.normpath((p or "").strip().strip('"')))


def _icon_setzen(shortcut) -> None:
    ico = ROOT / "assets" / "xlounger.ico"
    if ico.is_file():
        shortcut.IconLocation = f"{ico},0"


def _befuellen(shortcut, ziel: str, skript: str) -> None:
    shortcut.TargetPath = ziel
    shortcut.Arguments = f'"{skript}"'
    shortcut.WorkingDirectory = str(ROOT)
    shortcut.Description = f"{APP_DISPLAY_NAME} — Leiste"
    _icon_setzen(shortcut)
    shortcut.Save()


def _aumid_an_link(pfad: Path) -> None:
    """KVA 224 — AUMID-Property: Start ueber Startmenue gruppiert mit dem
    laufenden Fenster. Fehler nur loggen, Verknuepfung bleibt gueltig.

    Muss NACH Freigabe des Shortcut-COM-Objekts laufen — das haelt die
    Datei sonst gesperrt (0x80070020).
    """
    try:
        from src.taskleiste import lnk_aumid_setzen

        lnk_aumid_setzen(pfad)
    except Exception as exc:
        logging.warning("AUMID an Startmenü-Verknüpfung fehlgeschlagen: %s", exc)


def _link_hat_aumid(pfad: Path) -> bool:
    """True wenn die Verknüpfung schon die AUMID-Property trägt."""
    try:
        from win32com import storagecon
        from win32com.propsys import propsys, pscon

        store = propsys.SHGetPropertyStoreFromParsingName(
            str(pfad), None, storagecon.STGM_READ, propsys.IID_IPropertyStore
        )
        from src.taskleiste import AUMID

        return store.GetValue(pscon.PKEY_AppUserModel_ID).GetValue() == AUMID
    except Exception:
        return False


def pflegen() -> str:
    """Startmenü-Verknüpfung anlegen oder reparieren.

    Rückgabe: "neu" | "aktualisiert" | "ok" | "fehler".
    """
    try:
        import win32com.client
    except ImportError:
        logging.warning("startmenue: pywin32 fehlt — keine Verknüpfung gepflegt")
        return "fehler"

    ziel = _pythonw()
    skript = str(ROOT / "launcher2.py")
    pfad = link_pfad()
    shell = win32com.client.Dispatch("WScript.Shell")

    if pfad.is_file():
        sc = shell.CreateShortcut(str(pfad))
        if (
            _norm(sc.TargetPath) == _norm(ziel)
            and _norm(sc.Arguments) == _norm(skript)
            and _norm(sc.WorkingDirectory) == _norm(str(ROOT))
        ):
            sc = None  # COM-Objekt freigeben vor IPropertyStore
            gc.collect()
            if _link_hat_aumid(pfad):
                return "ok"
            _aumid_an_link(pfad)
            logging.info("Startmenü-Verknüpfung: AUMID nachgesetzt")
            return "aktualisiert"
        _befuellen(sc, ziel, skript)
        sc = None  # COM-Objekt freigeben, sonst Dateisperre beim AUMID-Setzen
        gc.collect()
        _aumid_an_link(pfad)
        logging.info("Startmenü-Verknüpfung aktualisiert: %s", pfad)
        return "aktualisiert"

    pfad.parent.mkdir(parents=True, exist_ok=True)
    sc = shell.CreateShortcut(str(pfad))
    _befuellen(sc, ziel, skript)
    sc = None  # COM-Objekt freigeben, sonst Dateisperre beim AUMID-Setzen
    gc.collect()
    _aumid_an_link(pfad)
    logging.info("Startmenü-Verknüpfung angelegt: %s", pfad)
    return "neu"
