"""Leiste am Griff ziehen — KVA 35 Live, Loslassen = E6 (_dock_to / _float_at)."""
import ctypes
import logging
import tkinter as tk
from .win32_optional import win32con, win32gui
from .. import monitors
from .. import layout


class LeisteDragMixin:
    def _init_leiste_drag_zustand(self) -> None:
        self._appbar_abgemeldet = False
        self._drag_motion_bind = None
        self._drag_release_bind = None
        self._drag_poll_job = None
        self._drag_arm_release = False
        self._drag_had_down = False
        self._drag_up_ticks = 0
        self._drag_offset = None
        self._drag_wh: tuple[int, int] | None = None
        self._drag_wh_cap: tuple[int, int] | None = None
        self._drag_live_anzahl: tuple[int, int] | None = None
        self._drag_live_gem: tuple[int, int] | None = None
        self._drag_live_dock: str | None = None
        self._drag_dock_wechsel = False
        self._drag_free_rect: tuple[int, int, int, int] | None = None
        self._inventur_armiert: str | None = None
        self._inventur_laenge: int | None = None
        self._drag_live_budget_w: int | None = None
        self._drag_live_budget_h: int | None = None
        self._drag_last_rect: tuple[int, int, int, int] | None = None
        self._dragging = False
        self._drag_monitor = None
        self._drag_motion_pending = None
        self._drag_motion_flush_job = None
        self._drag_split_deferred = False

    def _bind_drag_handle(self, widget) -> None:
        widget.bind("<Button-1>", self._drag_start)
        widget.bind("<ButtonRelease-1>", self._grip_release)
        widget.bind("<Button-3>", self._grip_menu_klick)

    def _drag_abort(self) -> None:
        self._drag_offset = None
        self._drag_wh = None
        self._drag_wh_cap = None
        self._drag_live_anzahl = None
        self._drag_live_gem = None
        self._drag_live_dock = None
        self._drag_dock_wechsel = False
        self._drag_live_budget_w = None
        self._drag_live_budget_h = None
        self._drag_last_rect = None
        self._drag_free_rect = None
        self._dragging = False
        self._drag_monitor = None
        self._drag_motion_pending = None
        self._drag_split_deferred = False
        job = self._drag_motion_flush_job
        if job is not None:
            try:
                self.root.after_cancel(job)
            except tk.TclError:
                pass
            self._drag_motion_flush_job = None
        self._drag_unbind()
        self._fenster_groesse_freigeben()
        try:
            self.root.grab_release()
        except tk.TclError:
            pass
        if self._appbar_abgemeldet and self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:
            self._appbar_abgemeldet = False
            try:
                self._dock_to(self.docked, save=False)
            except tk.TclError:
                pass

    def _drag_unbind(self) -> None:
        job = self._drag_poll_job
        if job is not None:
            try:
                self.root.after_cancel(job)
            except tk.TclError:
                pass
            self._drag_poll_job = None
        if self._drag_motion_bind:
            try:
                self.root.unbind_all("<B1-Motion>")
            except tk.TclError:
                pass
            self._drag_motion_bind = None
        if self._drag_release_bind:
            try:
                self.root.unbind_all("<ButtonRelease-1>")
            except tk.TclError:
                pass
            self._drag_release_bind = None

    @staticmethod
    def _maus_links_unten() -> bool:
        try:
            return bool(ctypes.windll.user32.GetAsyncKeyState(0x01) & 0x8000)
        except Exception:
            return True

    @staticmethod
    def _cursor_root() -> tuple[int, int]:
        class _POINT(ctypes.Structure):
            _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

        pt = _POINT()
        ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
        return int(pt.x), int(pt.y)

    def _drag_poll_loslassen(self) -> None:
        """Fallback, falls Tk den Release verschluckt (overrideredirect).

        Commit sofort beim ersten Hoch-Takt — nicht 3×30 ms warten
        (sonst Nachhol-Sprung ~90 ms, Messung 05.10.2026).
        """
        self._drag_poll_job = None
        if self._drag_offset is None:
            return
        if self._maus_links_unten():
            self._drag_had_down = True
            self._drag_poll_job = self.root.after(16, self._drag_poll_loslassen)
            return
        cx, cy = self._cursor_root()

        class _E:
            pass

        ev = _E()
        ev.x_root, ev.y_root = cx, cy
        self._drag_end(ev)

    def _drag_arm_loslassen(self) -> None:
        if self._drag_offset is not None:
            self._drag_arm_release = True

    def _drag_fenster_rect_lesen(self) -> tuple[int, int, int, int]:
        try:
            w = int(self.root.winfo_width())
            h = int(self.root.winfo_height())
            x = int(self.root.winfo_x())
            y = int(self.root.winfo_y())
        except tk.TclError:
            x, y = self._wx, self._wy
            w, h = self._drag_wh or (self.float_w, self.float_h)
        if win32gui:
            try:
                left, top, right, bottom = win32gui.GetWindowRect(self._toplevel_hwnd())
                x, y = int(left), int(top)
                w, h = int(right - left), int(bottom - top)
            except Exception:
                pass
        return x, y, w, h

    def _drag_commit_rect(self) -> tuple[int, int, int, int]:
        if self._drag_last_rect is not None:
            return self._drag_last_rect
        return (
            int(self.root.winfo_x()),
            int(self.root.winfo_y()),
            int(self.root.winfo_width()),
            int(self.root.winfo_height()),
        )

    def _drag_monitor_aktuell(self):
        m = getattr(self, "_drag_monitor", None)
        if m is not None:
            return m
        return monitors.get_primary_monitor() or self.monitor

    def _drag_fenster_setzen(self, x: int, y: int, w: int, h: int) -> None:
        ix, iy, iw, ih = int(x), int(y), int(w), int(h)
        if win32gui and win32con:
            try:
                hwnd = self._toplevel_hwnd()
                if hwnd:
                    flags = (
                        win32con.SWP_NOACTIVATE
                        | win32con.SWP_NOZORDER
                        | win32con.SWP_NOOWNERZORDER
                    )
                    if getattr(self, "_dragging", False):
                        flags |= getattr(win32con, "SWP_NOCOPYBITS", 0x0010)
                    win32gui.SetWindowPos(
                        hwnd,
                        0,
                        ix,
                        iy,
                        iw,
                        ih,
                        flags,
                    )
                    return
            except Exception:
                pass
        try:
            self.root.geometry(f"{iw}x{ih}+{ix}+{iy}")
        except tk.TclError:
            pass

    def _drag_start(self, event):
        self._grip_menu_opened = False
        self._ueberlauf_schliessen()
        self._icon_drag_abbrechen()
        self._drag_unbind()
        try:
            self.root.focus_force()
        except tk.TclError:
            pass
        self._dx = int(event.x_root)
        self._dy = int(event.y_root)
        self._wx = int(self.root.winfo_x())
        self._wy = int(self.root.winfo_y())
        self._dragging = False
        self._drag_had_down = True
        self._drag_arm_release = False
        self._drag_offset = (
            int(event.x_root) - self._wx,
            int(event.y_root) - self._wy,
        )
        try:
            self._drag_wh = (
                int(self.root.winfo_width()),
                int(self.root.winfo_height()),
            )
        except tk.TclError:
            self._drag_wh = (self.float_w, self.float_h)
        self._drag_monitor = monitors.get_primary_monitor() or self.monitor
        self._drag_motion_bind = self.root.bind_all("<B1-Motion>", self._drag)
        self._drag_release_bind = self.root.bind_all("<ButtonRelease-1>", self._drag_end)
        self._drag_poll_job = self.root.after(16, self._drag_poll_loslassen)

    def _drag_motion_flush(self) -> None:
        self._drag_motion_flush_job = None
        ev = self._drag_motion_pending
        if ev is None:
            return
        self._drag_motion_pending = None
        self._drag_apply(ev)

    def _drag_zeiger_sofort(self, event) -> None:
        """Fenster sofort unter den Zeiger — ohne auf Split/Idle zu warten."""
        if not getattr(self, "_dragging", False) or self._drag_offset is None:
            return
        nx = int(event.x_root) - int(self._drag_offset[0])
        ny = int(event.y_root) - int(self._drag_offset[1])
        last = self._drag_last_rect
        if not last:
            return
        _lx, _ly, lw, lh = last
        if _lx == nx and _ly == ny:
            return
        self._drag_fenster_setzen(nx, ny, int(lw), int(lh))

    def _drag(self, event):
        self._drag_zeiger_sofort(event)
        self._drag_motion_pending = event
        if self._drag_motion_flush_job is not None:
            return
        # after(0), nicht after_idle — sonst haengt die Leiste hinter der Maus.
        self._drag_motion_flush_job = self.root.after(0, self._drag_motion_flush)

    def _drag_apply(self, event):
        """Ein Tk-Frame pro Maus-Tick — weniger Ruckeln bei schnellem Zug."""
        if self._drag_offset is None:
            return
        if self._maus_links_unten():
            self._drag_had_down = True
        nx = int(event.x_root) - self._drag_offset[0]
        ny = int(event.y_root) - self._drag_offset[1]
        if not self._dragging:
            if (
                abs(event.x_root - self._dx) < layout.DRAG_START_PX
                and abs(event.y_root - self._dy) < layout.DRAG_START_PX
            ):
                return
            self._dragging = True
            # Reservierung waehrend Zug BEHALTEN (01.10.2026 / REIHENFOLGE E6):
            # kein ABM_REMOVE, kein SETPOS-Kaskade — ein Apply beim Loslassen.
            x, y, w, h = self._drag_fenster_rect_lesen()
            self._wx, self._wy = x, y
            self._drag_wh = (w, h)
            m = self._drag_monitor_aktuell()
            wl, wt, wr, wb = layout._work_tuple(m)
            self._drag_wh_cap = (
                max(layout.MIN_CONTENT_LENGTH, int(wr) - int(wl)),
                max(layout.MIN_CONTENT_LENGTH, int(wb) - int(wt)),
            )
            self._drag_live_anzahl = None
            self._drag_live_gem = None
            self._drag_live_dock = None
            self._drag_live_budget_w = None
            self._drag_live_budget_h = None
            self._drag_last_rect = (x, y, w, h)
            self._drag_free_rect = (x, y, w, h)
            self._drag_offset = (int(event.x_root) - x, int(event.y_root) - y)
            nx, ny = int(x), int(y)
            self._drag_fenster_setzen(x, y, w, h)
            self._fenster_groesse_fixieren(w, h)
            try:
                self.root.grab_set()
            except tk.TclError:
                pass
        w0, h0 = self._drag_wh or (self.float_w, self.float_h)
        # Kein detect_dock waehrend des Zugs — die 5-%-Zone zeigt nur die
        # Vorschau der Kante (Inventur); entschieden wird in _drag_end.
        nx, ny, w, h = self._drag_live_geometry(
            nx,
            ny,
            int(w0),
            int(h0),
            drop_x=int(event.x_root),
            drop_y=int(event.y_root),
        )
        nx, ny, w, h = self._drag_live_split_anwenden(nx, ny, w, h)
        if (
            self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER
            and self._drag_live_dock != self.docked
            and not self._appbar_abgemeldet
        ):
            appbar = getattr(self, "appbar", None)
            if appbar is not None:
                self._sync_appbar_hwnd()
                appbar.unregister()
            self._appbar_abgemeldet = True
        if self._drag_live_dock == layout.DOCK_FREE:
            self._drag_free_rect = (nx, ny, w, h)
        if self._drag_last_rect == (nx, ny, w, h):
            return
        self._drag_last_rect = (nx, ny, w, h)
        self._drag_fenster_setzen(nx, ny, w, h)

    def _drag_zone_dock(
        self,
        nx: int,
        ny: int,
        w: int,
        h: int,
        px: int | None,
        py: int | None,
        m,
    ) -> str:
        """Welche Kante liegt in ihrer 5-%-Zone — Zeiger ODER Leistenrand.

        Ohne Zeiger (px/py None) zaehlen nur die Leistenraender — so ruft
        der Commit-Weg dieselbe Entscheidung wie der Zug. Eigene Kante
        klebt (wie detect_dock): bleibt sie in Zone, gilt sie.
        """
        sl, st, sr, sb = layout._monitor_tuple(m)
        wl, wt, wr, wb = layout._work_tuple(m)
        zx = max(layout.SNAP_SIDE_PX, int((sr - sl) * layout.ZONE_FRACTION_LEFT))
        zy = max(layout.SNAP_PX, int((sb - st) * layout.ZONE_FRACTION_Y))

        def _min(*distanzen: int | None) -> int:
            return min(d for d in distanzen if d is not None)

        cur_l = max(0, px - wl) if px is not None else None
        cur_r = max(0, wr - px) if px is not None else None
        cur_t = max(0, py - wt) if py is not None else None
        cur_b = max(0, wb - py) if py is not None else None
        # Ueberstand gegen die physische Kante messen: eine angedockte Leiste
        # steht bewusst IN ihrer Reservierung (ny < wt) — nur wer tief hinter
        # den physischen Rand ragt, drueckt nicht „in die Zone".
        ueber = layout.EDGE_DOCK_PX
        # Ankerkante der Freiform (senkrechte Form: unten, quer: rechts):
        # dort liegt die Leistenkante durch die „immer bis Arbeitsbereich"-
        # Regel zwangslaeufig auf 0 — nur der Zeiger darf sie ausloesen
        # (Nutzer 07.10.2026), sonst dockt jede freie Ablage sofort.
        # Gilt nur im Alle-Modus (slot_limit None): bei Slot-Fixzahl ist
        # die Leiste kompakt — ihre Kante am Rand ist echte Absicht.
        anker = (
            (layout.DOCK_BOTTOM if int(h) > int(w) else layout.DOCK_RIGHT)
            if getattr(self, "slot_limit", None) is None
            else None
        )

        def _rand(kante: str, cur: int | None, kanten_d: int) -> int | None:
            if anker is not None and kante == anker:
                return cur
            return _min(cur, kanten_d)

        zu_rand = {
            layout.DOCK_LEFT: (_rand(layout.DOCK_LEFT, cur_l, max(0, nx - wl)), zx, nx - sl),
            layout.DOCK_RIGHT: (_rand(layout.DOCK_RIGHT, cur_r, max(0, wr - (nx + w))), zx, sr - (nx + w)),
            layout.DOCK_TOP: (_rand(layout.DOCK_TOP, cur_t, max(0, ny - wt)), zy, ny - st),
            layout.DOCK_BOTTOM: (_rand(layout.DOCK_BOTTOM, cur_b, max(0, wb - (ny + h))), zy, sb - (ny + h)),
        }
        # Leistenrand zaehlt nur, wenn er die Kante hoechstens knapp
        # ueberfaehrt — eine hohe Leiste, deren Rand bereits tief drueber
        # liegt, drueckt nicht „in die Zone" (sonst Vorschau ohne Absicht).
        # Steht der Zeiger selbst in der Zone, gilt die Kante trotzdem.
        cur_zone = {
            layout.DOCK_LEFT: cur_l,
            layout.DOCK_RIGHT: cur_r,
            layout.DOCK_TOP: cur_t,
            layout.DOCK_BOTTOM: cur_b,
        }
        in_zone = {}
        for k, (d, z, vorzeichen) in zu_rand.items():
            if d is None or d > z:
                continue
            if vorzeichen < -ueber:
                cd = cur_zone[k]
                if cd is None or cd > z:
                    continue
            in_zone[k] = d
        if not in_zone:
            return layout.DOCK_FREE
        if self.docked in in_zone:
            return self.docked
        if self.docked in layout.DOCK_CORNER:
            # Eck-Dock klebt ueber seine beiden Elternkanten.
            eltern = {
                layout.DOCK_TOP_LEFT: (layout.DOCK_TOP, layout.DOCK_LEFT),
                layout.DOCK_TOP_RIGHT: (layout.DOCK_TOP, layout.DOCK_RIGHT),
                layout.DOCK_BOTTOM_LEFT: (layout.DOCK_BOTTOM, layout.DOCK_LEFT),
                layout.DOCK_BOTTOM_RIGHT: (layout.DOCK_BOTTOM, layout.DOCK_RIGHT),
            }[self.docked]
            if any(p in in_zone for p in eltern):
                return self.docked
        return min(in_zone, key=in_zone.get)

    def _drag_live_geometry(
        self,
        nx: int,
        ny: int,
        w: int,
        h: int,
        drop_x: int | None = None,
        drop_y: int | None = None,
    ) -> tuple[int, int, int, int]:
        """Ausserhalb 5 %: Status quo. In der Zone: Vorschau der Kante live.

        Kein detect_dock hier — die Entscheidung bleibt _drag_end. Die Zone
        zeigt nur die Konsequenz (Inventur-Modell, Nutzer 05.10.2026).
        """
        m = self._drag_monitor_aktuell()
        sl, st, sr, sb = layout._monitor_tuple(m)
        wl, wt, wr, wb = layout._work_tuple(m)
        cap_w, cap_h = self._drag_wh_cap or (w, h)
        w = max(1, int(w))
        h = max(1, int(h))
        live_dock = self._drag_zone_dock(
            nx,
            ny,
            w,
            h,
            int(drop_x) if drop_x is not None else None,
            int(drop_y) if drop_y is not None else None,
            m,
        )
        prev = getattr(self, "_drag_live_dock", None)
        self._drag_live_dock = live_dock
        if prev is not None and prev != live_dock:
            self._drag_live_anzahl = None
            self._drag_live_gem = None
            self._drag_dock_wechsel = True
        if live_dock != self.docked and live_dock in layout.DOCK_EDGE | layout.DOCK_CORNER:
            # Fremde Kante im Blick: die gezogene Form bleibt unter dem Griff —
            # kein Umformen/Zucken mitten im Zug. Gedockt + geformt wird erst
            # beim Loslassen (detect_dock -> _dock_to).
            return layout.clamp_bar_geometry(
                nx, ny, int(w), int(h), m, layout.DOCK_FREE, ecken_andocken=False
            )
        if live_dock == layout.DOCK_FREE or self.docked == layout.DOCK_FREE:
            # Frei: die Leiste folgt dem Griff, aber ihre Laenge reicht IMMER
            # bis zum Arbeitsbereich-Rand — senkrechte Form y->wb, quer
            # x->wr. „Die Wahrheit zum Rand" (Nutzer 07.10.2026): hoeher
            # gezogen = laenger, runter = kuerzer; »N zaehlt den Rest.
            # Ausnahme wie bei den Dock-Pfaden oben: fester Slot-Modus
            # bestimmt die Laenge selbst — die gezogene Form bleibt.
            if getattr(self, "slot_limit", None) is None:
                if int(h) > int(w):
                    h = max(layout.MIN_CONTENT_LENGTH, int(wb) - int(ny))
                else:
                    w = max(layout.MIN_CONTENT_LENGTH, int(wr) - int(nx))
            return layout.clamp_bar_geometry(
                nx, ny, int(w), int(h), m, layout.DOCK_FREE,
                ecken_andocken=False,
            )
        if layout.is_horizontal(self.docked) or self.docked in layout.DOCK_CORNER:
            # Entlang Kante: Anker physisch (sl), Rest bis wr (KVA 35 / Regel 38).
            # Nicht nx auf wl ziehen — sonst Griff-Sprung nach rechts.
            if getattr(self, "slot_limit", None) is not None:
                nx = max(
                    int(wl),
                    min(int(nx), int(wr) - max(layout.MIN_CONTENT_LENGTH, int(w))),
                )
                nw = int(w)
            else:
                nx = max(int(sl), min(int(nx), int(wr) - layout.MIN_CONTENT_LENGTH))
                nw = max(layout.MIN_CONTENT_LENGTH, min(int(cap_w), int(wr) - nx))
            if "bottom" in self.docked:
                start_y = getattr(self, "_wy", None)
                # Gemessene Lage halten — nicht auf wb-h hochschieben
                # (Nutzer: 1 mm nach links, Sprung hoch, Loslassen wieder runter).
                ny = int(start_y) if start_y is not None else int(wb) - int(h)
            else:
                start_y = getattr(self, "_wy", None)
                if start_y is not None:
                    ny = int(start_y)
                else:
                    ny = int(st)
                    strip = getattr(self, "_appbar_strip_rect", None)
                    if strip and getattr(self.appbar, "registered", False):
                        ny = layout.strip_echo_y_top(m, strip[1], ny)
            return layout.clamp_bar_geometry(
                nx, ny, nw, int(h), m, self.docked,
                ecken_andocken=False, anker_halten=True,
            )
        if self.docked in layout.DOCK_VERTICAL:
            # Kante = gemessene Startlage beim Zug, sonst physischer Rand.
            # Sonst: Fenster steht auf wl=86, Live setzt sl=0 → Sprung 86↔0
            # (Live-Messung 05.10.2026, 17:05, 1 ms / 9 ms).
            start_x = getattr(self, "_wx", None)
            if start_x is None:
                kanten_x = sr - int(w) if self.docked == layout.DOCK_RIGHT else sl
            else:
                kanten_x = int(start_x)
            if getattr(self, "slot_limit", None) is not None:
                ny = max(
                    int(wt),
                    min(int(ny), int(wb) - max(layout.MIN_CONTENT_LENGTH, int(h))),
                )
                nh = int(h)
            else:
                ny = max(int(wt), min(int(ny), int(wb) - layout.MIN_CONTENT_LENGTH))
                nh = max(layout.MIN_CONTENT_LENGTH, min(int(cap_h), int(wb) - ny))
            nx = kanten_x
            return layout.clamp_bar_geometry(
                nx, ny, int(w), nh, m, self.docked, ecken_andocken=False
            )
        nx = max(int(wl), min(int(nx), int(wr) - int(w)))
        ny = max(int(wt), min(int(ny), int(wb) - int(h)))
        return layout.clamp_bar_geometry(
            nx, ny, int(w), int(h), m, layout.DOCK_FREE, ecken_andocken=False
        )

    def _drag_split_delta(self, visible: list, hidden: list) -> bool:
        """Nur die geaenderten Zellen anfassen — kein Zerstoeren aller Buttons.

        Der Live-Split ist ein Praefix (entries[:keep]): Zellen hinten weg
        oder hinten dazu, »N-Zahl + versteckte Liste folgen sofort.
        Rueckgabe False -> Aufrufer faellt auf _rebuild_entries zurueck.
        """
        knopf = self._finde_ueberlauf_knopf()
        if knopf is None:
            return False
        try:
            zellen = [b for b in self.buttons if not self._ist_ueberlauf_knopf(b)]
            pos = self.buttons.index(knopf)
        except ValueError:
            return False
        cur = len(zellen)
        want = len(visible)
        # Praefix muss zur gezogenen Soll-Menge passen — sonst voller Aufbau.
        for i in range(min(cur, want)):
            if getattr(zellen[i], "_target", None) != visible[i].get("target"):
                return False
        try:
            if want < cur:
                for btn in zellen[want:]:
                    btn.destroy()
                    self.buttons.remove(btn)
            elif want > cur:
                vertical = self._leiste_ist_senkrecht()
                # Quer liegt der End-Füller zwischen Zellen und »N —
                # neue Zellen gehoeren VOR den Fueller, nicht vor den Knopf.
                vor = getattr(self, "_body_filler", None)
                if not vertical and vor is not None and vor.winfo_exists():
                    ziel = vor
                else:
                    ziel = knopf
                for i in range(cur, want):
                    btn = self._create_entry_button(visible[i])
                    btn.pack(
                        side=tk.TOP if vertical else tk.LEFT,
                        padx=0,
                        pady=0,
                        fill=tk.X if vertical else tk.NONE,
                        anchor=tk.N if vertical else tk.CENTER,
                        before=ziel,
                    )
                    self.buttons.insert(pos, btn)
                    pos += 1
            knopf.configure(text=f"»{len(hidden)}")
            knopf._overflow_hidden = list(hidden)
            # Rechtsklick-Bind traegt eine Momentaufnahme — frisch setzen.
            knopf.bind(
                "<Button-3>",
                lambda e, h=list(hidden): self._ueberlauf_toggle(knopf, h),
            )
        except tk.TclError:
            return False
        self._ueberlauf_liste = list(hidden)
        return True

    def _drag_live_split_anwenden(
        self, x: int, y: int, w: int, h: int
    ) -> tuple[int, int, int, int]:
        if self.slot_limit is not None:
            return x, y, w, h
        entries = self.cfg.data.get("entries", [])
        if not entries:
            return x, y, w, h
        live = getattr(self, "_drag_live_dock", None) or self.docked
        quer = (
            layout.is_horizontal(live)
            or live in layout.DOCK_CORNER
            or (live == layout.DOCK_FREE and int(w) >= int(h))
        )
        # Split = eigene Form — IMMER. Was ueber die Arbeitsflaeche ragt,
        # wird nur abgeschnitten, nie umgebaut: sonst kollabiert die Leiste
        # beim Raus-Schieben zum Stummel (verf=140 -> »37, Nutzer 06.10.2026:
        # „Leiste wird kleiner — darf nie sein").
        avail_raw = int(w if quer else h)
        if getattr(self, "_dragging", False):
            slot = int(self.cfg.data.get("bar", {}).get("slot_hoehe_px") or 0)
            if slot <= 4:
                slot = int(getattr(self, "_entry_hoehe_schnitt", None) or 17)
            # Split nur in ganzen Slot-Schritten — sonst »/Buttons pro Pixel neu (Flackern).
            self._split_avail_override = max(slot, (avail_raw // slot) * slot)
        else:
            self._split_avail_override = avail_raw
        try:
            visible, hidden = self._split_entries_for_display(entries)
            anzahl = (len(visible), len(hidden))
            if anzahl != self._drag_live_anzahl:
                self._split_vorgabe = len(visible)
                # Delta statt Vollpopulate (Nutzer 05.10.2026: Zug ruckelte,
                # weil jede »-Aenderung alle Buttons zerstoerte + neu baute).
                try:
                    delta_ok = (
                        not getattr(self, "_drag_dock_wechsel", False)
                        and self._drag_split_delta(visible, hidden)
                    )
                except Exception:
                    delta_ok = False
                self._drag_dock_wechsel = False
                if delta_ok:
                    self._drag_live_anzahl = anzahl
                elif getattr(self, "_dragging", False):
                    # Kein _rebuild waehrend Zug — sonst kurz leere Leiste.
                    self._drag_split_deferred = True
                    return x, y, w, h
                else:
                    self._rebuild_entries(relayout_only=True)
                    self._apply_leisten_pack_richtung()
                    self._drag_live_anzahl = anzahl
                if delta_ok or not getattr(self, "_dragging", False):
                    self.root.update_idletasks()
                    gem_w, gem_h = self._gemessene_leisten_groesse()
                    outer = getattr(self, "outer", None)
                    if outer is not None:
                        outer_w = int(outer.winfo_reqwidth() or 0)
                        outer_h = int(outer.winfo_reqheight() or 0)
                        if outer_w > 1:
                            gem_w = outer_w
                        if outer_h > 1:
                            gem_h = outer_h
                    self._drag_live_gem = (gem_w, gem_h)
            else:
                pass
            gem = getattr(self, "_drag_live_gem", None)
            if gem is None:
                return x, y, w, h
            gem_w, gem_h = int(gem[0]), int(gem[1])
        except tk.TclError:
            return x, y, w, h
        finally:
            self._split_vorgabe = None
            self._split_avail_override = None
        if quer:
            fw = int(w)
            cap = int(gem_w) + 6
            prev_fw = getattr(self, "_drag_live_budget_w", None)
            self._drag_live_budget_w = fw
            # Entlang Kante verbreitern: Rest bis wr (KVA 35). Schrumpfen: weiter
            # am gemessenen Inhalt klemmen (Totraum vermeiden).
            expand = (
                fw > cap
                and self.slot_limit is None
                and getattr(self, "_dragging", False)
                and (
                    layout.is_horizontal(self.docked)
                    or self.docked in layout.DOCK_CORNER
                )
                and (prev_fw is None or fw >= int(prev_fw))
            )
            if expand:
                return x, y, max(layout.MIN_CONTENT_LENGTH, fw), h
            if self.docked == layout.DOCK_FREE:
                # Frei gezogene Leiste: gezogene Groesse bleibt — der Inhalt
                # darf das Fenster nicht kleiner machen (»N zaehlt den Rest).
                return x, y, max(layout.MIN_CONTENT_LENGTH, fw), h
            return x, y, max(layout.MIN_CONTENT_LENGTH, min(fw, cap)), h
        fh = int(h)
        cap_h = int(gem_h) + 6
        prev_fh = getattr(self, "_drag_live_budget_h", None)
        self._drag_live_budget_h = fh
        expand_h = (
            fh > cap_h
            and self.slot_limit is None
            and getattr(self, "_dragging", False)
            and self.docked in layout.DOCK_VERTICAL
            and (prev_fh is None or fh >= int(prev_fh))
        )
        if expand_h:
            return x, y, w, max(layout.MIN_CONTENT_LENGTH, fh)
        if self.docked == layout.DOCK_FREE:
            return x, y, w, max(layout.MIN_CONTENT_LENGTH, fh)
        return x, y, w, max(layout.MIN_CONTENT_LENGTH, min(fh, cap_h))

    def _drag_end(self, event):
        job = self._drag_motion_flush_job
        if job is not None:
            try:
                self.root.after_cancel(job)
            except tk.TclError:
                pass
            self._drag_motion_flush_job = None
        pending = self._drag_motion_pending
        if pending is not None:
            self._drag_motion_pending = None
            self._drag_apply(pending)

        if self._drag_offset is None and not self._dragging:
            self._drag_unbind()
            try:
                self.root.grab_release()
            except tk.TclError:
                pass
            return
        try:
            self.root.grab_release()
        except tk.TclError:
            pass

        x, y, w, h = self._drag_commit_rect()
        drop_x = int(getattr(event, "x_root", self._dx))
        drop_y = int(getattr(event, "y_root", self._dy))
        # Vor dem Reset merken — die letzte Freiform (Status quo) ist die
        # Ablage-Geometrie, nicht die Zonen-Vorschau. Ebenso die Startform:
        # an der Kante geschrumpfte Stummel bleiben fuer die Orientierung
        # senkrecht (detect_dock-Filter oben/unten, Nutzer 06.10.2026).
        frei_rect = self._drag_free_rect
        form_wh = self._drag_wh

        if not self._dragging:
            self._drag_abort()
            self._grip_menu_nach_klick(drop_x, drop_y)
            return

        if getattr(self, "_drag_split_deferred", False):
            self._drag_split_deferred = False
            self._drag_live_anzahl = None
            try:
                self._rebuild_entries(relayout_only=True)
                self._apply_leisten_pack_richtung()
                self._block_configure_relayout(0.6)
            except tk.TclError:
                pass

        self._drag_offset = None
        self._drag_wh = None
        self._drag_wh_cap = None
        self._drag_live_anzahl = None
        self._drag_live_gem = None
        self._drag_live_dock = None
        self._drag_dock_wechsel = False
        self._drag_live_budget_w = None
        self._drag_live_budget_h = None
        self._drag_last_rect = None
        self._drag_free_rect = None
        self._drag_unbind()
        self._fenster_groesse_freigeben()
        self._dragging = False
        self._drag_monitor = None

        new_dock = layout.detect_dock(
            drop_x=drop_x,
            drop_y=drop_y,
            monitor=self.monitor,
            start_x=self._dx,
            start_y=self._dy,
            current_dock=self.docked,
            bar_width=w,
            bar_height=h,
            bar_x=x,
            bar_y=y,
            form_w=form_wh[0] if form_wh else None,
            form_h=form_wh[1] if form_wh else None,
            rand_verankert=getattr(self, "slot_limit", None) is None,
        )
        logging.info(
            "Loslassen: zeiger=%s,%s leiste=%sx%s+%s+%s dock=%s -> %s",
            drop_x, drop_y, w, h, x, y, self.docked, new_dock,
        )
        if not monitors.is_point_on_primary(drop_x, drop_y):
            pm = monitors.get_primary_monitor()
            if pm:
                psl, pst, psr, psb = layout._monitor_tuple(pm)
                luft = layout.SNAP_PX
                if psl - luft <= drop_x < psr + luft and pst - luft <= drop_y < psb + luft:
                    drop_x = min(max(int(drop_x), psl), psr - 1)
                    drop_y = min(max(int(drop_y), pst), psb - 1)
                else:
                    drop_x = (psl + psr) // 2
                    drop_y = (pst + psb) // 2
                new_dock = layout.detect_dock(
                    drop_x=drop_x,
                    drop_y=drop_y,
                    monitor=self.monitor,
                    start_x=self._dx,
                    start_y=self._dy,
                    current_dock=self.docked,
                    bar_width=w,
                    bar_height=h,
                    bar_x=x,
                    bar_y=y,
                    form_w=form_wh[0] if form_wh else None,
                    form_h=form_wh[1] if form_wh else None,
                    rand_verankert=getattr(self, "slot_limit", None) is None,
                )

        sl, st, sr, sb = layout._monitor_tuple(
            monitors.get_primary_monitor() or self.monitor
        )
        wl, wt, wr, wb = layout._work_tuple(self.monitor)
        if (
            self.docked in (layout.DOCK_TOP, layout.DOCK_TOP_LEFT, layout.DOCK_TOP_RIGHT)
            and int(y) > int(st) + layout.SNAP_PX
        ):
            if new_dock in (layout.DOCK_TOP, layout.DOCK_TOP_LEFT, layout.DOCK_TOP_RIGHT):
                if int(y) + int(h) >= int(sb) - layout.SNAP_PX:
                    new_dock = layout.DOCK_BOTTOM
                else:
                    new_dock = layout.DOCK_FREE
            elif (
                new_dock == layout.DOCK_FREE
                and int(y) + int(h) >= int(sb) - layout.SNAP_PX
            ):
                new_dock = layout.DOCK_BOTTOM

        # Erster Anstoss NUR bei quer->rechts = Inventur — Leiste bleibt frei
        # an der Ablage-Stelle; zweites Heranschieben + Loslassen dockt.
        # Alle anderen Fremdkanten (links, oben, unten; Seitenleisten) docken
        # wie bisher sofort (Nutzer 06.10.2026).
        quer_quelle = (
            layout.is_horizontal(self.docked)
            or self.docked in layout.DOCK_CORNER
            or (self.docked == layout.DOCK_FREE and int(w) >= int(h))
        )
        inventur_laenge = None
        inventur_gerade = False
        if new_dock == layout.DOCK_RIGHT and new_dock != self.docked:
            if self._inventur_armiert == layout.DOCK_RIGHT:
                # Zweiter Anstoss: mit GENAU dem Inventur-Ergebnis andocken
                # — nicht neu an der Ziehlage rechnen (Nutzer 06.10.2026:
                # „Inventur dann genau diese Anzeige").
                inventur_laenge = self._inventur_laenge
                self._inventur_armiert = None
                self._inventur_laenge = None
            elif quer_quelle:
                # Inventur: die gezeigte Vorschau (Position + Form + »N)
                # bleibt stehen — nichts springt auf die Freiform zurueck.
                # Laenge an der Ablageposition rechnen, wie die Vorschau.
                self._inventur_armiert = layout.DOCK_RIGHT
                self._inventur_laenge = max(
                    layout.MIN_CONTENT_LENGTH, int(wb) - int(y)
                )
                inventur_gerade = True
                new_dock = layout.DOCK_FREE
                # Die abgelegte Inventur zeigt die Dock-Form (senkrecht,
                # Anker + Rest bis Kante — »N wie beim Andocken), steht aber
                # an der Ablage-Position unter dem Griff. Erst das zweite
                # Heranschieben dockt genau diese Anzeige.
                mon = monitors.get_primary_monitor() or self.monitor
                _px, _py, vw, vh, _ori = layout.dock_rect(
                    layout.DOCK_RIGHT,
                    mon,
                    int(h) if int(w) >= int(h) else int(w),
                    self._inventur_laenge,
                    anchor_x=x,
                    anchor_y=y,
                )
                x, y, w, h = layout.clamp_bar_geometry(
                    x, y, vw, vh, mon, layout.DOCK_FREE
                )
            else:
                self._inventur_armiert = None
                self._inventur_laenge = None
        else:
            self._inventur_armiert = None
            self._inventur_laenge = None

        # Frei abgelegt: Position bleibt die Ablagestelle unter dem Griff —
        # die FORM kommt aus der letzten Freiform des Zugs, nicht aus der
        # Zonen-Vorschau (gequetschte Slide-Breite bzw. Fremdform waere
        # falsch persistiert). Ausnahme Inventur-Ablage: dort IST die
        # gezeigte Vorschau der Stand — sie bleibt exakt so stehen.
        if (
            new_dock == layout.DOCK_FREE
            and frei_rect is not None
            and not inventur_gerade
        ):
            _fx, _fy, w, h = frei_rect

        self._save_position(x, y)
        self._platzbudget_nach_zug(self.docked, new_dock, w, h)
        if inventur_gerade:
            # Inventur-Laenge persistieren — _platzbudget_nach_zug leert
            # frei->frei, also danach setzen (frei, senkrecht geformt ->
            # _save_state schreibt platzbudget_h).
            self._vertical_platzbudget_h = self._inventur_laenge
        # Commit-Laenge = Vorschau-Laenge (Inventur): an der Zielposition
        # rechnen (wb - y / wr - x), NICHT aus dem letzten Zug-Rechteck —
        # Loslassen kann hinter dem letzten Motion-Event liegen, dann waere
        # h die Quer-Dicke (~49 -> max(MIN) = 80) und wuerde als Laenge
        # persistiert -> Stummel (Nutzer 06.10.2026, Log budget=80).
        pb_w = None
        pb_h = None
        if new_dock in layout.DOCK_CORNER:
            pb_w = int(w)
        elif new_dock in layout.DOCK_EDGE and new_dock != self.docked:
            # Gleiche Regel wie die Vorschau: Inventur hat Vorrang;
            # gleiche Achse (links<->rechts / oben<->unten / freie Form
            # derselben Achse) uebernimmt die gezogene Laenge — »N bleibt
            # gleich; Achswechsel rechnet Anker + Rest bis Kante.
            quelle_senkrecht = (
                self.docked in layout.DOCK_VERTICAL
                or (self.docked == layout.DOCK_FREE and int(h) > int(w))
            )
            quelle_quer2 = (
                layout.is_horizontal(self.docked)
                or self.docked in layout.DOCK_CORNER
                or (self.docked == layout.DOCK_FREE and int(w) >= int(h))
            )
            if new_dock in layout.DOCK_VERTICAL:
                pb_h = max(
                    layout.MIN_CONTENT_LENGTH,
                    int(inventur_laenge)
                    if inventur_laenge is not None
                    else int(h)
                    if quelle_senkrecht
                    else int(wb) - int(y),
                )
                self._vertical_platzbudget_h = pb_h
            else:
                pb_w = max(
                    layout.MIN_CONTENT_LENGTH,
                    int(w) if quelle_quer2 else int(wr) - int(x),
                )
                self._horizontal_platzbudget_w = pb_w
        try:
            if (
                new_dock == self.docked
                and new_dock in layout.DOCK_EDGE | layout.DOCK_CORNER
                and self._appbar_abgemeldet
            ):
                # Reservierung wurde beim Verlassen der Kante schon
                # freigegeben — der Slide allein meldet sie NICHT wieder
                # an (kein Shell-Roundtrip). Voller Dock-Pflicht, aber mit
                # der GEZOGENEN Laenge als Budget — gleiche Kante behaelt
                # Laenge/»N wie der Slide, nicht die volle Kante
                # (Nutzer 06.10.2026: 938 wurde beim Re-Dock zu 1152).
                if new_dock in layout.DOCK_VERTICAL:
                    pb_h = max(layout.MIN_CONTENT_LENGTH, int(h))
                    self._vertical_platzbudget_h = pb_h
                else:
                    pb_w = max(layout.MIN_CONTENT_LENGTH, int(w))
                    if new_dock not in layout.DOCK_CORNER:
                        self._horizontal_platzbudget_w = pb_w
                self._dock_to(
                    new_dock,
                    anchor_x=x,
                    anchor_y=y,
                    platzbudget_w=pb_w,
                    platzbudget_h=pb_h,
                    griff_ende=True,
                )
            elif (
                new_dock == self.docked
                and new_dock in layout.DOCK_EDGE | layout.DOCK_CORNER
            ):
                # Gleiche Kante (KVA 35): Anker + gezogene Länge — kein _dock_to
                # (sonst Stub/Fit/Populate → Sprung nach links, Regel 38).
                # Ein Commit, dann still — kein after-Fit (Parken 05.10.2026).
                self._leiste_entlang_kante_verschieben(x, y, w, h)
            elif new_dock in layout.DOCK_EDGE | layout.DOCK_CORNER:
                self._dock_to(
                    new_dock,
                    anchor_x=x,
                    anchor_y=y,
                    platzbudget_w=pb_w,
                    platzbudget_h=pb_h,
                    griff_ende=True,
                )
            else:
                # Frei: die abgelegte FORM bestimmt die Achse — sonst bleibt
                # orientation vom alten Dock und »/Split/Pack laufen falsch
                # (senkrechte Inventur-Form waere intern „quer").
                gedreht = (int(h) > int(w)) != self._leiste_ist_senkrecht()
                self.orientation = (
                    "vertical" if int(h) > int(w) else "horizontal"
                )
                # Bewusste Nutzer-Ablage: der Start-Heiler darf diese
                # Position nicht automatisch wieder andocken — „wo
                # abgelegt = dort bleibt", auch ueber Neustart.
                self.cfg.data["bar"]["frei_gewaehlt"] = True
                self._float_at(x, y, w, h, save=True)
                if gedreht:
                    # Achse hat gewechselt (Inventur-Vorschau senkrecht u.
                    # a.): Inhalt fuer die neue Richtung aufbauen — sonst
                    # bleibt die Quer-Packung im Hochkant-Fenster: leere
                    # Saeule, Griff ungreifbar, zweiter Anstoss unmoeglich
                    # (Nutzer 07.10.2026: „rechts andocken geht nicht bei
                    # Slot-Fixzahl" — der Slot-Fruehreturn im 30-ms-Sync
                    # liess den Schaden dauerhaft stehen).
                    self._rebuild_entries(relayout_only=True)
                    self._apply_leisten_pack_richtung()
                self.root.after(30, self._nach_ablage_ueberlauf_sync)
        finally:
            self._appbar_abgemeldet = False
        if not self._leiste_mitte_auf_primaer():
            self._zurueck_auf_primaermonitor("nach Ziehen ausserhalb Hauptmonitor")

    def _hintergrund_drag_start(self, event) -> str | None:
        try:
            ziel = self.root.winfo_containing(int(event.x_root), int(event.y_root))
        except tk.TclError:
            return None
        reserviert = {
            self.grip,
            self.grip_sep,
            self.add_btn,
            self.title_label,
            self.preview_badge,
        }
        w = ziel
        while w is not None:
            if w in reserviert:
                return None
            if getattr(w, "_xl_zelle", False) or getattr(w, "_xl_ueberlauf", False):
                return None
            if w in (self.body, self.frame, self.outer, self.root):
                break
            w = getattr(w, "master", None)
        if w not in (self.body, self.frame, self.outer):
            return None
        self._drag_start(event)
        return "break"

    def _nach_ablage_ueberlauf_sync(self) -> None:
        """»-Stand nach Griff-Loslassen gegen die committete Lage richten.

        Der letzte Live-Split kann von einer Zonen-Vorschau stammen —
        abgelegt gilt nur die echte Fenstergroesse (Nutzer 06.10.2026:
        » fehlte). Knopf fehlt oder Zellenzahl weicht ab -> ein Rebuild mit
        echtem Budget; sonst nur die Zahl nachziehen.
        """
        if getattr(self, "_dragging", False) or self.slot_limit is not None:
            return
        entries = self.cfg.data.get("entries", [])
        if not entries:
            return
        # KEIN winfo-Mass als Override: das Fenster folgt dem Inhalt —
        # ein transient kleines Mass wuerde sich als Budget ratschen
        # (Schrumpf-Spirale 08.10.2026). _split_available_* liest fuer
        # freie Leisten ohnehin die committete Form aus position.w/h,
        # die _float_at gerade gespeichert hat — das IST die echte
        # Fenstergroesse, die die Doku oben meint.
        vis, hid = self._split_entries_for_display(entries)
        zellen = [b for b in self.buttons if not self._ist_ueberlauf_knopf(b)]
        hat_knopf = self._finde_ueberlauf_knopf() is not None
        if len(zellen) != len(vis) or hat_knopf != bool(vis or hid):
            self._rebuild_entries(relayout_only=True)
            self._apply_leisten_pack_richtung()
            return
        self._ueberlauf_liste_aktualisieren()

    def _save_position(self, x, y):
        self.cfg.data["bar"]["position"]["x"] = x
        self.cfg.data["bar"]["position"]["y"] = y

    def _clamp_position(self, x, y):
        try:
            w = self.root.winfo_width() or self.float_w
            h = self.root.winfo_height() or self.dock_thickness + 8
        except tk.TclError:
            w, h = self.float_w, self.dock_thickness + 8
        if w < layout.MIN_CONTENT_LENGTH:
            w = self.float_w
        x, y, _, _ = layout.clamp_bar_geometry(x, y, w, h, self.monitor, self.docked)
        return x, y
