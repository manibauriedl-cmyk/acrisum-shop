"""Darstellung — Fonts, Farben, Transparenz, Fensterstil, Einstellungs-Dialog."""
import logging
import tkinter as tk
import tkinter.font as tkfont
from .win32_optional import win32con, win32gui
from .. import layout
from .. import masse
from ..appbar import AppBar


class DarstellungMixin:
    def _init_darstellung_zustand(self) -> None:
        """Zustand dieses Moduls — aus Bar.__init__, nach Monitor und Zoom (Farben, Masse, Fonts)."""
        self._refresh_bar_palette()
        self.red_border = self.cfg.data["bar"].get("red_border", False)
        self.orientation = self.cfg.data["bar"].get("orientation", "horizontal")
        self.icon_size = self._icon_groesse_leiste()
        self._font_leiste_h = None
        self._font_leiste_vert = None
        self._fonts_aktualisieren()
        # show_labels VOR _calc_dock_thickness setzen — sonst laeuft der erste
        # Aufruf mit dem Default True (Labels-Zweig) und blaeht die Hoehe auf
        # (35 statt Icon-Hoehe, Nutzer 28.09.2026: „nur diese Hoehe").
        self.show_labels = self.cfg.data["bar"].get("show_labels", True)
        # Anzeige-Modus: "beide" (Symbol+Text) | "symbole" | "text" (09.10.2026).
        # Alte Configs ohne anzeige_modus: aus show_labels ableiten.
        modus = self.cfg.data["bar"].get("anzeige_modus")
        if modus not in ("beide", "symbole", "text"):
            modus = "beide" if self.show_labels else "symbole"
        self.anzeige_modus = modus
        self._nur_text = modus == "text"
        self.show_labels = modus != "symbole"
        self.dock_thickness = self._calc_dock_thickness()
        self._grip_hover = False

    def _apply_borderless_style(self):
        if not win32gui:
            return
        try:
            # Top-Level-HWND — winfo_id ist oft das innere Tk-Fenster; der
            # Taskleisten-Button gehoert dem aeusseren Rahmen. Muss nach jedem
            # attributes()-Aufruf erneut laufen: Tk erzeugt das HWND dabei
            # neu und WS_EX_TOOLWINDOW waere weg (Nutzer 08.10.2026: Leiste
            # zeigte sich als Button in der Windows-Taskleiste).
            hwnd = AppBar.toplevel_hwnd(self.root.winfo_id())
            style = win32gui.GetWindowLong(hwnd, win32con.GWL_STYLE)
            style &= ~(
                win32con.WS_CAPTION
                | win32con.WS_THICKFRAME
                | win32con.WS_SYSMENU
                | win32con.WS_MAXIMIZEBOX
                | win32con.WS_MINIMIZEBOX
            )
            win32gui.SetWindowLong(hwnd, win32con.GWL_STYLE, style)
            exstyle = win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE)
            exstyle |= win32con.WS_EX_TOOLWINDOW
            exstyle &= ~win32con.WS_EX_CLIENTEDGE
            win32gui.SetWindowLong(hwnd, win32con.GWL_EXSTYLE, exstyle)
            # Kein TOPMOST hier — das steuert attributes('-topmost'); nur
            # die geaenderten Styles an die Shell melden.
            win32gui.SetWindowPos(
                hwnd,
                0,
                0, 0, 0, 0,
                win32con.SWP_FRAMECHANGED
                | win32con.SWP_NOMOVE
                | win32con.SWP_NOSIZE
                | win32con.SWP_NOZORDER
                | win32con.SWP_NOACTIVATE,
            )
        except Exception as e:
            logging.warning("Konnte Fensterstile nicht anwenden: %s", e)

    def _font_holen(self, name: str, attr: str, **konfig) -> tkfont.Font:
        fnt = getattr(self, attr, None)
        if fnt is None:
            try:
                fnt = tkfont.Font(root=self.root, name=name, **konfig)
            except tk.TclError:
                fnt = tkfont.nametofont(name)
                fnt.configure(**konfig)
            setattr(self, attr, fnt)
        else:
            fnt.configure(**konfig)
        return fnt

    def _fonts_aktualisieren(self) -> None:
        icon_px = self.icon_size
        h_px = masse.label_font_px(icon_px)
        fam_set = set(tkfont.families())
        h_family = next((f for f in ("Segoe UI", "Arial", "Tahoma") if f in fam_set), "Segoe UI")
        self._font_holen("XLFontLeisteH", "_font_leiste_h", family=h_family, size=-h_px, weight="normal")
        v_px = max(9, min(20, int(round(icon_px * 0.5))))
        self._font_holen("XLFontLeisteVert", "_font_leiste_vert", family=h_family, size=-v_px, weight="normal")

    def _label_font(self, *, horizontal: bool) -> tkfont.Font:
        if horizontal:
            return self._font_leiste_h
        return self._font_leiste_vert

    def _label_height(self) -> int:
        try:
            return int(
                self._label_font(horizontal=self._ist_horizontal()).metrics("linespace")
            )
        except Exception:
            return max(14, min(28, self.icon_size // 3))

    def _leiste_transparent(self) -> bool:
        return masse.hintergrund_volltransparent(self.cfg.data["bar"])

    def _refresh_bar_palette(self) -> None:
        self.bg_color = self._leiste_bg()

    def _leiste_bg(self) -> str:
        return masse.leiste_bg(self.cfg.data["bar"])

    def _leiste_fg(self) -> str:
        return masse.leiste_fg(self.cfg.data["bar"])

    def _bar_luminance(self) -> float:
        base = self.bg_color.lstrip("#")
        if len(base) != 6:
            return 0.5
        try:
            r, g, b = int(base[0:2], 16), int(base[2:4], 16), int(base[4:6], 16)
        except ValueError:
            return 0.5
        return (0.299 * r + 0.587 * g + 0.114 * b) / 255.0

    def _leiste_hover_bg(self) -> str:
        return masse.leiste_hover_bg(self.cfg.data["bar"])

    def _grip_bg(self) -> str:
        return masse.grip_bg(self.cfg.data["bar"])

    def _griff_bild_mit_hintergrund(self, bg: str) -> None:
        """Griff-Punkte: Hintergrund im PhotoImage — Label-bg allein zuckt bei Grau."""
        if not self.grip:
            return
        norm = (bg or "").strip().lower()
        if getattr(self, "_griff_bild_bg", None) == norm:
            return
        self._griff_bild_bg = norm
        vertical = self.orientation == "vertical" or self.docked in layout.DOCK_VERTICAL
        ziel_h = None
        if not vertical and getattr(self, "_nur_text", False):
            # Quer + nur Text: Griff mit Icon-Zoom mitskalieren (fix 26 px
            # frisst bei Stufe 3 die Leiste — Nutzer 24.10.2026).
            ziel_h = masse.leiste_quer_nur_text_kopf_px(self.icon_size)
        self._grip_img = masse.grip_photo(
            masse.grip_fg(bg),
            bg,
            vertical=vertical,
            ziel_hoehe=ziel_h,
        )
        self.grip.configure(image=self._grip_img, bg=bg)

    def _griff_hover_enter(self, _event=None) -> None:
        self._grip_hover = True
        self._griff_bild_mit_hintergrund(self._leiste_hover_bg())

    def _griff_hover_leave(self, _event=None) -> None:
        self._grip_hover = False
        self._griff_bild_mit_hintergrund(self._grip_bg())

    def _zelle_farben(self, zelle, *, bg: str, fg: str, relief: str = "flat", borderwidth: int = 0) -> None:
        zelle.configure(bg=bg, relief=relief, borderwidth=borderwidth, highlightthickness=0)
        for kid in zelle.winfo_children():
            if isinstance(kid, (tk.Label, tk.Button)):
                kid.configure(bg=bg)
                if kid.cget("text"):
                    kid.configure(fg=fg)
            elif getattr(kid, "_xl_punkt", False):
                kid.configure(bg=bg)
                try:
                    running = getattr(zelle, "_xl_laeuft", False)
                    kid.itemconfigure(1, fill=masse.RUNNING_DOT if running else bg)
                except Exception:
                    pass

    def _symbol_hover_bind(self, btn, *, normal_bg: str) -> None:
        horizontal = self.orientation != "vertical" and self.docked not in layout.DOCK_VERTICAL
        fg = self._leiste_fg()
        hover_bg = self._leiste_hover_bg()
        ist_zelle = bool(getattr(btn, "_xl_zelle", False))

        def hover_in(_e):
            if horizontal and ist_zelle:
                self._zelle_farben(btn, bg=hover_bg, fg=fg, relief="flat", borderwidth=0)
            else:
                btn.configure(bg=hover_bg, relief="flat", borderwidth=0)

        def hover_out(_e):
            if horizontal and ist_zelle:
                self._zelle_farben(btn, bg=normal_bg, fg=fg, relief="flat", borderwidth=0)
            else:
                btn.configure(bg=normal_bg, relief="flat", borderwidth=0)

        btn.bind("<Enter>", hover_in)
        btn.bind("<Leave>", hover_out)

    def _control_bg(self) -> str:
        """Griff/+ etwas heller als Leisten-Hintergrund."""
        if self.red_border:
            return "#a00000"
        base = self.bg_color.lstrip("#")
        if len(base) != 6:
            return "#505050"
        r, g, b = int(base[0:2], 16), int(base[2:4], 16), int(base[4:6], 16)
        r = min(255, r + 28)
        g = min(255, g + 28)
        b = min(255, b + 28)
        return f"#{r:02x}{g:02x}{b:02x}"

    _COLOR_PRESETS = {
        "Grau": "#606060",
        "Dunkelgrau": "#404040",
        "Schwarz": "#1e1e1e",
        "Office-Gruen": "#008000",
        "Blau": "#2b579a",
        "Hellgrau": "#a0a0a0",
        "Wie Windows-Leiste": "#9ec5eb",
    }

    def _settings_dialog(self):
        dlg = tk.Toplevel(self.root)
        dlg.title("Einstellungen")
        dlg.configure(bg=self.bg_color)
        dlg.resizable(False, False)
        dlg.attributes("-topmost", True)
        dlg.transient(self.root)
        dlg.grab_set()

        # Inhalt in Canvas — Scrollbalken rechts, wenn mehr Zeilen als Platz.
        aussen = tk.Frame(dlg, bg=self.bg_color)
        aussen.pack(fill="both", expand=True)
        canvas = tk.Canvas(aussen, bg=self.bg_color, highlightthickness=0, bd=0)
        scroll = tk.Scrollbar(aussen, orient="vertical", command=canvas.yview)
        innen = tk.Frame(canvas, bg=self.bg_color)
        innen.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")),
        )
        canvas.create_window((0, 0), window=innen, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)

        tk.Label(
            innen,
            text="Hintergrundfarbe:",
            bg=self.bg_color,
            fg="white",
            font=("Segoe UI", 9, "bold"),
        ).pack(anchor="w", padx=10, pady=(10, 4))

        color_row = tk.Frame(innen, bg=self.bg_color)
        color_row.pack(fill=tk.X, padx=10, pady=2)
        bg_aktuell = str(self.bg_color).lower()
        for label, color in self._COLOR_PRESETS.items():
            ist_aktuell = bg_aktuell == color.lower()
            btn = tk.Label(
                color_row,
                text="  ",
                bg=color,
                relief=tk.RAISED,
                bd=2,
                width=4,
                cursor="hand2",
                # Aktive Farbe: goldener Rahmen (Status-Anzeige fehlte).
                highlightthickness=3 if ist_aktuell else 0,
                highlightbackground="#ffcc00" if ist_aktuell else color,
            )
            btn.pack(side=tk.LEFT, padx=2)
            btn.bind("<Enter>", lambda e, b=btn: b.configure(relief=tk.SUNKEN))
            btn.bind("<Leave>", lambda e, b=btn: b.configure(relief=tk.RAISED))
            btn.bind("<Button-1>", lambda e, c=color: (self._set_bg(c), dlg.destroy()))

        tk.Label(
            innen,
            text="Sichtbare Symbole:",
            bg=self.bg_color,
            fg="white",
            font=("Segoe UI", 9, "bold"),
        ).pack(anchor="w", padx=10, pady=(10, 4))

        slot_frame = tk.Frame(innen, bg=self.bg_color)
        slot_frame.pack(fill=tk.X, padx=10, pady=2)
        for label, value in (
            ("0 Symbole — alles im »-Menü", 0),
            ("3 Symbole", 3),
            ("5 Symbole", 5),
            ("7 Symbole", 7),
            ("12 Symbole", 12),
            ("Alle", None),
        ):
            state = " (aktuell)" if self.slot_limit == value else ""
            btn = tk.Label(
                slot_frame,
                text=f"{label}{state}",
                bg="#505050" if self.slot_limit == value else self.bg_color,
                fg="white",
                cursor="hand2",
                padx=6,
                pady=2,
            )
            btn.pack(side=tk.LEFT, padx=2)
            btn.bind("<Enter>", lambda e, b=btn: b.config(bg="#505050"))
            btn.bind("<Leave>", lambda e, b=btn, v=value: b.config(bg="#505050" if self.slot_limit == v else self.bg_color))
            btn.bind("<Button-1>", lambda e, v=value: (self._set_slot_limit(v), dlg.destroy()))

        tk.Label(
            innen,
            text="Anzeige:",
            bg=self.bg_color,
            fg="white",
            font=("Segoe UI", 9, "bold"),
        ).pack(anchor="w", padx=10, pady=(10, 4))

        anzeige_frame = tk.Frame(innen, bg=self.bg_color)
        anzeige_frame.pack(fill=tk.X, padx=10, pady=2)
        modus_aktuell = getattr(self, "anzeige_modus", "beide")
        for label, modus in (
            ("Symbole + Text", "beide"),
            ("Nur Symbole", "symbole"),
            ("Nur Text", "text"),
        ):
            btn = tk.Label(
                anzeige_frame,
                text=f"{label}{' (aktuell)' if modus_aktuell == modus else ''}",
                bg="#505050" if modus_aktuell == modus else self.bg_color,
                fg="white",
                cursor="hand2",
                padx=6,
                pady=2,
            )
            btn.pack(side=tk.LEFT, padx=2)
            btn.bind("<Enter>", lambda e, b=btn: b.config(bg="#505050"))
            btn.bind(
                "<Leave>",
                lambda e, b=btn, m=modus: b.config(
                    bg="#505050" if self.anzeige_modus == m else self.bg_color
                ),
            )
            btn.bind(
                "<Button-1>",
                lambda e, m=modus: (self._set_anzeige_modus(m), dlg.destroy()),
            )

        tk.Label(
            innen,
            text="Transparenz:",
            bg=self.bg_color,
            fg="white",
            font=("Segoe UI", 9, "bold"),
        ).pack(anchor="w", padx=10, pady=(10, 4))

        trans_frame = tk.Frame(innen, bg=self.bg_color)
        trans_frame.pack(fill=tk.X, padx=10, pady=2)
        aktuell = float(self.cfg.data["bar"].get("transparency", 0.0))
        for label, value in (("Keine", 0.0), ("Mittel", 0.4), ("Stark", 0.7), ("Ganz transparent", 1.0)):
            state = "(aktuell)" if abs(aktuell - value) < 0.01 else ""
            txt = f"{label} {state}".strip()
            btn = tk.Label(
                trans_frame,
                text=txt,
                bg=self.bg_color,
                fg="white",
                cursor="hand2",
                padx=4,
            )
            btn.pack(anchor="w", pady=1)
            btn.bind("<Enter>", lambda e, b=btn: b.configure(bg="#505050"))
            btn.bind("<Leave>", lambda e, b=btn: b.configure(bg=self.bg_color))
            btn.bind("<Button-1>", lambda e, v=value: (self._set_transparency(v), dlg.destroy()))

        tk.Button(
            innen,
            text="Schließen",
            command=dlg.destroy,
            bg="#505050",
            fg="white",
        ).pack(anchor="e", padx=10, pady=(10, 10))

        dlg.update_idletasks()
        bedarf_h = int(innen.winfo_reqheight()) + 4
        max_h = min(bedarf_h, 560)
        canvas.configure(width=int(innen.winfo_reqwidth()), height=max_h)
        if bedarf_h > max_h:
            # Zu viele Zeilen — Scrollbalken rechts + Mausrad (Nutzer 09.10.2026).
            scroll.pack(side="right", fill="y")

            def _rad(e):
                canvas.yview_scroll(int(-e.delta / 120), "units")

            canvas.bind_all("<MouseWheel>", _rad)
            dlg.bind(
                "<Destroy>",
                lambda e: canvas.unbind_all("<MouseWheel>")
                if e.widget is dlg
                else None,
            )
        # Erst verbergen, dann positionieren: geometry() auf das schon gemappte
        # transient-Fenster wird sonst verworfen → Dialog bei (0,0).
        dlg.update_idletasks()
        dw = dlg.winfo_reqwidth()
        dh = dlg.winfo_reqheight()
        x, y = layout.dialog_zentriert_arbeitsbereich(
            layout._work_tuple(getattr(self, "monitor", None)), dw, dh,
        )
        dlg.withdraw()
        dlg.update_idletasks()
        dlg.geometry(f"{dw}x{dh}+{x}+{y}")
        dlg.deiconify()
        dlg.lift(self.root)
        dlg.after(80, lambda: dlg.lift(self.root))

    def _transparency_value(self) -> float:
        return masse.transparency_value(self.cfg.data["bar"])

    def _apply_appearance(self):
        self._refresh_bar_palette()
        trans = self._transparency_value()
        chroma = masse.chroma_transparent(self.cfg.data["bar"])
        topmost = bool(self.cfg.data["bar"].get("always_on_top", True))
        self.root.attributes("-topmost", topmost)

        # Ganz transparent (1.0): Chroma-Grau. Sonst gewaehlte Farbe — mittel/stark per Alpha.
        if chroma:
            key = self._colorkey_hex()
            self.root.attributes("-transparentcolor", key)
            self.root.attributes("-alpha", 1.0)
            bg = key
            outer_bg = "red" if self.red_border else key
        elif trans > 0:
            self.root.attributes("-transparentcolor", "")
            self.root.attributes("-alpha", max(0.2, 1.0 - trans))
            bg = self.bg_color
            outer_bg = "red" if self.red_border else self.bg_color
        else:
            self.root.attributes("-transparentcolor", "")
            # Auto-Abdunkeln bei Ueberlappung aus — flackerte mit Cursor/RAM-Tick
            # (Nutzer 08.10.2026: zu schnell zum Erkennen, stoert am Schreiben).
            self.root.attributes("-alpha", 1.0)
            bg = self.bg_color
            outer_bg = "red" if self.red_border else self.bg_color

        self.root.configure(bg=outer_bg)
        self.outer.configure(bg=outer_bg)
        self.frame.configure(bg=bg)
        self.header.configure(bg=bg)
        self.body.configure(bg=bg)
        self.footer.configure(bg=bg)
        grip_bg = self._leiste_hover_bg() if getattr(self, "_grip_hover", False) else self._grip_bg()
        if self.grip:
            self._griff_bild_mit_hintergrund(grip_bg)
        if self.grip_sep:
            self.grip_sep.configure(bg=grip_bg)
        if self.add_btn and isinstance(self.add_btn, tk.Label):
            self.add_btn.configure(bg=grip_bg, fg=self._leiste_fg())
        if self.preview_badge:
            self.preview_badge.configure(bg=self._leiste_bg(), fg=self._leiste_fg())
        if self.title_label:
            self.title_label.configure(bg=bg)
        cell_bg = self._leiste_bg()
        for btn in self.buttons:
            try:
                if self._ist_ueberlauf_knopf(btn):
                    btn.configure(bg=bg)
                    continue
                fg = self._leiste_fg()
                self._zelle_farben(btn, bg=cell_bg, fg=fg)
                punkt = getattr(btn, "_running_dot", None)
                if punkt:
                    target = getattr(btn, "_target", "")
                    is_running = self._running.get(target, False)
                    punkt.itemconfigure(1, fill=masse.RUNNING_DOT if is_running else cell_bg)
            except (tk.TclError, Exception):
                pass
        # attributes() oben kann das HWND neu erzeugt haben — Toolwindow
        # (kein Taskleisten-Button) danach wieder setzen.
        self._apply_borderless_style()

    def _colorkey_hex(self) -> str:
        return masse.chroma_key(self.cfg.data["bar"])

    def _set_window_shape(self):
        """Fensterform belassen (volles Rechteck).
        Zuschneiden auf Icons behindert das Ziehen, da die Maus beim
        Verschieben das Fenster verlassen wuerde. Stattdessen bleibt die
        Leiste ein normales Rechteck; Volltransparenz nutzt weiterhin den
        Chroma-Key, nur eben die Icons/der Griff sind klickbar.
        """
        if not win32gui:
            return
        hwnd = self.root.winfo_id()
        try:
            win32gui.SetWindowRgn(hwnd, 0, True)
        except Exception:
            pass

    def _apply_auto_transparency(self):
        """KVA 60 — aus (08.10.2026): periodisches Neuzeichnen ließ Leiste zucken."""
        return

    def _set_bg(self, color):
        bar = self.cfg.data["bar"]
        key = masse.schluessel_fuer_hex(color)
        if key:
            bar["leiste_hintergrund"] = key
        bar["background_color"] = color
        logging.info("Leisten-Farbe geaendert: %s (Schluessel %s)", color, key or "-")
        # Bei Chroma-Modus (ganz transparent) Farbe unsichtbar — auf „keine“ schalten.
        if masse.chroma_transparent(bar):
            bar["transparency"] = 0.0
        self._refresh_bar_palette()
        self._cfg_save()
        self._apply_appearance()
        self._rebuild_entries()

    def _set_transparency(self, value):
        value = max(0.0, min(1.0, value))
        self.cfg.data["bar"]["transparency"] = value
        logging.info("Transparenz geaendert: %s", value)
        self._refresh_bar_palette()
        self._cfg_save()
        self._apply_appearance()
        self._rebuild_entries()
        self._set_window_shape()

    def _toggle_topmost(self):
        topmost = not bool(self.cfg.data["bar"].get("always_on_top", True))
        self.cfg.data["bar"]["always_on_top"] = topmost
        self._cfg_save()
        self._apply_appearance()

    def _toggle_labels(self):
        """Namen an/aus — Fenster darf schrumpfen/wachsen (kein altes Platzbudget)."""
        self.show_labels = not self.show_labels
        # Anzeige-Modus mitsynchronisieren — Menue-Toggle ist nur beide/symbole.
        self.anzeige_modus = "beide" if self.show_labels else "symbole"
        self._nur_text = False
        self.cfg.data["bar"]["show_labels"] = self.show_labels
        self.cfg.data["bar"]["anzeige_modus"] = self.anzeige_modus
        self._fonts_aktualisieren()
        self.dock_thickness = self._calc_dock_thickness()
        self._cfg_save()
        self._horizontal_platzbudget_w = None
        self._vertical_platzbudget_h = None
        self._block_configure_relayout(0.9)
        if self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:
            self._dock_to(self.docked, platzbudget_w=None, platzbudget_h=None)
        else:
            self._float(platzbudget_w=None, platzbudget_h=None)
        try:
            self._ueberlauf_liste_aktualisieren()
        except tk.TclError:
            pass

    def _set_anzeige_modus(self, modus: str) -> None:
        """Anzeige-Modus: 'beide' (Symbol+Text) | 'symbole' | 'text' (nur Text)."""
        if modus not in ("beide", "symbole", "text"):
            return
        self.anzeige_modus = modus
        self._nur_text = modus == "text"
        self.show_labels = modus != "symbole"
        self.cfg.data["bar"]["anzeige_modus"] = modus
        self.cfg.data["bar"]["show_labels"] = self.show_labels
        self._fonts_aktualisieren()
        self.dock_thickness = self._calc_dock_thickness()
        self._cfg_save()
        self._horizontal_platzbudget_w = None
        self._vertical_platzbudget_h = None
        self._block_configure_relayout(0.9)
        if self.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:
            self._dock_to(self.docked, platzbudget_w=None, platzbudget_h=None)
        else:
            self._float(platzbudget_w=None, platzbudget_h=None)
        try:
            self._ueberlauf_liste_aktualisieren()
        except tk.TclError:
            pass
