import os
from pathlib import Path

from .app_id import APP_SLUG, LEGACY_APP_SLUG


def _appdata_basis() -> Path:
    appdata = os.environ.get("APPDATA")
    if not appdata:
        appdata = os.path.expanduser("~")
    return Path(appdata)


def _legacy_config_reicher(alt: Path, neu: Path) -> bool:
    """True wenn Legacy-Ordner die vollständigere config.json hat (Umbenennungs-Doppelordner)."""
    try:
        import json

        a = json.loads((alt / "config.json").read_text(encoding="utf-8"))
        n = json.loads((neu / "config.json").read_text(encoding="utf-8"))
        return len(a.get("entries") or []) > len(n.get("entries") or [])
    except Exception:
        return alt.is_dir() and not (neu / "config.json").is_file()


def _appdata_merge_von_legacy(alt: Path, neu: Path) -> None:
    import shutil

    neu.mkdir(parents=True, exist_ok=True)
    for item in alt.iterdir():
        dest = neu / item.name
        if item.is_dir():
            if dest.exists():
                shutil.copytree(item, dest, dirs_exist_ok=True)
            else:
                shutil.copytree(item, dest)
        else:
            shutil.copy2(item, dest)


def get_appdata_dir():
    """%APPDATA%\\launcher2 — Legacy xx1lounger einmalig übernehmen/mergen."""
    basis = _appdata_basis()
    neu = basis / APP_SLUG
    alt = basis / LEGACY_APP_SLUG
    if neu.is_dir() and alt.is_dir() and _legacy_config_reicher(alt, neu):
        _appdata_merge_von_legacy(alt, neu)
    if neu.is_dir():
        return neu
    if alt.is_dir():
        try:
            alt.rename(neu)
            return neu
        except OSError:
            return alt
    return neu


def get_config_path():
    return get_appdata_dir() / "config.json"


def get_log_path():
    return get_appdata_dir() / "xlounger.log"


def get_cache_dir():
    d = get_appdata_dir() / "cache"
    d.mkdir(parents=True, exist_ok=True)
    return d
