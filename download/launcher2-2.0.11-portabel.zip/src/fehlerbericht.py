"""Fehlerbericht (KVA 253/254/296).

- DSGVO (253): Pfade werden maskiert (Benutzername -> <name>).
- Vorschau (254): Der Nutzer sieht den kompletten Text VOR dem Senden.
- Server (296): optional, max. 3 pro Session.

Aufbau: DIE VERSION STEHT GANZ OBEN — Nutzerauftrag 25.09.2026
(„damit kein Verwechselung stattfindet").
"""
from __future__ import annotations

import logging
import os
import platform
import re
from datetime import datetime

MAX_PRO_SESSION = 3
_gesendet = 0


def pfad_maskieren(text: str) -> str:
    """KVA 253 — Benutzernamen in Pfaden maskieren (DSGVO)."""
    name = os.environ.get("USERNAME") or ""
    if name:
        text = text.replace(name, "<name>")
    # generisch: C:\Users\irgendwer\ — auch fremde/andere Konten
    text = re.sub(r"(?i)([A-Za-z]:\\Users\\)[^\\\s]+", r"\1<name>", text)
    return text


def bericht_erstellen(anlass: str = "", log_zeilen: int = 400) -> str:
    """Baut den Bericht. VERSION GANZ OBEN (Nutzerauftrag 25.09.2026)."""
    from src.paths import get_log_path
    from src.version import get_version

    teile = [
        f"xlounger Fehlerbericht — Version {get_version()}",
        f"Zeit: {datetime.now():%d.%m.%Y %H:%M:%S}",
        f"Windows: {platform.version()}",
    ]
    if anlass:
        teile += ["", "Anlass:", anlass]
    try:
        zeilen = (
            get_log_path()
            .read_text(encoding="utf-8", errors="replace")
            .splitlines()[-log_zeilen:]
        )
    except OSError:
        zeilen = ["(Log nicht lesbar)"]
    teile += ["", f"--- Log (letzte {log_zeilen} Zeilen) ---", *zeilen]
    return pfad_maskieren("\n".join(teile))


def senden(bericht: str, url: str) -> bool:
    """KVA 296 — optional an Server, max. MAX_PRO_SESSION pro Session."""
    global _gesendet
    if _gesendet >= MAX_PRO_SESSION:
        logging.warning("Fehlerbericht: Session-Limit %d erreicht", MAX_PRO_SESSION)
        return False
    try:
        import urllib.request

        req = urllib.request.Request(
            url,
            data=bericht.encode("utf-8"),
            headers={"Content-Type": "text/plain; charset=utf-8"},
        )
        with urllib.request.urlopen(req, timeout=10) as antwort:
            ok = 200 <= antwort.status < 300
    except Exception as exc:
        logging.error("Fehlerbericht senden fehlgeschlagen: %s", exc)
        return False
    if ok:
        _gesendet += 1
        logging.info("Fehlerbericht gesendet (%d/%d)", _gesendet, MAX_PRO_SESSION)
    return ok


SUPPORT_MAIL = "manibauriedl@gmail.com"


def bericht_dialog(root, anlass: str = "", server_url: str = "") -> None:
    """KVA 254 — Vorschau: Nutzer sieht den Text VOR jedem Senden.

    Drei Wege: als Datei speichern, per eigener Mail senden (Kunde
    kontrolliert die Mail), oder direkt an Acrisum (wenn URL gesetzt).
    """
    import os
    import tkinter as tk
    import urllib.parse
    from datetime import datetime
    from pathlib import Path
    from tkinter import filedialog, messagebox

    bericht = bericht_erstellen(anlass)

    dlg = tk.Toplevel(root)
    dlg.title("Fehlerbericht — bitte prüfen")
    dlg.geometry("680x560")
    dlg.transient(root)

    text = tk.Text(dlg, wrap="word")
    text.insert("1.0", bericht)
    text.pack(fill="both", expand=True, padx=8, pady=(8, 4))

    # Wohin geht der Bericht — ohne Adresse weiss der Nutzer beim Kopieren
    # nicht, wohin er ihn schicken soll (Nutzer 09.10.2026).
    zeile_hinten = tk.Frame(dlg)
    zeile_hinten.pack(fill="x", padx=8, pady=(0, 2))
    tk.Label(
        zeile_hinten,
        text=f"Geht an {SUPPORT_MAIL} — versendet wird nur, wenn Sie unten einen Weg wählen.",
        fg="#555555",
    ).pack(side="left")

    zeile = tk.Frame(dlg)
    zeile.pack(fill="x", padx=8, pady=(0, 8))

    def inhalt() -> str:
        return text.get("1.0", "end-1c")

    def _kopieren_still() -> None:
        dlg.clipboard_clear()
        dlg.clipboard_append(inhalt())

    def kopieren():
        _kopieren_still()
        # Rueckmeldung + Ziel — sonst weiss der Nutzer nicht, ob ueberhaupt
        # etwas passiert ist und wohin der Text soll (Nutzer 09.10.2026).
        messagebox.showinfo(
            "Fehlerbericht",
            "Bericht liegt in der Zwischenablage.\n"
            f"In eine E-Mail an {SUPPORT_MAIL} einfügen (Strg+V) —\n"
            "oder direkt „Per E-Mail senden“ nutzen.",
            parent=dlg,
        )

    def speichern():
        pfad = filedialog.asksaveasfilename(
            parent=dlg,
            title="Fehlerbericht speichern",
            initialfile=f"xlounger-fehlerbericht-{datetime.now():%Y%m%d-%H%M}.txt",
            defaultextension=".txt",
            filetypes=[("Textdatei", "*.txt")],
        )
        if not pfad:
            return
        try:
            Path(pfad).write_text(inhalt(), encoding="utf-8")
        except OSError as exc:
            messagebox.showerror("Fehlerbericht", f"Speichern fehlgeschlagen:\n{exc}", parent=dlg)
            return
        messagebox.showinfo("Fehlerbericht", f"Gespeichert:\n{pfad}", parent=dlg)

    def per_mail():
        # mailto-URLs sind längenbegrenzt — Bericht geht über Zwischenablage.
        _kopieren_still()
        sicherung = ""
        try:
            from src.paths import get_appdata_dir

            p = get_appdata_dir() / "fehlerbericht.txt"
            p.write_text(inhalt(), encoding="utf-8")
            sicherung = str(p)
        except OSError:
            pass
        from src.version import get_version

        body = "Der Fehlerbericht liegt in der Zwischenablage — bitte hier mit Strg+V einfügen."
        if sicherung:
            body += f"\n\n(Sicherungskopie auf diesem PC: {sicherung})"
        try:
            os.startfile(
                f"mailto:{SUPPORT_MAIL}"
                f"?subject={urllib.parse.quote('Launcher 2 Fehlerbericht — ' + get_version())}"
                f"&body={urllib.parse.quote(body)}"
            )
        except OSError as exc:
            # Kein Mail-Programm registriert (mailto ohne Handler) — ehrlich
            # sagen, wo der Bericht liegt, statt „geöffnet" zu behaupten
            # (Nutzer 09.10.2026: „geht nix, outlook nix aufgemacht").
            messagebox.showwarning(
                "Fehlerbericht",
                "E-Mail-Programm konnte nicht geöffnet werden.\n"
                f"Der Bericht liegt in der Zwischenablage — bitte an\n{SUPPORT_MAIL} senden."
                + (f"\n\nAuch als Datei gespeichert:\n{sicherung}" if sicherung else "")
                + f"\n\n({exc})",
                parent=dlg,
            )
            return
        messagebox.showinfo(
            "Fehlerbericht",
            "E-Mail-Programm wurde geöffnet.\n"
            "Der Bericht liegt in der Zwischenablage —\n"
            "mit Strg+V in die Mail einfügen.",
            parent=dlg,
        )

    def absenden():
        if senden(inhalt(), server_url):
            messagebox.showinfo("Fehlerbericht", "Bericht wurde gesendet — danke!", parent=dlg)
            dlg.destroy()
        else:
            messagebox.showwarning(
                "Fehlerbericht",
                "Senden fehlgeschlagen (oder Limit von 3 pro Sitzung erreicht).\n"
                "Die anderen Wege gehen immer — Datei, Mail oder Kopieren.",
                parent=dlg,
            )

    # Explizite Farben — auf manchen Systemen (Win 8.1) blieb sonst der
    # Standard-Button textlos-weiss (Nutzer-Screenshot 09.10.2026).
    btn_kw = {"fg": "black", "bg": "SystemButtonFace"}
    tk.Button(zeile, text="Als Datei speichern", command=speichern, **btn_kw).pack(side="left")
    tk.Button(zeile, text="Per E-Mail senden", command=per_mail, **btn_kw).pack(side="left", padx=6)
    if server_url:
        tk.Button(zeile, text="An Acrisum senden", command=absenden, **btn_kw).pack(side="left")
    tk.Button(zeile, text="Kopieren", command=kopieren, **btn_kw).pack(side="left", padx=6)
    tk.Button(zeile, text="Abbrechen", command=dlg.destroy, **btn_kw).pack(side="right")
    return dlg
