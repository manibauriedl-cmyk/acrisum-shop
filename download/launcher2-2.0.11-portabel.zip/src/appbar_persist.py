"""AppBar-HWND merken — ABM_REMOVE auch nach Kill/Deinstall/Alt-Launcher.

Mehrere Launcher-Versionen (1.2, xx1lounger, Launcher 2) koennen nacheinander
ABM_NEW ohne sauberes ABM_REMOVE hinterlassen. HWNDs in AppData + bekannte
Fenstertitel beim Stop/Deinstall nachziehen.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

from .app_id import APP_DISPLAY_NAME, APP_NAME, LEGACY_APP_SLUG
from .paths import get_appdata_dir

_MAX_HWND = 12
_DATEI = "appbar_hwnds.json"


def _pfad() -> Path:
    return get_appdata_dir() / _DATEI


def hwnd_merken(hwnd: int) -> None:
    if not hwnd or int(hwnd) <= 0:
        return
    h = int(hwnd)
    try:
        data = json.loads(_pfad().read_text(encoding="utf-8"))
        if not isinstance(data, list):
            data = []
    except (OSError, json.JSONDecodeError, TypeError):
        data = []
    data = [x for x in data if int(x) != h]
    data.append(h)
    data = data[-_MAX_HWND:]
    try:
        get_appdata_dir().mkdir(parents=True, exist_ok=True)
        _pfad().write_text(json.dumps(data), encoding="utf-8")
    except OSError:
        pass


def _gespeicherte() -> list[int]:
    try:
        data = json.loads(_pfad().read_text(encoding="utf-8"))
        if isinstance(data, list):
            return [int(x) for x in data if str(x).isdigit() or isinstance(x, int)]
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        pass
    return []


def _abm_remove(hwnd: int) -> None:
    import ctypes
    from ctypes import wintypes

    from .appbar import APPBARDATA, ABM_REMOVE

    if not hwnd:
        return
    if not ctypes.windll.user32.IsWindow(hwnd):
        return
    data = APPBARDATA()
    data.cbSize = ctypes.sizeof(APPBARDATA)
    data.hWnd = wintypes.HWND(int(hwnd))
    try:
        ctypes.windll.shell32.SHAppBarMessage(ABM_REMOVE, ctypes.byref(data))
        logging.info("Shell ABM_REMOVE (Persist) hwnd=%s", hwnd)
    except Exception:
        pass


def shell_appbar_bereinigen() -> int:
    """ABM_REMOVE auf gemerkte HWNDs + bekannte Leisten-Fenstertitel."""
    import ctypes

    user32 = ctypes.windll.user32
    n = 0
    seen: set[int] = set()
    for hwnd in _gespeicherte():
        if hwnd in seen:
            continue
        seen.add(hwnd)
        if user32.IsWindow(hwnd):
            _abm_remove(hwnd)
            n += 1
    for titel in (APP_DISPLAY_NAME, APP_NAME, LEGACY_APP_SLUG, "xlounger", "Acrisum Launcher"):
        h = int(user32.FindWindowW(None, titel) or 0)
        if h and h not in seen:
            seen.add(h)
            _abm_remove(h)
            n += 1
    return n
