import os
import subprocess
from pathlib import Path
import pythoncom
from win32com.shell import shell

from .browser_url import is_web_url, open_in_browser

_STRATA_DESKTOP_BAT = Path(
    r"C:\zzz-winsu-entwickler\scripts\WINSU-STRATA-DESKTOP-START.bat"
)


def _ist_strata_desktop_exe(path: str) -> bool:
    p = Path((path or "").strip().strip('"'))
    return p.name.casefold() == "strata-desktop.exe" and p.suffix.casefold() == ".exe"


def _winsu_strata_desktop_ziel(path: str) -> str:
    """Desktop-App mit Winsu-Vorbereitung (Q2/VRAM) — nicht Browser :8081."""
    if not _ist_strata_desktop_exe(path):
        return path
    try:
        if _STRATA_DESKTOP_BAT.is_file():
            return str(_STRATA_DESKTOP_BAT)
    except OSError:
        pass
    return path


def resolve_lnk(lnk_path):
    try:
        sl = pythoncom.CoCreateInstance(
            shell.CLSID_ShellLink,
            None,
            pythoncom.CLSCTX_INPROC_SERVER,
            shell.IID_IShellLink,
        )
        persist = sl.QueryInterface(pythoncom.IID_IPersistFile)
        persist.Load(lnk_path)
        path = sl.GetPath(shell.SLGP_UNCPRIORITY)[0]
        args = sl.GetArguments()
        return path, args
    except Exception:
        return None, None


def read_url_file(url_path):
    try:
        with open(url_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("URL="):
                    return line[4:].strip()
    except Exception:
        pass
    return None


def _open_url_target(url: str) -> bool:
    """KVA 146 — http(s) immer über browser_url (Localhost → 127.0.0.1)."""
    if is_web_url(url):
        return open_in_browser(url)
    try:
        os.startfile(url)
        return True
    except OSError:
        return False


def _lokaler_pfad(w: str) -> str:
    """Klare lokale Dateipfade (C:\\… oder \\\\Share\\…), sonst ''."""
    w = str(w or "").strip().strip("\"'")
    if (len(w) > 2 and w[0].isalpha() and w[1] == ":") or w.startswith("\\\\"):
        return w
    return ""


def _fehlende_pfade(args: str) -> str:
    """Erster lokaler Zielpfad in den Argumenten, der nicht existiert
    ('' wenn ok).

    Nur die Nutzlast pruefen — der exe-Pfad selbst hat eigene
    Fallbacks (Cache-lnk, Quell-lnk). Bei mehreren Pfad-Argumenten
    gilt „kaputt" nur, wenn keines existiert — Flags und gemischte
    Kommandozeilen bleiben erlaubt.
    """
    aw = str(args or "").strip()
    if not aw:
        return ""
    ganz = aw.strip("\"'")
    if aw == f'"{ganz}"' or " " not in ganz:
        # genau ein Pfad-Argument (mit oder ohne Anfuehrungszeichen)
        p = _lokaler_pfad(ganz)
        if p:
            return "" if os.path.exists(p) else p
        return ""
    lokal = [x for x in (_lokaler_pfad(t) for t in aw.split()) if x]
    if lokal and not any(os.path.exists(t) for t in lokal):
        # Unquotierter Pfad mit Leerzeichen zerfiel in Tokens — den Kern
        # ohne Flags noch als Ganzes pruefen, bevor wir warnen.
        kern = " ".join(
            t for t in aw.split() if not t.lstrip("\"'").startswith(("/", "-"))
        ).strip("\"'")
        p = _lokaler_pfad(kern)
        if p:
            return "" if os.path.exists(p) else p
        return lokal[0]
    return ""


def _lnk_admin_flag(lnk_path: str) -> bool:
    """„Als Administrator ausfuehren" — LinkFlags-Bit 0x20 an Offset 0x15;
    WScript.Shell kann das Feld nicht lesen."""
    try:
        with open(lnk_path, "rb") as f:
            d = f.read(0x16)
        return len(d) == 0x16 and bool(d[0x15] & 0x20)
    except OSError:
        return False


def _warn_ziel_fehlt(pfad: str) -> None:
    """Ehrliche Meldung statt stillem Fallback (Nutzer 10.10.2026:
    .lnk auf geloeschte .jpg oeffnete still „Dokumente" — sah aus
    wie „geht")."""
    try:
        import tkinter as tk
        from tkinter import messagebox

        root = tk._default_root
        if root is None:
            return  # ohne laufende UI nur via Rueckgabewert signalisieren
        messagebox.showwarning(
            "Ziel nicht gefunden",
            f"Das Ziel existiert nicht (mehr):\n\n{pfad}",
            parent=root,
        )
    except Exception:
        pass


def _start_pfad_args(path: str, args: str, workdir: str = "") -> bool:
    path = _winsu_strata_desktop_ziel(str(path or "").strip())
    if not path:
        return False
    if is_web_url(path):
        return open_in_browser(path)
    norm = path.replace("/", "\\").lower()
    if norm.endswith(".exe") and "\\microsoft\\windowsapps\\" in ("\\" + norm):
        # Ausfuehrungsalias (0-Byte-Reparse-Point): CreateProcess UND
        # ShellExecute scheitern mit WinError 2 — die echte Paket-exe
        # steht im Reparse-Puffer (DuckDuckGo, Nutzer 10.10.2026).
        try:
            from .icons import _appexec_ziel
            echt = _appexec_ziel(path)
            if echt:
                path = echt
        except Exception:
            pass
    cwd = str(workdir or "").strip()
    if Path(path).suffix.lower() == ".exe" and not args:
        try:
            subprocess.Popen([path], cwd=cwd or None)
            return True
        except OSError:
            pass
    cmd = f'"{path}"'
    if args:
        cmd += f" {args}"
    try:
        subprocess.Popen(cmd, shell=True, cwd=cwd or None)
        return True
    except OSError:
        return False


def start_entry(entry: dict | None) -> bool:
    """Start aus vollständigem Steckbrief (launch) — unabhängig von Desktop-.lnk."""
    if not entry or not isinstance(entry, dict):
        return False
    from .verbindung_profil import effektive_verknuepfung, launch_aus_entry, pfad_lang

    launch = launch_aus_entry(entry)
    kind = str(launch.get("kind") or "")

    if kind == "url":
        url = str(launch.get("url") or "").strip()
        if url:
            return _open_url_target(url)
        suf = Path(str(entry.get("target") or "")).suffix.lower()
        if suf == ".url":
            url = read_url_file(str(entry.get("target")))
            if url:
                return _open_url_target(url)
        return False

    if kind == "shell":
        try:
            os.startfile(str(launch.get("path") or ""))
            return True
        except OSError:
            return False

    path = pfad_lang(str(launch.get("path") or ""))
    args = str(launch.get("args") or "")
    workdir = pfad_lang(str(launch.get("workdir") or ""))

    if path and not os.path.isfile(path):
        try:
            from .programmpfad import programm_ziel_aufgeloest

            alt = programm_ziel_aufgeloest(path)
            if alt and os.path.isfile(alt):
                path = pfad_lang(alt)
        except Exception:
            pass

    fehl = _fehlende_pfade(args)
    if fehl:
        _warn_ziel_fehlt(fehl)
        return False

    # Fensterstil != normal (maximiert/minimiert) oder Admin-Flag: ueber
    # die .lnk-Datei selbst starten — die Shell wendet dann ALLE
    # gespeicherten Eigenschaften an (Fensterstil, „als Administrator",
    # Konsolen-Optionen, Kompatibilitaet). path+args-Popen koennte nur
    # Ziel und Argumente reproduzieren.
    try:
        ws = int(launch.get("window_style") or 1)
    except (TypeError, ValueError):
        ws = 1
    slnk_ws = effektive_verknuepfung(launch) or pfad_lang(
        str(launch.get("source_lnk") or "")
    )
    if (
        slnk_ws
        and Path(slnk_ws).suffix.lower() == ".lnk"
        and Path(slnk_ws).is_file()
        and (ws != 1 or _lnk_admin_flag(slnk_ws))
    ):
        try:
            os.startfile(slnk_ws)
            return True
        except OSError:
            pass

    if path and _start_pfad_args(path, args, workdir):
        return True

    # KVA 149 — Shell-Namespace, Cache-.lnk oder Desktop-.lnk
    slnk = effektive_verknuepfung(launch) or pfad_lang(str(launch.get("source_lnk") or ""))
    if slnk and Path(slnk).suffix.lower() == ".lnk":
        if Path(slnk).is_file():
            pth, arg = resolve_lnk(slnk)
            if pth and _start_pfad_args(pth, arg or args, workdir):
                return True
            try:
                os.startfile(slnk)
                return True
            except OSError:
                pass

    target = str(entry.get("target") or "").strip()
    if target:
        return _start_roher_pfad(target)
    return False


def _start_roher_pfad(target: str) -> bool:
    """Legacy-Start nur aus Pfadstring (ohne Rekursion über start_entry)."""
    target = str(target).strip()
    lower = target.lower()

    if is_web_url(target):
        return open_in_browser(target)

    if lower.startswith(("ms-settings:", "shell:", "mailto:")):
        os.startfile(target)
        return True

    p = Path(target)
    suffix = p.suffix.lower()

    if suffix == ".url":
        url = read_url_file(str(p))
        if url:
            return _open_url_target(url)

    if suffix == ".lnk":
        path, args = resolve_lnk(str(p))
        if path:
            return _start_pfad_args(path, args)
        try:
            os.startfile(str(p))
            return True
        except OSError:
            return False

    if suffix == ".msc":
        subprocess.Popen(["mmc", str(p)])
        return True

    if p.is_dir():
        subprocess.Popen(["explorer", str(p)])
        return True

    if p.is_file() and suffix == ".exe":
        return _start_pfad_args(str(p), "")

    if p.is_file():
        os.startfile(str(p))
        return True

    try:
        os.startfile(target)
        return True
    except Exception:
        return False


def start(target):
    if not target:
        return False
    target = str(target).strip()
    from .verbindung_profil import profil_aus_quelle

    return start_entry({"target": target, "launch": profil_aus_quelle(target)})
