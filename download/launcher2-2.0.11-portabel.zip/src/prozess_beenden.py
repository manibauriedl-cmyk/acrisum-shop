"""Launcher-2-Hintergrundprozesse (Wächter, Geist-Mutex) — nur Produkt-Pfade."""
from __future__ import annotations

import os
from pathlib import Path

from .app_id import APP_SLUG, LEGACY_APP_SLUG


def _cmdline_text(cmdline: list[str] | None) -> str:
    if not cmdline:
        return ""
    return " ".join(cmdline).lower().replace("\\", "/")


def _ist_launcher_cmd(text: str) -> bool:
    if not text:
        return False
    markers = (
        "launcher2.py",
        "xx1lounger.py",
        "launcher2_prozess.py",
        f"/{APP_SLUG}/",
        f"/{LEGACY_APP_SLUG}/",
        f"\\{APP_SLUG}\\",
        f"\\{LEGACY_APP_SLUG}\\",
    )
    return any(m in text for m in markers)


def _subkommando(text: str) -> str:
    """Letztes CLI-Argument — nicht „waechter“ im Log-Pfad o. ä."""
    teile = text.replace('"', " ").split()
    return teile[-1].lower() if teile else ""


def _rolle(text: str) -> str | None:
    if "launcher2.py" in text or "xx1lounger.py" in text:
        return "leiste"
    if "launcher2_prozess.py" not in text:
        return None
    if _subkommando(text) == "waechter":
        return "waechter"
    return "prozess"


def _iter_launcher_prozesse():
    try:
        import psutil
    except ImportError:
        return
    me = os.getpid()
    for proc in psutil.process_iter(["pid", "name", "cmdline"]):
        try:
            pid = int(proc.info.get("pid") or 0)
            if pid <= 0 or pid == me:
                continue
            name = (proc.info.get("name") or "").lower()
            if "python" not in name:
                continue
            text = _cmdline_text(proc.info.get("cmdline"))
            if not _ist_launcher_cmd(text):
                continue
            rolle = _rolle(text)
            if rolle:
                yield pid, rolle, proc
        except (OSError, ValueError, TypeError):
            continue


def waechter_beenden() -> int:
    n = 0
    for pid, rolle, proc in _iter_launcher_prozesse():
        if rolle != "waechter":
            continue
        try:
            proc.terminate()
            proc.wait(timeout=8)
            n += 1
        except Exception:
            try:
                proc.kill()
                n += 1
            except Exception:
                pass
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    lock = Path(base) / APP_SLUG / "xlounger_waechter.lock"
    try:
        lock.unlink(missing_ok=True)
    except OSError:
        pass
    return n


def geist_leiste_beenden() -> int:
    """Mutex ohne Fenster: nur launcher2.py / xx1lounger.py beenden (scoped)."""
    n = 0
    for pid, rolle, proc in _iter_launcher_prozesse():
        if rolle != "leiste":
            continue
        try:
            proc.terminate()
            proc.wait(timeout=8)
            n += 1
        except Exception:
            try:
                proc.kill()
                n += 1
            except Exception:
                pass
    return n
