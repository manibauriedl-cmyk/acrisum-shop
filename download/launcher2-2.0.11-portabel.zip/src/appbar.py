import ctypes
import logging
from ctypes import wintypes

from .app_id import APP_NAME

shell32 = ctypes.windll.shell32
user32 = ctypes.windll.user32


class APPBARDATA(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("hWnd", wintypes.HWND),
        ("uCallbackMessage", wintypes.UINT),
        ("uEdge", wintypes.UINT),
        ("rc", wintypes.RECT),
        ("lParam", wintypes.LPARAM),
    ]


ABM_NEW = 0
ABM_REMOVE = 1
ABM_QUERYPOS = 2
ABM_SETPOS = 3

ABE_LEFT = 0
ABE_TOP = 1
ABE_RIGHT = 2
ABE_BOTTOM = 3

# Shell → AppBar (wParam bei RegisterWindowMessage-Callback)
ABN_STATECHANGE = 0
ABN_POSCHANGED = 1
ABN_FULLSCREENAPP = 2
ABN_WINDOWARRANGE = 3

GA_ROOT = 2


class AppBar:
    def __init__(self, hwnd):
        self.hwnd = hwnd
        self.registered = False
        self._last_thickness = None
        self._registered_hwnd = None  # HWND, mit dem ABM_NEW wirklich lief
        self._callback_msg = 0
        try:
            user32.RegisterWindowMessageW.argtypes = [wintypes.LPCWSTR]
            user32.RegisterWindowMessageW.restype = wintypes.UINT
            self._callback_msg = user32.RegisterWindowMessageW(f"{APP_NAME}_appbar")
        except Exception:
            self._callback_msg = 0

    @property
    def callback_message(self) -> int:
        return int(self._callback_msg or 0)

    @staticmethod
    def toplevel_hwnd(hwnd):
        """Tk-winfo_id liefert oft das innere Fenster; Shell braucht Top-Level."""
        hwnd = int(hwnd)
        try:
            root = int(user32.GetAncestor(hwnd, GA_ROOT) or 0)
            if root and root != hwnd:
                return root
        except Exception:
            pass
        try:
            parent = int(user32.GetParent(hwnd) or 0)
            if parent:
                return parent
        except Exception:
            pass
        return hwnd

    def _effective_hwnd(self):
        return self.toplevel_hwnd(self.hwnd)

    def unregister(self):
        """Shell-AppBar lösen — immer ABM_REMOVE (registered-Flag kann stale sein).

        WICHTIG: ABM_REMOVE muss auf das HWND gehen, mit dem ABM_NEW lief.
        Tk kann das Fenster-Handle neu erzeugen (z. B. nach wm_attributes) —
        sonst bleibt die alte Reservierung als Phantom in der Shell haengen
        (doppelt reservierter Streifen)."""
        ziele = []
        if self._registered_hwnd:
            ziele.append(int(self._registered_hwnd))
        aktuell = self._effective_hwnd()
        if aktuell not in ziele:
            ziele.append(aktuell)
        for hwnd in ziele:
            data = APPBARDATA()
            data.cbSize = ctypes.sizeof(APPBARDATA)
            data.hWnd = hwnd
            try:
                shell32.SHAppBarMessage(ABM_REMOVE, ctypes.byref(data))
                logging.info("AppBar ABM_REMOVE hwnd=%s", hwnd)
            except Exception:
                pass
        self.registered = False
        self._last_thickness = None
        self._registered_hwnd = None

    def remove_hwnd(self, hwnd: int) -> None:
        """Nur dieses HWND von der Shell loesen (z. B. altes Tk-Top-Level)."""
        hwnd = int(hwnd)
        data = APPBARDATA()
        data.cbSize = ctypes.sizeof(APPBARDATA)
        data.hWnd = hwnd
        try:
            shell32.SHAppBarMessage(ABM_REMOVE, ctypes.byref(data))
            logging.info("AppBar ABM_REMOVE hwnd=%s", hwnd)
        except Exception:
            pass
        if self._registered_hwnd is not None and int(self._registered_hwnd) == hwnd:
            self.registered = False
            self._registered_hwnd = None
            self._last_thickness = None

    def register(self):
        hwnd = self._effective_hwnd()
        if (
            self.registered
            and self._registered_hwnd is not None
            and int(self._registered_hwnd) == int(hwnd)
        ):
            return
        self.unregister()
        data = APPBARDATA()
        data.cbSize = ctypes.sizeof(APPBARDATA)
        data.hWnd = hwnd
        data.uCallbackMessage = self._callback_msg
        try:
            shell32.SHAppBarMessage(ABM_NEW, ctypes.byref(data))
            self._registered_hwnd = hwnd
            logging.info("AppBar ABM_NEW hwnd=%s", hwnd)
            try:
                from .appbar_persist import hwnd_merken

                hwnd_merken(hwnd)
            except Exception:
                pass
        except Exception:
            pass
        self.registered = True

    def set_pos(self, edge, x, y, width, height):
        hwnd = self._effective_hwnd()
        thickness = width if edge in (ABE_LEFT, ABE_RIGHT) else height

        if not self.registered:
            self.register()
        elif self._registered_hwnd and int(self._registered_hwnd) != int(hwnd):
            self.register()
        # Dickenwechsel (Zoom): nur QUERYPOS/SETPOS — kein ABM_REMOVE.
        # Sonst zuckt die Workarea und fremde Leisten (andere AppBars) rutschen mit.
        self._last_thickness = thickness

        data = APPBARDATA()
        data.cbSize = ctypes.sizeof(APPBARDATA)
        data.hWnd = hwnd
        data.uEdge = edge
        data.rc.left = x
        data.rc.top = y
        data.rc.right = x + width
        data.rc.bottom = y + height

        shell32.SHAppBarMessage(ABM_QUERYPOS, ctypes.byref(data))

        # QUERYPOS kann Dicke auf 0 quetschen — wiederherstellen.
        if edge in (ABE_LEFT, ABE_RIGHT):
            if edge == ABE_LEFT:
                data.rc.right = data.rc.left + thickness
            else:
                data.rc.left = data.rc.right - thickness
        elif edge == ABE_TOP:
            data.rc.bottom = data.rc.top + thickness
        elif edge == ABE_BOTTOM:
            data.rc.top = data.rc.bottom - thickness

        if edge == ABE_LEFT:
            data.rc.right = data.rc.left + width
        elif edge == ABE_RIGHT:
            data.rc.left = data.rc.right - width
        elif edge == ABE_TOP:
            data.rc.bottom = data.rc.top + height
        elif edge == ABE_BOTTOM:
            data.rc.top = data.rc.bottom - height

        shell32.SHAppBarMessage(ABM_SETPOS, ctypes.byref(data))

        left = data.rc.left
        top = data.rc.top
        right = data.rc.right
        bottom = data.rc.bottom

        if edge in (ABE_LEFT, ABE_RIGHT):
            width = right - left
        else:
            height = bottom - top

        return left, top, width, height
