"""Programm-Identität — Launcher 2 (Kunde).

Dev-Baum: D:\\xx1lounger (Ordnername historisch — Produkt heißt „Launcher 2“).
Nicht verwechseln mit D:\\winsu\\projekte\\launcher2 (altes Winsu-Dev, archiviert).

APP_SLUG: Mutex, AUMID, %APPDATA%, Autostart-Dateinamen (ohne Leerzeichen).
APP_DISPLAY_NAME: Fenster, Tray, Menüs, Setup-Anzeige.
"""

APP_DISPLAY_NAME = "Launcher 2"
APP_SLUG = "launcher2"
LEGACY_APP_SLUG = "xx1lounger"

# Technische ID in Code (Mutex, Pfade) — nicht in UI anzeigen.
APP_NAME = APP_SLUG
