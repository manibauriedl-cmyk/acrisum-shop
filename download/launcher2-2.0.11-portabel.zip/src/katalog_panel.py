"""Anheften-Panel (KVA 128–132, 135, 137–139, 130)."""

from __future__ import annotations



import tkinter as tk

from tkinter import ttk



from . import drop
from . import native_dialog

from . import icons

from . import katalog

from . import layout

from . import ui_clipboard

from .config import stable_id

from . import entry_hilfe

from . import tooltip

from .launcher import start



# ~430 px brauchen die drei Fuss-Buttons (+Grip) — schmaler clipsst
# „Schliessen" aus dem Fenster (Nutzer-Screenshot 09.10.2026).
_MIN_BREITE = 440

_MIN_HOEHE = 280

_DEFAULT_BREITE = 420

_DEFAULT_HOEHE = 520

_SCHRIFT_MIN = 9

_SCHRIFT_MAX = 18

_SCHRIFT_DEFAULT = 11

# Suche: UI-Thread nicht mit tausenden Widgets blockieren (Nutzer 27.10.2026).
_SUCHE_ENTPRELL_MS = 220
_SUCHE_MAX_ZEILEN = 96
_ZEILEN_BATCH = 12
_ZEILEN_SYNC_MAX = 36


# Alles zugeklappt als Startzustand — die Liste ist mit den registrierten
# Apps zu lang zum Durchscrollen; Zustand wird pro Nutzer gespeichert
# (gruppen_zuklapp in config, Nutzer 09.10.2026).
_GRUPPE_ZUKLAPP_STD: dict[str, bool] = {

    "system": True,

    "programme": True,

    "netz": True,

    "ordner": True,

    "startmenue": True,

    "desktop": True,

    "entfernt": True,

}





class KatalogPanel:

    def __init__(self, bar) -> None:

        self._bar = bar

        self._win: tk.Toplevel | None = None

        self._search_var = tk.StringVar()

        self._inner: tk.Frame | None = None

        self._zeilen_icons: list = []

        self._save_geo_ok = False

        self._geo_after: str | None = None

        self._drag: dict | None = None

        self._resize: dict | None = None

        self._gruppe_zuklapp: dict[str, bool] = {}

        self._fuellen_gen = 0

        self._fuellen_batch_after: str | None = None

        self._fuellen_queue: list[tuple[tk.Frame, dict, str]] = []

        self._fuellen_suche: str = ""



    def _panel_cfg(self) -> dict:

        return self._bar.cfg.data.setdefault(

            "anheften_panel",

            {

                "width": _DEFAULT_BREITE,

                "height": _DEFAULT_HOEHE,

                "x": 100,

                "y": 100,

                "user_placed": False,

                "schrift_pt": _SCHRIFT_DEFAULT,

                "gruppen_zuklapp": {},

            },

        )



    def _schrift_pt(self) -> int:

        try:

            pt = int(self._panel_cfg().get("schrift_pt", _SCHRIFT_DEFAULT))

        except (TypeError, ValueError):

            pt = _SCHRIFT_DEFAULT

        return max(_SCHRIFT_MIN, min(_SCHRIFT_MAX, pt))



    def _icon_px(self) -> int:

        return max(20, self._schrift_pt() + 11)



    def _font(self, *, bold: bool = False) -> tuple[str, int, str]:

        w = "bold" if bold else "normal"

        return ("Segoe UI", self._schrift_pt(), w)



    def _gruppe_zuklapp_laden(self) -> None:

        cfg = self._panel_cfg().get("gruppen_zuklapp")

        if isinstance(cfg, dict):

            self._gruppe_zuklapp = {**_GRUPPE_ZUKLAPP_STD, **{k: bool(v) for k, v in cfg.items()}}

        else:

            self._gruppe_zuklapp = dict(_GRUPPE_ZUKLAPP_STD)



    def _gruppe_zuklapp_speichern(self) -> None:

        self._panel_cfg()["gruppen_zuklapp"] = dict(self._gruppe_zuklapp)

        self._bar._cfg_save()



    def _schrift_aendern(self, delta: int) -> None:

        neu = max(_SCHRIFT_MIN, min(_SCHRIFT_MAX, self._schrift_pt() + delta))

        self._panel_cfg()["schrift_pt"] = neu

        self._bar._cfg_save()

        self._fuellen()



    def oeffnen(self) -> None:

        if self._win and self._win.winfo_exists():

            if self._win.state() == "iconic":

                self._win.deiconify()

            self._win.lift()

            self._win.focus_force()

            return

        self._gruppe_zuklapp_laden()

        root = self._bar.root

        w = tk.Toplevel(root)

        w.title("Anheften — Programme, Ordner, URLs")

        w.configure(bg="#404040")

        w.minsize(_MIN_BREITE, _MIN_HOEHE)

        w.resizable(True, True)

        w.attributes("-topmost", True)

        # transient auf overrideredirect-Leiste erzeugt ein Geister-Owner-
        # Fenster (kleine Titelleiste ueber dem Dialog). 05.10.2026.
        try:
            if not bool(root.overrideredirect()):
                w.transient(root)
        except tk.TclError:
            pass

        self._win = w

        self._save_geo_ok = False



        zieh = tk.Frame(w, bg="#4a4a4a", height=32, cursor="fleur")

        zieh.pack(fill=tk.X)

        zieh.pack_propagate(False)

        tk.Label(

            zieh,

            text="Anheften — ziehen zum Verschieben",

            bg="#4a4a4a",

            fg="#e8e8e8",

            font=self._font(bold=True),

            cursor="fleur",

        ).pack(side=tk.LEFT, padx=10, pady=4)

        schrift_row = tk.Frame(zieh, bg="#4a4a4a")

        schrift_row.pack(side=tk.RIGHT, padx=4)

        tk.Label(schrift_row, text="Schrift", bg="#4a4a4a", fg="#c0c0c0", font=("Segoe UI", 8)).pack(

            side=tk.LEFT, padx=(0, 4),

        )

        tk.Button(

            schrift_row,

            text="A−",

            width=3,

            command=lambda: self._schrift_aendern(-1),

            bg="#606060",

            fg="white",

            relief=tk.RAISED,

            font=("Segoe UI", 9, "bold"),

        ).pack(side=tk.LEFT, padx=1)

        self._schrift_anzeige = tk.Label(

            schrift_row,

            text=str(self._schrift_pt()),

            bg="#4a4a4a",

            fg="white",

            font=("Segoe UI", 9),

            width=2,

        )

        self._schrift_anzeige.pack(side=tk.LEFT)

        tk.Button(

            schrift_row,

            text="A+",

            width=3,

            command=lambda: self._schrift_aendern(1),

            bg="#606060",

            fg="white",

            relief=tk.RAISED,

            font=("Segoe UI", 9, "bold"),

        ).pack(side=tk.LEFT, padx=1)

        tk.Button(

            zieh,

            text="×",

            command=self._schliessen,

            bg="#c0c0c0",

            fg="#000000",

            activebackground="#ffffff",

            font=("Segoe UI", 11, "bold"),

            width=2,

            relief=tk.RAISED,

            cursor="hand2",

            bd=2,

        ).pack(side=tk.RIGHT, padx=(4, 6), pady=2)

        self._ziehleiste_binden(zieh)



        top = tk.Frame(w, bg="#404040")

        top.pack(fill=tk.X, padx=8, pady=8)

        tk.Label(top, text="Suchen:", bg="#404040", fg="white", font=self._font()).pack(side=tk.LEFT)

        ent = tk.Entry(

            top,

            textvariable=self._search_var,

            bg="#505050",

            fg="white",

            insertbackground="white",

            font=self._font(),

        )

        ent.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(6, 0))

        ui_clipboard.entry_clipboard_bind(ent)

        # Entprellen: sonst baut jeder Tastendruck die ganze Liste neu.
        self._search_var.trace_add("write", lambda *_: self._suche_geplant())



        body = tk.Frame(w, bg="#353535")

        body.pack(fill=tk.BOTH, expand=True)



        canvas = tk.Canvas(body, bg="#353535", highlightthickness=0)

        scroll = ttk.Scrollbar(body, orient=tk.VERTICAL, command=canvas.yview)

        inner = tk.Frame(canvas, bg="#353535")

        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

        canvas_item = canvas.create_window((0, 0), window=inner, anchor="nw")

        canvas.configure(yscrollcommand=scroll.set)

        # Nutzer 07.10.2026 „Totraum verboten": inneren Frame auf die
        # Canvas-Breite ziehen — sonst bleibt rechts ein leerer Streifen.
        canvas.bind(
            "<Configure>",
            lambda e: canvas.itemconfigure(canvas_item, width=e.width),
        )

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(8, 0), pady=(0, 4))

        scroll.pack(side=tk.RIGHT, fill=tk.Y, pady=(0, 4), padx=(0, 4))

        self._inner = inner

        self._canvas = canvas



        def _wheel(ev):

            canvas.yview_scroll(int(-1 * (ev.delta / 120)), "units")



        def _wheel_an(_ev):

            canvas.bind_all("<MouseWheel>", _wheel, add="+")



        def _wheel_aus(_ev):

            try:

                canvas.unbind_all("<MouseWheel>")

            except tk.TclError:

                pass



        canvas.bind("<Enter>", _wheel_an)

        canvas.bind("<Leave>", _wheel_aus)



        btn_row = tk.Frame(w, bg="#404040")

        btn_row.pack(fill=tk.X, padx=8, pady=(0, 8))

        tk.Button(

            btn_row,

            text="+ Ordner / Netz wählen…",

            command=self._ordner_waehlen,

            bg="#505050",

            fg="white",

            font=self._font(),

        ).pack(side=tk.LEFT)

        tk.Button(

            btn_row,

            text="Ziel manuell…",

            command=lambda: (self._schliessen(), self._bar._add_entry_dialog()),

            bg="#505050",

            fg="white",

            font=self._font(),

        ).pack(side=tk.LEFT, padx=6)

        grip = tk.Label(

            btn_row,

            text="◢",

            bg="#404040",

            fg="#b0b0b0",

            font=("Segoe UI", 11),

            cursor="size_nw_se",

            padx=4,

        )

        grip.pack(side=tk.RIGHT)

        grip.bind("<ButtonPress-1>", self._resize_press)

        grip.bind("<B1-Motion>", self._resize_motion)

        grip.bind("<ButtonRelease-1>", self._resize_release)

        tk.Button(

            btn_row,

            text="Schließen",

            command=self._schliessen,

            bg="#606060",

            fg="white",

            activebackground="#808080",

            font=self._font(bold=True),

            relief=tk.RAISED,

            padx=10,

            pady=2,

            cursor="hand2",

        ).pack(side=tk.RIGHT, padx=(8, 0))



        w.bind("<Escape>", self._escape)

        w.bind("<Configure>", self._on_configure)

        w.protocol("WM_DELETE_WINDOW", self._schliessen)



        self._fuellen()

        if not self._geometry_laden(w):

            self._positioniere_an_leiste(w)

        # Windows kann ein frisches Toplevel iconic mappen (live beobachtet
        # 07.10.2026: Panel oeffnete minimiert bei -32000,-32000). Einmal
        # nach dem Mappen zurueckholen, falls das passiert.
        w.after(80, lambda: w.winfo_exists() and w.state() == "iconic" and w.deiconify())

        w.after(350, self._geo_speichern_aktivieren)

        ent.focus_set()



    def _suche_geplant(self) -> None:

        """Suche entprellt ausloesen — kurze Pause, damit Tastatur nicht blockiert."""

        alt = getattr(self, "_suche_after", None)

        if alt and self._win:

            try:

                self._win.after_cancel(alt)

            except tk.TclError:

                pass

        if self._win:

            self._suche_after = self._win.after(_SUCHE_ENTPRELL_MS, self._fuellen)



    def _fuellen_batch_abbrechen(self) -> None:

        alt = self._fuellen_batch_after

        if alt and self._win:

            try:

                self._win.after_cancel(alt)

            except tk.TclError:

                pass

        self._fuellen_batch_after = None

        self._fuellen_queue = []



    def _escape(self, _event=None) -> None:

        if (self._search_var.get() or "").strip():

            self._search_var.set("")

            return

        self._schliessen()



    def _ziehleiste_binden(self, frame: tk.Frame) -> None:

        for widget in (frame, *frame.winfo_children()):

            if isinstance(widget, tk.Button) and widget.cget("text") == "×":

                continue

            if widget is getattr(self, "_schrift_anzeige", None):

                continue

            widget.bind("<ButtonPress-1>", self._drag_press)

            widget.bind("<B1-Motion>", self._drag_motion)

            widget.bind("<ButtonRelease-1>", self._drag_release)



    def _drag_press(self, event) -> None:

        w = self._win

        if not w:

            return

        self._drag = {

            "x_root": event.x_root,

            "y_root": event.y_root,

            "win_x": w.winfo_x(),

            "win_y": w.winfo_y(),

        }



    def _drag_motion(self, event) -> None:

        st = self._drag

        w = self._win

        if not st or not w:

            return

        nx = st["win_x"] + (event.x_root - st["x_root"])

        ny = st["win_y"] + (event.y_root - st["y_root"])

        w.geometry(f"+{nx}+{ny}")



    def _drag_release(self, _event) -> None:

        self._drag = None

        self._geometry_speichern()



    def _resize_press(self, event) -> None:

        w = self._win

        if not w:

            return

        self._resize = {

            "x_root": event.x_root,

            "y_root": event.y_root,

            "width": w.winfo_width(),

            "height": w.winfo_height(),

        }



    def _resize_motion(self, event) -> None:

        st = self._resize

        w = self._win

        if not st or not w:

            return

        nw = max(_MIN_BREITE, st["width"] + (event.x_root - st["x_root"]))

        nh = max(_MIN_HOEHE, st["height"] + (event.y_root - st["y_root"]))

        w.geometry(f"{nw}x{nh}")



    def _resize_release(self, _event) -> None:

        self._resize = None

        self._geometry_speichern()



    def _geo_speichern_aktivieren(self) -> None:

        self._save_geo_ok = True



    def _on_configure(self, event) -> None:

        if not self._win or event.widget != self._win or not self._save_geo_ok:

            return

        if self._geo_after:

            try:

                self._win.after_cancel(self._geo_after)

            except tk.TclError:

                pass

        self._geo_after = self._win.after(400, self._geometry_speichern)



    def _geometry_laden(self, w: tk.Toplevel) -> bool:

        cfg = self._panel_cfg()

        if not cfg.get("user_placed"):

            return False

        try:

            pw = int(cfg.get("width") or _DEFAULT_BREITE)

            ph = int(cfg.get("height") or _DEFAULT_HOEHE)

            x = int(cfg.get("x"))

            y = int(cfg.get("y"))

        except (TypeError, ValueError):

            return False

        pw = max(_MIN_BREITE, min(1200, pw))

        ph = max(_MIN_HOEHE, min(900, ph))

        monitor = getattr(self._bar, "monitor", None)

        ml, mt, mr, mb = layout._work_tuple(monitor)

        x = max(ml, min(x, max(ml, mr - pw)))

        y = max(mt, min(y, max(mt, mb - ph)))

        w.geometry(f"{pw}x{ph}+{x}+{y}")

        return True



    def _geometry_speichern(self) -> None:

        w = self._win

        if not w or not w.winfo_exists():

            return

        if w.state() == "iconic":

            return

        try:

            w.update_idletasks()

            pw = int(w.winfo_width())

            ph = int(w.winfo_height())

            x = int(w.winfo_x())

            y = int(w.winfo_y())

        except tk.TclError:

            return

        cfg = self._panel_cfg()

        cfg["width"] = max(_MIN_BREITE, pw)

        cfg["height"] = max(_MIN_HOEHE, ph)

        cfg["x"] = x

        cfg["y"] = y

        cfg["user_placed"] = True

        self._bar._cfg_save()



    def _schliessen(self) -> None:

        w = self._win

        if not w or not w.winfo_exists():

            self._win = None

            self._inner = None

            return

        try:

            if self._save_geo_ok:

                self._geometry_speichern()

        except Exception:

            pass

        try:

            w.unbind_all("<MouseWheel>")

        except tk.TclError:

            pass

        self._fuellen_batch_abbrechen()

        try:

            w.destroy()

        except tk.TclError:

            pass

        self._win = None

        self._inner = None

        # Suchbegriff zuruecksetzen — beim naechsten Oeffnen volle Liste
        # statt stiller Restfilter (Nutzer 09.10.2026). Trace feuert
        # _fuellen, das bei _inner=None sofort zurueckkehrt.
        try:

            self._search_var.set("")

        except tk.TclError:

            pass

        self._geo_after = None



    def _positioniere_an_leiste(self, w: tk.Toplevel) -> None:

        bar = self._bar

        anchor = getattr(bar, "add_btn", None) or bar.root

        try:

            kx = int(anchor.winfo_rootx())

            ky = int(anchor.winfo_rooty())

            kb = max(1, int(anchor.winfo_width()))

            kh = max(1, int(anchor.winfo_height()))

        except tk.TclError:

            return

        w.update_idletasks()

        pw = max(_MIN_BREITE, int(w.winfo_width() or _DEFAULT_BREITE))

        ph = max(_MIN_HOEHE, int(w.winfo_height() or _DEFAULT_HOEHE))

        monitor = getattr(bar, "monitor", None)

        ml, mt, mr, mb = layout._work_tuple(monitor)

        dock = getattr(bar, "docked", layout.DOCK_FREE)

        senkrecht = dock in layout.DOCK_VERTICAL or (

            dock == layout.DOCK_FREE and getattr(bar, "orientation", "") == "vertical"

        )

        if senkrecht:

            x = kx + kb

            y = ky

            if x + pw > mr:

                x = max(ml, kx - pw)

            if y + ph > mb:

                y = max(mt, mb - ph)

        else:

            x = kx

            y = ky + kh

            if x + pw > mr:

                x = max(ml, mr - pw)

            if y + ph > mb:

                y = max(mt, ky - ph)

        w.geometry(f"{pw}x{ph}+{x}+{y}")



    def _ordner_waehlen(self) -> None:

        pfad = native_dialog.askdirectory(parent=self._win, title="Ordner oder Netzpfad")

        if pfad:

            self._anheften(pfad, pfad.split("\\")[-1] or pfad)



    def _anheften(self, target: str, name: str) -> None:

        roh = (target or "").strip()

        if not roh:

            return

        if self._ist_auf_leiste(roh):

            # Schon auf der Leiste -> Positionsmenue zum VERSCHIEBEN
            # (Nutzer 07.10.2026: Klick auf angeheftete Zeile war stille
            # Totstelle — Eintrag liess sich nicht an Anfang/Ende schieben).
            self._anheften_position_fragen(roh, name, vorhanden=True)

            return

        # Nutzer 07.10.2026: vor dem Heften fragen — Anfang oder Ende?
        self._anheften_position_fragen(roh, name)



    def _anheften_position_fragen(self, roh: str, name: str, *, vorhanden: bool = False) -> None:
        """Wohin auf die Leiste — Abbrechen = Menue einfach wegklicken."""

        bar = self._bar

        try:

            x = int(self._win.winfo_pointerx())

            y = int(self._win.winfo_pointery())

        except (tk.TclError, AttributeError):

            x = int(bar.root.winfo_pointerx())

            y = int(bar.root.winfo_pointery())

        def wahl(vorne: bool) -> None:

            if vorhanden:

                self._eintrag_verschieben(roh, vorne=vorne)

            else:

                self._anheften_eintrag(roh, name, vorne=vorne)

        menu = bar._make_menu(self._win)

        menu.add_command(

            label="An den Anfang der Leiste",

            command=lambda: wahl(True),

        )

        menu.add_command(

            label="Ans Ende der Leiste",

            command=lambda: wahl(False),

        )

        # Bei Aufruf aus dem Zeilen-Kontextmenue laeuft noch das modale
        # TrackPopupMenu — das Auswahlmenue erst posten, wenn es zurueck ist.
        bar.root.after(50, lambda: bar._post_context_menu(menu, x, y))



    def _anheften_eintrag(self, roh: str, name: str, *, vorne: bool) -> None:

        from . import verbindung_profil

        verbindung_profil.eintrag_einfuegen(

            self._bar.cfg.data,

            roh,

            name,

            insert_idx=0 if vorne else None,

        )

        if not self._bar._cfg_save(entries_changed=True):

            return

        self._bar._rebuild_entries()

        if self._bar.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:

            self._bar._dock_to(self._bar.docked)

        else:

            self._bar._float()



    def _eintrag_verschieben(self, roh: str, *, vorne: bool) -> None:

        """Schon angehefteten Eintrag an Anfang/Ende schieben."""

        from . import verbindung_profil

        entries = self._bar.cfg.data.get("entries", [])

        schluessel = verbindung_profil.ziel_schluessel_fuer_quelle(roh)

        for i, e in enumerate(entries):

            if not isinstance(e, dict):

                continue

            if verbindung_profil.ziel_schluessel(

                verbindung_profil.launch_aus_entry(e)

            ) == schluessel:

                eintrag = entries.pop(i)

                entries.insert(0 if vorne else len(entries), eintrag)

                break

        else:

            return

        if not self._bar._cfg_save(entries_changed=True):

            return

        self._bar._rebuild_entries()

        if self._bar.docked in layout.DOCK_EDGE | layout.DOCK_CORNER:

            self._bar._dock_to(self._bar.docked)

        else:

            self._bar._float()



    def _ist_auf_leiste(self, target: str) -> bool:

        roh = (target or "").strip()

        if not roh:

            return False

        from . import verbindung_profil

        # ziel_schluessel_fuer_quelle ist lru-gecacht — der Pool-Dedup hat
        # die COM/.lnk-Aufloesung schon bezahlt (Nutzer 09.10.2026: sonst
        # ~20 s beim ersten Buchstaben, ~180 Treffer-Zeilen x COM).
        schluessel = verbindung_profil.ziel_schluessel_fuer_quelle(roh)

        # „exec:|“ = Ziel nicht aufloesbar — nicht gegen Leisten-Eintraege
        # matchen, sonst Faelsch-positiv bei kaputten Eintraegen.
        if not schluessel or schluessel == "exec:|":

            return False

        return schluessel in self._leisten_schluessel()



    def _leisten_schluessel(self) -> frozenset:

        """Schluessel aller Leisten-Eintraege — einmal pro _fuellen-Aufbau.

        Vorher pro Zeile neu berechnet: Zeilen x Eintraege launch-Parses
        (bei .lnk-Eintraegen je ein COM-Aufruf).
        """

        cache = getattr(self, "_leisten_schl", None)

        if cache is not None:

            return cache

        from . import verbindung_profil

        cache = frozenset(

            verbindung_profil.ziel_schluessel(

                verbindung_profil.launch_aus_entry(e)

            )

            for e in self._bar.cfg.data.get("entries", [])

        )

        self._leisten_schl = cache

        return cache



    def _leisten_target(self, target: str) -> str | None:

        roh = (target or "").strip()

        if not roh:

            return None

        from . import verbindung_profil

        schluessel = verbindung_profil.ziel_schluessel_fuer_quelle(roh)

        for e in self._bar.cfg.data.get("entries", []):

            if verbindung_profil.ziel_schluessel(
                verbindung_profil.launch_aus_entry(e)
            ) == schluessel:

                return str(e.get("target") or "")

        return None



    def _oeffnen_ziel(self, target: str, name: str) -> None:

        t = (target or "").strip()

        if not t:

            return

        auf = self._leisten_target(t)

        if auf:

            self._bar._on_click(auf)

            return

        if not start(t):

            return

        from . import verlauf

        verlauf.verlauf_hinzufuegen(self._bar.cfg.data, t, name or t)

        self._bar._cfg_save()



    def _zeile_kontext(self, event, target: str, name: str) -> str:

        bar = self._bar

        menu = bar._make_menu(self._win)

        auf = self._ist_auf_leiste(target)

        leisten_t = self._leisten_target(target)

        menu.add_command(

            label="Oeffnen",

            command=lambda: self._oeffnen_ziel(target, name),

        )

        menu.add_separator()

        if auf and leisten_t:

            menu.add_command(

                label="An den Anfang der Leiste",

                command=lambda: self._eintrag_verschieben(target, vorne=True),

            )

            menu.add_command(

                label="Ans Ende der Leiste",

                command=lambda: self._eintrag_verschieben(target, vorne=False),

            )

            menu.add_separator()

            menu.add_command(

                label="Von Leiste entfernen",

                command=lambda lt=leisten_t: self._von_leiste_entfernen(lt),

            )

        else:

            # Position direkt waehlen — „An Leiste heften" sagte nicht
            # wohin und oeffnete erst ein zweites Menue (Nutzer 07.10.2026).
            menu.add_command(

                label="An den Anfang der Leiste",

                command=lambda: self._anheften_eintrag(target, name, vorne=True),

            )

            menu.add_command(

                label="Ans Ende der Leiste",

                command=lambda: self._anheften_eintrag(target, name, vorne=False),

            )

        menu.add_separator()

        # Auf der Leiste -> Leisten-Eigenschaften; sonst Windows-Eigenschaften
        # der Datei (vorher: stummer Leer-Return, Nutzer 04.10.2026).
        if leisten_t:

            eigenschaften_cmd = lambda: bar._entry_properties_dialog(

                leisten_t,

                anchor_x=int(event.x_root),

                anchor_y=int(event.y_root),

            )

        else:

            eigenschaften_cmd = lambda: bar._open_windows_properties(
                target,
                hwnd=self._win.winfo_id() if self._win else 0,
            )

        menu.add_command(

            label="Eigenschaften...",

            command=eigenschaften_cmd,

        )

        bar._post_context_menu(menu, int(event.x_root), int(event.y_root))

        return "break"



    def _von_leiste_entfernen(self, leisten_target: str) -> None:

        # Neu fuellen passiert zentral in _cfg_save(entries_changed=True) —

        # sonst bleibt die Zeile gruen, obwohl der Eintrag weg ist.

        self._bar._remove_entry(leisten_target)



    def _gruppe_toggle(self, kid: str) -> None:

        self._gruppe_zuklapp[kid] = not self._gruppe_zuklapp.get(kid, False)

        self._gruppe_zuklapp_speichern()

        self._fuellen()



    def _zeile_hover_bind(

        self,

        widgets: tuple[tk.Widget, ...],

        normal_bg: str,

        hover_bg: str,

    ) -> None:

        def hover_in(_e):

            for w in widgets:

                try:

                    w.configure(bg=hover_bg)

                except tk.TclError:

                    pass



        def hover_out(_e):

            for w in widgets:

                try:

                    w.configure(bg=normal_bg)

                except tk.TclError:

                    pass



        for w in widgets:

            w.bind("<Enter>", hover_in, add="+")

            w.bind("<Leave>", hover_out, add="+")



    def _auf_leiste(self, e: dict, target: str, leisten_set: frozenset) -> bool:

        from . import verbindung_profil

        zs = str(e.get("zs") or "")

        if not zs:

            zs = verbindung_profil.ziel_schluessel_fuer_quelle((target or "").strip())

        if not zs or zs == "exec:|":

            return False

        return zs in leisten_set



    def _zeile_einfuegen(

        self,

        liste: tk.Frame,

        e: dict,

        *,

        icon_px: int,

        dock: str,

        leisten_set: frozenset,

        suche_aktiv: bool,

        fuellen_gen: int,

    ) -> None:

        if fuellen_gen != self._fuellen_gen:

            return

        try:

            if not liste.winfo_exists():

                return

        except tk.TclError:

            return

        name = e.get("name") or e.get("target") or "?"

        target = e.get("target") or ""

        auf_leiste = self._auf_leiste(e, target, leisten_set)

        row_bg = "#353535"

        row = tk.Frame(liste, bg=row_bg)

        row.pack(fill=tk.X, padx=4, pady=1)

        ph = self._icon_platzhalter(icon_px)

        icon_lbl = tk.Label(row, image=ph, bg=row_bg, cursor="hand2")

        icon_lbl.pack(side=tk.LEFT, padx=(2, 4))

        self._icon_ausstehend.append((icon_lbl, name, target))

        btn_bg = "#445c50" if auf_leiste else "#484848"

        btn_fg = "#f0fff4" if auf_leiste else "white"

        btn_wrap_bg = "#6fcf97" if auf_leiste else row_bg

        btn_wrap = tk.Frame(row, bg=btn_wrap_bg, padx=1 if auf_leiste else 0, pady=1)

        btn_wrap.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 2))

        btn = tk.Button(

            btn_wrap,

            text=(name + "   ✓") if auf_leiste else name,

            anchor="w",

            bg=btn_bg,

            fg=btn_fg,

            activebackground="#556d60" if auf_leiste else "#585858",

            activeforeground="#ffffff",

            relief=tk.FLAT,

            borderwidth=0,

            font=self._font(bold=auf_leiste),

            command=lambda t=target, n=name: self._anheften(t, n),

        )

        btn.pack(fill=tk.BOTH, expand=True)

        hover_bg = "#5a5a5a" if not auf_leiste else "#4d6558"

        self._zeile_hover_bind((row, icon_lbl, btn_wrap, btn), btn_bg if auf_leiste else row_bg, hover_bg)

        if not suche_aktiv:

            tip = entry_hilfe.entry_tooltip_text(

                {"target": target},

                name=name,

                display_target=target,

                typ=entry_hilfe.entry_typ_label(target),

            )

            tip = tip.removesuffix("Linksklick = starten · Rechtsklick = Menü")

            tip += (

                "Auf der Leiste — Klick = an Anfang/Ende schieben"

                if auf_leiste

                else "Klick = an Leiste heften"

            ) + " · Rechtsklick = Menü"

            tooltip.Tooltip(row, tip, dock=dock, auch=(icon_lbl, btn, btn_wrap), show_ms=1500)

        icon_lbl.bind("<Button-1>", lambda _e, t=target, n=name: self._anheften(t, n))

        for w in (row, icon_lbl, btn_wrap, btn):

            w.bind(

                "<Button-3>",

                lambda ev, t=target, n=name: self._zeile_kontext(ev, t, n),

                add="+",

            )



    def _fuellen_batch(self, gen: int, icon_px: int, dock: str, leisten_set: frozenset, suche_aktiv: bool) -> None:

        self._fuellen_batch_after = None

        if gen != self._fuellen_gen or not self._inner:

            return

        if suche_aktiv and (self._search_var.get() or "").strip() != self._fuellen_suche:

            self._fuellen_queue = []

            return

        batch = self._fuellen_queue[:_ZEILEN_BATCH]

        self._fuellen_queue = self._fuellen_queue[_ZEILEN_BATCH:]

        for liste, e, _kid in batch:

            self._zeile_einfuegen(

                liste,

                e,

                icon_px=icon_px,

                dock=dock,

                leisten_set=leisten_set,

                suche_aktiv=suche_aktiv,

                fuellen_gen=gen,

            )

        if self._fuellen_queue and self._win and self._win.winfo_exists():

            self._fuellen_batch_after = self._win.after(

                1,

                lambda: self._fuellen_batch(gen, icon_px, dock, leisten_set, suche_aktiv),

            )

            return

        if self._icon_ausstehend and self._win:

            self._win.after(10, lambda: self._icons_nachladen(icon_px))



    def _fuellen(self) -> None:

        if not self._inner:

            return

        if hasattr(self, "_schrift_anzeige") and self._schrift_anzeige.winfo_exists():

            self._schrift_anzeige.config(text=str(self._schrift_pt()))

        # Scrollposition merken — der Rebuild zerstoert alle Zeilen und
        # wuerde sonst sichtbar auf Anfang springen (Nutzer 07.10.2026:
        # „aktualisieren zuckt rum — Nutzer erschrickt, wirkt kaputt").
        canvas = getattr(self, "_canvas", None)

        y_anteil = 0.0

        if canvas is not None:

            try:

                y_anteil = canvas.yview()[0]

            except tk.TclError:

                canvas = None

        self._fuellen_batch_abbrechen()

        self._fuellen_gen += 1

        gen = self._fuellen_gen

        for child in self._inner.winfo_children():

            child.destroy()

        self._zeilen_icons.clear()
        self._icon_ausstehend = []

        # Eintraege koennen sich seit dem letzten Aufbau geaendert haben
        # (Anheften/Entfernen) -> Leisten-Schluessel neu bilden.
        self._leisten_schl = None

        leisten_set = self._leisten_schluessel()

        zeilen_queue: list[tuple[tk.Frame, dict, str]] = []

        suche_rest = 0

        # Pool nicht fertig -> „Lade Katalog“ statt synchroner Vollscan auf
        # dem UI-Thread (fror das Panel bis zum Ende des Scans schwarz ein).
        # Nur wenn das Vorwaermen selbst fehlgeschlagen ist, synchron als
        # letzte Stufe weiter (Nutzer 09.10.2026).
        if not katalog.pool_bereit() and not katalog.pool_fehlgeschlagen():

            katalog.vorgewaermen_starten()

            tk.Label(

                self._inner,

                text="Lade Katalog…",

                bg="#353535",

                fg="#cccccc",

                font=self._font(),

                pady=12,

            ).pack()

            if self._win:

                self._win.after(400, self._fuellen)

            return

        q = (self._search_var.get() or "").strip()

        self._fuellen_suche = q

        suche_aktiv = bool(q)

        icon_px = self._icon_px()

        dock = getattr(self._bar, "docked", "none")



        hat_treffer = False

        suche_gezeigt = 0

        for kid, titel, items in katalog.gruppen(data=self._bar.cfg.data):

            items = katalog.suche_filter(items, q)

            if not items:

                continue

            hat_treffer = True

            zuk = False if suche_aktiv else self._gruppe_zuklapp.get(kid, _GRUPPE_ZUKLAPP_STD.get(kid, True))

            pfeil = "▶" if zuk else "▼"

            hdr = tk.Button(

                self._inner,

                text=f"{pfeil}  {titel}  ({len(items)})",

                command=lambda k=kid: self._gruppe_toggle(k),

                bg="#606060",

                fg="#ffffff",

                activebackground="#707070",

                relief=tk.FLAT,

                font=self._font(bold=True),

                anchor="w",

                padx=8,

                pady=4,

                cursor="hand2",

            )

            hdr.pack(fill=tk.X, padx=4, pady=(6, 2))

            if zuk:

                continue

            liste = tk.Frame(self._inner, bg="#353535")

            liste.pack(fill=tk.X)

            kat_limit = 80 if kid == "startmenue" else 200

            for e in items[:kat_limit]:

                if suche_aktiv and suche_gezeigt >= _SUCHE_MAX_ZEILEN:

                    suche_rest += 1

                    continue

                zeilen_queue.append((liste, e, kid))

                if suche_aktiv:

                    suche_gezeigt += 1

        if suche_aktiv and suche_rest:

            tk.Label(

                self._inner,

                text=f"… und {suche_rest} weitere Treffer — Suche verfeinern",

                bg="#353535",

                fg="#999999",

                font=self._font(),

                pady=6,

            ).pack()

        if zeilen_queue and (suche_aktiv or len(zeilen_queue) > _ZEILEN_SYNC_MAX):

            self._fuellen_queue = zeilen_queue

            self._fuellen_batch(gen, icon_px, dock, leisten_set, suche_aktiv)

        else:

            for liste, e, _kid in zeilen_queue:

                self._zeile_einfuegen(

                    liste,

                    e,

                    icon_px=icon_px,

                    dock=dock,

                    leisten_set=leisten_set,

                    suche_aktiv=suche_aktiv,

                    fuellen_gen=gen,

                )

            if self._icon_ausstehend and self._win:

                self._win.after(10, lambda: self._icons_nachladen(icon_px))

        # Bei Suche ohne Treffer bisher nur schwarze Flaeche — Nutzer wusste
        # nicht, ob gesucht wurde oder der Katalog kaputt ist (09.10.2026).
        if suche_aktiv and not hat_treffer:

            tk.Label(

                self._inner,

                text=f"Kein Treffer für „{q}“",

                bg="#353535",

                fg="#dddddd",

                font=self._font(bold=True),

                pady=8,

            ).pack()

            tk.Label(

                self._inner,

                text="Anderen Begriff versuchen — oder unten „Ziel manuell…“",

                bg="#353535",

                fg="#999999",

                font=self._font(),

            ).pack()

        if canvas is not None and y_anteil and not suche_aktiv:

            def _scroll_zurueck(versuche: int = 3) -> None:

                try:

                    # Direkt nach dem Rebuild ist bbox("all") noch zu klein
                    # (Geometrie laeuft erst im Idle) — moveto klemmte dann auf
                    # eine Mini-Region und die Liste sprang sichtbar nach oben
                    # (Nutzer 09.10.2026). Erst Geometrie rechnen lassen.
                    self._win.update_idletasks()

                    canvas.configure(scrollregion=canvas.bbox("all"))

                    canvas.yview_moveto(y_anteil)

                    if versuche > 1 and abs(canvas.yview()[0] - y_anteil) > 0.02:

                        self._win.after(50, lambda: _scroll_zurueck(versuche - 1))

                except tk.TclError:

                    pass

            self._win.after_idle(_scroll_zurueck)



    def _icon_platzhalter(self, px: int):

        ph = getattr(self, "_icon_ph_img", None)

        if ph is None or ph.width() != px:

            ph = tk.PhotoImage(width=px, height=px)

            # Leeres PhotoImage (keine Pixeldaten) zeichnet Tk als winziges
            # „x" — sah aus wie ein kaputter Eintrag (Nutzer 09.10.2026).
            # blank() fuellt es mit echten transparenten Pixeln = unsichtbar.
            ph.blank()

            self._icon_ph_img = ph

        return ph



    def _icons_nachladen(self, icon_px: int) -> None:

        ausstehend = getattr(self, "_icon_ausstehend", None) or []

        batch, rest = ausstehend[:8], ausstehend[8:]

        self._icon_ausstehend = rest

        for lbl, name, target in batch:

            try:

                if not lbl.winfo_exists():

                    continue

                photo = icons.get_icon(name, target, icon_px, False)

                self._zeilen_icons.append(photo)

                lbl.config(image=photo)

                lbl.image = photo

            except tk.TclError:

                continue

        if rest and self._win and self._win.winfo_exists():

            self._win.after(10, lambda: self._icons_nachladen(icon_px))





def oeffnen_anheften_panel(bar) -> None:

    inst = getattr(bar, "_katalog_panel", None)

    if inst is None:

        inst = KatalogPanel(bar)

        bar._katalog_panel = inst

    inst.oeffnen()


