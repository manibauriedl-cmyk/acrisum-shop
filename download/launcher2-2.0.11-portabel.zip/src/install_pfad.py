"""Installationsroot, Auslieferungs-Erkennung, eingebettete Python-Laufzeit.

KVA 313 (eingebettetes Python), KVA 314 (PORTABLE.ON), KVA 287 (Update-Paket).
Dev: D:\\xx1lounger ohne python\\ — Kunden-Mutex und System-Python.
Auslieferung: python\\pythonw.exe im Paket — kein separates Python nötig.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from .app_id import APP_NAME, LEGACY_APP_SLUG
from .version import get_version

INSTALL_ROOT = Path(__file__).resolve().parent.parent
PORTABLE_MARKER = INSTALL_ROOT / "PORTABLE.ON"

# Vom Setup geschrieben (%APPDATA%\launcher2\last_install_dir.txt) — naechstes Setup
# startet wieder mit diesem Zielordner (auch anderes Laufwerk / fuer-alle-Modus).
LAST_INSTALL_DIR_MARKER = "last_install_dir.txt"
_EMBED_PY = INSTALL_ROOT / "python" / "python.exe"
_EMBED_PYW = INSTALL_ROOT / "python" / "pythonw.exe"


def runtime_bereit() -> bool:
    """Eingebettete Laufzeit vollständig (python + pythonw)."""
    return _EMBED_PY.is_file() and _EMBED_PYW.is_file()


def ist_auslieferung() -> bool:
    """Kunden-Paket: Runtime da oder PORTABLE-Marker (Stick/Program Files)."""
    return runtime_bereit() or PORTABLE_MARKER.is_file()


def ist_entwicklung() -> bool:
    """Entwickler-Baum — kein eingebettetes Python im Installationsordner."""
    return not runtime_bereit()


def _mutex_ver_suffix() -> str:
    return get_version("0.0.0").split("-")[0].strip().replace(".", "_")


def mutex_name() -> str:
    """Ein Mutex pro Version — Dev und Install teilen sich die Leiste (kein Doppelstart)."""
    return f"{APP_NAME}_single_instance_{_mutex_ver_suffix()}"


def legacy_mutex_name() -> str:
    """Alter Mutex-Name — verhindert Doppelstart nach Umbenennung (xx1 → launcher2)."""
    return f"{LEGACY_APP_SLUG}_single_instance_{_mutex_ver_suffix()}"


def python_exe() -> str:
    if runtime_bereit():
        return str(_EMBED_PY)
    return sys.executable or "python"


def pythonw_exe() -> str:
    if runtime_bereit():
        return str(_EMBED_PYW)
    exe = sys.executable or ""
    if exe.lower().endswith("python.exe"):
        alt = exe[:-10] + "pythonw.exe"
        if os.path.isfile(alt):
            return alt
    for cand in (
        r"C:\Program Files\Python312\pythonw.exe",
        r"C:\Program Files\Python311\pythonw.exe",
    ):
        if os.path.isfile(cand):
            return cand
    return exe.replace("python.exe", "pythonw.exe") if exe else "pythonw"
