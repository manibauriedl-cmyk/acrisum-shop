"""Tray-Icon nativ ueber Win32 (Shell_NotifyIconW) — kein pystray-Thread.

KVA 225–232: Icon im Infobereich, Linksklick/Doppelklick zeigt die Leiste,
Rechtsklick oeffnet das Menue, generiertes Fallback-Icon, orange im Dev-Profil.

24.09.2026 stuerzte pystray+PIL im eigenen Thread ab (GIL). Diese Version
laeuft komplett im Tk-Hauptthread: Die Shell schickt Maus-Events als
Callback-Message an das Leisten-Fenster; die DROPFILES-WndProc reicht sie
als on_tray durch. Kein zusaetzlicher Thread, kein PIL.
"""
from __future__ import annotations

import ctypes
import logging
import os
from ctypes import wintypes
from pathlib import Path

from .app_id import APP_DISPLAY_NAME

user32 = ctypes.windll.user32
shell32 = ctypes.windll.shell32
gdi32 = ctypes.windll.gdi32

# Eigene Callback-Message im WM_USER-Bereich (0x0401 = OLE-Drop in drop.py).
WM_TRAYICON = 0x0402

NIF_MESSAGE = 0x00000001
NIF_ICON = 0x00000002
NIF_TIP = 0x00000004
NIM_ADD = 0x00000000
NIM_DELETE = 0x00000002

WM_LBUTTONUP = 0x0202
WM_LBUTTONDBLCLK = 0x0203
WM_RBUTTONUP = 0x0205

IMAGE_ICON = 1
LR_LOADFROMFILE = 0x00000010

# COLORREF ist 0x00BBGGRR
_GRAU = 0x00808080
_ORANGE = 0x0000A5FF
_ROT = 0x000000FF
_WEISS = 0x00FFFFFF


class NOTIFYICONDATAW(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("hWnd", wintypes.HWND),
        ("uID", wintypes.UINT),
        ("uFlags", wintypes.UINT),
        ("uCallbackMessage", wintypes.UINT),
        ("hIcon", wintypes.HICON),
        ("szTip", wintypes.WCHAR * 128),
        ("dwState", wintypes.DWORD),
        ("dwStateMask", wintypes.DWORD),
        ("szInfo", wintypes.WCHAR * 256),
        ("uVersion", wintypes.UINT),
        ("szInfoTitle", wintypes.WCHAR * 64),
        ("dwInfoFlags", wintypes.DWORD),
        ("guidItem", ctypes.c_byte * 16),
        ("hBalloonIcon", wintypes.HICON),
    ]


def _icon_generieren(orange: bool = False) -> int:
    """KVA 231 — Fallback-Icon per GDI zeichnen (kein PIL noetig).

    Graues Quadrat mit rotem Rahmen und „XL" — orange im Dev-Profil.
    Rueckgabe: HICON (0 bei Fehler).
    """
    breite = hoehe = 32
    hdc_screen = user32.GetDC(None)
    if not hdc_screen:
        return 0
    hdc = gdi32.CreateCompatibleDC(hdc_screen)
    hbm_color = gdi32.CreateCompatibleBitmap(hdc_screen, breite, hoehe)
    # Maske explizit nullen (alles sichtbar) — CreateBitmap mit NULL liefert
    # undefinierten Speicher; konnte das Icon als Farbquadrat/Muell zeigen.
    mask_bytes = b"\x00" * (((breite + 15) // 16) * 2 * hoehe)
    hbm_mask = gdi32.CreateBitmap(
        breite, hoehe, 1, 1, ctypes.create_string_buffer(mask_bytes, len(mask_bytes))
    )
    if not (hdc and hbm_color and hbm_mask):
        return 0
    alt = gdi32.SelectObject(hdc, hbm_color)
    try:
        hintergrund = gdi32.CreateSolidBrush(_ORANGE if orange else _GRAU)
        stift = gdi32.CreatePen(0, 3, _ROT)  # PS_SOLID
        rect = wintypes.RECT(0, 0, breite, hoehe)
        user32.FillRect(hdc, ctypes.byref(rect), hintergrund)
        alt_stift = gdi32.SelectObject(hdc, stift)
        gdi32.Rectangle(hdc, 1, 1, breite - 1, hoehe - 1)
        gdi32.SelectObject(hdc, alt_stift)
        # „XL" weiss mittig
        gdi32.SetTextColor(hdc, _WEISS)
        gdi32.SetBkMode(hdc, 1)  # TRANSPARENT
        user32.DrawTextW(hdc, "XL", -1, ctypes.byref(rect), 0x25)  # CENTER|VCENTER|SINGLELINE
        gdi32.DeleteObject(stift)
        gdi32.DeleteObject(hintergrund)
    finally:
        gdi32.SelectObject(hdc, alt)
        gdi32.DeleteDC(hdc)
        user32.ReleaseDC(None, hdc_screen)

    class ICONINFO(ctypes.Structure):
        _fields_ = [
            ("fIcon", wintypes.BOOL),
            ("xHotspot", wintypes.DWORD),
            ("yHotspot", wintypes.DWORD),
            ("hbmMask", wintypes.HBITMAP),
            ("hbmColor", wintypes.HBITMAP),
        ]

    info = ICONINFO(True, 0, 0, hbm_mask, hbm_color)
    hicon = user32.CreateIconIndirect(ctypes.byref(info))
    gdi32.DeleteObject(hbm_color)
    gdi32.DeleteObject(hbm_mask)
    return int(hicon or 0)


def _icon_laden(orange: bool) -> int:
    """assets/xlounger.ico (Dev: xlounger_dev.ico) laden, sonst generiert (KVA 231)."""
    assets = Path(__file__).resolve().parent.parent / "assets"
    namen = ["xlounger_dev.ico", "xlounger.ico"] if orange else ["xlounger.ico"]
    pfad = next((assets / n for n in namen if (assets / n).is_file()), None)
    if pfad is not None:
        hicon = user32.LoadImageW(
            None, str(pfad), IMAGE_ICON, 0, 0, LR_LOADFROMFILE
        )
        if hicon:
            return int(hicon)
        logging.warning("Icon-Datei unlesbar, generiere Ersatz: %s", pfad)
    return _icon_generieren(orange=orange)


def explorer_pid() -> int:
    """PID des Explorers (Shell-Fenster). 0 wenn gerade kein Shell-Fenster."""
    hwnd_shell = user32.GetShellWindow()
    if not hwnd_shell:
        return 0
    pid = wintypes.DWORD(0)
    user32.GetWindowThreadProcessId(hwnd_shell, ctypes.byref(pid))
    return int(pid.value)


class TrayWin32:
    """Natives Tray-Icon — laeuft im Tk-Hauptthread (kein eigener Thread)."""

    def __init__(self, hwnd: int, on_show=None, on_menu=None, dev: bool = False):
        self.hwnd = int(hwnd)
        self.on_show = on_show
        self.on_menu = on_menu
        self.dev = dev
        self._hicon = 0
        self._aktiv = False
        self._explorer_pid = 0

    def _notify(self, aktion: int) -> bool:
        data = NOTIFYICONDATAW()
        data.cbSize = ctypes.sizeof(NOTIFYICONDATAW)
        data.hWnd = self.hwnd
        data.uID = 1
        if aktion != NIM_DELETE:
            data.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP
            data.uCallbackMessage = WM_TRAYICON
            data.hIcon = self._hicon
            data.szTip = APP_DISPLAY_NAME
        return bool(shell32.Shell_NotifyIconW(aktion, ctypes.byref(data)))

    def start(self, erzwingen: bool = True) -> None:
        """Icon in den Infobereich. Idempotent — doppelter Aufruf tut nichts.

        erzwingen: Kompatibilitaet zum alten pystray-Aufruf (hier immer an).
        """
        if self._aktiv:
            return
        if os.environ.get("XLOUNGER_NO_TRAY", "").strip() in ("1", "true", "yes"):
            logging.info("Tray deaktiviert (XLOUNGER_NO_TRAY)")
            return
        self._hicon = _icon_laden(orange=self.dev)
        if not self._hicon:
            logging.warning("Tray-Icon konnte nicht erzeugt werden")
            return
        if self._notify(NIM_ADD):
            self._aktiv = True
            self._explorer_pid = explorer_pid()
            logging.info("Tray-Icon (nativ) im Infobereich%s", " — Dev orange" if self.dev else "")
        else:
            logging.warning("Shell_NotifyIconW NIM_ADD fehlgeschlagen")

    def pruefe_explorer_neustart(self) -> bool:
        """KVA 229 — Explorer neu gestartet? Dann Tray-Icon neu anmelden.

        Die Shell vergisst alle Tray-Icons beim Explorer-Neustart. Ohne
        WndProc (TaskbarCreated) pruefen wir die Explorer-PID im Watch-Tick.
        Rueckgabe: True wenn neu angemeldet.
        """
        if not self._aktiv:
            return False
        pid = explorer_pid()
        if not pid or pid == self._explorer_pid:
            return False
        self._explorer_pid = pid
        if self._notify(NIM_ADD):
            logging.info("Tray-Icon nach Explorer-Neustart neu angemeldet")
            return True
        logging.warning("Tray-Neuanmeldung nach Explorer-Neustart fehlgeschlagen")
        return False

    def handle_message(self, lparam: int) -> None:
        """Maus-Event vom Tray-Icon (aus der DROPFILES-WndProc, Tk-Thread).

        KVA 226/227: Linksklick + Doppelklick zeigen die Leiste.
        KVA 228: Rechtsklick oeffnet das Menue (Anzeigen/Beenden).
        """
        if lparam in (WM_LBUTTONUP, WM_LBUTTONDBLCLK):
            if self.on_show:
                self.on_show()
        elif lparam == WM_RBUTTONUP:
            if self.on_menu:
                self.on_menu()

    def stop(self) -> None:
        if self._aktiv:
            try:
                self._notify(NIM_DELETE)
            except Exception:
                pass
            self._aktiv = False
        if self._hicon:
            try:
                user32.DestroyIcon(self._hicon)
            except Exception:
                pass
            self._hicon = 0
