import ctypes
from ctypes import wintypes

from .app_id import APP_NAME, LEGACY_APP_SLUG
from .install_pfad import legacy_mutex_name, mutex_name

MUTEX_NAME = mutex_name()

# Registrierte Windows-Message fuer Zweitstart → laufende Instanz anzeigen.
WM_XLOUNGER_SHOW = ctypes.windll.user32.RegisterWindowMessageW(f"{APP_NAME}_show_bar")
WM_LEGACY_SHOW = ctypes.windll.user32.RegisterWindowMessageW(f"{LEGACY_APP_SLUG}_show_bar")


class SingleInstance:
    def __init__(self):
        self.mutex = None

    def acquire(self):
        kernel32 = ctypes.windll.kernel32
        for name in (MUTEX_NAME, legacy_mutex_name()):
            existing = kernel32.OpenMutexW(0x00100000, False, name)
            if existing:
                kernel32.CloseHandle(existing)
                return False
        self.mutex = kernel32.CreateMutexW(None, False, MUTEX_NAME)
        err = kernel32.GetLastError()
        return err == 0

    def release(self):
        if self.mutex:
            ctypes.windll.kernel32.CloseHandle(self.mutex)
            self.mutex = None


def request_show_existing():
    """Broadcast: laufende Instanz zeigen (aktueller + Legacy-Mutex-Name)."""
    HWND_BROADCAST = 0xFFFF
    user32 = ctypes.windll.user32
    for msg in (WM_XLOUNGER_SHOW, WM_LEGACY_SHOW):
        user32.PostMessageW(HWND_BROADCAST, msg, 0, 0)
