"""Erhöhter Start (Admin-Token) erkennen — Leiste ohne Erhöhung neu starten.

Hintergrund (Fehlerbericht Test-PC Win10, 08.11.2026): Wird das Setup per
„Als Administrator ausführen“ (oder aus einem erhöhten Prozess) gestartet,
läuft auch „Launcher 2 jetzt starten“ erhöht — Inno kann dann nicht auf den
Original-Benutzer zurück (offizielle Doku, Flag runasoriginaluser).
Folgen einer erhöhten Leiste:
- Explorer (mittlere Integrität) darf per UIPI nichts auf ein erhöhtes Fenster
  ziehen: OLE-Drop und WM_DROPFILES kommen nie an — kein Eintrag im Log.
- Ein nicht erhöhter Deinstaller/Stop erreicht das Fenster nicht (WM_CLOSE
  wird gefiltert) — python.exe bleibt gesperrt, Deinstall „geht nicht“.

Weg: Prozess über den Explorer-Desktop starten (IShellDispatch2.ShellExecute,
Raymond Chen „launch an unelevated process from an elevated process“) — das
Kind erbt das Token des Explorers. Fallback: Windows-Bordmittel
``runas /trustlevel:0x20000`` (Regel 31). Klappt beides nicht: weiterlaufen und
ehrlich loggen (Regel 26 — Nutzer nicht behindern).
"""
from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import logging
import os
import subprocess
import sys

_TOKEN_QUERY = 0x0008
_TokenElevationType = 18
_TokenElevation = 20
# TOKEN_ELEVATION_TYPE
TYP_UNBEKANNT = 0
TYP_DEFAULT = 1  # UAC aus oder Standardbenutzer ohne Admin-Hälfte
TYP_FULL = 2  # erhöhte Hälfte eines geteilten Tokens (UAC-Admin, „Als Administrator“)
TYP_LIMITED = 3  # normale (nicht erhöhte) Hälfte — so läuft auch der Explorer

NEUSTART_MARKER = "--nach-deerhoehung"

_CLSID_SHELLWINDOWS = "{9BA05972-F6A8-11CF-A442-00A0C90A8F39}"
_SWC_DESKTOP = 8
_SWFO_NEEDDISPATCH = 1


def _token_info(klasse: int) -> int | None:
    adv = ctypes.windll.advapi32
    k32 = ctypes.windll.kernel32
    k32.GetCurrentProcess.restype = wt.HANDLE
    adv.OpenProcessToken.argtypes = [wt.HANDLE, wt.DWORD, ctypes.POINTER(wt.HANDLE)]
    adv.GetTokenInformation.argtypes = [
        wt.HANDLE,
        ctypes.c_int,
        ctypes.c_void_p,
        wt.DWORD,
        ctypes.POINTER(wt.DWORD),
    ]
    h = wt.HANDLE()
    if not adv.OpenProcessToken(k32.GetCurrentProcess(), _TOKEN_QUERY, ctypes.byref(h)):
        return None
    try:
        wert = wt.DWORD()
        rueck = wt.DWORD()
        ok = adv.GetTokenInformation(
            h, klasse, ctypes.byref(wert), ctypes.sizeof(wert), ctypes.byref(rueck)
        )
        return int(wert.value) if ok else None
    finally:
        k32.CloseHandle(h)


def token_erhoehung_typ() -> int:
    """1 = Default, 2 = Full (erhöht, geteiltes Token), 3 = Limited, 0 = unbekannt."""
    return _token_info(_TokenElevationType) or TYP_UNBEKANNT


def ist_erhoeht() -> bool:
    return bool(_token_info(_TokenElevation))


def beschreibung() -> str:
    """Kurztext für Log/Fehlerbericht, z. B. ``ja (Typ Full)``."""
    namen = {TYP_DEFAULT: "Default", TYP_FULL: "Full", TYP_LIMITED: "Limited"}
    typ = token_erhoehung_typ()
    return f"{'ja' if ist_erhoeht() else 'nein'} (Token-Typ {namen.get(typ, typ)})"


def _ueber_explorer_starten(exe: str, args: str, cwd: str) -> None:
    import pythoncom
    import win32com.client
    from win32com.shell import shell, shellcon

    pythoncom.CoInitialize()
    fenster = win32com.client.Dispatch(_CLSID_SHELLWINDOWS)
    desktop = fenster.FindWindowSW(
        shellcon.CSIDL_DESKTOP, pythoncom.Empty, _SWC_DESKTOP, 0, _SWFO_NEEDDISPATCH
    )
    if isinstance(desktop, tuple):
        desktop = desktop[0]
    if desktop is None:
        raise RuntimeError("Explorer-Desktop nicht gefunden")
    sp = desktop._oleobj_.QueryInterface(pythoncom.IID_IServiceProvider)
    browser = sp.QueryService(shell.SID_STopLevelBrowser, shell.IID_IShellBrowser)
    view = browser.QueryActiveShellView()
    hintergrund = view.GetItemObject(shellcon.SVGIO_BACKGROUND, pythoncom.IID_IDispatch)
    app = win32com.client.Dispatch(hintergrund).Application
    app.ShellExecute(exe, args, cwd, "open", 0)


def _ueber_runas_starten(exe: str, args: str, cwd: str) -> None:
    runas = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "runas.exe")
    subprocess.Popen(
        [runas, "/trustlevel:0x20000", f'"{exe}" {args}'],
        cwd=cwd,
        creationflags=subprocess.CREATE_NO_WINDOW,
    )


def ohne_erhoehung_sicherstellen(argv: list[str]) -> bool:
    """Erhöht gestartet → ohne Erhöhung neu starten. True = Aufrufer soll beenden.

    Nur bei Token-Typ Full: dann läuft der Explorer des Nutzers mit der
    nicht erhöhten Hälfte, und die Leiste muss dorthin. Bei UAC aus (Default)
    oder bereits Limited ist nichts zu tun. ``--nach-deerhoehung`` verhindert
    eine Schleife, falls der Neustart wider Erwarten wieder erhöht ankommt.
    """
    typ = token_erhoehung_typ()
    if NEUSTART_MARKER in argv:
        logging.info("Start nach Neustart ohne Erhöhung — erhöht: %s", beschreibung())
        return False
    if typ != TYP_FULL:
        logging.info("Start — erhöht: %s", beschreibung())
        return False
    exe = sys.executable
    skript = os.path.abspath(argv[0]) if argv else ""
    rest = " ".join(f'"{a}"' for a in argv[1:])
    args = f'"{skript}" {NEUSTART_MARKER} {rest}'.strip()
    cwd = os.path.dirname(skript) or os.getcwd()
    logging.warning(
        "Prozess läuft erhöht (Admin-Token, Typ Full) — Explorer könnte nichts auf die "
        "Leiste ziehen; Neustart ohne Erhöhung über Explorer-Desktop"
    )
    try:
        _ueber_explorer_starten(exe, args, cwd)
        logging.info("Neustart ohne Erhöhung angestoßen (Explorer): %s %s", exe, args)
        return True
    except Exception as exc:
        logging.warning("Neustart über Explorer fehlgeschlagen: %s — Fallback runas", exc)
    try:
        _ueber_runas_starten(exe, args, cwd)
        logging.info("Neustart ohne Erhöhung angestoßen (runas /trustlevel): %s %s", exe, args)
        return True
    except Exception as exc:
        logging.error(
            "Neustart ohne Erhöhung nicht möglich (%s) — Leiste läuft erhöht weiter; "
            "Ziehen vom Desktop ist dann blockiert",
            exc,
        )
        return False
