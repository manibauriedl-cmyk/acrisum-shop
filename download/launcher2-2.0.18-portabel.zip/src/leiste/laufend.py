"""Laufende Programme — Running-Punkt, Ueberlappung/Auto-Transparenz, fremder Fokus, Browser-Tabs."""
import ctypes
import logging
import os
import re
import shutil
import time
import tkinter as tk
import psutil
from .win32_optional import win32gui, win32process
from ..browser_url import browser_url, is_web_url
from ..appbar import (
    AppBar,
)
from .. import masse


# Generische Oeffner — das Ziel (Datei/Bild/Ordner) wird von ihnen nur
# angezeigt; der Oeffner selbst ist nicht das „laufende Programm" und
# haette als Shell ohnehin immer ein Fenster (Nutzer 09.10.2026).
_GENERIC_OEFFNER = frozenset({"explorer.exe"})

# Prozesse, die andere Ziele per Kommandozeile starten (mmc.exe -> devmgmt.msc).
_LAUNCHER_PROZESSE = frozenset(
    {
        "mmc.exe",
        "rundll32.exe",
        "control.exe",
        "wscript.exe",
        "cscript.exe",
        "powershell.exe",
        "cmd.exe",
        "explorer.exe",
        "msiexec.exe",
        "hh.exe",
        "python.exe",
        "pythonw.exe",
    }
)


_EXE_ARG_RE = re.compile(r"(?i)\.exe\b")


def _split_exe_args(target: str) -> tuple[str, str]:
    """'…prog.exe arg1 arg2' -> (exe-Teil, args-Teil). 'prog.exe' -> ('prog.exe', '')."""
    t = target.strip()
    if t.startswith('"'):
        end = t.find('"', 1)
        if end != -1:
            return t[1:end].strip(), t[end + 1 :].strip()
        return t.strip('"'), ""
    m = _EXE_ARG_RE.search(t)
    if m and t[m.end() :].strip():
        return t[: m.end()].strip(), t[m.end() :].strip()
    return t, ""


def _arg_tokens(args: str) -> list[str]:
    """Argument-Tokens (klein, ohne Anfuehrungszeichen/URLs) fuer den
    Kommandozeilen-Vergleich."""
    toks: list[str] = []
    for t in args.split():
        t = t.strip("\"'").lower()
        if t and not t.startswith(("http://", "https://")):
            toks.append(t)
    return toks


class LaufendMixin:
    def _ziel_aufgeloest(self, target: str) -> tuple[str | None, str | None]:
        """Gecacht: .lnk -> exe-Pfad, .url -> URL. (None, None) wenn nichts."""
        cache = self.__dict__.setdefault("_ziel_cache", {})
        if target in cache:
            return cache[target]
        exe = url = None
        try:
            low = target.lower()
            if low.endswith(".lnk"):
                from ..launcher import resolve_lnk

                p, a = resolve_lnk(target)
                if p and p.lower().endswith(".exe"):
                    exe = os.path.normcase(os.path.abspath(p))
                # Browser-Verknuepfung (chrome.exe --new-window "http://…"):
                # URL aus den Argumenten mitnehmen — Lauf-Punkt und
                # „laeuft bereits"-Check gehen dann ueber die Adressleiste.
                for tok in (a or "").split():
                    tok = tok.strip("\"'")
                    if is_web_url(tok):
                        url = tok
                        break
            elif low.endswith(".url"):
                from ..launcher import read_url_file

                url = read_url_file(target)
        except Exception:
            pass
        cache[target] = (exe, url)
        return exe, url

    def _ziel_args(self, target: str) -> str:
        """Argumente einer .lnk-Verknuepfung (ohne URL-Teil)."""
        cache = self.__dict__.setdefault("_ziel_cache", {})
        key = target + "#args"
        if key in cache:
            return cache[key]
        args = ""
        try:
            if target.lower().endswith(".lnk"):
                from ..launcher import resolve_lnk

                _p, a = resolve_lnk(target)
                args = (a or "").strip()
        except Exception:
            pass
        cache[key] = args
        return args

    def _init_laufend_zustand(self) -> None:
        """Zustand dieses Moduls — aus Bar.__init__."""
        self._running: dict[str, bool] = {}
        # Hysterese: Roh-Ergebnis des letzten Checks — ein Zustandswechsel
        # wird erst uebernommen, wenn zwei Checks (ca. 4 s) dasselbe liefern.
        # Kurzlebige Prozesse (WindowsApps-Stubs, flackernde Dienste) wuerden
        # den Punkt sonst blinken lassen.
        self._running_roh: dict[str, bool] = {}
        # PID-Menge der Prozesse mit Fenster — pro Check neu aufgebaut.
        self._fenster_pids: set[int] | None = None
        # PID -> sichtbare Fenster-Titel (klein) — fuer den Ordner-Familien-
        # Match: erst ein passendes Fenster macht „Suite-Modul laeuft" wahr.
        self._fenster_titel: dict[int, list[str]] | None = None
        self._url_launched: dict[str, float] = {}

    def _start_running_check(self):
        self.root.after(2000, self._check_running)

    def _pid_hat_fenster(self, pid: int) -> bool:
        """True, wenn der Prozess ein Fenster besitzt (sichtbar oder minimiert)."""
        if not win32gui or not win32process:
            return True
        if self._fenster_pids is None:
            pids: set[int] = set()
            titel_map: dict[int, list[str]] = {}

            def _enum(w, _):
                try:
                    if not (win32gui.IsWindowVisible(w) or win32gui.IsIconic(w)):
                        return
                    # Mini-Hilfsfenster ohne Titel (z. B. RustDesks 16x16
                    # „Tao Thread Event Target") stehen mit WS_VISIBLE da —
                    # liessen den Punkt gruen, obwohl das echte Fenster
                    # geschlossen/in den Tray war (Nutzer 09.10.2026).
                    # Titel oder brauchbare Flaeche = echtes App-Fenster.
                    r = win32gui.GetWindowRect(w)
                    t = (win32gui.GetWindowText(w) or "").strip().lower()
                    if not t and (r[2] - r[0]) * (r[3] - r[1]) < 3600:
                        return
                    _, p = win32process.GetWindowThreadProcessId(w)
                    pids.add(p)
                    if t:
                        titel_map.setdefault(p, []).append(t)
                except Exception:
                    pass

            try:
                win32gui.EnumWindows(_enum, None)
            except Exception:
                pass
            self._fenster_pids = pids
            self._fenster_titel = titel_map
        return pid in self._fenster_pids

    def _fenster_titel_von(self, pid: int) -> list[str]:
        """Sichtbare Fenster-Titel eines Prozesses (leer ohne Fenster)."""
        self._pid_hat_fenster(pid)  # baut _fenster_pids + _fenster_titel auf
        return (getattr(self, "_fenster_titel", None) or {}).get(pid, [])

    def _entry_liveness_path(self, entry: dict) -> str:
        """Start-Skript (.bat) → Lauf-Punkt an der echten Desktop-exe (nicht cmd/Titel)."""
        launch = entry.get("launch") or {}
        p = str(launch.get("liveness_path") or "").strip().strip('"')
        if p.lower().endswith(".exe") and os.path.isfile(p):
            return os.path.abspath(p)
        custom: dict = {}
        if hasattr(self, "_entry_custom"):
            custom = self._entry_custom(entry) or {}
        else:
            eid = str(entry.get("id") or "")
            if eid:
                custom = (self.cfg.data.get("user_customizations") or {}).get(eid) or {}
        p = str(custom.get("liveness_path") or "").strip().strip('"')
        if p.lower().endswith(".exe") and os.path.isfile(p):
            return os.path.abspath(p)
        return ""

    def _check_running(self):
        self._fenster_pids = None
        self._fenster_titel = None
        if not self.root.winfo_exists():
            return
        running: dict[str, bool] = {}
        try:
            entries = self.cfg.data.get("entries", [])
            exe_by_name: dict[str, list[str]] = {}
            exe_by_path: dict[str, list[str]] = {}
            # Target -> geforderte Argument-Tokens: „prog.exe --safe" zaehlt
            # nur, wenn die Kommandozeile des Prozesses die Parameter
            # enthaelt. Gleiche exe + andere Parameter = anderer Eintrag.
            arg_by_target: dict[str, list[str]] = {}
            # Programmordner -> Eintrags-Targets: Schwester-exe aus demselben
            # Ordner zaehlt zur Familie (scalc.exe-Eintrag vs. laufendes
            # soffice.bin). Nicht unter %WINDIR% — sonst wuerde notepad.exe
            # halb System32 adoptieren.
            dir_targets: dict[str, list[str]] = {}
            windir = os.path.normcase(os.environ.get("WINDIR", r"C:\Windows"))

            def _reg_exe(exe_abs: str, tkey: str) -> None:
                # Nur der volle Pfad entscheidet — gleichnamige exe in
                # einem anderen Ordner darf nicht matchen (Nutzer
                # 09.10.2026). exe_by_name bleibt allein fuer bare
                # Namen ohne Pfad (notepad.exe). Mehrere Eintraege auf
                # dieselbe exe (verschiedene Parameter) -> Liste.
                exe_by_path.setdefault(os.path.normcase(exe_abs), []).append(tkey)
                d = os.path.normcase(os.path.dirname(exe_abs))
                if d and not d.startswith(windir):
                    dir_targets.setdefault(d, []).append(tkey)
                try:
                    from ..icons import _appexec_ziel

                    echt = _appexec_ziel(exe_abs)
                    if echt:
                        # WindowsApps-Alias (0-Byte-Stub) -> Paket-exe.
                        exe_by_path.setdefault(os.path.normcase(echt), []).append(
                            tkey
                        )
                except Exception:
                    pass

            # Nicht-exe-Ziele (devmgmt.msc, .bat, Ordner-Kommandos) — werden ueber
            # die Kommandozeile der Start-Programme (mmc.exe, control.exe, ...)
            # erkannt. Basename -> Eintrags-Target.
            sonstige: dict[str, str] = {}
            # Ziele, deren Oeffner ein generischer Prozess ist (explorer.exe
            # fuer Dateien/Bilder): der Oeffner laeuft immer — erkannt wird
            # der Eintrag nur ueber einen passenden Fenster-Titel.
            nur_titel: list[str] = []
            # Titel-Tokens pro Target fuer den Ordner-Familien-Match:
            # Eintragsname + Datei-Stamm. Nur wenn ein Fenster-Titel den
            # Eintrag wiedererkennt, zaehlt eine Schwester-exe als „sein"
            # Modul — das OpenOffice-Start Center allein darf Writer+Calc
            # nicht als laufend malen (Nutzer 08.10.2026).
            token_by_target: dict[str, list[str]] = {}
            for e in entries:
                target = e.get("target", "")
                if not target:
                    continue
                liv = self._entry_liveness_path(e)
                if liv:
                    _reg_exe(liv, target)
                tokens: list[str] = []
                for wert in (
                    str(e.get("name") or ""),
                    os.path.splitext(os.path.basename(target))[0],
                ):
                    w = " ".join(wert.lower().split())
                    if len(w) >= 4 and w not in tokens:
                        tokens.append(w)
                token_by_target[target] = tokens
                low = target.lower()
                exe_teil = ""
                args = ""
                if ".exe" in low and not low.endswith((".lnk", ".url")):
                    exe_teil, args = _split_exe_args(target)
                if exe_teil and exe_teil.lower().endswith(".exe"):
                    # URL in den Argumenten („chrome.exe --new-window <url>")
                    # zaehlt wie eine Browser-Verknuepfung ueber die
                    # Adressleiste — nicht ueber jedes Browser-Fenster.
                    arg_url = ""
                    for tok in args.split():
                        if is_web_url(tok.strip("\"'")):
                            arg_url = tok.strip("\"'")
                            break
                    if arg_url:
                        if self._url_is_open(arg_url, str(e.get("name") or "")):
                            running[target] = True
                    else:
                        pfad = (
                            exe_teil
                            if os.path.isfile(exe_teil)
                            else shutil.which(exe_teil)
                        )
                        if pfad:
                            _reg_exe(os.path.abspath(pfad), target)
                        if not pfad or (
                            os.sep not in exe_teil and "/" not in exe_teil
                        ):
                            # Bare-Name ohne Pfad (notepad.exe) — Namen-Match
                            # ist die einzige Moeglichkeit (08.10.2026).
                            exe_by_name.setdefault(
                                os.path.basename(exe_teil.lower()), []
                            ).append(target)
                        toks = _arg_tokens(args)
                        if toks:
                            arg_by_target[target] = toks
                elif target.startswith(("http://", "https://")):
                    if self._url_is_open(target, str(e.get("name") or "")):
                        running[target] = True
                elif low.startswith("shell:"):
                    continue
                elif low.endswith((".lnk", ".url")):
                    exe, url = self._ziel_aufgeloest(target)
                    if exe and url:
                        # Browser-Verknuepfung „chrome.exe --new-window <url>":
                        # nur die URL zaehlt — sonst malt jedes beliebige
                        # Browser-Fenster den Punkt (Nutzer 09.10.2026).
                        exe = None
                    elif exe and os.path.basename(exe).lower() in _GENERIC_OEFFNER:
                        exe = None
                        nur_titel.append(target)
                    if exe:
                        _reg_exe(exe, target)
                        toks = _arg_tokens(self._ziel_args(target))
                        if toks:
                            arg_by_target[target] = toks
                    if url and self._url_is_open(url, str(e.get("name") or "")):
                        running[target] = True
                    if not exe and not url:
                        if not liv:
                            sonstige[os.path.basename(low)] = target
                        # .lnk auf Dokument (kein exe im Ziel): das
                        # aufgehende Fenster traegt den Namen im Titel.
                        # Ordner bleiben raus — „Desktop" wuerde sonst an
                        # jedem „SimplySign Desktop"-Fenster haengen.
                        if os.path.splitext(low)[1] and not liv:
                            nur_titel.append(target)
                else:
                    if liv:
                        continue
                    sonstige[os.path.basename(low)] = target
                    # Direkt gepinnte Datei (z. B. .png): der Oeffner
                    # (Photos o. ae.) ist kein Launcher-Prozess, also
                    # zaehlt der Fenster-Titel (Nutzer 10.10.2026).
                    # Nur Dateien mit Endung — Ordner-Pins wie „Desktop"
                    # wuerden an fremden Fenstertiteln kleben.
                    if os.path.splitext(low)[1]:
                        nur_titel.append(target)
            if exe_by_name or exe_by_path or sonstige:
                treffer_pid_target: dict[int, str] = {}
                paare: list[tuple[int, int]] = []
                for proc in psutil.process_iter(["name", "pid", "ppid", "exe"]):
                    try:
                        pid = proc.info.get("pid") or 0
                        paare.append((pid, proc.info.get("ppid") or 0))
                        pname = (proc.info.get("name") or "").lower()
                        pexe = proc.info.get("exe")
                        treffer: list[str] = []
                        if pexe:
                            treffer = list(
                                exe_by_path.get(os.path.normcase(pexe), ())
                            )
                        if not treffer:
                            treffer = list(exe_by_name.get(pname, ()))
                        if not treffer and sonstige and pname in _LAUNCHER_PROZESSE:
                            cmd = " ".join(proc.cmdline() or []).lower()
                            for base, tkey in sonstige.items():
                                if base and base in cmd:
                                    treffer = [tkey]
                                    break
                        target_keys: list[str] = []
                        cmd_lower = ""
                        for tkey in treffer:
                            # Eintrag verlangt Parameter -> alle Tokens
                            # muessen in der Kommandozeile stehen.
                            toks = arg_by_target.get(tkey)
                            if toks:
                                if not cmd_lower:
                                    cmd_lower = " ".join(
                                        proc.cmdline() or []
                                    ).lower()
                                if not all(t in cmd_lower for t in toks):
                                    continue
                            target_keys.append(tkey)
                        if target_keys:
                            # Treffer IMMER in die Familie — auch ohne
                            # eigenes Fenster: Stub-Launcher (git-bash.exe
                            # -> mintty.exe, swriter.exe -> soffice.bin)
                            # besitzen das sichtbare Fenster erst im
                            # Kindprozess (Nutzer 10.10.2026).
                            treffer_pid_target[pid] = list(target_keys)
                            # Punkt = „Programm hat ein Fenster" (sichtbar
                            # oder minimiert). Prozesse ohne Fenster —
                            # Browser-Hintergrundjobs, Suite-Stubs, Dienste,
                            # Host-Skripte — halten den Punkt nicht fest,
                            # nachdem der Nutzer das Fenster geschlossen
                            # hat (Nutzer 09.10.2026).
                            if not (pid and self._pid_hat_fenster(pid)):
                                continue
                            for tk_ in target_keys:
                                running[tk_] = True
                            # Zwei Eintraege auf dieselbe exe (bare Name +
                            # Startmenue-lnk — „Zeichentabelle"/„Character
                            # Map" bei charmap.exe): alle markieren, nicht
                            # nur den ersten (Nutzer 10.10.2026).
                            treffer_pid_target[pid] = list(target_keys)
                            if win32gui:
                                for tk_ in target_keys:
                                    self._update_last_hwnd(tk_, pid)
                        elif pexe:
                            # Prozess ist selbst kein Eintrag, liegt aber im
                            # Programmordner eines Eintrags -> Schwester-exe
                            # derselben Suite (soffice.bin fuer scalc.exe).
                            # Eintrag-Prozesse landen nie hier (sie matchen
                            # oben schon) — Excel.exe malt so nicht auch
                            # Word/Outlook als „laeuft". Fenster-Pflicht
                            # gegen Helfer ohne Oberflaeche (GoogleUpdate
                            # neben chrome.exe u. a.) (08.10.2026).
                            if not (pid and self._pid_hat_fenster(pid)):
                                continue
                            pdir = os.path.dirname(os.path.normcase(pexe))
                            # Zusaetzlich muss ein Fenster-Titel den Eintrag
                            # wiedererkennen (Token = Name oder Datei-Stamm) —
                            # das Start Center („Apache OpenOffice 4") darf
                            # nicht alle OO-Module rot malen, ohne dass ein
                            # Dokument offen ist (Nutzer 08.10.2026).
                            titel = self._fenster_titel_von(pid)
                            for tkey in dir_targets.get(pdir, ()):
                                toks = token_by_target.get(tkey) or []
                                if toks and not any(
                                    k in t for t in titel for k in toks
                                ):
                                    continue
                                running[tkey] = True
                                treffer_pid_target.setdefault(
                                    pid, []
                                ).append(tkey)
                                if pid and win32gui:
                                    self._update_last_hwnd(tkey, pid)
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        pass
                # Kindprozesse gehoeren zur Familie (Launcher -> java u. a.) —
                # solange der Eltern-Prozess noch laeuft.
                geaendert = True
                while geaendert:
                    geaendert = False
                    for pid, ppid in paare:
                        tkeys = treffer_pid_target.get(ppid)
                        if tkeys and pid not in treffer_pid_target:
                            treffer_pid_target[pid] = tkeys
                            # Erbt in jedem Fall weiter (auch ueber
                            # fensterlose Zwischenprozesse) — den Punkt
                            # gibt es aber nur mit sichtbarem Fenster.
                            if self._pid_hat_fenster(pid):
                                for tk_ in tkeys:
                                    running[tk_] = True
                            geaendert = True
                # Generische-Oeffner-Ziele (explorer.exe -> Bild/Datei):
                # nur ein Fenster-Titel mit dem Eintrags-/Dateinamen zaehlt.
                if nur_titel:
                    alle_titel = [
                        t
                        for titel in (self._fenster_titel or {}).values()
                        for t in titel
                    ]
                    for target in nur_titel:
                        toks = token_by_target.get(target) or []
                        if toks and any(
                            k in t for t in alle_titel for k in toks
                        ):
                            running[target] = True
        except Exception as exc:
            logging.debug("Fehler Laufpruefung: %s", exc)
        # Hysterese: nur uebernehmen, wenn der Roh-Wert zweimal hintereinander
        # gleich war — sonst bleibt die Anzeige (kein Flackern).
        neu = dict(self._running)
        for k in set(self._running) | set(running):
            jetzt = bool(running.get(k))
            if jetzt == bool(self._running_roh.get(k)):
                if jetzt:
                    neu[k] = True
                else:
                    neu.pop(k, None)
        self._running_roh = dict(running)
        changed = neu != self._running
        if changed:
            logging.info(
                "Lauf-Status: neu=%s weg=%s",
                [os.path.basename(k).encode("ascii", "replace").decode() for k in neu if not self._running.get(k)],
                [os.path.basename(k).encode("ascii", "replace").decode() for k in self._running if not neu.get(k)],
            )
        self._running = neu
        if changed:
            self._update_running_indicators()
        self._start_running_check()

    def _update_last_hwnd(self, target, pid):
        """Letztes sichtbares Fenster-Handle fuer einen Eintrag merken."""
        try:
            best = None
            def _enum(wnd, _):
                nonlocal best
                if not win32gui.IsWindowVisible(wnd):
                    return
                if win32gui.IsIconic(wnd):
                    return
                _, wpid = win32process.GetWindowThreadProcessId(wnd)
                if wpid == pid:
                    title = win32gui.GetWindowText(wnd)
                    if title:
                        best = wnd
            win32gui.EnumWindows(_enum, None)
            if best:
                hwnds = self.cfg.data.setdefault("last_window_hwnds", {})
                hwnds[target] = best
        except Exception:
            pass

    def _sync_running_dot(self, punkt, *, running: bool, bg: str) -> None:
        """Lauf-Punkt: gruen nur wenn laeuft; sonst keine sichtbare Ecke (Overlay).

        Symbol+Text: place nur bei gruen — reservierte Ecke bleibt frei.
        Nur-Text: Oval links (grau/gruen), Platz wie bisher.
        """
        if punkt is None:
            return
        try:
            punkt.configure(bg=bg)
            punkt.delete("all")
        except tk.TclError:
            return
        d = max(5, int(punkt.cget("width")) or 5)
        overlay = bool(getattr(punkt, "_xl_overlay", True))
        if overlay:
            if running:
                punkt.create_oval(
                    1, 1, d - 1, d - 1, fill=masse.RUNNING_DOT, outline=""
                )
                punkt.place(relx=0.0, rely=0.0, anchor="nw")
            else:
                punkt.place_forget()
            return
        fill = masse.RUNNING_DOT if running else bg
        punkt.create_oval(1, 1, d - 1, d - 1, fill=fill, outline="")

    def _update_running_indicators(self):
        entries = self.cfg.data.get("entries", [])
        cell_bg = self._leiste_bg()
        for btn in self.buttons:
            target = getattr(btn, "_target", None)
            if not target:
                continue
            entry = next((e for e in entries if e.get("target") == target), None)
            if not entry:
                continue
            running = self._running.get(target, False)
            try:
                btn._xl_laeuft = running
                punkt = getattr(btn, "_running_dot", None)
                if punkt:
                    self._sync_running_dot(punkt, running=running, bg=cell_bg)
            except tk.TclError:
                pass
        # Offenes »-Feld mitziehen — Nutzer soll den Punkt nicht erst
        # nach Schliessen/Oeffnen sehen muessen (09.10.2026).
        for btn, entry in getattr(self, "_ueberlauf_feld_knoepfe", None) or []:
            try:
                running = bool(self._running.get(entry.get("target")))
                btn._xl_laeuft = running
                punkt = getattr(btn, "_running_dot", None)
                if punkt:
                    self._sync_running_dot(punkt, running=running, bg=cell_bg)
            except tk.TclError:
                pass

    def _url_is_open(self, url: str, name: str = "") -> bool:
        if is_web_url(url):
            url = browser_url(url)
        # 1) Kuerzlich ueber xlounger gestartet
        launched = self._url_launched.get(url, 0)
        if time.monotonic() - launched < 60:
            return True
        # 2) Exakt: echte Adressleiste per UI-Automation — voller
        #    URL-Abgleich (Host, Port UND Pfad, urls_gleiche_seite).
        #    Kein Titel-Raten (KVA 158 / Nutzer 09.10.2026:
        #    „gesamtpfad als Entscheidungspunkt").
        try:
            from ..browser_tab import finde_url_fenster

            return bool(finde_url_fenster(url, (name,) if name else ()))
        except Exception:
            return False
