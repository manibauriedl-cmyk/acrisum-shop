"""Alte Launcher-Namen (xx1lounger, …) — Laufzeit-Reste vor Install/Update räumen.

Einstellungen: %APPDATA%\\xx1lounger wird nicht gelöscht, sondern nach launcher2
gemerged (paths.get_appdata_dir). Hier: Prozesse, AppBar, Autostart, tote Ordner.
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
from pathlib import Path

from .app_id import APP_DISPLAY_NAME, APP_NAME, APP_SLUG, LEGACY_APP_SLUG
from .appbar_persist import shell_appbar_bereinigen
from .paths import get_appdata_dir
from .prozess_beenden import geist_leiste_beenden, waechter_beenden

# Bekannte frühere Produkt-/Ordnernamen (2.x-Linie + Beta)
LEGACY_APPDATA_NAMEN = (
    LEGACY_APP_SLUG,  # xx1lounger
    "xlounger",
    "Launcher2",
    "Launcher 2",
)
LEGACY_PROGRAMS_ORDNER = (
    LEGACY_APP_SLUG,
    APP_SLUG,
    "Launcher2",
    "Launcher 2",
)
AUTOSTART_VBS = (
    f"{APP_SLUG}.vbs",
    f"{LEGACY_APP_SLUG}.vbs",
    "xlounger.vbs",
    "XX1LOUNGER.vbs",
)


def _appdata_basis() -> Path:
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return Path(base)


def _local_programs() -> Path:
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return Path(base) / "Programs"


def _startup() -> Path:
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return Path(base) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"


def _fenster_schliessen() -> int:
    import ctypes

    user32 = ctypes.windll.user32
    n = 0
    for titel in (
        APP_DISPLAY_NAME,
        APP_NAME,
        LEGACY_APP_SLUG,
        "xlounger",
        "xx1lounger",
        "Acrisum Launcher",
    ):
        for _ in range(20):
            h = user32.FindWindowW(None, titel)
            if not h:
                break
            user32.PostMessageW(h, 0x0010, 0, 0)
            n += 1
    return n


def _autostart_vbs_entfernen() -> int:
    startup = _startup()
    n = 0
    for name in AUTOSTART_VBS:
        p = startup / name
        if p.is_file():
            try:
                p.unlink()
                logging.info("Legacy Autostart entfernt: %s", p)
                n += 1
            except OSError:
                pass
    return n


def _appbar_hwnds_aus_legacy_importieren() -> int:
    """AppBar-HWND-Listen aus alten AppData-Ordnern in launcher2 übernehmen."""
    ziel = get_appdata_dir() / "appbar_hwnds.json"
    gesamt: list[int] = []
    try:
        if ziel.is_file():
            raw = json.loads(ziel.read_text(encoding="utf-8"))
            if isinstance(raw, list):
                gesamt.extend(int(x) for x in raw)
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        pass
    for name in LEGACY_APPDATA_NAMEN:
        alt = _appdata_basis() / name / "appbar_hwnds.json"
        if not alt.is_file():
            continue
        try:
            raw = json.loads(alt.read_text(encoding="utf-8"))
            if isinstance(raw, list):
                gesamt.extend(int(x) for x in raw)
        except (OSError, json.JSONDecodeError, TypeError, ValueError):
            continue
    if not gesamt:
        return 0
    uniq: list[int] = []
    for h in gesamt:
        if h not in uniq:
            uniq.append(h)
    uniq = uniq[-12:]
    get_appdata_dir().mkdir(parents=True, exist_ok=True)
    ziel.write_text(json.dumps(uniq), encoding="utf-8")
    return len(uniq)


def _letzter_install_ordner() -> Path | None:
    p = get_appdata_dir() / "last_install_dir.txt"
    if not p.is_file():
        p = _appdata_basis() / APP_SLUG / "last_install_dir.txt"
    if not p.is_file():
        p = _appdata_basis() / LEGACY_APP_SLUG / "last_install_dir.txt"
    if not p.is_file():
        return None
    try:
        line = p.read_text(encoding="utf-8").splitlines()[0].strip()
        if line:
            return Path(line)
    except OSError:
        pass
    return None


def _programmordner_kandidaten() -> list[Path]:
    seen: set[str] = set()
    out: list[Path] = []
    for name in LEGACY_PROGRAMS_ORDNER:
        p = _local_programs() / name
        key = str(p).lower()
        if p.is_dir() and key not in seen:
            seen.add(key)
            out.append(p)
    extra = _letzter_install_ordner()
    if extra and extra.is_dir():
        key = str(extra).lower()
        if key not in seen:
            seen.add(key)
            out.append(extra)
    return out


def _programmordner_bereinigen() -> list[str]:
    """Tote/teilweise Programme unter LocalAppData\\Programs — unins000 oder Hinweis."""
    erledigt: list[str] = []
    for ordner in _programmordner_kandidaten():
        haupt = ordner / "launcher2.py"
        alt_h = ordner / "xx1lounger.py"
        unins = ordner / "unins000.exe"
        if haupt.is_file() or alt_h.is_file():
            continue  # noch gültige Installation — nicht anfassen
        if unins.is_file():
            try:
                subprocess.run(
                    [str(unins), "/VERYSILENT", "/NORESTART"],
                    cwd=str(ordner),
                    timeout=120,
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                )
                erledigt.append(f"deinstall:{ordner}")
            except (OSError, subprocess.TimeoutExpired):
                erledigt.append(f"deinstall_fehler:{ordner}")
        elif any(ordner.iterdir()):
            erledigt.append(f"rest_muell:{ordner}")
    return erledigt


def legacy_bereinigung(*, programmordner: bool = True) -> dict[str, int | list[str]]:
    """Vor Neuinstallation: Fragmente alter Namen entfernen, AppBar nachziehen."""
    from .paths import get_appdata_dir as _gad

    _gad()  # xx1lounger → launcher2 merge anstoßen
    report: dict[str, int | list[str]] = {
        "waechter_beendet": waechter_beenden(),
        "geist_leiste_beendet": geist_leiste_beenden(),
        "fenster_wm_close": _fenster_schliessen(),
        "autostart_vbs": _autostart_vbs_entfernen(),
        "appbar_hwnds_import": _appbar_hwnds_aus_legacy_importieren(),
        "appbar_remove": shell_appbar_bereinigen(),
    }
    if programmordner:
        report["programmordner"] = _programmordner_bereinigen()
    logging.info("Legacy-Bereinigung: %s", report)
    return report
