#!/usr/bin/env python3
"""Launcher 2 — Prozess-Hilfen (läuft? starten wenn tot, Wächter).

Log: %%APPDATA%%\\launcher2\\xlounger-waechter.log
"""
from __future__ import annotations

import argparse
import ctypes
import json
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent

sys.path.insert(0, str(ROOT))
from src.app_id import APP_DISPLAY_NAME, APP_NAME, LEGACY_APP_SLUG  # noqa: E402
from src.install_pfad import legacy_mutex_name, mutex_name, pythonw_exe  # noqa: E402

MUTEX_NAME = mutex_name()
SYNCHRONIZE = 0x00100000
WAECHTER_INTERVAL = 30
FAILS_BEFORE_START = 2
START_COOLDOWN_SEC = 45


def _appdata() -> Path:
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    d = Path(base) / APP_NAME
    d.mkdir(parents=True, exist_ok=True)
    return d


def _log(msg: str) -> None:
    line = f"[{datetime.now().strftime('%d.%m.%Y %H:%M:%S')}] {msg}\n"
    try:
        with (_appdata() / "xlounger-waechter.log").open("a", encoding="utf-8") as f:
            f.write(line)
    except OSError:
        pass
    print(line.rstrip(), flush=True)


def lebt() -> bool:
    """True wenn Launcher-2-Mutex existiert (= Instanz läuft, inkl. Legacy-Name)."""
    kernel32 = ctypes.windll.kernel32
    for name in (MUTEX_NAME, legacy_mutex_name()):
        handle = kernel32.OpenMutexW(SYNCHRONIZE, False, name)
        if handle:
            kernel32.CloseHandle(handle)
            return True
    return False


def pythonw() -> str:
    return pythonw_exe()


def start_if_down() -> int:
    if lebt():
        _log("start-if-down: xlounger läuft bereits")
        return 0
    exe = pythonw()
    script = str(ROOT / "launcher2.py")
    _log(f"start-if-down: starte {exe} {script}")
    subprocess.Popen(
        [exe, script],
        cwd=str(ROOT),
        creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
    )
    return 0


def stop() -> int:
    """Sauber beenden per WM_CLOSE — _quit meldet die AppBar ab.

    Kein harter Kill: der hinterlaesst die AppBar-Reservierung als
    Geist im Explorer (25.09.2026 — Arbeitsbereich oben wuchs 134→212 px).
    """
    if not lebt():
        _log("stop: xlounger läuft nicht")
        return 0
    user32 = ctypes.windll.user32
    hwnd = 0
    # Fenstertitel ist APP_DISPLAY_NAME („Launcher 2“, bar.py) — 28.10.2026:
    # stop() suchte APP_NAME („launcher2“) und fand das Fenster nie, Update/
    # Deinstall liess die Leiste als Geist mit Mutex laufen (Kunde: „öffnet nicht“).
    # Mutex kommt beim Start SEKUNDEN vor dem Fenster (Kalteinstart ~7–10 s) —
    # deshalb bis zu 15 s auf das Fenster warten, sonst schliesst stop() eine
    # gerade startende Leiste nicht (Deinstall waehrend des Starts).
    for _ in range(60):
        for titel in (APP_DISPLAY_NAME, APP_NAME, LEGACY_APP_SLUG):
            hwnd = user32.FindWindowW(None, titel)
            if hwnd:
                break
        if hwnd:
            break
        time.sleep(0.25)
    if not hwnd:
        _log("stop: Mutex da, aber Fenster nicht gefunden — bitte prüfen")
        return 1
    user32.PostMessageW(hwnd, 0x0010, 0, 0)  # WM_CLOSE
    # 25.09.2026: 5 s waren zu knapp, wenn der Nutzer die Leiste gerade
    # bedient (Menü offen) — WM_CLOSE wird dann verzögert angenommen.
    for _ in range(120):
        if not lebt():
            _log("stop: sauber beendet")
            return 0
        time.sleep(0.1)
    _log("stop: nach 12 s noch da — bitte prüfen (kein harter Kill)")
    return 1


def _waechter_lock_nehmen() -> bool:
    lock = _appdata() / "xlounger_waechter.lock"
    if lock.is_file():
        try:
            old = json.loads(lock.read_text(encoding="utf-8"))
            pid = int(old.get("pid") or 0)
            if pid > 0:
                kernel32 = ctypes.windll.kernel32
                h = kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
                if h:
                    kernel32.CloseHandle(h)
                    return False
        except (OSError, ValueError, TypeError):
            pass
    lock.write_text(
        json.dumps({"pid": os.getpid(), "seit": datetime.now().isoformat(timespec="seconds")}),
        encoding="utf-8",
    )
    return True


def neustart_erlaubt() -> bool:
    """KVA 241 — False wenn sauber beendet (Flag); Start loescht das Flag."""
    return not (_appdata() / "sauber-beendet.flag").is_file()


def boot_check(warte_sek: float = 10.0) -> int:
    """KVA 240 — Nachstart, wenn der Mutex nach 10 s noch fehlt.

    Fuer den Autostart-Eintrag: erst dem normalen Startweg Zeit geben,
    dann pruefen. Ein Boot ist eine neue Session — ein altes
    sauber-beendet.flag gilt hier nicht mehr und wird entfernt.
    """
    flag = _appdata() / "sauber-beendet.flag"
    try:
        flag.unlink(missing_ok=True)
    except OSError:
        pass
    time.sleep(warte_sek)
    if lebt():
        _log("boot-check: Mutex da — nichts zu tun")
        return 0
    _log(f"boot-check: Mutex fehlt nach {warte_sek:.0f} s — starte nach")
    return start_if_down()


def waechter() -> int:
    if not _waechter_lock_nehmen():
        _log("waechter: zweite Kopie — Ende")
        return 0
    _log("waechter: gestartet")
    fails = 0
    last_start = 0.0
    flag_gemeldet = False
    while True:
        if lebt():
            fails = 0
            flag_gemeldet = False
        else:
            fails += 1
            if fails >= FAILS_BEFORE_START:
                now = time.monotonic()
                if now - last_start >= START_COOLDOWN_SEC:
                    if not neustart_erlaubt():
                        if not flag_gemeldet:
                            _log("waechter: sauber beendet — kein Neustart")
                            flag_gemeldet = True
                    else:
                        _log("waechter: xlounger tot — Neustart")
                        start_if_down()
                    last_start = now
                    fails = 0
        time.sleep(WAECHTER_INTERVAL)


def main() -> int:
    parser = argparse.ArgumentParser(description="xlounger Prozess-Hilfen")
    parser.add_argument(
        "aktion",
        choices=("status", "start-if-down", "waechter", "stop", "boot-check"),
        help="status | start-if-down | waechter | stop | boot-check",
    )
    args = parser.parse_args()
    if args.aktion == "status":
        print("ok" if lebt() else "tot")
        return 0 if lebt() else 1
    if args.aktion == "start-if-down":
        return start_if_down()
    if args.aktion == "stop":
        return stop()
    if args.aktion == "boot-check":
        return boot_check()
    return waechter()


if __name__ == "__main__":
    raise SystemExit(main())
